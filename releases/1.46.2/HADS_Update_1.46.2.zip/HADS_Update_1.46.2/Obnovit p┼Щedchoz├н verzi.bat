@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PYCMD="
for %%P in (py python python3) do (
  if not defined PYCMD (
    %%P --version >nul 2>&1 && set "PYCMD=%%P"
  )
)
if not defined PYCMD (
  echo [CHYBA] Python 3.8+ nebyl nalezen.
  pause
  exit /b 1
)
if "%~1"=="" (
  REM Bez argumentu Python otevře standardní dialog a ukáže poslední zálohu.
  "%PYCMD%" "%~dp0hads_updater.py" --rollback
) else (
  "%PYCMD%" "%~dp0hads_updater.py" --rollback %*
)
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Obnovení nebylo provedeno. Podrobnosti jsou ve výpisu výše.
pause
exit /b %RC%
