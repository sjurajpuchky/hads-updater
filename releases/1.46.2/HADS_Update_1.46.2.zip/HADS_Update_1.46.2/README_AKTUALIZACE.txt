HADS 1.46.0 – detailní FFT rozbor lze vynutit
============================================

Karta Protokol má nové zaškrtávátko „Vždy plné FFT podklady“. Popis je
v části 0.

Balíček je kumulativní. Aktualizujete-li z verze starší než 1.45.0, dostanete
zároveň vše z 1.45.0 (výtky k rozsahu měření podle role spektra), z 1.44.0
(strukturu závěru řídí editovatelná šablona), z 1.43.0 (hodnocení ložisek
pouze ze směru H a bez odhadovaného pásma A/B), z 1.42.0 (opory hodnocení:
baseline, sesterský stroj a rychlost změny trendu), z 1.41.0 (FFT podklady
pro AI, metodologie diagnostiky, role spekter, etapy poškození ložiska,
časová vlna a kinematika na kartě stroje) i z 1.40.0 (personalizace loga
a údajů firmy). Vše je níže shrnuto.


ČÁST 0 – vynutitelné plné FFT podklady (1.46.0)
===============================================

Co bylo špatně
--------------
Rozsah spektrálních podkladů pro AI se řídil nejhorším pásmem stroje:

  pásmo A     → jen celkové hodnoty, žádné spektrální nálezy
  pásmo B     → spárované nálezy a tři nejvyšší vrcholy
  pásmo C, D  → vrcholy, harmonické i poruchové frekvence ložisek

Smyslem byla úspora tokenů: u stroje, na kterém není co vyšetřovat, nemá
cenu posílat desítky vrcholů. Jenže u stroje v pásmu A se spektrální nálezy
vůbec NEPOČÍTALY, takže do zadání pro AI nedorazily a v závěru se objevilo
„spektrální nálezy nebyly vyžádány“.

Napsat si o ně do Doplňujících pokynů nešlo a nejde. Rozsah podkladů je
rozhodnutí o SBĚRU DAT, které padne dřív, než se prompt vůbec sestaví —
žádný text v promptu proto nemůže spektra doplnit. Nepřebíjelo to tedy
pokyny, ta data v zadání prostě nebyla.

Jak to funguje nyní
-------------------
Na kartě Protokol, vedle „Zobrazit minulou hodnotu“, je zaškrtávátko:

  [ ] Vždy plné FFT podklady

Nezaškrtnuté = dosavadní úspora podle pásma. Zaškrtnuté = plné podklady
(vrcholy, řády otáčkové frekvence, harmonické i poruchové frekvence
přiřazeného ložiska) pro všechny stroje bez ohledu na pásmo. Nastavení se
ukládá s návrhem protokolu.

Na zdravém ventilátoru v pásmu A to znamená rozdíl mezi zadáním bez jediného
spektrálního nálezu a zadáním s desítkami vrcholů; podklady povyrostou
zhruba o čtvrtinu. Doplňující pokyny pak už mají o čem mluvit — například
„proveď detailní FFT analýzu, i když jsou všechny hodnoty v pásmu A“.


ČÁST 0B – výtky k rozsahu měření podle role spektra (1.45.0)
============================================================

Co bylo špatně
--------------
HADS u každého spektra kontroluje, zda zvolené F_max a rozlišení na
zamýšlenou diagnózu stačí (metodologie B.2). Kontrola ale běžela pro všechna
spektra stejně, takže mimo jiné hlásila:

  „F_max 1600 Hz nepokrývá pásmo vlastních frekvencí ložisek (do 2000 Hz);
   druhá etapa poškození nemusí být vidět."

a to i u SPEKTRA RYCHLOSTI a u OBÁLKY ZRYCHLENÍ. U obou je to nesmysl:

- obálka vzniká demodulací kolem ložiskové rezonance, takže vysoké frekvence
  z principu neobsahuje — poruchové frekvence v ní leží v desítkách až
  stovkách Hz. Ložisko 22232CC má nejvyšší poruchovou frekvenci BPFI
  10,822× otáčky; při 23 Hz je to 249 Hz a tři harmonické se vejdou do
  750 Hz. Rozsah 1600 Hz je tedy více než dostatečný;
- spektrum rychlosti slouží k nízkofrekvenční dynamice v řádech otáčkové
  frekvence a ložiska se z něj neposuzují vůbec.

Následkem toho AI do závěru psala, že rozsah nemusí pokrýt pásmo vlastních
frekvencí ložiska, a do doporučení dávala rozšíření F_max nad 2000 Hz — u
zcela vyhovujícího měření.

Jak to funguje nyní
-------------------
Každá výtka platí jen pro spektrum, které se k dané diagnóze používá:

  pásmo vlastních frekvencí ložisek (do 2000 Hz) → jen spektrum ZRYCHLENÍ
  pokrytí alespoň 20× otáčkové frekvence         → jen spektrum RYCHLOSTI
  tři harmonické poruchových frekvencí ložiska   → ZRYCHLENÍ a OBÁLKA
  3,25× frekvence záběru zubů                    → ZRYCHLENÍ a OBÁLKA
  rozlišení postranních pásem s odstupem 1× ot   → všechna spektra

U spektra s nerozpoznaným názvem se o pásmu vlastních frekvencí mlčí —
nelze poznat, zda je demodulované, a falešná výtka k rozsahu znehodnotí
jinak platný nález.

Pásmo A–D v podkladech pro AI
-----------------------------
Podklady pro AI počítaly pásmo jinak než tabulka protokolu. Verze 1.43.0
zrušila dopočítávání hranice A/B u zrychlení a obálky v tabulce, ale
v podkladech pro AI odhad zůstal — tabulka tedy ukazovala A, zatímco závěr
od AI mluvil o pásmu B a odvozoval z něj etapu poškození ložiska.

Nově platí na obou místech totéž pravidlo: hranice A/B se dopočítává jako
polovina meze výstrahy POUZE u limitu z normy, protože ten odhad zavádí
norma. U mezí z databáze přístroje i u ručně zadaných prahů jsou meze jen
dvě, takže pásmo B nevznikne.


ČÁST 0B – strukturu závěru řídí šablona, ne kód (1.44.0)
========================================================

Co bylo špatně
--------------
Nastavení → AI prompty nabízí pro každou verzi protokolu editovatelnou
šablonu. Text se do zadání pro AI opravdu posílal, jenže na úplný konec
zadání kód ještě připojil vlastní odstavec, který se řídil pouze číslem
verze protokolu:

  verze 1 → „…se stručným závěrem a doporučením."
  verze 2 → „…'zaver' obsahuje PŘESNĚ 4 číslované body v pořadí 1) rychlost
             dle normy…, 4) FFT zrychlení + obálka."
  verze 3 → „…PŘESNĚ 3 číslované body…"

Model četl tento odstavec jako poslední, takže poslechl jeho. Následek:
upravená šablona neměla na výstup vliv a dvě zcela shodné šablony daly dva
různé výsledky. Ještě jeden pevný předpis struktury („1) ZÁVĚR, 2) HODNOCENÍ
RYCHLOSTI VIBRACÍ dle normy, 3) MOŽNÉ ZÁVADY, 4) DOPORUČENÍ“) se do zadání
dostával spolu s podklady stroje.

Jak to funguje nyní
-------------------
Oba pevné předpisy struktury jsou pryč. Zadání pro AI se skládá takto:

1. SYSTÉMOVÁ ČÁST = přesně to, co máte v Nastavení → AI prompty: společná
   metodologie ({methodology}) + šablona zvolené verze protokolu. Zde napište,
   kolik bodů má závěr mít, v jakém pořadí a co má být předmětem hodnocení.
2. PODKLADY STROJE = naměřené hodnoty, pásma, meze, spektra. Bez pokynů ke
   struktuře.
3. POKYNY DIAGNOSTIKA k tomuto protokolu (pole „Doplňující pokyny pro AI“
   na kartě Protokol) — jdou úplně poslední.

Neměnný zůstává jediný prvek: JSON obal odpovědi, který se do šablony vkládá
přes povinný {report_contract}. Zajišťuje, že výsledek půjde načíst do
editoru protokolu (klíče 'problem', 'zaver', 'doporuceni'). Nově je u všech
tří verzí stejný a soběstačný, takže šablonu můžete přepsat celou, aniž se
rozbije načítání — dřív byl u verzí 2 a 3 jen ocáskem výchozí šablony.

Doplňující pokyny pro AI
------------------------
Mají PŘEDNOST před šablonou. Pro jeden konkrétní protokol tedy lze změnit
i rozsah a strukturu hodnocení, například:

  „Jedná se o třídič. Nehodnoť stav rychlosti vibrací dle normy, zaměř se
   pouze na stav valivých ložisek.“

Dřív takový pokyn neuspěl — hned za ním stálo „1) rychlost dle normy“.
Naměřené hodnoty, pásma ani meze pokyny nemění; ty pocházejí vždy z dat.

Beze změny nastavení se nic nemění
----------------------------------
Výchozí šablony popisují přesně totéž co dosud: detailní protokol čtyři body
v původním pořadí, protokol z vyvažování tři. Kdo do promptů nesáhne, dostane
stejné výstupy jako z 1.43.0.


ČÁST 0B – opravy hodnocení ložisek a otáček (1.43.0)
====================================================

1) Zrychlení a obálka pouze z horizontálního směru
-------------------------------------------------
Rychlost vibrací popisuje chování celého stroje, a proto se u ní i nadále
bere nejhorší z vybraných směrů H/V/A. Zrychlení a obálka zrychlení ale
popisují stav JEDNOHO valivého ložiska. Dosavadní maximum z H/V/A proto
mísilo tři různá měřicí místa do jedné buňky a mohlo stav ložiska zhoršit
složkou, která s ním nesouvisí.

Nově se obě tyto veličiny berou VÝHRADNĚ z horizontálního směru, a to
shodně:
- ve sloupcích souhrnné tabulky protokolu (nadpisy jsou nyní „zrychlení H"
  a „obálka H"),
- ve stavu valivého ložiska,
- v podkladech pro AI, tedy i u FFT spekter zrychlení a obálky.

Nemá-li ložisko čitelný horizontální bod (chybí, nebo je název bodu
nejednoznačný), zůstanou obě buňky prázdné. To je záměr: raději prázdno než
hodnota z cizího směru.

2) Konec odhadovaného pásma A/B u zrychlení a obálky
---------------------------------------------------
Norma pro rychlost vibrací zná tři meze (A/B, B/C, C/D). Není-li hranice
A/B uvedena, HADS ji odhaduje jako polovinu meze výstrahy — to zůstává.

Zrychlení a obálka ale žádnou normu nemají; v přístroji jsou u nich jen DVĚ
skutečné meze, výstraha a alarm. Tentýž odhad se u nich přesto uplatňoval,
takže například 1,07 g při výstraze 2,0 g (tedy zhruba polovina limitu)
spadlo do pásma B a stav ložiska hlásil B, přestože na kartě stroje nebylo
nic překročeno.

Nově se u zrychlení a obálky pásmo A/B neodhaduje. Není-li hranice A/B
skutečně zadaná, platí prostě:
- hodnota pod výstrahou   = A,
- výstraha až alarm       = C,
- alarm a výše            = D.
Je-li hranice A/B u veličiny zadaná, používá se beze změny.

3) Detekované, ale neuložené otáčky
-----------------------------------
Otáčková frekvence se do podkladů pro AI přebírá z karty stroje. Detekce
otáček se zapisuje do historie okamžitě, ale platnými otáčkami se stane až
uložením na kartě stroje — teprve pak se z ní počítají řády 1x-nX.

Dřív se v takové situaci v závěru objevilo pouze „otáčky nejsou známy",
i když karta stroje detekci zobrazovala. Nově podklady uvedou nalezenou
hodnotu i datum detekce, výslovně řeknou, že uložena NENÍ, a doporučí ji na
kartě stroje uložit a analýzu zopakovat. Stejné upozornění se zobrazí i na
kartě stroje u panelu otáček.


ČÁST 1 – opory hodnocení, AI a FFT spektra
==========================================

Co se změnilo
-------------
Do verze 1.39.1 dostávala AI z každého spektra JEDINÉ číslo (celkovou
hodnotu). Přesto po ní šablona detailního protokolu chtěla "zhodnocení FFT
spektra a možnou příčinu" — komentovala tedy data, která nikdy neviděla.

Nově aplikace ze spektra sama spočítá a do podkladů předá:
- nejvyšší vrcholy: frekvence, amplituda a řád otáčkové frekvence (x ot),
- amplitudu přímo na otáčkové frekvenci a jejích harmonických (1x-6x),
- amplitudu přímo na poruchových frekvencích přiřazeného ložiska
  (FTF, BSF, BPFO, BPFI) včetně jejich násobků.

Veškerý výpočet probíhá v aplikaci a je pokrytý testy. Model už nic
nepřepočítává — pouze interpretuje. Stejný princip jako u pásem A-D.

Které spektrum k čemu slouží
----------------------------
Každá veličina zvýrazňuje jiné frekvenční pásmo, a proto se z ní vyvozuje
jiný druh závady. HADS toto rozdělení nově vynucuje už při výpočtu:

- spektrum RYCHLOSTI [mm/s] slouží k nízkofrekvenční dynamice v řádech
  otáčkové frekvence: nevyváženost, nesouosost, mechanické uvolnění, ohnutá
  hřídel, nakřivo nasazené ložisko, řemenový převod, rezonance. Jen zde se
  počítají řády 1x-nX, poměr 2x/1x a subharmonické;
- spektrum ZRYCHLENÍ [g] a OBÁLKY zrychlení [gE] slouží k vysokofrekvenčnímu
  poškození: valivá ložiska, ozubení, přidírání, kavitace. Jen zde se
  vyhodnocují poruchové frekvence ložisek a záběr zubů.

Poruchové frekvence ložiska se tedy do spektra rychlosti vůbec nepočítají,
i kdyby tam odpovídající frekvence náhodou vyšla. Role každého spektra je
v podkladech uvedena v hranatých závorkách a metodologie ji vynucuje i pro
model. Odhad počtu lopatek se hlásí u rychlosti, odhad počtu zubů u
zrychlení a obálky.

Etapy poškození ložiska a časová vlna
-------------------------------------
- ETAPY 1-4 podle metodologie D.9.3 se odhadují pro každé ložisko z několika
  nezávislých znaků (poruchové frekvence a jejich násobky, modulace, pásma
  zrychlení a obálky, práh šumu, trend). Přiřazují se konzervativně a vždy
  se vypisují i důvody. Osamocená poruchová frekvence bez násobku a bez
  modulace na 3. etapu nestačí.
- ČASOVÁ VLNA (ACC TIME) se nově vyhodnocuje: činitel výkmitu, míra ořezání
  a periodicita rázů. Ořezaná (zploštělá) vlna odliší přidírání od
  spektrálně velmi podobného mechanického uvolnění. Práh ořezání je
  kalibrován podle harmonického průběhu, takže na čistou sinusovku nesepne.
- NAVRŽENÁ PRIORITA podle tabulky E.6 a STROP MÍRY JISTOTY podle pravidel
  G.1 se počítají v aplikaci, ne v modelu. Protože databáze přístroje
  neobsahuje fázi, je strop jistoty u dvojice nevyváženost/nesouosost trvale
  nejvýše STŘEDNÍ - a HADS to přizná místo aby to obcházel.
- Růst trendu se posuzuje z průměrů dvou polovin řady, ne z krajních hodnot;
  jednorázový výkyv s následným poklesem se tak nezamění za rostoucí trend.

Diagnostické vzorce podle metodologie
-------------------------------------
Nad rámec samotných vrcholů aplikace nově dopočítá strukturní znaky, ze
kterých metodologie odvozuje závadu:

- POSTRANNÍ PÁSMA kolem poruchových frekvencí a silných složek. Odstup pásem
  identifikuje modulující prvek: 1x ot = vnitřní kroužek, FTF = valivý
  element, žádná modulace = vnější kroužek. Vyžadují se alespoň dvě
  symetrické dvojice, aby náhodná složka neprošla jako modulace.
- VZOREC SPEKTRA: délka harmonické řady nad 20 % z 1x, subharmonické
  0,5x / 1,5x / 2,5x, zlomkové řády 1/3 až 1/5, poměr 2x/1x a práh šumu.
  Tím se rozliší mechanické uvolnění od nesouososti a od přidírání rotoru.
- SMĚROVOST H/V/A na každém ložisku z rychlosti vibrací. Fázi databáze
  přístroje neobsahuje, takže směrovost je jediný dostupný způsob, jak
  odlišit nevyváženost od nesouososti — závěr podle ní má proto strop
  na STŘEDNÍ jistotě.
- KONTROLA ROZSAHU A ROZLIŠENÍ podle části B.2 metodologie: upozorní,
  když F_max nestačí na harmonické poruchových frekvencí nebo když je
  šířka čáry na rozlišení postranních pásem příliš hrubá.
- OVĚŘENÍ OTÁČEK: nemá-li zadaná 1x ve spektrech stroje harmonické,
  aplikace upozorní, že řády mohou být neplatné.

Opory hodnocení: baseline a sesterský stroj
-------------------------------------------
Metodologie řadí způsoby hodnocení podle spolehlivosti: trend téhož bodu,
baseline ze známého dobrého stavu, shodný (sesterský) stroj za srovnatelných
podmínek, a teprve nakonec norma - ta je výslovně jen hrubé vodítko pro stroj
BEZ historie. HADS nyní počítá všechny tři lepší opory a v podkladech uvádí,
které jsou k dispozici a která je nejsilnější.

Karta stroje má novou sekci "Opory hodnocení":
- BASELINE - datum známého dobrého stavu (např. po generální opravě).
  Ukládá se jen DATUM; hodnoty se čtou přímo z .ndb, takže se reference
  nikdy nerozejde se skutečným měřením a nezabírá místo. U každé veličiny
  se pak vypíše hodnota z toho data a odchylka od ní.
- SESTERSKÝ STROJ - vybírá se ze seznamu strojů v databázi. Který stroj je
  sesterský NELZE odvodit z dat, protože jen diagnostik ví, že jde o shodné
  provedení ve shodném provozu. Porovnává se podle dvojice ložisko +
  veličina, se směrem u každého řádku, a do podkladů jde jen to, co se od
  sestry nápadně liší.

RYCHLOST ZMĚNY TRENDU se počítá metodou nejmenších čtverců z celého trendu
a uvádí se v procentech za 30 dní. Neextrapoluje se z krátkého rozpětí:
odečty pořízené během jednoho dne by po přepočtu daly hodnoty v tisících
procent, proto se tempo počítá až od rozpětí sedmi dní.

Chybí-li úplně všechno - trend, baseline, sesterský stroj i norma - podklady
to výslovně uvedou, aby model nevydával absolutní číslo za posouzení stavu.

Kinematika na kartě stroje
--------------------------
Karta stroje má v Základních informacích novou sekci "Kinematika stroje".
Vše je VOLITELNÉ; vyplněné údaje mění odhad ze spektra na přesný výpočet:

- počet lopatek (ventilátor, čerpadlo) -> BPF = počet x 1x a její násobky,
- počet pólů motoru a síťová frekvence -> 2F_L a F_P (průchod pólů),
- počty zubů hnacího a hnaného kola   -> GMF a její násobky,
- délka řemene a průměry řemenic      -> řemenová frekvence,
- typ pohonu (spojka / řemen / ozubení / přímé).

Dvě kontroly zadání, které chrání před chybou v údajích:
- neodpovídá-li zadaný počet lopatek dominantnímu řádu ve spektru, HADS to
  vypíše jako upozornění (buď je chybný údaj, nebo složka pochází odjinud);
- dává-li zadaný počet pólů při naměřených otáčkách skluz mimo obvyklé
  rozmezí, F_P se vůbec nespočítá a místo ní jde upozornění - jinak by se
  interpretovala smyšlená frekvence.

Bez ozubeného převodu na kartě stroje HADS už netvrdí "odpovídalo by počtu
zubů N": u ventilátoru je to smyšlenka. Vypíše jen samotný dominantní řád,
který je fakt, a mechanismus nechá neurčený.

Chybějící kinematika
--------------------
U převodovek často není známo přesné schéma a u řemenů rozměry. Protože
ale platí BPF = počet lopatek x 1x a GMF = počet zubů x 1x, je dominantní
celočíselný řád sám o sobě ODHADEM toho počtu. HADS jej proto vypíše jako
kandidáta k ověření na stroji, nikdy ne jako zjištěný údaj. Řemenový převod
se pozná podle řady tří a více harmonických POD otáčkovou frekvencí.

Asynchronní motory
------------------
Z otáček se dopočítá počet pólů, synchronní otáčky, skluz a frekvence
průchodu pólů F_P; z ní pak postranní pásma kolem 2F_L. Vyjde-li skluz mimo
obvyklé rozmezí, označí se odvození za nevěrohodné — u hnaného stroje za
řemenem otáčky se synchronními souviset nemusí.

Toleranční pásmo shody frekvencí
--------------------------------
Naměřená složka nikdy neleží přesně na vypočtené frekvenci: otáčky kolísají
se zatížením, valivé elementy prokluzují a spektrum má konečné rozlišení.
Amplituda se proto odečítá v tolerančním pásmu kolem cílové frekvence.

V Nastavení -> AI prompty lze zadat DVĚ samostatné tolerance v %:
  - otáčková frekvence a harmonické  (výchozí 1 %),
  - poruchové frekvence ložisek      (výchozí 2 %).

Dvě hodnoty odpovídají fyzice: otáčky známe přesně, takže jejich řády stačí
hledat těsně; BPFO/BPFI/BSF/FTF se kvůli prokluzu valivých elementů reálně
liší od vypočtených hodnot o jednotky procent.

Pásmo je vždy nejméně POLOVINA čáry spektra, tedy "nejbližší dostupná čára" —
u nízkých frekvencí je procento menší než rozlišení měření.

U každé shody se do podkladů vypisuje SKUTEČNÁ ODCHYLKA, například
  BPFO (88.0 Hz, odch. +0.2 %) = 0.41
takže je vidět, jak těsná shoda to byla, a nepřesnost se neschovává.

Bezpečnostní pravidla výpočtu
-----------------------------
- Jedna čára spektra nikdy nenese dva popisky. Kolidují-li dvě blízké
  poruchové frekvence, vyhrává nejtěsnější shoda. Do protokolu se tak
  nedostane závada, kterou měření nedokládá.
- Nejsou-li zadány otáčky, řády ani poruchové frekvence se NEURČUJÍ a
  prompt to výslovně uvádí.
- Amplitudy pod mezí čitelnosti se nevypisují vůbec.

DŮLEŽITÉ: vyplňte na kartě stroje OTÁČKY. Bez nich zůstane spektrální
analýza omezená jen na frekvence vrcholů bez jejich významu.

Kolik podkladů se posílá
------------------------
Řídí se nejhorším pásmem stroje, aby se neplýtvalo tam, kde není co řešit:
  pásmo A    -> jen celkové hodnoty,
  pásmo B    -> spárované nálezy + tři nejvyšší vrcholy,
  pásmo C/D  -> plné podklady včetně harmonických a poruchových frekvencí.
Na jeden stroj platí strop počtu řádků. AI poradce u JEDNOHO měřicího bodu
dostává vždy plné podklady.

Porovnání proti správným mezím
------------------------------
Podklady nově uvádějí mez A/B, B/C i C/D, ZDROJ platné meze (norma / ruční
přepis / databáze přístroje) a — je-li platná mez z normy — také nepoužité
meze z .ndb. Norma má vždy přednost.

Jedna metodologie
-----------------
Odborný postup hodnocení je nyní v jedné společné, editovatelné šabloně:
Nastavení -> AI prompty -> "Metodologie diagnostiky (společná)".
Používá ji protokol (všechny tři verze) i poradce u měřicího bodu.

Verze protokolu ji vkládají přes volitelný placeholder {methodology}.
Metodologie se uplatní VŽDY: pokud placeholder v šabloně není (typicky
u šablony upravené ve starší verzi HADS), vloží se na začátek. Vaše
dosavadní úpravy promptů proto zůstávají platné a nepřijdete o ně.

Strukturu odpovědi a neměnný JSON kontrakt nadále řídí výhradně aplikace —
metodologie do nich nezasahuje.


ČÁST 2 – personalizace loga a firmy (beze změny od 1.40.0)
==========================================================

Co je nového
------------
- Nastavení → nová podzáložka "Firma a logo".
- Nahrání vlastního LOGA, které se vykreslí vlevo nahoře na titulní straně
  protokolu. Přijímá se JPG i PNG; PNG se automaticky převede na JPEG
  s bílým pozadím, protože generátor PDF jiný formát nevkládá.
  Náhled ukazuje logo přesně tak, jak se vytiskne.
- Vlastní údaje do PATIČKY každé strany protokolu: název firmy, adresa a web.
- Vlastní ZNAČKA do hlavičky (použije se jen tehdy, není-li žádné logo).
- Vlastní výchozí jméno do pole "Schválil" u nového návrhu protokolu.
- Tlačítko "Obnovit výchozí" vrátí texty dodané s programem; logo ponechá.
- Kontrola uložených dat (Nastavení → Databáze) nově vypisuje i stav
  personalizace: výchozí / vlastní.

Kde je personalizace uložena
----------------------------
    data/branding/settings.json   – texty vydavatele
    data/branding/logo.jpg        – vlastní logo

DŮLEŽITÉ: Logo NIKDY neukládejte ručně do backend/assets. Tuto složku
aktualizace celou nahrazuje, takže by se logo při první aktualizaci ztratilo.
Používejte výhradně Nastavení → Firma a logo.

Nastavení je GLOBÁLNÍ pro celou instalaci HADS, ne pro jednotlivou databázi:
popisuje firmu, která protokol VYDÁVÁ. Údaje o podniku v záložce Databáze
zůstávají beze změny – tam se zadává ZÁKAZNÍK, jehož stroje se měří.

Prázdné pole vždy znamená "použij výchozí hodnotu", takže protokol nikdy
nezůstane bez názvu firmy.

Chování u starších protokolů
----------------------------
PDF i DOCX používají personalizaci platnou v okamžiku vykreslení. Protokol
znovu vygenerovaný z historie proto ponese aktuální logo i aktuální patičku;
naměřená data, závěry ani klasifikace se nijak nemění.

Bezpečnost dat
--------------
Aktualizace nemění data/ ani runtime/. Zachovává databáze, techniky, karty,
AI credentials, prompty, AI vzory, historii, rozpracované protokoly, výběry
H/V/A a nově i personalizaci. Aktualizátor personalizaci navíc zálohuje mezi
malými perzistentními soubory a ochrana dat ji kontroluje v inventáři.

Nahrané logo se přijme jen jako skutečný, vykreslitelný JPEG do 2 MB v RGB
nebo odstínech šedi. Poškozený nebo nepodporovaný soubor se odmítne českou
hláškou a předchozí logo zůstane beze změny.

Update i sdílený balíček neobsahují data, runtime, credentials ani soukromý
podpisový klíč.

Oprava aktualizátoru
--------------------
Opakované spuštění aktualizace ze stejné rozbalené složky dříve selhalo
hláškou "Obsah payloadu přesně neodpovídá manifestu". Aktualizátor si totiž
při běhu zapsal do payloadu bytekód (__pycache__) a ten pak neprošel kontrolou
integrity. Typicky to potkalo toho, komu první pokus skončil proto, že běžel
HADS: zavřel jej a spustil aktualizaci znovu. Nyní se bytekód nezapisuje
a případný __pycache__ se ignoruje.


Postup aktualizace
------------------
1. Ukončete HADS přes Nastavení -> Aktualizace -> Ukončit HADS.
2. Rozbalte HADS_Update_1.46.0.zip mimo instalaci.
3. Spusťte Aktualizovat HADS.bat a vyberte kořen instalace HADS.
4. Po ověření podpisu a manifestu potvrďte aktualizaci.
5. Pro návrat použijte Obnovit předchozí verzi.bat z rozbaleného update.

Poznámka k HADS.exe
-------------------
Nativní spouštěč se v tomto vydání nemění, proto si ve vlastnostech souboru
ponechává své vlastní číslo verze. Verze aplikace v hlavičce HADS je 1.46.0.

Plný HADS_aplikace_v1.46.0.zip je pouze pro novou instalaci. Obsahuje čisté
osivo pod clean_seed/HADS a nesmí se kopírovat přes existující HADS/data.
