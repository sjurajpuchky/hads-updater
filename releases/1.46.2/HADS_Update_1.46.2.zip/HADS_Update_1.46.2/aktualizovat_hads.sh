#!/usr/bin/env sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PYTHON=""
for candidate in python3 python py; do
  if command -v "$candidate" >/dev/null 2>&1; then PYTHON="$candidate"; break; fi
done
if [ -z "$PYTHON" ]; then
  echo "[CHYBA] Python 3.8+ nebyl nalezen." >&2
  exit 1
fi
# Bez argumentu updater nabídne český interaktivní textový výběr a potvrzení.
exec "$PYTHON" "$HERE/hads_updater.py" "$@"
