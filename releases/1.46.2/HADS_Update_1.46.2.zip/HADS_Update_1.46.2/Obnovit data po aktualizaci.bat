@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PYCMD="
for %%P in (py python python3) do (
  if not defined PYCMD (
    %%P --version >nul 2>&1 && set "PYCMD=%%P"
  )
)
if not defined PYCMD (
  echo [CHYBA] Python 3.8+ nebyl nalezen.
  pause
  exit /b 1
)
echo Zobrazí se náhled a obnoví se jen chybějící ověřené soubory.
echo Existující odlišné soubory se nikdy nepřepisují bez parametru --confirm-overwrite.
"%PYCMD%" "%~dp0hads_updater.py" --recover-data --apply-missing %*
pause
