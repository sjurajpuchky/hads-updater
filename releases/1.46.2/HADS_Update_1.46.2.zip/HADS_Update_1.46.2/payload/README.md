# HADS – Heistech AI Diagnostic Software

Lokální webová aplikace pro prohlížení a správu diagnostických dat z přenosného
měřicího přístroje. Aplikace běží **plně offline** na vašem počítači
a otevírá databázové soubory `.ndb` exportované z přístroje.

> **Verze 1.46.0 – detailní FFT rozbor lze vynutit.** Karta Protokol má
> nové zaškrtávátko **„Vždy plné FFT podklady"**. U stroje, který je celý
> v pásmu A, se totiž spektrální nálezy (vrcholy, řády, poruchové frekvence)
> vůbec nepočítaly — šetřilo to tokeny, ale znamenalo to, že AI spektra
> nikdy neviděla a v závěru psala „spektrální nálezy nebyly vyžádány".
>
> Vyžádat si je textem v **Doplňujících pokynech nešlo a nejde**: rozsah
> podkladů je rozhodnutí o sběru dat, které padne dřív, než se prompt vůbec
> sestaví. Proto je z něj samostatný ovládací prvek. Zaškrtnuté políčko
> pošle plné podklady bez ohledu na pásmo.
>
> **Verze 1.45.0 – konec falešných výtek k rozsahu měření.** Kontrola
> vhodnosti F_max (metodologie B.2) se nově řídí **rolí spektra**. Požadavek
> na pokrytí pásma vlastních frekvencí ložisek (do 2000 Hz) platí jen pro
> **nedemodulované spektrum zrychlení** — obálka je z principu nese už
> přepočtené dolů na poruchové frekvence a spektrum rychlosti ložiska neřeší
> vůbec. Stejně tak se pokrytí 20× otáček žádá jen po spektru rychlosti
> a tři harmonické poruchových frekvencí jen po zrychlení a obálce.
>
> Dosud padala výtka na každé spektrum, takže u ložiska 22232CC (BPFI
> 10,822× ot, při 23 Hz tedy 249 Hz) AI psala o nedostatečném rozsahu
> a doporučovala rozšířit F_max nad 2000 Hz, ačkoli tři harmonické ležely
> na 750 Hz, hluboko uvnitř rozsahu 1600 Hz.
>
> Opraven i rozpor mezi tabulkou a podklady pro AI: **odhad hranice A/B**
> jako poloviny meze výstrahy se nyní na obou místech dělá pouze u mezí
> **z normy**. U mezí z databáze přístroje a u ručně zadaných prahů jsou
> meze jen dvě, takže pásmo B se nedopočítává. Dřív tabulka ukazovala A,
> zatímco závěr od AI mluvil o pásmu B.
>
> **Verze 1.44.0 – strukturu závěru si určuje zákazník.** Počet a pořadí
> bodů závěru, i to, co má být předmětem hodnocení, nově určuje **výhradně
> editovatelná šablona** v Nastavení → AI prompty. Dosud ji přebíjel pevný
> odstavec v kódu, který se přidával na konec zadání podle verze protokolu —
> upravená šablona proto neměla na výstup vliv a dvě stejné šablony dávaly
> různé výsledky.
>
> V kódu zůstává neměnný jen **JSON obal odpovědi** (`{report_contract}`),
> aby šel výsledek spolehlivě načíst do editoru protokolu. Ten je nyní
> u všech verzí stejný a soběstačný, takže šablonu lze přepsat celou.
>
> **Doplňující pokyny pro AI** u konkrétního protokolu mají přednost před
> šablonou — lze jimi pro jedno měření změnit i rozsah hodnocení, například
> „jde o třídič, rychlost dle normy nehodnoť, zaměř se na ložiska". Naměřené
> hodnoty, pásma ani meze nemění.
>
> Výchozí šablony popisují totéž co dosud (4 body u detailního, 3 u protokolu
> z vyvažování), takže bez zásahu do nastavení se výstupy nemění.
>
> **Verze 1.43.0 – hodnocení ložisek pouze z H a bez odhadu pásma A/B.**
> Zrychlení a obálka zrychlení popisují stav **jednoho** ložiska, proto se
> nově — u statických hodnot i u FFT spekter — berou **výhradně
> z horizontálního směru**. Dosavadní maximum z H/V/A míchalo do jedné buňky
> tři různá měřicí místa. Rychlost vibrací popisuje chování celého stroje,
> a proto u ní maximum z vybraných H/V/A zůstává.
>
> Zároveň se u zrychlení a obálky **přestala odhadovat hranice A/B** jako
> polovina meze výstrahy. Tyto veličiny mají v přístroji jen dvě skutečné meze
> (výstraha a alarm), takže odhad vyráběl pásmo **B** i tam, kde hodnota ležela
> hluboko pod limitem. Odhad A/B zůstává jen u rychlosti vibrací, kde jej
> zavádí použitá norma.
>
> Jsou-li otáčky pouze **detekované a neuložené** na kartě stroje, podklady pro
> AI to nyní výslovně uvedou včetně nalezené hodnoty a data detekce a doporučí
> ji na kartě uložit a analýzu zopakovat. Dřív se v závěru objevilo jen
> „otáčky nejsou známy".
>
> **Verze 1.42.0 – opory hodnocení: baseline a sesterský stroj.** Metodologie
> řadí spolehlivost hodnocení takto: **trend** téhož bodu, **baseline** ze
> známého dobrého stavu, **shodný (sesterský) stroj** za srovnatelných
> podmínek, a teprve pak **norma** — ta je jen hrubé vodítko pro stroj bez
> historie. HADS nyní počítá všechny tři lepší opory a uvádí, které jsou
> k dispozici.
>
> Karta stroje má sekci **Opory hodnocení**: *baseline* se ukládá jen jako
> **datum**, hodnoty se čtou z `.ndb`, takže se reference nikdy nerozejde
> s měřením; *sesterský stroj* se **vybírá ze seznamu**, protože z dat ho
> odvodit nelze — jen diagnostik ví, že jde o shodné provedení ve shodném
> provozu. Porovnává se podle dvojice ložisko + veličina včetně směru a do
> podkladů jde jen to, co se nápadně liší.
>
> **Rychlost změny trendu** se počítá metodou nejmenších čtverců z celého
> trendu v % za 30 dní, ale **neextrapoluje se z krátkého rozpětí** — odečty
> z jednoho dne by daly tisíce procent, proto se tempo počítá až od sedmi dní.
> Chybí-li všechny opory, podklady to výslovně uvedou.
>
> **Verze 1.41.0 – kinematika na kartě stroje.** Karta stroje má v Základních
> informacích novou **volitelnou** sekci *Kinematika stroje*: počet lopatek,
> počet pólů a síťová frekvence, počty zubů, rozměry řemenového převodu a typ
> pohonu. Vyplněný údaj mění odhad ze spektra na **přesný výpočet** — z počtu
> lopatek se spočítá BPF, z počtu zubů GMF, z počtu pólů 2F_L a F_P, z rozměrů
> řemenice řemenová frekvence, vždy včetně násobků a odchylky shody.
>
> Dvě kontroly chrání před chybou v zadání: **neodpovídá-li zadaný počet
> lopatek** dominantnímu řádu ve spektru, HADS to vypíše, a **dává-li zadaný
> počet pólů** při naměřených otáčkách skluz mimo obvyklé rozmezí, F_P se
> vůbec nespočítá. Bez zadaného ozubeného převodu už HADS netvrdí „odpovídalo
> by počtu zubů N“ — u ventilátoru je to smyšlenka; vypíše jen samotný
> dominantní řád a mechanismus nechá neurčený.
>
> **Verze 1.41.0 – role spekter, etapy ložiska a časová vlna.** Každá veličina
> zvýrazňuje jiné pásmo, a proto se z ní vyvozuje jiný druh závady. HADS to
> nově vynucuje už při výpočtu: **spektrum rychlosti** slouží k nízkofrekvenční
> dynamice v řádech otáčkové frekvence (nevyváženost, nesouosost, uvolnění,
> ohnutá hřídel, nakřivo nasazené ložisko, řemenový převod), zatímco **spektrum
> zrychlení a obálky** k vysokofrekvenčnímu poškození (valivá ložiska, ozubení,
> přidírání, kavitace). Poruchové frekvence ložiska se proto do spektra
> rychlosti vůbec nepočítají a řády 1×–nX se nepočítají v obálce.
>
> Pro každé ložisko se odhaduje **etapa poškození 1–4** z několika nezávislých
> znaků a vždy s výpisem důvodů; osamocená poruchová frekvence bez násobku
> a bez modulace na 3. etapu nestačí. Nově se vyhodnocuje i **časová vlna**
> (činitel výkmitu, ořezání, periodicita rázů), která odliší přidírání od
> spektrálně podobného uvolnění. **Navrženou prioritu** a **strop míry jistoty**
> počítá aplikace, ne model — a protože databáze přístroje neobsahuje fázi,
> je strop u dvojice nevyváženost/nesouosost trvale nejvýše střední.
>
> **Verze 1.41.0 – diagnostické vzorce a chybějící kinematika.** Nad rámec
> vrcholů aplikace dopočítá i strukturní znaky, ze kterých se závada odvozuje:
> **postranní pásma** s identifikací modulujícího prvku (odstup 1× ot =
> vnitřní kroužek, FTF = valivý element), **vzorec spektra** (harmonická řada
> nad 20 % z 1×, subharmonické 0,5×/1,5×/2,5×, zlomkové řády 1/3–1/5, poměr
> 2×/1×, práh šumu) a **směrovost H/V/A** na každém ložisku. Fáze v databázi
> přístroje není, takže směrovost je jediný způsob, jak odlišit nevyváženost
> od nesouososti — závěr podle ní má proto strop na střední jistotě.
>
> U **převodovek bez známého schématu a u řemenů bez rozměrů** si HADS poradí
> bez nich: protože BPF = počet lopatek × 1× a GMF = počet zubů × 1×, je
> dominantní celočíselný řád sám o sobě **odhadem toho počtu** — vypíše se
> jako kandidát k ověření na stroji, nikdy jako zjištěný údaj. Řemenový převod
> se pozná podle řady tří a více harmonických **pod** otáčkovou frekvencí.
> U **asynchronních motorů** se z otáček dopočítá počet pólů, skluz a
> frekvence průchodu pólů; nevěrohodný skluz se označí. Přibyla i **kontrola
> vhodnosti F_max a rozlišení** a ověření, že zadaná 1× má ve spektrech
> harmonické.
>
> **Verze 1.41.0 – AI vidí FFT spektra a drží se jedné metodologie.** Do
> verze 1.39.1 dostávala AI ze spektra jediné číslo (celkovou hodnotu), přesto
> po ní šablona detailního protokolu chtěla „zhodnocení FFT spektra a možnou
> příčinu“ — komentovala tedy data, která nikdy neviděla. Nově aplikace
> **deterministicky spočítá nálezy** a předá je hotové: **nejvyšší vrcholy**
> s frekvencí, amplitudou a **řádem otáčkové frekvence (× ot)**, amplitudu
> **přímo na otáčkové frekvenci a jejích harmonických** a amplitudu **přímo na
> poruchových frekvencích přiřazeného ložiska** (FTF/BSF/BPFO/BPFI a jejich
> násobcích). Veškerá aritmetika probíhá v `backend/fft_analysis.py` a je
> ověřená testy; **model už nic nepřepočítává, jen interpretuje**. Jedna čára
> spektra nikdy nenese dva popisky — kolize blízkých poruchových frekvencí se
> rozhoduje ve prospěch nejtěsnější shody, takže se do protokolu nedostane
> závada, kterou měření nedokládá. **Bez zadaných otáček** se řády ani
> poruchové frekvence neurčují a prompt to výslovně uvádí.
>
> Naměřená složka nikdy neleží přesně na vypočtené frekvenci, proto se
> amplituda odečítá v **tolerančním pásmu**. V **Nastavení → AI prompty** lze
> zadat **dvě samostatné tolerance v %**: těsnou pro **otáčkovou frekvenci a
> její harmonické** (výchozí 1 %, otáčky známe přesně) a volnější pro
> **poruchové frekvence ložisek** (výchozí 2 %, valivé elementy prokluzují).
> Pásmo je vždy nejméně **polovina čáry spektra**, tedy „nejbližší dostupná
> čára“. U každé shody se do podkladů vypisuje **skutečná odchylka**
> (`BPFO (88,0 Hz, odch. +0,2 %)`), takže je vidět, jak těsná shoda to byla,
> a nepřesnost se neschovává.
>
> Rozsah podkladů se řídí **nejhorším pásmem stroje**: pásmo A → jen celkové
> hodnoty, pásmo B → spárované nálezy a tři nejvyšší vrcholy, pásmo C/D → plné
> podklady včetně harmonických a poruchových frekvencí. Na stroj platí strop
> počtu řádků. **AI poradce u jednoho měřicího bodu** dostává vždy plné
> podklady.
>
> Hodnoty se nově porovnávají **proti správné mezi včetně jejího původu**:
> prompt uvádí mez **A/B, B/C i C/D**, zda pochází **z normy, z ručního
> přepisu, nebo z databáze přístroje**, a je-li platná mez z normy, vypíše
> i **nepoužité meze z `.ndb`**. Norma má vždy přednost.
>
> Odborný postup je nově v **jedné společné metodologii** — samostatné
> editovatelné šabloně v **Nastavení → AI prompty**, kterou verze protokolu
> vkládají přes volitelný placeholder `{methodology}`. Metodologie se uplatní
> vždy; není-li placeholder v šabloně uveden (například u šablony upravené ve
> starší verzi HADS), vloží se na začátek, takže starší přepis nemůže společný
> postup obejít. Strukturu odpovědi i neměnný JSON kontrakt nadále řídí
> výhradně aplikace.
>
> **Verze 1.40.0 – personalizace loga a firmy v protokolech.** Logo a údaje
> vydavatele už nejsou natvrdo v programu. V **Nastavení → Firma a logo** lze
> nahrát **vlastní logo** do hlavičky titulní strany (JPG i PNG; PNG se
> automaticky převede na JPEG s bílým pozadím, protože generátor PDF jiný
> formát nevkládá) a zadat **název firmy, adresu, web, značku** do patičky
> každé strany a **výchozí jméno pro pole „Schválil“**. Nastavení je
> **globální pro celou instalaci** — popisuje firmu, která protokol **vydává**;
> *Údaje o podniku* v záložce Databáze zůstávají zákazníkem, jehož stroje se
> měří. Prázdné pole vždy znamená „použij výchozí“, takže protokol nikdy
> nezůstane bez názvu firmy. PDF, DOCX i protokol **znovu vygenerovaný
> z historie** používají aktuální personalizaci. Vše je uloženo v
> `data/branding/`, kterou **aktualizace nikdy nepřepíše ani nesmaže**;
> aktualizátor ji zálohuje a ochrana dat ji hlídá v inventáři. Logo nikdy
> neukládejte do `backend/assets` — tuto složku aktualizace nahrazuje.
> Přijme se jen skutečný, vykreslitelný JPEG do 2 MB v RGB nebo odstínech
> šedi; poškozený soubor se odmítne českou hláškou a předchozí logo zůstane
> beze změny.
>
> **Verze 1.39.1 – bezpečný kontrakt AI návrhu protokolu.** AI závěr pro každý stroj musí mít přesný JSON objekt s textovými poli `problem`, `zaver` a `doporuceni`. Objekt, pole, číslo, `null` nebo jiný nepodporovaný tvar se bezpečně odmítne, nikdy se nepřevede na text a nedostane se do editoru, PDF, DOCX, historie ani znalostní báze. Místo technické chyby `(... || "").replace is not a function` HADS návrh dokončí bez vadného AI textu a ukáže konkrétní českou zprávu bez upstream těla, klíče či interní diagnostiky. Platí pro OpenAI, Claude Sonnet/Haiku a Anthropic AI Agent (protokol), všechny tři editovatelné promptové varianty a nemění kanonický výběr H/V/A z 1.39.0.
>
> **Verze 1.39.0 – kanonický výběr hodnot protokolu H/V/A.** DDS nemá
> důvěryhodné společné ID akvizice mezi směry, proto H, V a A HADS nikdy
> časově nespojuje. Každý směr má vlastní stabilní výskyt a výchozně používá
> své poslední platné měření; rychlost, zrychlení i obálka pak zobrazí maximum
> právě vybraných směrů s vítězným písmenem. Stejný kanonický výsledek používá
> tabulka, klasifikace, AI, historie, PDF i DOCX. Sbalený ovladač **Výběr
> měření ložisek** nabízí přesný čas a hodnoty R/Z/O pro každý existující směr,
> okamžitý náhled a samostatný výběr porovnání. Starý společný výběr se zachová
> jen při přesně prokazatelné shodě; jinak bezpečně přejde na poslední hodnotu
> daného směru a zobrazí stručné upozornění.
>
> **Verze 1.38.2 – obnova uložených techniků a dat po aktualizaci.** Nastavení
> podniku se nyní váže na vnitřní identitu aktivní `.ndb`, ne na instalační
> cestu, dočasný adresář aktualizace ani název souboru. Při výběru databáze se
> bezpečně prověří historické per-podnikové složky. Jeden prokazatelně patřící
> osiřelý adresář se ihned znovu zpřístupní; pokud jsou technici v obou
> uložištích, bezpečně se spojí bez duplicit. Zdrojová data se při tom nemažou.
>
> **Verze 1.38.1 – oprava načtení Nastavení → AI po aktualizaci.** Bezpečný
> loopback GET pro stav AI a prompty přijímá standardní same-origin požadavek
> prohlížeče i bez hlavičky `Origin`; přesný `Host`, loopback peer a případný
> `Origin`/`Referer` zůstávají povinně kontrolovány. Změny klíčů a promptů
> nadále vyžadují přesný origin a jednorázový nonce. Nečitelný credential se
> nikdy při čtení nemaže; poškozené AI prompty bezpečně použijí výchozí šablony.
>
> **Verze 1.36.3 – ochrana dat při aktualizaci.** Aktualizátor i sdílená
> aktualizace nemění `data/` ani `runtime/`: před změnou vytvoří inventář,
> po změně jej porovná a při prvním startu ověří znovu. Malé persistentní
> soubory včetně AI konfigurace, šifrovaného credential blobu a fallback key
> jsou navíc v `updates/backups/`; `.ndb` a jejich sidecary se nekopírují ani
> nemění. Plný `HADS_aplikace_v1.39.1.zip` je záměrně uložen pod
> `clean_seed/HADS/` a jeho instalátor odmítne existující `HADS/data`, takže
> jej nelze tiše sloučit přes živou instalaci. Pro opravu staršího problému je
> v update ZIPu **Obnovit data po aktualizaci**: nejdříve ukáže náhled a bez
> výslovného potvrzení nepřepíše žádný odlišný soubor.
>
> **Od verze 1.32.3 – úplný rebranding HADS.** Samostatný aktualizátor bezpečně rozpozná strukturálně platnou
> starší instalaci bez závislosti na jejím jménu, po úspěšném ověření ji
> přejmenuje na `HADS` a při automatickém i ručním rollbacku obnoví program,
> původní cestu i uživatelská data.
>
> **Verze 1.36.2 – oprava vzhledu klasifikace protokolu.** Kompaktní tabulka
> opět přesně používá původní barevné obdélníky pouze s A/B/C/D (nebo `—`) ve
> sloupcích **Pásmo** a **Stav ložiska**; žádný popis ani „ručně“ se do buněk
> nevkládá. Vysvětlení nad tabulkou zní: **Pásmo = rychlost, Stav ložiska =
> zrychlení/obálka.** Pásmo je pouze efektivní rychlost a Stav ložiska je
> maximum efektivního zrychlení a obálky — rychlost jej nikdy nezmění. Kliknutí
> na badge otevře skrytou klávesnicí ovladatelnou volbu **Automaticky**, A, B,
> C nebo D; ruční auditní značka je nenápadný bod s tooltipem v editoru a
> zůstává čitelná ve footnotě PDF/DOCX. Návrh, historie a aktualizace limitů
> ruční volby zachovávají a nikdy nemění kartu stroje ani zdrojovou `.ndb`.
>
> **Verze 1.35.0 – bezpečné AI klíče jen pro tento počítač.** Nastavení → **AI agenti** obsahuje samostatné karty OpenAI a Anthropic, stav bez vyzrazení klíče, výchozí model a oddělené potvrzené mazání. Windows ukládá klíče přes DPAPI LocalMachine; klíče se nevrací do UI, odpovědí API, logů ani distribučních balíčků.
>
> **Verze 1.34.5 – opravený Windows handshake výměny databáze.** Tlačítko **Aktualizovat databázi** soubor nejprve pouze streamuje a read-only ověří. Ještě před shutdownem musí nativní `HADS.exe` supervizor a jeho `pythonw.exe` potomek provést ověřený jednorázový handshake (nonce, kanonické cesty, vlastní log a čerstvá challenge/response). Ověření používá skutečně živý Win32 process handle s 64bitově typovaným `HANDLE`; PID supervizoru se záměrně neporovnává s PID potomka. Při chybě HADS zůstane spuštěn a vrátí konkrétní český důvod. Teprve potom externí pomocník po úplném skončení backendu přesune starou `.ndb` i WAL/SHM/JOURNAL do rollbacku, ověří nový snímek a restartuje HADS. Finální výměna nikdy neběží v živém backendu a eliminuje Windows WAL lock.
>
> **Verze 1.34.1 – bezpečné ukončení před ruční aktualizací.** V Nastavení → Aktualizace použijte **Ukončit HADS**: po výslovném potvrzení backend dokončí kritickou práci, uzavře databázové cache, uvolní vlastní instalační lock a zobrazí stav pro bezpečné zavření okna. Samotné zavření prohlížeče backend vždy nezastaví. Pro běžná vydání používejte ověřený aktualizátor, nikoli ruční přepis běžící instalace.

> **Verze 1.34.0 – podepsané sdílené aktualizace.** V Nastavení → Aktualizace lze vybrat lokálně synchronizovanou složku, bezpečně zkontrolovat podepsané vydání a po výslovném potvrzení spustit staging s rollbackem.

> **Verze 1.33.0 – nativní Windows spouštěč.** Na Windows spusťte přímo
> **`HADS.exe`**: neotevírá konzolové okno, bezpečně spustí lokální službu až z
> vlastního instalačního adresáře a prohlížeč otevře až po odpovědi zdraví služby.
> Plný balíček obsahuje ověřený přenosný CPython 3.12 runtime, takže zákazník
> nemusí instalovat Python. Po prvním úspěšném spuštění je na uživatelské Ploše
> vytvořen nebo opraven jeden zástupce `HADS.lnk`; `HADS.exe --create-shortcut`
> jej lze kdykoli opravit ručně. Po zavření prohlížeče může služba zůstat běžet;
> další spuštění bezpečně restartuje jen ověřenou instanci stejné instalace.

> Po dvojkliku na `Aktualizovat HADS.bat` bez
> argumentu vždy otevře standardní dialog Windows pro výběr instalační složky
> HADS. Vyberte kořen s `backend/`, `frontend/` a `data/`, případně jeho
> nadřazenou složku s jedinou platnou instalací; neplatná volba zobrazí českou chybu
> a lze ji vybrat znovu. Storno ani potvrzení **Ne** nic nemění. Před změnou se
> zobrazí vybraná cesta, nalezená verze a cílová verze; ruční obnovení navíc
> ukáže poslední zálohu. Explicitní cesta (`Aktualizovat HADS.bat
> "C:\Programy\HADS"` nebo `--install`) zůstává bezdialogová pro správce a
> automatizaci. Linux/macOS bez argumentu použije český textový prompt.
>
> **Od verze 1.32.0** je k vydání dodáván samostatný bezpečný offline
> aktualizátor. Před jakoukoli změnou ověří manifest, velikost a SHA-256 všech
> programových souborů, odmítne běžící HADS, vytvoří timestampovanou zálohu a
> při chybě automaticky vrátí původní programové soubory. Aktualizace nikdy
> nepřepisuje ani nemaže `data/*.ndb`, `data/podniky/`, `ai_config.json`,
> `ai_examples.json`, `custom_norms.json`, návrhy/historii protokolů ani jiná
> uživatelská data. Zálohy programu a malých JSON konfigurací jsou v
> `updates/backups/`; ponechávají se poslední tři a ruční návrat provede
> `Obnovit předchozí verzi.bat` / `.sh`.

> **Od verze 1.31.4** je **ČSN ISO 20816-9 Převodovky** součástí skutečného
> **vestavěného backendového katalogu** (`backend/ai_eval.py`), API
> `/api/norms/catalog` i dynamického výběru norem na kartě stroje. Norma je
> tedy vždy dostupná, i když soubor `data/custom_norms.json` **neexistuje**,
> je prázdný nebo se do distribučního ZIPu vůbec nepřibalí. Obsahuje třídy
> **VR 3,15** (A/B 2,0; B/C 3,15; C/D 5,0), **VR 5** (3,15; 5,0; 8,0),
> **VR 8** (5,0; 8,0; 12,5), **VR 12,5** (8,0; 12,5; 20,0) a **VR 20**
> (12,5; 20,0; 31,5) mm/s RMS. Mapování je vždy **A/B → `ab`**,
> **B/C → `warning`** a **C/D → `alarm`**; hodnota přímo na hranici přejde
> do následujícího pásma (A/B = B, B/C = C, C/D = D).
>
> Vlastní normy z `data/custom_norms.json` zůstávají doplňkem katalogu.
> Deduplikace je deterministická: záznam vlastního souboru se stejným názvem
> jako vestavěný standard se ignoruje a platí výhradně vestavěná definice;
> opakované záznamy jiné vlastní normy se spojí, přičemž stejná třída se řídí
> posledním zápisem v souboru. Katalog/UI proto zobrazí každý standard a
> každou třídu jen jednou. Existující přiřazení podle dvojice
> `standard` + `machine_class`, režim **Více norem dle ložisek**, AI i příloha
> použitých norem v PDF/DOCX zůstávají kompatibilní.
>
> **Od verze 1.31.3** se „poslední hodnota“ v **protokolu** vybírá pro
> každé ložisko, bod **H** a každou ze tří přesně nakonfigurovaných
> protokolových veličin podle **skutečného času měření v historii**, nikdy
> podle `rowid`, pořadí vložení ani pořadí řádků v databázi. Použije se jen
> konečná číselná hodnota s platným timestampem; `NULL`, text, `NaN` a
> nekonečno se nepovažují za poslední měření. Je-li při tvorbě návrhu zvolen
> konkrétní den nebo relativní období, hodnoty mimo toto okno se do tabulky,
> stavu ložiska ani data u stroje nedostanou. Při shodném timestampu je
> výsledek deterministický: parser použije stabilní pořadí záznamu statistik
> a pozici v datovém BLOBu až jako **tie-breaker**, ne jako náhradu času.
> Okruh se ukládá přímo do návrhu, takže tlačítko **„Aktualizovat“** zachová
> stejné časové omezení. Editor, PDF i DOCX vykreslují stejná uložená data
> návrhu. Cache serveru drží pouze otevřené spojení k `.ndb`, nikoli poslední
> trendové hodnoty.
>
> **Od verze 1.31.2** má tabulka i automatický stav ložiska v **protokolu**
> jeden shodný, úzký datový základ: pro každé ložisko se použije výhradně
> **horizontální směr H** a pouze tři přesné názvy veličin z nastavení
> **„Veličiny do tabulek protokolu“** (rychlost, zrychlení a obálka).
> Vysoká hodnota stejné veličiny ve směru V/A, ukazatel **BEARING RMS** ani
> jiná nevybraná akcelerační veličina stav protokolu nezvýší. Chybí-li H
> buňka zvolené veličiny, tabulka ukáže „—“ a nepoužije náhradu z V/A;
> jestliže pro ložisko nejsou žádné z těchto tří H hodnot, je **Neměřeno**.
> Stav ložiska je nejhorší pásmo A–D z dostupných zobrazených H buněk a
> celkový automatický stav stroje z nich vychází stejným způsobem. Platné
> limity ISO/DDS, vyloučení řádku a ruční přepis stavu zůstávají zachovány.
> Tlačítko **„Aktualizovat“**, PDF i DOCX používají tutéž logiku. Dashboard
> a karta stroje si ponechávají širší diagnostiku přes H/V/A.
>
> **Od verze 1.31.1** je opraveno zařazení do pásem **C a D** u DDS
> statických objektů (např. **BEARING RMS**, ACC RMS, ENV RMS), jejichž
> limitní XML v `.ndb` obsahuje **více než 2 platné limitní hodnoty** a
> chybí (nebo nesedí) doprovodný blok `alarmId` se závažností. Záložní
> heuristika dříve u takové veličiny vzala jako meze Varování/Alarm (hranice
> B/C a C/D) **dvě nejnižší** hodnoty místo dvou nejvyšších — např. u
> `BEARING RMS` s mezemi `[0.4, 0.8, 1.2]` vycházela chybně hranice C/D už na
> 0,8 mm/s RMS (namísto 1,2) a hodnoty mezi 0,8 a 1,2 se tak nesprávně
> hlásily jako pásmo **D** (Ohrožení) místo správného pásma **C**
> (Výstraha). Nyní se pásma **C a D vždy určují dvěma nejvyššími platnými**
> limitními hodnotami veličiny — mez C/D = nejvyšší, mez B/C = druhá
> nejvyšší — bez ohledu na pořadí, duplicity nebo počet mezí (2, 3 i více) v
> XML; neplatné (poškozené/nedekódovatelné) hodnoty se před výběrem vyřadí.
> **Při přesně 2 platných mezích je mapování shodné jako dřív** (žádná
> změna pro běžná/existující data). Oprava je centrální (`parse_cell_limits`
> v `backend/ndb_parser.py`) a platí shodně pro **přehled stavu
> (dashboard), kartu stroje, generování protokolu i tlačítko
> „Aktualizovat“** — všechny čtou limity ze stejného místa. **Normy ISO
> 20816 přiřazené na kartě stroje nejsou touto opravou dotčeny** — jejich
> meze (A/B, B/C, C/D) se čtou přímo z katalogu norem
> (`backend/ai_eval.py`) a mají vždy přednost před limity z `.ndb`.
>
> **Od verze 1.31.0** umí protokol exportovat i jako **plně editovatelný
> soubor Word (.docx)** — tlačítko **„Exportovat DOCX“** vygeneruje dokument
> se stejným designem jako PDF (hlavička, dashboard, tabulky, barvy pásem
> A–D), ale jako standardní WordprocessingML soubor, který lze v Microsoft
> Word nebo LibreOffice Writer volně upravovat — nic není „zamčené“ jako
> obrázek. Doplňkově je možné vyexportovaný a ve Wordu upravený dokument
> **bezpečně naimportovat zpět**: tlačítko **„Import z DOCX“** rozpozná
> POUZE textová pole **„Závěry“** a **„Doporučení“** u každého stroje (díky
> skrytým, needitovatelným strojovým značkám vloženým při exportu) a nabídne
> **náhled se srovnáním starého/nového textu** — dovoluje vybrat jednotlivé
> stroje/pole a přenést je do rozpracovaného protokolu. **Žádná naměřená ani
> technická hodnota (rychlosti, pásma A–D, stav ložisek, meze, data měření
> apod.) se z Wordu NIKDY nečte ani nezapisuje** — import je omezen výhradně
> na textové závěry a doporučení a vždy vyžaduje ruční potvrzení (žádné
> automatické přepsání dat). Generátor DOCX používá pouze standardní
> knihovnu Pythonu (žádná závislost na `python-docx` ani jiném externím
> balíčku).
>
> **Od verze 1.30.2** je opraven výpočet pásem u strojů, které mají
> **více norem přiřazených různým skupinám ložisek** (režim „Více norem dle
> ložisek“ na kartě stroje). Dříve se norma vyhodnocovala **jednou za celý
> stroj**, tedy bez informace o konkrétním ložisku – v režimu více norem proto
> nedostalo limity z normy **žádné** ložisko a všechny body se tiše
> klasifikovaly podle limitů uložených v `.ndb`. Například u převodovky s
> normou **Varování 8; Alarm 12,5 mm/s RMS** přiřazenou ložiskům L3–L8 spadly
> hodnoty 7,08–7,84 mm/s do pásma **C**, přesto že jsou pod mezí varování
> (správně **B**). Nyní se norma řeší **pro každé ložisko samostatně**: každý
> měřicí bod používá výhradně normu své skupiny, skupiny se navzájem
> nepřepisují, **výsledek nezávisí na pořadí přiřazení** a ložisko, které není
> zaškrtnuté u žádného přiřazení, se klasifikuje z limitů `.ndb`. Zároveň se
> přiřazení normy propíše do limitů **všech** zaškrtnutých ložisek i tehdy,
> když na nich nejsou žádné ruční limity, a **překrývající se skupiny** se při
> uložení karty normalizují na disjunktní (ložisko zůstane v prvním
> přiřazení). Oprava platí shodně pro **kartu stroje, přehled stavu
> (dashboard), protokol, AI vyhodnocení i tlačítko „Aktualizovat“** – po změně
> přiřazení stačí protokol aktualizovat a pásma se přepočítají se zachováním
> ručních textů. Detaily viz kapitola
> [Karty strojů — limity a ložiska](#karty-strojů--limity-a-ložiska).
>
> **Od verze 1.30.1** má tvorba protokolu tlačítko **„Aktualizovat“**. Když
> během práce na protokolu změníte limity na kartě stroje (nebo normu, ze
> které se limity odvozují), nemusíte generovat celý nový návrh – tlačítko
> přepočítá **stav (pásmo A–D) jednotlivých měřicích bodů a ložisek** podle
> **aktuálně uložených limitů karet strojů** a obnoví z nich odvozené souhrny
> (nejhorší pásmo, automatický stav stroje, meze v trendech a spektrech,
> úspěšnost vyvážení, příloha „použité normy“). **Ručně upravené texty
> zůstávají zachovány** – závěry, doporučení, popis problému, hlavička, úvod,
> úvod přílohy, ruční přepis stavu stroje, vyloučené body i výběr grafů
> včetně komentářů. Aktualizace pracuje i s **dosud neuloženými úpravami**
> v editoru a vypíše seznam bodů, jejichž stav se změnil, ať víte, u kterých
> strojů zkontrolovat závěr. Detaily viz kapitola
> [Aktualizace protokolu podle limitů](#aktualizace-protokolu-podle-limitů-tlačítko-aktualizovat).
>
> **Od verze 1.30.0** se data KAŽDÉHO PODNIKU ukládají do vlastní složky
> `data/podniky/<název-podniku>/` (místo dřívějších společných souborů
> `data/machine_config.json`, `report_history.json`, `report_drafts.json`,
> `company.json`, `report_settings.json`). Díky tomu je **bezpečné sdílet
> složku `data/` mezi dvěma PC** (Syncthing, Nextcloud, OneDrive, síťový
> disk): když dva uživatelé pracují každý na jiném zákazníkovi, zapisují
> do různých složek a nevznikají konflikty celých souborů. **Migrace je
> automatická** – při prvním spuštění se staré společné soubory rozdělí
> do složek podle podniků a původní soubory se ponechají jako záloha s
> příponou `.migrated`. **Doporučení pro synchronizaci:** ze sdílení
> vylučte soubor `data/ai_config.json` (obsahuje živé API klíče – měl by
> zůstat lokální na každém PC) a velké databáze `.ndb` (kvůli objemu dat).
>
> **Od verze 1.29.1** je tvorba protokolu rozdělena do čitelnějších záložek:
> **Okruh strojů** (výběr okruhu dle data měření, verze protokolu, AI a
> generování návrhu) a nová **Úvodní strana** (hlavička, úvod a **příloha
> – použité normy**). Na Úvodní straně lze editovat **úvod přílohy** (propíše
> se do PDF) a je zde **náhled skutečně použitých norem** včetně mezí pásem
> A/B, B/C a C/D [mm/s RMS]. Záložky **Stroje – závěry a doporučení** a
> **Historie protokolů** zůstávají beze změny.
>
> **Od verze 1.29.0** se aplikace jmenuje **HADS – Heistech AI Diagnostic
> Software**. „měřicí přístroj“ zůstává označením **zdroje dat / měřicího přístroje**
> (databáze `.ndb`), nikoli názvem aplikace.
>
> **Od verze 1.29.0** aplikace umí **učit se z minulých protokolů (varianta B –
> znalostní báze AI)**. V **Nastavení → AI vzory** lze spravovat kurátorované
> vzorové závěry a doporučení (typ stroje, verze protokolu, stav, závady,
> situace, závěr, doporučení). Při generování protokolu se do AI promptu
> automaticky vkládají **nejpodobnější vzory** jako ukázka **stylu a
> struktury** formulací – AI z nich **nikdy nepřebírá konkrétní hodnoty ani
> pásma**, ty vždy počítá z aktuálních dat stroje. V editoru protokolu (i v
> historii) je u každého stroje tlačítko **„Povýšit na vzor AI“**, které
> předvyplní nový vzor z hotového závěru.

> **Verze aplikace** se zobrazuje vždy v hlavičce vedle názvu (např. `v1.10.0`)
> a je rovněž součástí názvu ZIP souboru (např. `HADS_aplikace_v1.10.0.zip`).
> Číslo verze je centrálně uloženo v souboru `backend/version.py`.

## Co aplikace umí

- **Spektrální podklady pro AI a společná metodologie (od verze 1.41.0)** —
  aplikace z posledního spektra každého bodu **sama spočítá** nejvyšší vrcholy,
  jejich **řád otáčkové frekvence** a amplitudy **na otáčkové frekvenci,
  harmonických i poruchových frekvencích ložiska**, a předá je AI jako hotovou
  tabulku nálezů. Model tak už FFT nekomentuje „naslepo“, ale ani nic
  nepočítá — veškerá aritmetika je v aplikaci a je pokrytá testy. Odborný
  postup hodnocení je v jedné **editovatelné metodologii**
  (Nastavení → AI prompty), kterou používá protokol i poradce u měřicího bodu.
  **Tip:** vyplňte na kartě stroje **otáčky** — bez nich nelze určit řády ani
  poruchové frekvence a AI pak spektra záměrně neinterpretuje.
- **Personalizace protokolů — vlastní logo a firma (od verze 1.40.0)** —
  v **Nastavení → Firma a logo** nahrajete **logo**, které se vykreslí vlevo
  nahoře na titulní straně protokolu, a zadáte **název firmy, adresu a web**
  do patičky každé strany, **značku** do hlavičky (použije se jen bez loga)
  a **výchozí jméno do pole „Schválil“**. Nastavení platí **globálně pro celou
  instalaci** a ukládá se do `data/branding/`, takže je aktualizace programu
  nikdy nepřepíše. Uplatní se v **PDF, DOCX i u protokolu znovu vygenerovaného
  z historie**.
- **Karty strojů — limity a ložiska** — pro každý stroj lze spravovat **limity
  (Varování / Alarm)** pro jednotlivé měřené veličiny (ISO RMS, BEARING RMS,
  ACC RMS…) **na ložisko** (L1, L2…) sdíleně přes všechny směry (H/V/A) a
  **přiřadit typ ložiska** s defektními frekvencemi. Výchozí limity se čtou
  z databáze a lze je přepsat. Limity se promítají do trendů, přiřazené
  ložisko do spekter (viz níže). **Od verze 1.25.7** se u každé poslední
  naměřené hodnoty (per směr H/V/A) zobrazuje **malý stavový puntík**
  (zelený = pod limity, oranžový = nad varováním, červený = nad alarmem),
  aby bylo na první pohled vidět, která aktuální veličina překračuje limit.
- **Interní databáze defektních ložiskových frekvencí** — obsahuje přes **31 000
  ložisek** (82 výrobců: SKF, FAG, NTN, KOYO, SNR…) s koeficienty FTF / BSF /
  BPFO / BPFI. Ložisko vyhledáte podle označení nebo typu, případně zadáte
  koeficienty ručně (viz níže).
- **Strom strojů a měřicích bodů** — hierarchie závod → stroj → měřicí bod
  (ložisko, směr H/V/A) s barevnou indikací stavu. **Kliknutím na uzel stroje**
  (uzel, který má pod sebou měřené body) se otevře **karta příslušného stroje**;
  kliknutím na měřicí bod se přejde přímo na jeho měření. **Od verze 1.25.3**
  má i **samotný uzel stroje** barevnou tečku se stavem — zobrazuje **nejhorší
  stav ze všech jeho měřicích bodů** (např. má-li libovolný bod stavu Výstraha
  nebo Ohrožení, tečka stroje tento stav převezme), takže rizikový stroj
  poznáte na první pohled i bez rozbalování stromu.
- **Přehled stavu (dashboard) s kartami strojů** — hlavní stránka nezobrazuje
  všechny veličiny, ale **kartu každého stroje** s měřicími body pod ním a jejich
  statistikou: celkový počet bodů, počty podle závažnosti (Ok / Varování / Výstraha
  / Ohrožení) a nejhorší stav stroje. Stroje jsou seřazeny od nejvíce ohrožených.
  Z karty se kliknutím na bod přejde rovnou na jeho měření.
- **Filtr dashboardu podle data posledního měření** — v hlavičce přehledu lze
  vybrat, které stroje se zobrazí podle stáří posledního záznamu (např. měřené za
  posledních 7 / 14 / 30 / 90 dní nebo za poslední rok; výchozí je *všechny měřené*).
  **Stroje bez jakékoli naměřené hodnoty se nezobrazují vůbec.** Pod hlavičkou se
  vypíše poznámka, kolik strojů bylo odfiltrováno. KPI řádek (počty bodů a závažností)
  se přepočítává pouze ze zobrazených strojů.
- **Otáčky stroje (na celý stroj) s autodetekcí ze spektra** — v kartě stroje lze
  zadat **otáčky [Hz]**, které platí pro **všechna měřicí místa** stroje a používají
  se jako výchozí otáčková frekvence ve spektrech. Tlačítko **„Detekovat ze spektra“**
  otáčky automaticky najde jako **maximální amplitudu spektra rychlosti vibrací
  (ISO SPECTRUM) v rozsahu 5–70 Hz** napříč body stroje. Aplikace navíc vede
  **historii posledních 5 detekcí** (datum + hodnota) s možností **jedním kliknutím
  obnovit** dříve detekovanou hodnotu (viz níže).
- **Tlačítko „Domů"** — kdykoli vás vrátí na hlavní stránku (přehled stavu).
- **Trendy statických hodnot** — vývoj celkových hodnot (ISO RMS, BEARING RMS,
  ACC RMS, ENV RMS…) v čase, včetně statistik (poslední, max, min, průměr).
- **Porovnání více měřicích bodů v jednom grafu** — ve stromu lze zapnout
  **režim porovnání** (tlačítko „Porovnat" nad stromem), zaškrtnout několik
  měřicích bodů najednou a zobrazit jejich trendy zvolené veličiny v **jedné
  společné časové ose**. Pomáhá to odhalit **korelace a současné nárůsty
  vibrací** mezi body. K dispozici je volitelná **normalizace (0–100 %)** pro
  srovnání bodů s různými rozsahy hodnot, přehledová tabulka sérií s určením
  trendu (roste / klesá / stabilní) a **korelační matice (Pearson)** barevně
  zvýrazňující, které body se vyvíjejí společně. (viz níže)
- **FFT spektra s dynamickými grafy (jako DDS software)** — frekvenční spektra
  s pokročilým ovládáním grafu (viz níže).
- **Celková hodnota (overall) ze spektra + hornopásmový filtr 1 Hz** — u každého
  spektra se počítá celková hodnota (overall) jako RMS přes čáry spektra. Na všechna
  spektra se přitom aplikuje **hornopásmový filtr na 1 Hz**, který odřízne
  stejnosměrnou (DC) složku signálu, takže ji overall nezkresluje (viz níže).
- **Vodopádový graf FFT spekter (waterfall)** — interaktivní vizualizace vývoje
  frekvenčních spekter v čase pro vybraný měřicí bod. Umožňuje sledovat
  **degradaci ložisek nebo postupné změny ve vibracích** napříč více měřeními
  (viz níže).
- **Časové signály** — surové časové průběhy zrychlení s výpočtem max a RMS,
  s jednoduchým kurzorem.
- **Správa více databází** — do aplikace lze načíst libovolný počet databází `.ndb`.
  Mezi uloženými databázemi přepínáte **rozbalovacím seznamem** vpravo nahoře —
  data zvolené databáze se okamžitě načtou. Databáze lze také **přejmenovat**
  (vlastní srozumitelný název) nebo **smazat** přes tlačítko správy (ozubené kolo).
- **Import dat** — nahrání nové databáze `.ndb` přímo z aplikace (tlačítko
  „Načíst databázi").
- **Protokol z měření (PDF)** — automatické vygenerování **profesionálního
  protokolu z měření ve formátu PDF** se **střízlivým, technickým designem**
  (převážně černobílý, barva jen u stavů a pásem) zaměřeným na to, aby **hlavní
  informace byly hned na prvních stranách**. Vyberete **okruh strojů podle data
  měření** (posledních N dní / poslední týden / konkrétní datum / všechny) a
  volitelně jej dále upravte **ručním zaškrtnutím konkrétních strojů** podle
  podniku (od verze 1.23.0), vyplníte hlavičku (podnik, číslo zakázky, kdo
  měřil a schválil), upravíte úvod a u problémových strojů **stručný závěr
  a doporučení (generuje AI)**. K dispozici jsou **tři verze protokolu**:
  stručná (V1, od verze 1.22.0), detailní (V2) a **vyvažování (V3, od verze
  1.25.5)** — viz níže.
  Protokol je strukturován jako: **strana 1 — manažerský dashboard** (semafor
  stavu + KPI metriky + prioritizovaná akční tabulka kritických strojů řazená
  podle závažnosti), **strana 2 — metodika a souhrnná tabulka VŠECH strojů**
  (stav, nejhorší pásmo, doporučení) — tyto dvě strany jsou u OBĚ verzí
  stejné. Dále následují **detailní strany strojů** se **sjednocenou tabulkou
  ložisek** (rychlost, zrychlení a obálka výhradně v **horizontálním směru
  H**, jedna kolonka na ložisko): ve **verzi 1 (výchozí)** jen pro **problémové
  stroje** (Výstraha / Alarm); ve **verzi 2** pro **všechny stroje**, navíc
  se sloupcem **předchozí hodnoty rychlosti** vedle aktuální pro porovnání
  vývoje; ve **verzi 3 (vyvažování, od verze 1.25.5)** má tabulka **dva
  samostatné sloupce rychlosti — PŘED a PO vyvážení — každý s vlastním
  pásmem A–D a navíc sloupec % úspěšnosti vyvážení**. Vše s **klasifikací do
  pásma A/B/C/D dle ČSN ISO 20816**. Volitelně lze do protokolu zaškrtnout
  **trendy a FFT spektra** vybraných měřicích bodů, vykreslené jako **vektorové
  grafy přímo v PDF (offline)**. **Od verze 1.25.7** se výběr grafů u každého bodu
  **rozděluje samostatně na trendy (statické hodnoty) a FFT spektra** — každá
  skupina má **vlastní komentář**, u trendů lze zvolit **počet bodů** (10–120)
  a u spekter přidat **frekvenční značky** (otáčková 1×, harmonické 2×–6×,
  ložiskové BPFO/BPFI/BSF/FTF), které se do spektra vykreslí jako svislé čáry
  s popiskem. **Od verze 1.25.8** je sekce „Grafy do protokolu" u každého
  stroje **rozdělena do podzáložek podle měřicího bodu** (L1H-motor,
  L1V-motor, …), takže výběr trendů/spekter je přehledný i u strojů s mnoha
  body. **Od verze 1.25.9** se **komentáře i značky nastavují až v dialogu
  interaktivního náhledu** — diagnostik tak komentuje a značkuje přesně to, co
  má před očima. V panelu u každého bodu zůstávají jen **zaškrtávátka grafů**
  (trendy / FFT spektra) a tlačítko **Náhled**. V dialogu náhledu je:
  **komentář zvlášť pro každý graf** (jiný text pro FFT rychlosti než pro FFT
  zrychlení), u **spekter** navíc **volba automatických značek**
  (otáčková 1×, harmonické 2×–6×, ložiskové BPFO/BPFI/BSF/FTF) a
  **přidávání vlastních značek kliknutím do grafu**. U **vlastní značky ve
  spektru** lze nastavit **počet harmonických** (výchozí 3) a **postranní
  pásma** (počet + rozteč [Hz]), které se do spektra vykreslí jako doplňkové
  svislé čáry (harmonické světlejší, postranní pásma nejsvětlejší, bez
  popisku). U **trendu** je vlastní značka jednoduchá svislá čára na bodu.
  Volba **počtu bodů trendu byla odstraněna** — trend vždy zobrazuje **všechny
  body** (při dostupném trendu je omezování zbytečné). Náhled je
  **interaktivní (Plotly)** s **přiblížením/posunem**; nastavené **přiblížení
  (rozsah os), komentář, automatické i vlastní značky (včetně harmonických a
  postranních pásem) se přenesou do PDF**.
  **Verze 3 navíc umožňuje vložit externí
  obrázek** (typicky graf polarích vektorů exportovaný z měřicího přístroje), který
  se přidá na konec přílohy s grafy. Vše je před vygenerováním **editovatelné**
  (viz níže).
- **Export protokolu do Wordu (DOCX) a bezpečný import zpět (od verze
  1.31.0)** — tlačítko **„Exportovat DOCX“** vedle exportu PDF vygeneruje
  **stejný protokol jako plně editovatelný dokument Word** (.docx) se shodným
  designem, sekcemi, tabulkami i barvami pásem A–D — vhodné, když je potřeba
  protokol před odesláním ještě upravit v běžném textovém editoru. Tlačítko
  **„Import z DOCX“** pak umožní načíst zpět soubor, který byl ve Wordu
  upravený, a zobrazí **náhled se srovnáním původního a nového textu** pro
  **Závěry** a **Doporučení** každého stroje — uživatel v náhledu **vybere,
  které konkrétní pole u kterého stroje** se má přenést, a teprve po potvrzení
  se hodnoty zapíšou do rozpracovaného protokolu. Rozpoznání, který text patří
  ke kterému stroji, zajišťují **skryté strojové značky** vložené při exportu
  (nejsou vidět ani se netisknou). **Import je natvrdo omezen výhradně na pole
  Závěry/Doporučení — žádná naměřená ani technická hodnota (rychlosti,
  pásma A–D, stav ložisek, meze, data měření apod.) se z Wordu nikdy nečte ani
  nezapisuje**, a to i kdyby soubor byl poškozený nebo záměrně upravený.
  Generátor DOCX je postavený **čistě na standardní knihovně Pythonu** (žádná
  závislost na `python-docx` ani jiném externím balíčku).
- **AI poradce pro diagnostiky na úrovni měřicího bodu** — přímo v detailu bodu
  (pod trendy a spektry) lze provést **lokální AI vyhodnocení** zaměřené na daný
  bod a jeho **přiřazené ložisko**. Panel zobrazí **defektní frekvence ložiska**
  (FTF/BSF/BPFO/BPFI) v násobcích otáček i přepočtené do Hz, umožní **detekci
  otáček ze spektra nebo ruční zadání** a výběr z **více modelů** (OpenAI / Claude).
  Norma se dědí z karty stroje. Všechna vyhodnocení se **automaticky ukládají**
  včetně historie (viz níže).

### Dynamické grafy (inspirace softwarem DDS)

U spekter a časových signálů je nad grafem **ovládací lišta** s funkcemi, které
odpovídají dynamickým grafům v DDS:

- **Kurzor** — Vypnutý / Jednoduchý / **Harmonický** (násobky 1X, 2X … NX) /
  **Postranní pásma** (sidebands). Kurzor umístíte kliknutím do grafu; u spektra
  se automaticky „přichytí" na nejbližší vrchol.
- **Najít vrchol** — najde globální (nebo nejbližší) špičku a umístí na ni kurzor.
  U harmonického kurzoru se z polohy 1X dopočítají otáčky v ot/min.
- **Typ osy Y** — Lineární / Logaritmická / **Decibely (dB)**.
- **Typ osy X** — Lineární / Logaritmická.
- **Značky poruchových frekvencí** — Ložiska (BPFO, BPFI, BSF, FTF a jejich
  násobky), Převod (GMF), Asynchronní motor (1X, 2X, 2× síťový kmitočet).
  Značky se vykreslí podle zadaných **otáček [Hz]** (lze zadat ručně, nebo se
  převezmou z měření, pokud jsou v databázi).
- **Počet harmonických / pásem** — kolik násobků kurzor zobrazí.
- **Lokální maxima** — vyznačí N nejvyšších vrcholů ve spektru a vypíše je do
  seřazené **tabulky** (frekvence + amplituda).
- **Mřížka** — zapnutí/vypnutí mřížky grafu.

Kromě toho lze graf přibližovat, posouvat, exportovat do obrázku a zobrazit přesné
hodnoty najetím myší (standardní ovládání v pravém horním rohu grafu).

**Jednoduchý kurzor a odečet hodnoty (od verze 1.17.0)** — ve všech grafech
(statických i dynamických) sleduje při pohybu myší **svislý kurzor** a v pravém
horním rohu grafu se zobrazuje **aktuální hodnota** pod kurzorem (u trendů čas a
hodnota, u spekter frekvence v Hz a amplituda, u časového signálu čas a amplituda).
U dynamických grafů je tento kurzor zapnutý **výchozí** — a to i v přehledu
všech grafů.

### Záložky na stránce bodu a přehled všech grafů (od verze 1.17.0)

Na stránce **měřicího bodu** jsou záložky jednotlivých měření rozděleny do
dvou přehledných řádků:

- **Statická data** — trendy (ISO RMS, BEARING RMS, ACC RMS …).
- **Dynamická data** — spektra a časové signály; v tomto řádku je i tlačítko
  **„Vodopád spekter“**.

**Podbarvení statických záložek dle limitu** — záložky statických (trendových)
měření jsou barevně označeny podle stavu poslední hodnoty vůči platným limitům
(z databáze nebo z karty stroje):

- **zelená** = v pořádku,
- **oranžová** = překročen limit *Varování*,
- **červená** = překročen limit *Alarm*.

Díky tomu je na první pohled vidět, která veličina je v normě a která ne, ještě
před otevřením konkrétního grafu.

**Tlačítko „Vykreslit všechny grafy“** — vykreslí **všechny grafy bodu naráz**
(statické i dynamické) do přehledné **mřížky mini-panelů**. Každý panel má
menší interaktivní graf, popisek měření a tlačítko **„Detail“** pro otevření
grafu v plném interaktivním zobrazení (s kurzory, značkami a dalšími funkcemi).
V režimu přehledu všech grafů je **AI poradce skrytý** — do běžného zobrazení
jednoho grafu se vrátíte kliknutím na libovolnou záložku nebo na tlačítko
„Detail“.

> Poznámka: Značky poruchových frekvencí ložisek a převodů používají orientační
> koeficienty (nikoli konkrétní geometrii daného ložiska). Slouží jako vizuální
> vodítko pro odhad polohy poruchových složek; pro přesnou diagnostiku zadejte
> správné otáčky a porovnejte s katalogovými hodnotami ložiska.

### Karty strojů — limity a ložiska

**Stroj** je v hierarchii uzel, který má pod sebou **měřicí místa** (např.
*Vrátek Motor1*). U každého stroje lze otevřít jeho **kartu** a spravovat zde
limity a přiřazená ložiska.

Kartu stroje otevřete na **přehledu stavu (dashboard)** tlačítkem
**„Karta stroje — limity a ložiska"** na kartě příslušného stroje. Karta
obsahuje panel pro **každé ložisko** stroje (L1, L2, L3…). Měřicí místo je
označeno kódem **ložiska a směru**: `L1` je první ložisko, směry se rozlišují
příponou — `L1H` (horizontální), `L1V` (vertikální), `L1A` (axiální). Všechny
směry téhož ložiska tvoří **jeden panel** a sdílejí společné limity i ložisko.

**Záložky karty stroje (od verze 1.16.0)**

Protože karta stroje obsahuje hodně údajů, je rozdělena do přehledných
**záložek** (taby v horní části karty):

- **Základní informace o stroji** — identifikační údaje a obrázek stroje pro
  protokol, nastavení otáček stroje a **od verze 1.25.3 také výběr normy pro
  hodnocení** — viz níže. **Od verze 1.25.4** jsou v katalogu také normy
  **ČSN 20 0065** (frézky – dutina ve vřetenu do/nad 50 mm) a **ISO 14694**
  (ventilátory kategorie BV-1 až BV-5, tuhé i pružné uložení, tabulka 5 –
  in situ, RMS). Nabídka tříd/kategorií se automaticky přizpůsobuje zvolené
  normě. **Od verze 1.27.0** lze v Nastavení → Normy přidávat, **upravovat**
  i mazat **vlastní normy** a každá třída má nyní **tři meze rychlosti
  vibrací [mm/s RMS]**: **A/B** (zelená – dobrý stav), **B/C = varování**
  (žlutá) a **C/D = alarm** (červená). Hodnoty se tím klasifikují do pásem
  **A–D** a shodně se propisují i do **protokolu (PDF)**. Nezadáte-li hranici
  A/B, odhadne se jako polovina meze varování (zpětně kompatibilní).
  **Od verze 1.27.1** je i vestavěná norma **ISO 14694** převedena na tři
  pásma dle tabulky 5 (efektivní rychlost vibrací / RMS): **A/B = Počáteční**,
  **B/C = Výstraha** (varování) a **C/D = Odstavení** (alarm) pro každou
  kategorii BV-1 až BV-5 (tuhé i pružné uložení). U **BV-1 a BV-2** není mez
  odstavení (C/D) normou definována (Poznámka 1) – tyto kategorie se proto
  klasifikují pouze do pásem **A/B/C**.
  **Od verze 1.31.4** je zde bez jakéhokoli importu vlastní normy také
  **ČSN ISO 20816-9 Převodovky** s pěti třídami **VR 3,15 / VR 5 / VR 8 /
  VR 12,5 / VR 20** a se třemi přesnými mezemi A/B, B/C, C/D. Zvolte ji ve
  výběru **Norma**, vyberte třídu VR a aplikace ji stejně jako ostatní normy
  propíše do ISO RMS, dashboardu, AI i přílohy protokolu PDF/DOCX. Vlastní
  norma se stejným názvem ji nemůže přepsat ani zdvojit; jiné vlastní normy
  zůstávají v nabídce.
  **Od verze 1.28.0** lze při zadávání vlastní normy vložit **více tříd pod
  jednu normu najednou** – tlačítkem **„+ Přidat další třídu“** se přidávají
  další řádky (např. celá tabulka VR 3,15 / 5 / 8 / 12,5 / 20 se třemi mezemi
  A/B, B/C, C/D). Mez **C/D je nyní volitelná** i u vlastních norem (při
  vynechání se klasifikuje jen do pásem A/B/C).
  **Od verze 1.28.3** lze na kartě stroje v sekci „Norma pro hodnocení
  rychlosti vibrací" přepnout mezi režimem **„Jedna norma pro celý stroj"**
  a **„Více norem dle ložisek"**. V režimu více norem se přidá jedno či
  více přiřazení (norma + třída) a u každého se **zaškrtnou ložiska**
  (L1, L2…), která pod danou normu spadají. Klasifikace ISO RMS i limity
  v PDF protokolu se pak počítají pro každý měřicí bod podle normy
  přiřazené jeho ložisku; ložisko, které není zaškrtnuté u žádného
  přiřazení, se z normy neklasifikuje. Starší karty (bez režimu) se chovají
  jako dosud (jedna norma pro celý stroj).
  **Od verze 1.30.2** funguje režim více norem správně i při **klasifikaci
  do pásem**. Dříve se norma vyhodnocovala jednou za celý stroj (bez klíče
  ložiska), takže v režimu více norem nezískalo limity z normy žádné ložisko
  a všechny body se klasifikovaly podle limitů z `.ndb` – hodnoty se pak
  jevily o pásmo horší (např. 7,84 mm/s pod mezí varování 8 mm/s vycházelo
  jako **C** místo **B**). Platná pravidla mapování mezí jsou:
  **A/B → hranice pásem A a B**, **B/C = „Varování“**, **C/D = „Alarm“**.
  Norma je **autoritativní**: chybí-li v ní mez C/D (např. ISO 14694 BV-1
  a BV-2), **nedoplní se z `.ndb`** a bod se klasifikuje jen do pásem A/B/C.
  Chybí-li mez A/B, odhadne se jako polovina meze varování. Nově platí, že
  **každé ložisko používá výhradně normu své skupiny**, přiřazení se
  navzájem nepřepisují, **pořadí přiřazení ani pořadí ložisek v nich nemá
  na výsledek vliv** a ložisko mimo všechna přiřazení se klasifikuje z limitů
  `.ndb`. Zaškrtnou-li se stejná ložiska ve dvou přiřazeních, uloží se
  **disjunktní** skupiny – ložisko zůstane v prvním přiřazení. Limity z normy
  se propíšou do konfigurace **všech** zaškrtnutých ložisek (i těch bez
  ručních limitů) a po odebrání normy se z nich zase odstraní. Karta stroje,
  přehled stavu, protokol i AI vyhodnocení tak vždy zobrazují stejné meze.
  **Od verze 1.28.5** úvod (metodika měření) i závěrečná příloha protokolu
  již neuvádějí natvrdo jednu normu (dříve „ČSN 20 816" / „ČSN ISO 20816"),
  ale **skutečně použité normy** podle přiřazení na kartách strojů (funguje
  pro režim jedna norma i více norem dle ložisek). V příloze se u každé normy
  navíc vypíšou její **mezní hodnoty rychlosti vibrací [mm/s RMS]** pro pásma
  A/B, B/C (výstraha) a C/D (alarm) včetně toho, kterých strojů/ložisek se
  týkají. Starší uložené návrhy protokolů zobrazí skutečné normy v příloze
  zpětně (dopočítají se ze strojů); dynamický úvod se týká nově vytvořených
  protokolů.
  **Od verze 1.28.6** má tvorba protokolu novou záložku **„Historie
  protokolů"**. Každý dokončený protokol se do historie uloží buď ručně
  tlačítkem **„Uložit do historie"**, nebo **automaticky při vygenerování
  PDF**. Historie se vede **samostatně pro každý podnik (databázi)** a ukládá
  **kompletní obsah protokolu** — všechny úvody (metodika), **doplňující
  pokyny pro AI**, **okruh strojů**, i **závěry a doporučení** u každého
  stroje. Uložený protokol je **zpětně vyvolatelný a plně editovatelný**:
  u každé položky lze **Otevřít / editovat** (načte celý protokol do editoru
  a další uložení nabídne přepis původní položky, nebo vytvoření nové kopie),
  **Duplikovat jako nový**, **Stáhnout PDF** přímo z uložené verze, nebo
  položku **Smazat**. Seznam ukazuje název protokolu, datum měření, verzi
  protokolu, počet strojů a čas uložení i poslední editace.
  **Od verze 1.28.7** se **náhled protokolu otevírá na nové kartě**
  prohlížeče (místo dialogového okna) – více prostoru pro prohlížení a možnost
  nechat náhled otevřený vedle editoru. V záložce **„Stroje – závěry
  a doporučení“** nově **zůstává rozbalený právě editovaný stroj** – při
  překreslení (např. po AI generování nebo přepnutí záložek) se již
  nesbalí všechno. Nad stromem strojů přibylo tlačítko **„Sbalit vše /
  Rozbalit vše“** a při přepínání záložek (karta stroje, ložiska, protokol)
  se spolehlivě **pamatuje pozice posuvníku** jednotlivých záložek.
  **Od verze 1.28.8** jsou **stavy strojů sjednocené napříč celou aplikací**
  (dashboard, stromy, normy i protokol) na **tři úrovně**: **OK** (pásmo A/B,
  zelená), **Upozornění** (pásmo C, žlutá) a **Výstraha** (pásmo D, červená).
  Celkový stav stroje v protokolu se nově **odvozuje výhradně z hodnot
  a jejich pásem zobrazených v protokolu** (rychlost H, zrychlení H, obálka H,
  stav ložiska) – už nemůže nastat rozpor typu „hodnoty A/B, ale stroj
  klasifikován jako alarm“. Při tvorbě protokolu lze navíc stav stroje
  **ručně přepsat** (rozbalovací pole „Stav stroje“ s možností *Automaticky*
  / OK / Upozornění / Výstraha); ručně nastavený stav je označen „(ručně)“
  a přepočet vyloučených bodů jej zachová.
  **Od verze 1.28.9** se v sekcích **„02 Co je potřeba řešit“** a
  **„04 Přehled všech strojů“** již nezobrazuje sloupec **PÁSMO** – stav
  stroje reprezentuje pouze **barevný puntík** (OK / Upozornění / Výstraha).
- **Ložiska a limity** — limity Varování / Alarm pro jednotlivé veličiny,
  přepínač „Klasifikovat dle limitů“ a přiřazení typu ložiska (defektní
  frekvence) pro všechna ložiska stroje. **Od verze 1.25.3** jsou karty
  jednotlivých ložisek rozdělené do **podzáložek** (jedna podzáložka na
  ložisko L1, L2…) — není tak nutné procházet dlouhým scrollem, pokud má
  stroj více ložisek. Aplikace si **pamatuje poslední zvolenou podzáložku**
  i pozici scrollu při přepínání mezi ložisky.
> **Nastavení jako záložka (od verze 1.27.0)** — Nastavení se již neotvírá jako
> dialogové okno, ale jako **samostatná záložka na hlavní stránce** s
> **podzáložkami**: **Veličiny**, **Normy**, **Technici** a **Databáze**.
> Pro přehlednost se karta stroje a karta měřicího bodu otevírají **vždy v jedné
> sdílené záložce** (otevření jiného stroje/bodu přepoužije stejnou záložku).

- **Vyhodnocení pomocí AI** — spuštění AI vyhodnocení stavu (viz níže).
  **Od verze 1.25.3** se norma a třída stroje **jen zobrazují jako informace
  pro AI** (načtené ze „Základních informací o stroji“) — samotný výběr normy
  se provádí v záložce **„Základní informace o stroji“** (viz níže).
- **Chat s diagnostikem (od verze 1.18.0)** — interaktivní dialog s AI, která
  má k dispozici kompletní podklady stroje (viz níže).
- **Adaptivní limity EWMA (od verze 1.19.0)** — v záložce „Ložiska a limity“ se
  vedle ručních limitů zobrazuje **poslední naměřená hodnota** každého směru a
  **adaptivní limit** vypočtený z historie trendu metodou EWMA (viz níže).
- **Rychlé načítání u velkých databází (od verze 1.20.0)** — optimalizace
- **Přepínatelné panely bod / protokol / stroj (od verze 1.21.0)** — kartu bodu, tvorbu protokolu a kartu stroje lze mít otevřené zároveň jako panely a přepínat mezi nimi klávesou Ctrl+Tab (nebo Ctrl+1/2/3, případně kliknutím).
  (indexy, načítání jen jednoho stroje, hromadné dotazy, WAL), které zkracují
  dobu otevření karty stroje i měřicího bodu z desítek sekund na zlomky
  sekundy (viz níže).

Mezi záložkami se přepíná kliknutím. **Změny ve všech záložkách se ukládají
najednou** tlačítkem **„Uložit kartu stroje“** — není nutné ukládat každou
záložku zvlášť.

**Fixní (ukotvená) hlavička karty (od verze 1.17.0)**

Hlavička karty stroje — **název stroje**, tlačítko **„Uložit kartu stroje“**,
vysvětlující text i samotné **záložky** — zůstává při posouvání **ukotvená
nahoře**. Skroluje se pouze obsah pod ní (formuláře, panely ložisek, měřicí
místa), takže máte tlačítko pro uložení a přepínání záložek vždy po ruce.

**Identifikační údaje stroje a obrázek**

V horní části karty je panel **„Identifikace stroje“** s doplňujícími údaji,
které se použijí na **straně stroje v PDF protokolu** (viz níže):

- **Číslo pohonu**, **technické místo**, **výkon [kW]**, **otáčky stroje
  [ot/min]**, **průměr oběžného kola [mm]** a volný **popis stroje**.
- **Obrázek stroje** — lze nahrát fotografii nebo náčrt stroje (JPG/PNG); obrázek
  se zmenší a uloží přímo do konfigurace stroje a zobrazí se na jeho straně
  v protokolu.

Všechny tyto údaje se ukládají spolu s kartou stroje (soubor
`data/machine_config.json`, vázaný na název podniku).

> **Limity jsou jen jedny — na ložisko.** Barvy teček u měřicích bodů ve stromu
> vycházejí ze stavu **vyhodnoceného v databázi** (`.ndb`). Karta stroje s tímto
> stavem pracuje jako s jediným zdrojem pravdy: výchozí prahy se **načtou
> z databáze** a teprve když je chcete změnit, zadáte vlastní hodnotu (přepis).
>
> **Sjednocené vyhodnocení závažnosti (od verze 1.25.3).** Stav bodu, ložiska
> i celého stroje — ve stromu, na přehledu (dashboard) i na kartě stroje — se
> nyní všude počítá **stejným způsobem**: porovnáním **poslední naměřené
> hodnoty** s **platným limitem** (norma → ruční přepis → výchozí hodnota
> z databáze, v tomto pořadí priority). Dříve se na některých místech používala
> syrová hodnota závažnosti z přístroje HADS (`MaxSeverityId`), která nemusela
> odpovídat vlastním nebo normou odvozeným limitům — to je nyní sjednoceno, takže
> např. adaptivně nebo ručně přepsané limity ovlivní stav bodu **všude stejně**
> (strom, dashboard, karta stroje).

**Limity (Varování / Alarm) pro více veličin**

- Pro každé ložisko lze nastavit limity **zvlášť pro každou měřenou
  veličinu** (ISO RMS, BEARING RMS, ACC RMS, ENV RMS…), **sdíleně přes
  všechny směry** (H/V/A) daného ložiska.
- U každé veličiny se zadává **Varování** (warning) a **Alarm** —
  dvě nezávislé prahové hodnoty.
- **Výchozí hodnoty z databáze** se zobrazují jako šedý náznak v poli a
  veličina je označena štítkem **„z DB"**. Vyplněním pole limit **přepíšete**
  (štítek **„vlastní"**); ponecháte-li pole prázdné, použije se hodnota z DB.
- Nastavené limity se promítají do **trendů**: v grafu trendu se vykreslí
  **vodorovné čáry** na úrovni Varování a Alarmu (s poznámkou *z DB* / *vlastní*)
  a body trendu se **obarví podle stavu**. Pod grafem přibude řádek
  **„Stav (poslední)"** s vyhodnocením poslední naměřené hodnoty.

**Klasifikovat stav dle limitů — zapnutí / vypnutí (od verze 1.15.0)**

Ne vždy dává smysl hodnotit stav podle limitů u všech veličin nebo u všech
ložisek (např. snímač byl dočasně odpojen, daná veličina není pro koncepci
stroje relevantní apod.). Proto lze klasifikaci **cíleně vypnout**:

- **U každé měřené veličiny** je v tabulce limitů sloupec **„Klasifikovat“**
  se zaškrtávacím polem. Když je odškrtnete, této veličině se **nepřiřadí
  pásmo A–D** — nezapočítá se do stavu ložiska ani do **celkového stavu
  stroje** a v protokolu zůstane bez hodnocení.
- **U celého ložiska** je v jeho hlavičce přepínač **„Klasifikovat dle
  limitů“**. Vypnutím vyřadíte z klasifikace **celé ložisko** (všechny jeho
  veličiny i směry najednou).
- **Výchozí stav je zapnuto** (klasifikuje se). Vypnutý stav se uloží do
  `data/machine_config.json` a zachová se i po restartu.

**Přiřazení ložiska (defektní ložiskové frekvence)**

- Ke každému ložisku lze přiřadit **typ ložiska** s jeho poruchovými
  frekvencemi (koeficienty **FTF / BSF / BPFO / BPFI**); přiřazení platí
  sdíleně pro všechny směry (H/V/A).
- Ložisko lze zadat dvěma způsoby:
  - **Vyhledáním v interní databázi** — tlačítkem otevřete vyhledávání,
    napíšete označení nebo typ (např. `6205`, `22312`) a volitelně filtrujete
    podle **výrobce**. Databáze obsahuje přes **31 000 ložisek** od **82
    výrobců**. Po kliknutí na záznam se koeficienty doplní automaticky.
  - **Ručním zadáním koeficientů** — pokud ložisko v databázi není, vyplníte
    FTF / BSF / BPFO / BPFI přímo do polí karty.
- Konfigurace karty se **uloží tlačítkem „Uložit"** a zachová se i po restartu
  (soubor `data/machine_config.json`, vázaný na danou databázi). Ukládají se
  **pouze vaše přepisy** — výchozí limity zůstávají v databázi.

**Otáčky stroje (na celý stroj) a jejich autodetekce**

- V kartě stroje je panel **„Otáčky stroje“** s polem **Otáčky [Hz]**. Hodnota platí
  pro **celý stroj — všechna měřicí místa** a používá se jako **výchozí otáčková
  frekvence ve spektrech** (základ pro harmonické i ložiskové značky). Pole plní
  stejnou logiku jako limity: prázdné pole = použije se hodnota z databáze (štítek
  **„z DB“** / **„nezadáno“**), vyplněním hodnotu přepíšete (štítek **„vlastní“**).
- Tlačítko **„Detekovat ze spektra“** otáčky najde **automaticky**: napříč body
  stroje projde **spektrum rychlosti vibrací (ISO SPECTRUM, mm/s)** a vybere
  frekvenci s **maximální amplitudou v rozsahu 5–70 Hz**. Detekovaná hodnota se
  předvyplní do pole (zobrazí se i bod a amplituda, ze kterých pochází) — uložíte
  ji tlačítkem **„Uložit“**. Otáčky se ukládají do `data/machine_config.json`.
- **Historie detekcí otáček** — pod polem otáček je tabulka **„Historie detekcí
  otáček“** s **posledními 5 detekcemi** provedenými tlačítkem **„Detekovat ze
  spektra“**. U každého záznamu se zobrazuje **datum a čas detekce** a **detekovaná
  hodnota [Hz]** (nejnovější nahoře, zvýrazněná). Díky tomu lze sledovat, zda se
  provozní otáčky stroje v čase nemění. Tlačítkem **„Obnovit“** u libovolného
  záznamu se daná hodnota **jedním kliknutím** vyplní do pole aktuálních otáček
  stroje (nezapomeňte ji uložit tlačítkem **„Uložit“**). Historie se ukládá
  spolu s konfigurací stroje do `data/machine_config.json`.

**Zobrazení přiřazeného ložiska ve spektru**

- Když má ložisko přiřazený typ, otevře se spektrum kteréhokoli jeho směru
  s předvolenou volbou značek **„Přiřazené ložisko (název)"** v ovládací liště.
- Po zadání **otáček [Hz]** se do spektra vykreslí značky poruchových
  frekvencí ložiska **BPFO, BPFI, BSF a FTF** včetně jejich **harmonických
  násobků** (skutečná frekvence = koeficient × otáčky). To pomáhá rychle
  ověřit, zda se ve spektru objevují složky odpovídající poškození ložiska.
- Jako výchozí otáčky ve spektru se předvyplní **otáčky stroje** (viz výše), pokud
  jsou zadány; lze je ve spektru kdykoli ručně změnit.

Databáze ložisek i konfigurace strojů fungují **plně offline** — vše je
součástí aplikace, nic se nestahuje z internetu.

### Vyhodnocení stroje pomocí AI (OpenAI / Claude)

Na **kartě stroje** je panel **„Vyhodnocení pomocí AI“**, který umožní nechat
celkový stav stroje posoudit jazykovým modelem v roli **senior vibračního
diagnostika** s mnohaletými zkušenostmi. Na výběr jsou modely od dvou
poskytovatelů — **OpenAI** i **Anthropic (Claude)**.

> **Pozor — toto je jediná funkce, která se připojuje k internetu.** Volání AI
> odesílá data stroje do zvolené služby (**OpenAI** nebo **Anthropic**) a
> **spotřebovává kredity** příslušného účtu. Veškeré ostatní funkce aplikace
> zůstávají plně offline.

**Výběr modelu**

- Vedle tlačítka pro spuštění je **rozbalovací seznam „Model AI“**, kde zvolíte
  konkrétní model. K dispozici jsou např. **OpenAI GPT-4o**, **GPT-4o mini**,
  **Anthropic Claude Sonnet 4.6**, **Claude Haiku 4.5** a **Anthropic AI Agent
  (protokol)** (viz níže).
- Modely poskytovatele, pro kterého **není nastaven API klíč**, jsou v seznamu
  **zakázané** (označené poznámkou „chybí API klíč“). Výchozí volba odpovídá
  modelu nastavenému v `data/ai_config.json`.

**Anthropic AI Agent (protokol) — od verze 1.24.0**

- Vedle přímých volání OpenAI/Anthropic Messages API je jako **další volba**
  k dispozici model **„Anthropic AI Agent (protokol)“**, který místo běžného
  API volá **samostatně nakonfigurovaného agenta v Anthropic Console** přes
  **beta Managed Agents / Sessions REST API** (`/v1/sessions`, `/v1/sessions/
  {id}/events`). Agent má svůj vlastní systémový prompt a nastavení uložené
  přímo v Console.
- Používá se hlavně pro **AI tvorbu závěrů a doporučení v protokolu** (viz níže,
  sekce „Doplňující pokyny pro AI a obrázek stroje“), lze ho ale zvolit i pro
  běžné vyhodnocení na kartě stroje či chat s diagnostikem — je zařazen do
  stejného seznamu modelů.
- **Nic se instalovat nemusí** — stejně jako ostatní modely volá Anthropic
  API přímo přes vestavěnou knihovnu `urllib` (žádný balíček `anthropic`
  ani jiná závislost). Používá **stejný `ANTHROPIC_API_KEY`** jako ostatní
  Claude modely — klíč navíc musí mít povolený přístup k beta Managed
  Agents API v Anthropic Console (jinak volání skončí chybou).
- Identifikátory `agent_id` a `environment_id` jsou nakonfigurovány jako
  konstanty (`AI_AGENT_ID`, `AI_AGENT_ENVIRONMENT_ID`) v `backend/ai_eval.py` —
  pokud v Console vytvoříte nového agenta nebo prostředí, je potřeba tyto
  konstanty ručně aktualizovat.
- Odpověď agenta se získává opakovaným dotazováním („polling“) na stav
  session cca každou 1–2 sekundy, dokud není hotovo (nebo do 180 s), takže
  odpověď může trvat o něco déle než u přímých Claude/OpenAI modelů.

**Jak to funguje**

1. **Otáčky** — použijí se **aktuální otáčky** z pole „Otáčky stroje“ (lze je
   zadat ručně, vybrat z historie nebo detekovat ze spektra). Pokud pole zůstane
   prázdné, použije se hodnota z databáze.
2. **Norma pro hodnocení rychlosti vibrací** — normu **ČSN ISO 20816-3**,
   **třídu stroje** (Skupina 1/2, tuhý/pružný základ) a volitelně **vlastní
   poznámku** s dodatečným kontextem nastavíte v záložce **„Základní
   informace o stroji“** (od verze 1.25.3 — dříve se nastavovalo přímo zde).
   AI panel zde normu a třídu **jen zobrazuje jako informaci pro AI** spolu
   s **orientačními limity** rychlosti vibrací dle normy: **Varování (pásmo
   B/C)** a **Alarm (pásmo C/D)** v mm/s RMS.
3. **Sestavení promptu** — aplikace shromáždí **poslední měření a krátký trend**
   (posledních ~5 hodnot) všech veličin na všech měřicích bodech, jejich
   **nastavené limity** (Varování / Alarm), **přiřazená ložiska** a otáčky a
   sestaví z nich strukturovaný dotaz pro AI.
4. **Vyhodnocení** — tlačítkem **„Vyhodnotit pomocí AI“** se dotaz odešle do
   zvoleného modelu. AI vrátí strukturovaný závěr ve čtyřech částech:
   **1) ZÁVĚR**, **2) HODNOCENÍ RYCHLOSTI VIBRACÍ dle normy** (porovnání s pásmy
   normy), **3) MOŽNÉ ZÁVADY** a **4) DOPORUČENÍ**.

**Automatické propsání limitů normy do měřicích bodů**

- Když je u stroje nastavena **třída dle ISO 20816-3**, limity normy se po
  **uložení karty stroje** **automaticky propíšou** do limitu veličiny
  **„ISO RMS“** (rychlost vibrací) **každého měřicího bodu** stroje.
  - **Varování** = horní mez pásma **B/C**, **Alarm** = horní mez pásma **C/D**.
- Takto odvozené limity jsou v kartě označeny příznakem **„z normy“**. Původní
  limity z databáze zůstávají zachované a v případě zrušení normy se obnoví.

**Závěry a doporučení na kartě stroje**

- Výsledek se **zobrazí přímo na kartě stroje** spolu s informacemi o čase
  vyhodnocení, použitých otáčkách, normě a **použitém modelu**.
- Vyhodnocení se **automaticky uloží** (soubor `data/machine_config.json`)
  a po opětovném otevření karty se znovu zobrazí. Data jsou vázána na
  **název podniku** (viz níže), nikoli na jméno souboru — zůstávají proto
  zachována i po opětovném načtení nebo přejmenování databáze.
- Tlačítkem **„Upravit závěr“** lze text **ručně upravit** (např. doplnit vlastní
  poznámky diagnostika) a uložit tlačítkem **„Uložit úpravy“**. Ručně upravené
  vyhodnocení je označeno štítkem **„ručně upraveno“**.

**Historie vyhodnocení a zpětné vyvolání**

- **Každé** AI vyhodnocení (i ručně upravené) se **automaticky ukládá do
  historie** stroje a zůstává k dispozici i po opětovném otevření databáze.
- Pod výsledkem je seznam **„Historie vyhodnocení“** (od nejnovějšího), kde má
  každý záznam štítky s **datem a časem**, **použitým modelem** a **normou**,
  krátký náhled textu a tlačítko **„Zobrazit“**.
- Tlačítkem **„Zobrazit“** lze libovolné starší vyhodnocení **zpětně vyvolat** a
  nastavit jako aktuálně zobrazené (aktivní záznam je označen jako „Zobrazeno“).
  Historie tak umožňuje porovnat např. výstupy různých modelů nad stejnými daty.

**Nastavení přístupových klíčů (OpenAI / Anthropic)**

- V **Nastavení → AI agenti** každá karta ukáže pouze **„Klíč je nastaven“**
  nebo **„Klíč není nastaven“**. Vstup je prázdný `password` input; po uložení
  ho HADS vyčistí a nikdy jej nepředvyplní, nemaskuje ani nevrací přes API.
  Prázdné pole nic nemění. Klíč se odstraní jen samostatným tlačítkem
  **„Odstranit klíč…“** a výslovným potvrzením.
- `data/ai_config.json` od verze 1.35.0 obsahuje pouze ne-secret metadata
  (`schema`, `model`). Historický plaintext klíč se při prvním použití atomicky
  převede, ověří a z konfigurace odstraní.
- Na Windows je ciphertext v `data/ai_credentials.bin` chráněn správně
  typovaným **Windows DPAPI CryptProtectData/ CryptUnprotectData** se scope
  **LocalMachine**, zakázaným UI a entropií instalace. Blob funguje pouze na
  stejném Windows počítači; aktualizace jej ponechávají, ale standardní plný,
  update i sdílený balíček jej nikdy neobsahují.
- Na jiných systémech Python standardní knihovna neposkytuje OS keychain.
  HADS proto používá 0600 šifrovaný blob a oddělený 0600 lokální klíč,
  kryptograficky svázaný s identitou počítače; proces nebo uživatel, který
  může číst oba soubory na stejném počítači, klíč obnoví. Pro přísnější provoz
  nastavte místo toho proměnné prostředí **`OPENAI_API_KEY`** a
  **`ANTHROPIC_API_KEY`**, které mají přednost.
- Volitelný nástroj `tools/export_internal_ai_credentials.py` se spouští jen
  s explicitním `--source-install` a
  `--i-understand-same-windows-computer`. Vytvoří nepodepsanou interní zálohu
  pouze DPAPI ciphertextu pro stejný PC, nikdy plaintext. Není součástí
  běžného ani sdíleného zákaznického vydání; na jiném PC je nutné klíče zadat
  znovu (nebo použít budoucí centrální secret service).
- Model **„Anthropic AI Agent (protokol)“** používá **stejný** `ANTHROPIC_API_KEY`
  jako ostatní Claude modely — žádný samostatný klíč se nekonfiguruje.

### Chat s diagnostikem — dialog s AI nad daty stroje (od verze 1.18.0)

Na **kartě stroje** je záložka **„Chat s diagnostikem“**, která umožňuje vést
**interaktivní dialog** s AI v roli **senior vibračního diagnostika**. Na rozdíl
 od jednorázového „Vyhodnocení pomocí AI“ lze klást **navazující dotazy** a
upřesňovat odpovědi.

> **Pozor — tato funkce se připojuje k internetu.** Každý dotaz odesílá podklady
> stroje a historii konverzace do zvolené služby (**OpenAI** nebo **Anthropic**)
> a **spotřebovává kredity** příslušného účtu.

**Jaká data má AI k dispozici**

Při každém dotazu dostane AI **kompletní podklady tohoto stroje** — stejně jako
u „Vyhodnocení pomocí AI“ (režim **plný kontext předem**):

- **poslední měření a krátký trend** všech veličin na všech měřicích bodech,
- jejich **nastavené limity** (Varování / Alarm),
- **přiřazená ložiska** a jejich defektní frekvence,
- **otáčky** a **norma** (přebírají se z otáček stroje a ze záložky „Základní
  informace o stroji“, od verze 1.25.3),
- **obrázek stroje** z karty (pokud je nahraný) — pro modely s podporou vidění.

AI tak může odpovídat na dotazy typu **„Jaký je celkový stav stroje?“**, **„Co
může způsobovat zvýšené hodnoty na ložisku L1?“** nebo **„Jak interpretovat
FFT spektrum?“** — vždy s ohledem na konkrétní naměřená data.

**Ovládání**

- Dotaz napíšete do pole dole a odešlete tlačítkem **„Odeslat“** nebo klávesou
  **Enter** (**Shift+Enter** vloží nový řádek).
- **Model AI** se volí v roletce nad oknem konverzace (stejná nabídka jako u
  vyhodnocení; nedostupné modely bez API klíče jsou zakázané).
- Tlačítkem **„Vymazat konverzaci“** začnete dialog znovu.

**Poznámka:** Historie chatu se **neukládá** — je vedena pouze dočasně v paměti
prohlížeče a po opuštění stroje (otevření jiného stroje) se vymaže. Pro trvalý
záznam závěru použijte záložku „Vyhodnocení pomocí AI“, která výsledky ukládá
do historie stroje.

### Adaptivní limity vibrací (EWMA) a poslední naměřená hodnota (od verze 1.19.0)

V záložce **„Ložiska a limity“** na kartě stroje se vedle nastavených ručních
limitů (Varování / Alarm) zobrazují dvě nové informace pro každou měřenou
veličinu:

- **Poslední naměřená hodnota** — samostatně pro **každý směr / měřicí bod**
  ložiska (H / V / A). Zobrazuje se v rozbalených řádcích pod každou veličinou
  (např. „poslední: 0,0911“).
- **Adaptivní limit (EWMA)** — orientační návrh limitů Varování / Alarm
  vypočtený **z historie trendu** dané veličiny.

**Co je EWMA**

Adaptivní limity se počítají metodou **EWMA** (Exponentially Weighted Moving
Average — exponenciálně vážený klouzavý průměr). Z historie trendu každého
směru se průběžně počítá:

- **vyhlazený průměr** \(S_t = \lambda \cdot x_t + (1-\lambda)\cdot S_{t-1}\),
- a **vyhlazená směrodatná odchylka** \(\sigma\).

Adaptivní limity jsou pak:

- **Varování** \(= S_t + L_{var}\cdot\sigma\),
- **Alarm** \(= S_t + L_{alarm}\cdot\sigma\).

Limit se tedy **sám přizpůsobuje** chování konkrétního stroje — nevychází
z obecné tabulky, ale z toho, jak se daná veličina **historicky chová**.

**Pro které veličiny se počítají**

Adaptivní limity se počítají pro **všechny statické (skalární) veličiny mimo
rychlost vibrací** (RMS rychlosti / ISO). Rychlost vibrací totiž řeší norma
**ČSN ISO 20816** a má jasně dané absolutní hranice pásem — u ní se proto
v tabulce zobrazuje pouze poznámka **„řeší norma“**.

**Nastavitelné parametry (společné pro celý stroj)**

V panelu **„Adaptivní limity (EWMA)“** v záložce „Ložiska a limity“ lze nastavit:

- **λ (rychlost adaptace)** — výchozí **0,2**. Nižší hodnota = pomalejší,
  hladší přizpůsobení; vyšší = rychlejší reakce na poslední měření.
- **L pro Varování** — násobitel směrodatné odchylky pro úroveň Varování
  (výchozí **3**).
- **L pro Alarm** — násobitel směrodatné odchylky pro úroveň Alarm
  (výchozí **4**).
- **Min. počet měření** — kolik bodů musí trend mít, jinak se limit nepočítá
  (výchozí **8**). Při menším počtu se zobrazí **„málo dat“**.
- **Počítat adaptivní limity** — zapnutí / vypnutí celého výpočtu.

Parametry jsou **společné pro celý stroj** a ukládají se spolu s kartou stroje
tlačítkem **„Uložit kartu stroje“**.

**Tlačítko „Převzít“**

U každé veličiny (mimo rychlost) je tlačítko **„Převzít“**, které **zkopíruje
adaptivní hodnoty Varování / Alarm do ručního limitu** daného ložiska (bere se
nejvyšší hodnota napříč směry, protože ruční limit je sdílený přes směry).
Hodnoty se vloží do polí ručních limitů — uložíte je tlačítkem „Uložit kartu
stroje“.

> **Adaptivní limity jsou pouze orientační (informativní).** Skutečnou
> **klasifikaci stavu** (pásma A–D) i nadále řídí **ruční limity**, případně
> norma. Adaptivní limit se do klasifikace promítne až tehdy, když ho tlačítkem
> „Převzít“ převezmete do ručního limitu a kartu stroje uložíte.

Výpočet probíhá **lokálně, offline** nad uloženou historií trendu z databáze
`.ndb` — nepřipojuje se k internetu a nespotřebovává žádné kredity.

### AI poradce pro diagnostiky — lokální vyhodnocení měřicího bodu

Kromě celkového posouzení na kartě stroje nabízí aplikace **AI poradce přímo na
úrovni jednotlivého měřicího bodu**. Slouží k tomu, aby bylo možné v případě
**zvýšených hodnot vibrací na konkrétním ložisku** provést **lokální vyhodnocení
problému** — obdobně jako na kartě stroje, ale zaměřené pouze na daný bod a jeho
ložisko. AI zde vystupuje jako **rádce pro diagnostiky**.

Panel **„AI poradce pro diagnostiky — lokální vyhodnocení bodu“** se zobrazuje
v **detailu měřicího bodu**, pod trendy a spektry. Skládá se ze tří částí:
otáčky, přiřazené ložisko a samotné AI vyhodnocení.

> **Pozor — volání AI se připojuje k internetu** a **spotřebovává kredity**
> příslušného účtu (OpenAI / Anthropic), stejně jako vyhodnocení na kartě stroje.
> Veškeré ostatní funkce zůstávají plně offline.

**Otáčky pro diagnostiku bodu (autodetekce nebo ruční zadání)**

- Pod grafy je panel **„Otáčky pro diagnostiku bodu“** s polem **Otáčky [Hz]**.
- Tlačítkem **„Detekovat ze spektra“** aplikace **automaticky najde otáčky** podle
  **maximální amplitudy spektra rychlosti** tohoto bodu v rozsahu **5–70 Hz**.
- Otáčky lze rovněž **zadat ručně**. Pokud pole zůstane prázdné, použijí se
  otáčky **z karty stroje / databáze**.
- Zadané/detekované otáčky se použijí pro **přepočet defektních frekvencí
  ložiska do Hz** a vloží se do promptu pro AI.
- Vede se **historie detekcí otáček** (datum, čas a hodnota) s možností starší
  hodnotu **„Obnovit“**.

**Přiřazené ložisko a jeho defektní frekvence**

- Panel **„Přiřazené ložisko“** zobrazuje ložisko přiřazené danému měřicímu místu
  (a směru) **na kartě stroje** — jeho **označení, výrobce a typ**.
- Zobrazí se **defektní frekvence ložiska**: **FTF** (klec), **BSF** (valivý
  element), **BPFO** (vnější kroužek) a **BPFI** (vnitřní kroužek) — a to jak
  v **násobcích otáček (×ot)**, tak **přepočtené do Hz** podle aktuálně zadaných
  otáček (`f [Hz] = koeficient ×ot × otáčky [Hz]`).
- Pokud ložisko zatím není přiřazeno, panel na to upozorní a odkáže na **kartu
  stroje**, kde se ložisko přiřazuje.

**Vyhodnocení bodu pomocí AI**

- Stejně jako na kartě stroje je k dispozici **rozbalovací seznam „Model AI“**
  (OpenAI GPT-4o, GPT-4o mini, Anthropic Claude Sonnet 4.6, Claude Haiku 4.5);
  modely bez nastaveného API klíče jsou zakázané.
- **Norma** se **dědí ze záložky „Základní informace o stroji“** (ČSN ISO
  20816-3 a třída stroje, od verze 1.25.3) — není potřeba ji zadávat znovu.
  Pokud na kartě stroje norma nastavena není, AI použije obecné principy
  ČSN ISO 20816.
- Po stisku **„Vyhodnotit bod pomocí AI“** aplikace sestaví **prompt zaměřený na
  daný bod**: poslední hodnoty a krátký trend všech veličin bodu, jejich limity,
  **přiřazené ložisko a jeho defektní frekvence (v Hz)**, otáčky a normu. AI vrátí
  strukturovaný závěr (**1) ZÁVĚR**, **2) HODNOCENÍ RYCHLOSTI VIBRACÍ**, **3) MOŽNÉ
  ZÁVADY** se zaměřením na ložisko, **4) DOPORUČENÍ**).

**Ukládání, úpravy a historie**

- Každé vyhodnocení bodu se — stejně jako na kartě stroje — **automaticky ukládá**
  (soubor `data/machine_config.json`, vázáno na **název podniku**) a po opětovném
  otevření bodu se znovu zobrazí.
- Závěr lze **ručně upravit** a uložit; ručně upravené vyhodnocení je označeno.
- Vede se **historie vyhodnocení bodu** (od nejnovějšího) se štítky data, modelu
  a normy a možností starší vyhodnocení **zpětně vyvolat** — lze tak porovnat
  např. výstupy různých modelů nad stejnými daty bodu.

### Podnik (údaje o závodu)

Každá databáze `.ndb` představuje **jeden podnik**. V hlavičce aplikace je
tlačítko **„Podnik“**, které otevře dialog s údaji o podniku vázanými na
**aktuálně načtenou databázi**:

- **Název podniku**
- **Adresa**
- **Kontaktní osoba** (jméno, telefon, e-mail)

Údaje se ukládají do souboru **`data/company.json`** a po opětovném otevření se
předvyplní. Při přepnutí na jinou databázi se zobrazí údaje příslušného podniku.

**Párování dat s podnikem (důležité)**

Všechna ukládaná data (údaje o podniku, AI vyhodnocení a jejich historie, karty
strojů) se vážou na **název podniku** — ten je dán **prvním uzlem ve stromovém
adresáři databáze** (kořenový uzel typu závod/skupina, např. `MND`). Nikoli
na jméno souboru `.ndb`. Díky tomu:

- Data **zůstanou spárovaná** i když totéž databázi **znovu načtete** (i když
  aplikace soubor uloží pod jiným jménem, např. `DDS_ukazka (2).ndb`) nebo
  soubor **přejmenujete**.
- Pokud databáze nemá kořenový uzel, použije se jako záloha název trasy a
  teprve nakonec jméno souboru.
- Data uložená dřívějšími verzemi (která byla vázána na jméno souboru) se při
  prvním načtení databáze **automaticky převedou** na nový klíč podle názvu
  podniku, takže se neztratí.

### Nastavení databáze — veličiny protokolu a jména techniků (od verze 1.25.15)

V hlavičce aplikace je tlačítko **„Nastavení“**, které otevře dialog s
nastavením vázaným na **aktuálně načtenou databázi (podnik)**. Nastavení se
ukládá do souboru **`data/report_settings.json`** (klíčováno názvem podniku,
stejně jako údaje o podniku) a použije se při tvorbě protokolu.

**1) Veličiny do tabulek protokolu**

U některých databází se na měřicích bodech vyskytuje **více měřených veličin**
(např. `ISO RMS`, `ACC RMS 10 - 6400 Hz`, `ACC ENV RMS 500 Hz`,
`ACC ENV RMS 1 kHz`, `BEARING RMS` …). V dialogu lze pro danou databázi
**předem určit**, které měřené veličiny se v tabulkách protokolu berou jako:

- **Rychlost vibrací [mm/s]**
- **Zrychlení [g]**
- **Obálka zrychlení [g]**

Každé pole je rozbalovací seznam naplněný **skutečnými veličinami z aktuální
databáze**. První položka `(výchozí – …)` znamená, že se použije **výchozí**
veličina (u obálky navíc funguje i automatický výběr podle typu ložiska).
Nevyplněné pole = výchozí chování jako v předchozích verzích. Díky tomu je
**předem jasné**, které veličiny se do protokolu dostanou, i když databáze
obsahuje více variant měření.

**2) Jména techniků**

Do seznamu lze vložit **jména techniků** (např. `Ing. Lukáš Heisig, Ph.D.`).
Seznam se pak nabídne jako **výběr (auto-doplňování)** v polích **Vypracoval**,
**Měřil** a **Schválil** při tvorbě protokolu — stačí kliknout do pole a vybrat
ze seznamu, případně dopsat ručně. Jména lze přidávat a mazat; duplicity se
ignorují bez ohledu na velikost písmen.

### Protokol z měření (PDF)

Aplikace umí z naměřených dat vygenerovat **kompletní protokol z měření ve
formátu PDF** — vhodný k předání zákazníkovi. Protokol otevřete tlačítkem
**„Protokol“** v hlavičce aplikace.

**1) Výběr okruhu strojů (podle data měření)**

Do protokolu se zahrnou stroje podle zvoleného **okruhu**:

- **Posledních N dní** — stroje měřené v posledních N dnech (výchozí 3 dny).
- **Poslední týden** — stroje měřené za posledních 7 dní.
- **Konkrétní datum** — stroje měřené v jeden zvolený den.
- **Všechny měřené** — všechny stroje s naměřenými daty.

Okruh se vyhodnocuje podle **data posledního měření** každého stroje. Stroje bez
naměřených dat se do protokolu nezahrnují.

**1b) Výběr verze protokolu (od verze 1.22.0, verze 3 od 1.25.5)**

V sekci „1) Okruh strojů a vytvoření návrhu“ je k dispozici výběr „Verze
protokolu“ se třemi šablonami. Úvodní strana (dashboard) a strana se souhrnnou
tabulkou všech strojů jsou u VŠECH verzí naprosto stejné — liší se způsob,
jakým protokol prezentuje jednotlivé stroje a grafy:

- **Verze 1 — stručná (výchozí)** — jen stroje se stavem Výstraha nebo
  Alarm dostanou vlastní detailní stranu (jeden stroj = jedna nová
  strana), s obrázkem stroje, sjednocenou tabulkou (jeden řádek na
  ložisko s nejvyšší hodnotou rychlosti přes směry) a grafy vykreslenými
  hned pod tabulkou daného stroje.
- **Verze 2 — detailní** — ÚPLNĚ VŠECHNY stroje v okruhu (včetně těch v
  pořádku) se objeví v sekci „Hodnocení technického stavu“, kde jsou
  jejich kompaktní bloky (bez obrázku stroje) řazeny plynule za sebou —
  nový stroj nezačíná automaticky na nové stránce, ale pokračuje tam, kde
  skončil předchozí, a stránka se zalomí jen tehdy, když se blok stroje už
  nevejde. Tabulka má navíc sloupec minulá s předchozí hodnotou rychlosti
  vibrací pro přímé porovnání vývoje. Všechny grafy (trendy a FFT spektra)
  jsou u této verze vyňaty ze sekce hodnocení a vykreslují se souhrnně až v
  samostatné příloze na konci protokolu (viz bod 5d).
- **Verze 3 — vyvažování (od verze 1.25.5)** — varianta detailního protokolu
  určená pro **protokol z vyvažování rotorů** (zpravidla ventilátorů).
  Sekce „Zhodnocení vyvažování“ ukazuje pro každý vyvažovaný stroj tabulku
  s **rychlostí PŘED vyvážením (vel_prev) i PO vyvážení (vel_cur)** včetně
  **pásem A–D obou měření** a se sloupcem **procentuální úspěšnosti
  vyvážení** ((vel_prev − vel_cur) / vel_prev × 100 %). Hodnotí se i **stav
  ložisek** (zrychlení, obálka, klasifikace). AI závěr má pevnou strukturu
  do **3 číslovaných bodů** (pokles pásma → FFT rychlosti po vyvážení →
  stav ložisek + provozní stav). Grafy z přílohy se vykreslují stejně jako u
  verze 2 a **na konec přílohy lze volitelně vložit externí obrázek**
  (JPEG / PNG) — typicky **graf polarích vektorů (CR1/IR/TR) exportovaný
  z měřicího přístroje**. Pole pro upload a popisek se zobrazí v editoru až po
  přepnutí na verzi 3.

Zvolená verze se ukládá spolu s návrhem protokolu a při opětovném otevření se
znovu načte.

**Diagnostika AI závěrů (od verze 1.28.4).** Když je zaškrtnuto „Doplnit AI
závěry a doporučení", ale pole Závěry / Doporučení zůstanou prázdná, aplikace
nyní **jasně uvede důvod** (dříve se případná chyba tichě spolkla a uživatel
nedostal žádnou zpětnou vazbu). Po vytvoření návrhu se zobrazí upozornění
(toast i stavový řádek) s konkrétním důvodem per stroj, např.:
- **chyba API modelu** (např. neplatný klíč, rate limit 429, timeout) — včetně
  hlášky od poskytovatele,
- **stroj nemá data měření** vhodná pro AI vyhodnocení,
- **AI vrátila prázdný závěr** — doporučí generování zopakovat, případně
  změnit model.

Hláška rozlišuje, zda se závěry nepodařily pro **žádný** stroj, nebo jen pro
**některé** (u zbytku vznikly normálně). Nastínuje tím, kde problém hledat —
typicky v nastavení API klíče v sekci AI, nebo v tom, že vybraný stroj nemá
k danému datu žádná měření.

**1c) Ruční výběr konkrétních strojů (od verze 1.23.0)**

Okruh dle data (bod 1) určuje jen **výchozí** nabídku strojů. Pod ním se v
**panelu „Výběr konkrétních strojů (volitelné)“** zobrazí **seznam všech
strojů, které mají alespoň jedno měření**, seskupený podle **podniku /
závodu**, každý s vlastním zaškrtávacím políčkem. To řeší případ, kdy je
potřeba vyhodnotit v protokolu jen některé stroje jednoho podniku, bez ohledu
na datum jejich posledního měření.

- Seznam se **automaticky předvyplní** dle zvoleného okruhu (stroje, které
  okruh dle data již vybral, jsou předem zaškrtnuté).
- Změnou okruhu (režimu, počtu dní nebo konkrétního data) se seznam
  **znovu načte a předvyplní** dle nového okruhu (ruční úpravy se tím
  vynulují).
- Uživatel může libovolný stroj **přidat nebo odebrat** zaškrtnutím, bez
  ohledu na to, zda spadá do aktuálního okruhu dle data.
- Tlačítka **„Vybrat vše“** a **„Zrušit výběr“** umožňují rychle zaškrtnout
  nebo odzaškrtnout všechny zobrazené stroje najednou.
- Do protokolu se při vytvoření návrhu zahrnou **právě ty stroje, které jsou
  v okamžiku kliknutí na „Vytvořit návrh protokolu“ zaškrtnuté** — pokud
  uživatel výběr nijak neupravil, použije se beze změny původní okruh dle
  data.

**2) Hlavička protokolu (editovatelná)**

Na **úvodní straně** protokolu jsou údaje, které se předvyplní a lze je upravit:

- **Název a adresa podniku** (převezmou se z údajů o podniku, viz výše),
- **Název protokolu**, **číslo zakázky** a **číslo objednávky**,
- **Termín vytvoření** (automaticky dnešní datum) a **termín měření**
  (automaticky odvozený z dat zvoleného okruhu),
- **Měřil** a **Schválil** — pole *Schválil* je předvyplněno na
  **Ing. Lukáš Heisig, Ph.D. CTD**.

> **Dva technici u pole Měřil (od verze 1.25.15).** Měření mohli provést
> až **dva technici** — pole *Měřil* proto obsahuje **dvě jména** (1. a 2.
> technik, druhé je volitelné). V PDF se obě jména zobrazí na jednom řádku
> oddělená čárkou (např. `Jan Novák, Petr Svoboda`). Pole *Vypracoval*,
> *Měřil* i *Schválil* nabízejí **auto-doplňování jmény techniků** uloženými
> v Nastavení databáze (viz sekce „Nastavení databáze“ výše).

**3) Úvod (editovatelný)**

Pod hlavičkou je **úvodní text** protokolu, který je předvyplněn obvyklou
formulací (rozsah a účel měření) a lze jej libovolně přepsat.

**4) Strana 1 — manažerský dashboard (stavový přehled)**

Hned **první strana** protokolu je navržena pro rychlé rozhodování — zákazník
nemusí listovat dlouhým protokolem, aby zjistil, co je důležité. Obsahuje:

- **Logo HEISTECH** v levém horním rohu hlavičky (místo dřívějšího textu) a
  popisek **„PROTOKOL Z MĚŘENÍ VIBRACÍ“** vpravo nahoře. **Název zprávy** je
  umístěn jako velký nadpis **pod hlavičkou**.
- **Dvouřádkový pás údajů** pod nadpisem: zákazník (s adresou, pokud je
  vyplněna), **místo měření** (pokud je vyplněno), číslo zakázky a **rámcová
  smlouva** v prvním řádku; ve druhém řádku **kdo měření provedl**, **kdo jej
  schválil**, **termín měření** a **vyhotoveno** (datum vytvoření protokolu).
  **Oba řádky mají shodně široké sloupce, takže jsou pole přesně zarovnaná pod
  sebou** (MÍSTO MĚŘENÍ pod SCHVÁLIL, ČÍSLO ZAKÁZKY pod TERMÍN MĚŘENÍ, RÁMCOVÁ
  SMLOUVA pod VYHOTOVENO). Poslední sloupec je zarovnaný k pravému okraji, aby
  text nepřetékal. Mezi hlavičkou s logem a názvem zprávy je větší mezera pro
  lepší čitelný odstup.
- **Stavový přehled (semafor + KPI metriky)** — karty s počty strojů:
  celkem, v pořádku (provoz), alarm a výstraha, doplněné **vodorovným
  pruhem rozdělení** strojů podle nejhoršího pásma závažnosti. **Legenda je
  vizuálně oddělena** pod pruhem, aby s ním nesplývala.
- **Akční tabulka „Co je potřeba řešit“** — **prioritizovaný seznam pouze
  kritických strojů** (Výstraha / Alarm) **řazený podle závažnosti** s
  uvedením stavu, nejhoršího pásma a doporučené akce. **Každý řádek stroje je
  klikací odkaz** — kliknutím v PDF se přesunete přímo na **detailní stranu
  daného stroje**. Pokud žádný stroj není kritický, zobrazí se zelené shrnutí,
  že je vše v pořádku.

**5) Strana 2 — metodika a souhrn všech strojů**

Druhá strana obsahuje **Metodiku měření** — úvodní text protokolu (rozsah a
účel měření, způsob vyhodnocení), editovatelný před vygenerováním — a dále
**sekci 04**, jejíž obsah se od verze 1.23.0 **liší podle zvolené verze
protokolu**:

- **Verze 1 — „04 Přehled všech strojů“** (beze změny) — souhrnná tabulka
  VŠECH strojů v okruhu, jeden řádek na stroj se **stavem**, **nejhorším
  pásmem A/B/C/D**, **datem měření** a stručným **doporučením / poznámkou**.
  Tabulka je **řazená podle závažnosti** (nejprve problémové stroje). Stroje
  v pořádku (pásmo A/B) se objeví **pouze zde**.
- **Verze 2 — „04 Závěry a doporučení“** (od verze 1.23.0) — stejná sekce
  je přejmenovaná a přepracovaná: místo tabulky se pro každý stroj v okruhu
  (řazeno dle závažnosti) zobrazí blok s barevnou tečkou stavu, názvem stroje
  a štítkem nejhoršího pásma A/B/C/D, ale **bez sloupce s datem měření** a
  **bez obrázku stroje**. Místo stručné poznámky se vypíše **celý text závěru
  i celý text doporučení** (stejná data jako na detailní straně stroje v bodě
  5b), bez zkracování. Pokud u stroje není vyplněn závěr ani doporučení,
  zobrazí se náhradní text („V pořádku — bez nutnosti zásahu.“ pro stroje
  v pořádku, „Neměřeno.“ pro stroje bez měření). Sekce může při větším
  počtu strojů přetéct na další stranu/strany — stránkování navazujících
  sekcí protokolu se tomu automaticky přizpůsobí.

**5b) Detailní strana strojů (obsah závisí na zvolené verzi protokolu)**

Podoba této části protokolu se řídí volbou „Verze protokolu“ popsanou výše
(bod 1b). Klasifikace A/B/C/D a blok závěru/doporučení jsou u obou verzí
založené na stejném principu, ale rozvržení stránky, rozsah strojů a
umístění grafů se liší:

- **Klasifikace A/B/C/D dle ČSN ISO 20816** — každá hodnota je zařazena do
  pásma A (dobrý / nový stroj), B (přijatelný pro dlouhodobý provoz),
  C (nevyhovující pro dlouhodobý provoz) nebo D (nebezpečí poškození).
  Pásma jsou v tabulkách barevně odlišena.
- **Závěr a doporučení** — závěr je vysázen na šířku tabulky, doporučení
  pak na celou šířku stranky pod ním. Při generování návrhu protokolu nechá
  aplikace u každého problémového stroje vytvořit velmi stručný závěr a
  doporučení pomocí AI (vyžaduje nastavený API klíč). Oba texty lze ručně
  upravit.

Obě verze používají stejnou sjednocenou tabulku — jeden řádek na
ložisko (místo) s rychlostí, zrychlením a obálkou [g] výhradně v
horizontálním směru H a stavem ložiska. Pásmo
(barevná klasifikace A–D) se zobrazuje pouze u rychlosti a u stavu ložiska
— u zrychlení a obálky se záměrně neuvádí. Rozdíl mezi verzemi je v rozvržení:

**Verze 1 — stručná (výchozí): „Detailní strana stroje“**

- Vlastní detailní stranu dostanou pouze stroje se stavem Výstraha nebo
  Alarm (stroje v pořádku zůstávají jen v souhrnné tabulce). Každý stroj
  začíná na nové stránce.
- Hlavička stroje obsahuje název, barevný proužek stavu, stavový štítek,
  základní informace z karty stroje (číslo pohonu, technické místo,
  výkon, otáčky, průměr oběžného kola, norma, datum posledního měření) a
  obrázek stroje vpravo, pokud byl nahrán. Text závěru a doporučení vždy
  začíná až pod obrázkem, takže se s ním nepřekrývá.
- Tabulka neobsahuje sloupec s předchozí hodnotou rychlosti.
- Grafy (trendy a FFT spektra) vybrané u daného stroje se vykreslují
  hned pod jeho tabulkou, na téže nebo bezprostředně následující straně.

**Verze 2 — detailní: sekce „Hodnocení technického stavu“**

- Tato sekce zahrnuje úplně všechny stroje v okruhu, včetně těch
  v pořádku, a jejich kompaktní bloky (barevný proužek stavu, název,
  otáčky, umístění a datum měření na jednom řádku, poté tabulka) plynou
  za sebou — stroj nezačíná automaticky na nové stránce, pokračuje
  přímo pod předchozím, dokud se na stránku vejde. Stránka se zalomí jen
  tehdy, když by se celý blok stroje už nevešel.
- Obrázek stroje se v této sekci nezobrazuje, ani když je na kartě
  stroje nahraný — bloky jsou proto výrazně kompaktnější než u verze 1.
- Tabulka má navíc sloupec minulá s předchozí naměřenou hodnotou
  rychlosti (stejný směr jako aktuální maximum) hned vedle aktuální, pro
  rychlé posouzení vývoje v čase.
- Grafy (trendy a FFT spektra) se v této sekci nevykreslují — pro
  všechny stroje jsou souhrnně přesunuty do samostatné přílohy na konci
  protokolu (viz bod 5d), podobně jako v koncepci referenčního protokolu.

> **Pozor:** generování závěru a doporučení používá AI, a proto se (stejně jako
> vyhodnocení na kartě stroje) připojuje k internetu a spotřebovává kredity
> příslušného účtu. Pokud AI nevyužijete, můžete texty napsat ručně.

**Doplňující pokyny pro AI a obrázek stroje (od verze 1.15.0)**

V sekci **„1) Okruh strojů a vytvoření návrhu“** je pod volbou **„Doplnit AI
závěry a doporučení“** pole **„Doplňující pokyny pro AI (volitelné)“**. Sem lze
zapsat **vlastní kontext a pokyny**, které se přidají do promptu pro AI závěry,
např.:

- za jakých **podmínek se měřilo** (za provozu / za klidu, jmenovité otáčky…),
- jaké **stroje / koncepce** se měřily (čerpací soustrojí, převodovka, ventilátor…),
- **co přesně vyhodnotit a co ne** vzhledem ke koncepci stroje (např. „obálku
  zrychlení nehodnoť, snímač byl dočasně odpojen“).

Navíc, pokud je u stroje na jeho **kartě nahrán obrázek** (fotografie nebo náčrt),
přidá se tento **obrázek do promptu pro AI** (vision), aby model lépe pochopil
koncepci stroje. Vyžaduje model s podporou obrázků (např. OpenAI GPT-4o,
Anthropic Claude nebo **Anthropic AI Agent (protokol)**). Pokyny se ukládají
spolu s návrhem protokolu a při opětovném otevření protokolu se znovu načtou.

**Výběr AI modelu pro protokol (od verze 1.25.0)**

Vedle pole „Doplnit AI závěry a doporučení“ je v sekci „1) Okruh strojů a
vytvoření návrhu“ rozbalovací seznam **„AI model pro protokol“**, kterým se
vybírá, jaký model připraví závěr a doporučení pro každý stroj v protokolu.
Nabízené modely jsou stejné jako u běžného vyhodnocení na kartě stroje
(OpenAI GPT-4o/mini, Anthropic Claude Sonnet/Haiku i **„Anthropic AI Agent
(protokol)“**) — model bez nastaveného API klíče je v seznamu zobrazen, ale
zakázaný. Zvolený model se ukládá spolu s návrhem protokolu a při opětovném
otevření se předvybere. Model **„Anthropic AI Agent (protokol)“** na rozdíl
od přímých volání Messages API odpovídá podle **systémového promptu
nastaveného v Anthropic Console** pro daného agenta, ale konkrétní strukturu
závěru (viz níže) řídí stále prompt sestavený aplikací.

**Struktura AI závěru dle verze protokolu (od verze 1.25.0)**

Text AI závěru pro každý stroj se liší podle zvolené **verze protokolu**
(viz bod 1b):

- **Verze 1 — stručná**: závěr zůstává **velmi stručný** (2–3 krátké věty
v jednom odstavci), stejně jako doposud.
- **Verze 2 — detailní**: závěr je **strukturovaný do 4 číslovaných bodů**
v tomto pevném pořadí:
  1. zhodnocení **rychlosti vibrací dle normy** (ČSN ISO 10816/20816) s
     vyjádřením **nejhoršího zjištěného stavu**,
  2. zhodnocení **FFT spektra rychlosti vibrací** a možná příčina — pokud
     FFT analýza rychlosti neodhalila žádnou zvýšenou hodnotu, bod obsahuje
     jednoduše větu „FFT spektra rychlosti vibrací bez detekce nedostatků.“,
  3. zhodnocení dle **zrychlení a obálky zrychlení**,
  4. zhodnocení **FFT zrychlení a obálky zrychlení**.

Každý bod je psaný jako 1–2 stručné, jasné věty. Struktura platí pro všechny
modely (včetně Anthropic AI Agenta) — řídí ji prompt sestavený aplikací dle
zvolené verze protokolu, ne nastavení agenta v Anthropic Console. Text závěru
zůstává plně **editovatelný** v editoru návrhu před vygenerováním PDF.

**Vykreslení číslovaných závěrů a zarovnání do bloku v PDF (od verze 1.25.1)**

PDF generátor (`backend/pdf_writer.py`, `backend/report_pdf.py`) nyní rozezná
číslovanou strukturu textu ("1. ... 2. ... 3. ...") v poli **závěr** i
**doporučení** a vykreslí ji jako skutečný číslovaný seznam — každá položka má
tučné číslo s odsazeným zalomeným textem a mezeru mezi jednotlivými body,
místo splynutí do jednoho odstavce. Toto se týká jak souhrnné sekce
**„04 Závěry a doporučení“** (verze protokolu 2), tak detailní stránky stroje
(verze protokolu 1). Pokud text žádnou číslovanou strukturu neobsahuje
(např. stručný závěr u verze 1, nebo pole doporučení, které bývá jedna souvislá
věta), použije se automaticky standardní odstavcové vykreslení — číslování se
nikde nevynucuje uměle.

Současně bylo zapnuto **zarovnání do bloku** (justify — zarovnání k levému
i pravému okraji, kromě posledního řádku odstavce) pro veškerý souvislý text
protokolu: úvodní odstavec v **„03 Metodika měření“**, texty **„04 Závěry a
doporučení“** a **„05 Hodnocení technického stavu“**, i vysvětlující odstavce
v **příloze** (ČSN ISO 20816, analýza ložisek, FFT). Krátké prvky jako popisky
pásem A–D v příloze zůstávají zarovnané doleva, protože jde o legendu, ne o
souvislý text.

**Podzáložky v tvorbě protokolu a pamatování pozice stránky (od verze 1.25.2)**

Editor tvorby protokolu (bod 5) je nyní rozdělen do dvou podzáložek nad
formulářem, se stejným vzhledem jako záložky karty stroje:

- **„Okruh strojů a návrh“** — obsahuje výběr okruhu strojů a tlačítko pro
  vytvoření návrhu (vždy viditelné, i bez existujícího návrhu), a po
  vygenerování návrhu i editovatelnou **hlavičku** a **úvod** protokolu.
- **„Stroje – závěry a doporučení“** — obsahuje editovatelné závěry a
  doporučení pro jednotlivé stroje zařazené do protokolu. Dokud návrh
  neexistuje, zobrazuje se zde jen krátká nápověda místo prázdného panelu.

Přepínání mezi podzáložkami nenačítá nic znovu ani nemaže rozpracované
úpravy — jde čistě o rozdělení stejného formuláře do dvou karet kvůli
přehlednosti u delších protokolů s mnoha stroji.

Současně byla opravena **pozice skrolování** při přepínání záložek: jak u
těchto nových podzáložek protokolu, tak u záložek karty stroje
(„Základní informace“, „Ložiska a limity“, „Vyhodnocení pomocí AI“, „Chat
s diagnostikem“), se nyní pozice posuvníku hlavního obsahu pamatuje zvlášť
pro každou záložku a při návratu se obnoví — dříve se scroll při každém
přepnutí resetoval na začátek stránky. Záložky výběru grafu na kartě bodu
(trend/spektrum/vodopád) scroll nikdy neresetovaly, takže tam žádná úprava
nebyla potřeba.

**5c) Grafy do protokolu — trendy a FFT spektra**

U každého stroje lze v editoru (na kartě stroje) zaškrtnout, které grafy
se mají do protokolu vykreslit. Pro každý měřicí bod jsou na výběr trendy i
FFT spektra hned ve třech veličinách:

- **Trend rychlosti** / **Trend zrychlení** / **Trend obálky** — vývoj
  efektivní hodnoty dané veličiny v čase (rychlost [mm/s], zrychlení a obálka
  zrychlení [g]).
- **FFT rychlosti** / **FFT zrychlení** / **FFT obálky** — poslední naměřené
  frekvenční spektrum daného bodu pro zvolenou veličinu.

**Komentáře a značky v dialogu náhledu (od verze 1.25.9).** Zaškrtnutím grafu
se v panelu bodu objeví jen tlačítko **Náhled**; komentář i značky se
nastavují až v **dialogu interaktivního náhledu**, aby diagnostik komentoval a
značkoval přesně to, co má před očima. V dialogu je:

- **Komentář zvlášť pro každý graf** (per-veličina) — např. jiný text pro
  FFT rychlosti než pro FFT zrychlení téhož bodu. Komentář se vytiskne pod
  příslušný graf.
- **Automatické značky (jen spektra)** — zaškrtávátka pro **otáčkovou 1×**,
  **harmonické 2×–6×** a **ložiskové BPFO/BPFI/BSF/FTF** (pokud jsou známy
  otáčky a násobky ložiska). U trendů se tato sekce nezobrazuje.
  **Od verze 1.25.10** se automatické značky po zaškrtnutí vykreslí **hned
  přímo v náhledu spektra** (otáčková zeleně, harmonické modře, ložiskové
  červeně), aby bylo vidět, kam padnou, ještě před vygenerováním PDF. Pokud
  bod nemá známé otáčky, aplikace na to upozorní.
- **Vlastní značky** — přidávají se **kliknutím přímo do grafu**. U spektra
  lze u každé značky nastavit **počet harmonických** (výchozí 3) a
  **postranní pásma** (počet + rozteč [Hz]); ty se vykreslí jako doplňkové
  svislé čáry (harmonické světlejší, postranní pásma nejsvětlejší, bez
  popisku). U trendu je vlastní značka jednoduchá svislá čára na bodu.

**Volba počtu bodů trendu byla odstraněna (od verze 1.25.9)** — trend vždy
zobrazuje **všechny dostupné body** (podvzorkování je při práci s trendem
zbytečné).

- **Hladiny limitů v trendech** — do každého trendu se vykreslí vodorovné
  čárkované hladiny pásem A/B, B/C a C/D (podle limitů nastavených u
  měřicího bodu), takže je na první pohled vidět, jak blízko je hodnota mezi.

Vybrané grafy se vykreslují jako jednoduché vektorové grafy přímo do PDF
(opět plně offline, bez knihovny Plotly). Výběr grafů i popisy se ukládají
spolu s návrhem protokolu.

**Shodné spektrum v náhledu i v PDF (oprava od verze 1.25.10).** Dříve se FFT
spektrum při vykreslení do PDF **pod-vzorkovalo kročejí** na ~300 bodů, čímž se
u spekter bez použití zoomu vynechávaly špičky a spektrum vypadalo jinak než
v náhledu. Nyní se redukce provádí **se zachováním špiček** a s vysokým
limitem, takže spektrum v PDF **odpovídá náhledu i bez zoomu** (typická spektra
do ~1600 linek se nemění vůbec).

**Popis pod grafem zarovnaný do bloku (oprava od verze 1.25.11).** Dříve se
delší popis pod grafem **ořezával na 2 řádky** a mohl **přetékat doprava** mimo
šířku grafu. Nyní se popis **zalomí do celé šířky grafu**, zarovná se **do
bloku** pod obrázek a zobrazí se **celý** (bez ořezu). Mřížka grafů si navíc
rezervuje místo podle výšky popisu, takže delší popisy **nepřetékají do dalšího
řádku grafů**. Platí pro **všechny verze protokolu**.

**Zalomení dlouhých řetězců bez mezer (oprava od verze 1.25.14).** Pokud popis
pod grafem obsahoval **velmi dlouhé slovo bez mezer** (např. náhodný řetězec
nebo dlouhý kód), stále mohl **přetékat za pravý okraj** bloku, protože
zalamování probíhalo jen po mezerách. Nyní se taková slova **rozdělí i po
znacích**, takže žádný řádek už nikdy nepřeteče šířku bloku. Oprava platí pro
**veškerý zalamovaný text v PDF** (popisy pod grafy, závěry, úvod atd.) a pro
**všechny verze protokolu**.

**Závěry bez číslování (od verze 1.25.11).** V závěrech a doporučeních se už
**nečísluje** — text se vykresluje jako **samostatné odstavce**. Každé zalomení
řádku (Enter) v textu závěru/doporučení začíná **nový odstavec** oddělený
**malou mezerou**, takže text nesplyne do souvislého bloku. Platí pro **verzi 1**
(detailní strana stroje) i **verzi 2** (sekce „Závěry a doporučení“).

**Norma u každého stroje v sekci 5 (od verze 1.25.11).** V sekci „Hodnocení
technického stavu“ (verze 2) se v informačním řádku každého stroje nově uvádí
i **norma, dle které je stroj hodnocen** (ČSN ISO 20816 — třída stroje), vedle
otáček, umístění a data měření.

Kam se grafy v protokolu umístí, závisí na zvolené verzi:

- **Verze 1** — grafy se vykreslují inline, hned pod tabulkou hodnot
  daného stroje na jeho detailní straně, a automaticky se zalamují na
  další strany, pokud se jich vejde víc.
- **Verze 2** — grafy se nevykreslují v sekci „Hodnocení technického
  stavu“. Místo toho se pro všechny stroje, které mají vybrané nějaké
  grafy, vypíší souhrnně v samostatné příloze „Grafy: trendy a FFT
  spektra“ na konci protokolu — viz bod 5d.

**5d) Příloha — grafy: trendy a FFT spektra (jen verze 2)**

U protokolu ve verzi 2 se za sekcí „Hodnocení technického stavu“ vloží
samostatná příloha s grafy: na nové straně se pro každý stroj, který má
vybrané nějaké grafy (bod 5c), vypíše jeho název a poté jeho trendy a FFT
spektra ve dvousloupcové mřížce, plynule napříč stránkami — stejně jako u
sekce hodnocení, i zde se stránka zalomí jen tehdy, když se další graf už
nevejde. Pokud žádný stroj nemá vybrané grafy, příloha se nevytváří. U
protokolu ve verzi 1 tato příloha není potřeba, protože grafy jsou už
vykreslené inline u jednotlivých strojů (bod 5c).

**5e) Příloha — použité normy a hodnocení**

Na konci protokolu je automaticky přidána příloha s vysvětlením
použitých norem a metod: norma ČSN ISO 20816 (hodnocení rychlosti vibrací),
barevná tabulka pásem stavu A–D, metoda obálky zrychlení pro analýzu
valivých ložisek a frekvenční analýza (FFT). Tato příloha je u obou verzí
protokolu vždy poslední stranou (u verze 2 tedy následuje až za přílohou s
grafy z bodu 5d).

> **Rozbalovací seznam strojů (sekce 4):** každý stroj se v editoru zobrazí
> nejprve **sbalený** — vidíte jen **název stroje a barevný pruh stavu**
> (zelená / žlutá / červená). **Kliknutím na hlavičku** se stroj rozbalí a zobrazí
> se k nahlédnutí **sjednocená tabulka celkových hodnot** — **jeden řádek na
> ložisko**: **rychlost vibrací H**, **zrychlení H**, **obálka H** a
> **celkový stav ložiska**. Hodnoty i stav vycházejí pouze z těchto tří
> přesně vybraných veličin v horizontálním směru; V/A ani jiné veličiny se
> jako náhrada nepoužijí. **Pásmo (barevná klasifikace A–D) se
> zobrazuje pouze u rychlosti a u stavu ložiska** — u hodnot zrychlení a
> obálky se pásmo záměrně neuvádí (slouží jen jako informativní čísla). Je-li
> zvolena **verze 2 protokolu (bod 1b)**, má tabulka navíc sloupec **minulá**
> s předchozí naměřenou hodnotou rychlosti vedle aktuální. Editor je pro obě
> verze protokolu stejný — v samotném editoru se stroje vždy zobrazují jako
> jednoduchý sbalitelný seznam, bez obrázku a bez stránkování; průběžné
> řazení strojů za sebou a vynechání obrázku se projeví až ve **vygenerovaném
> PDF** u verze 2 (viz bod 5b).
>
> **Vyloučení měřicích bodů z protokolu (od verze 1.25.15).** Ne vždy se měří
> všechny body. Tabulka celkových hodnot proto obsahuje sloupec **„Zahrnout“**
> se zaškrtávátkem u každého řádku (ložiska). **Odškrtnuté** místo se do
> vygenerovaného PDF **nezahrne** — nezobrazí se v tabulce a **nevstupuje ani do
> hodnocení** (celkový stav stroje a nejhorší pásmo se přepočítají pouze ze
> zbylých bodů). V editoru je odškrtnutý řádek zšedivelněný a přeškrtnutý.
> Volba se ukládá do návrhu, takže zůstane zachována i po znovuotevření
> protokolu; uložený návrh však zůstává kompletní (včetně zaškrtávátek),
> vyloučení se aplikuje až při vykreslení PDF.
>
> Pod tabulkou jsou teprve editovatelná pole **závěrů, doporučení a výběr
> grafů** pro daný stroj.

**6) Editace a vygenerování PDF**

Po stisknutí **„Vytvořit návrh protokolu“** se sestaví celý protokol, který je
**plně editovatelný** přímo v aplikaci — hlavička, úvod i závěry a doporučení u
jednotlivých strojů. Návrh se průběžně ukládá (soubor `data/report_drafts.json`),
takže se o rozpracovaný protokol nepřijde. Po odsouhlasení stisknete
**„Vygenerovat PDF“** a protokol se vygeneruje a stáhne jako soubor PDF.

**Editovatelný název PDF souboru (od verze 1.25.13).** V hlavičce protokolu je
pole **„Název PDF souboru“**. Aplikace do něj **automaticky předvyplní výchozí
název** složený ve tvaru **`číslo zakázky-název zákazníka-název protokolu`**
(např. `2026-042-Heistech_s_r_o-Zpráva_z_měření_vibrací`). Dokud název ručně
neupravíte, **automaticky se aktualizuje** při každé změně čísla zakázky,
zákazníka nebo názvu protokolu. Název lze **kdykoli ručně přepsat** — ruční
úprava zůstane zachována a dalšími změnami polí se už nepřepíše. Tlačítkem
**„Obnovit výchozí“** se ruční název zahodí a znovu se složí výchozí název
z aktuálních údajů. Příponu `.pdf` doplňuje aplikace automaticky; **česká
písmena i mezery jsou zachovány** (mezery a nepovolené znaky se v názvu souboru
nahradí podtržítkem). Je-li vše prázdné, použije se název `Protokol.pdf`.

**Náhled PDF před vygenerováním (od verze 1.25.12).** Vedle tlačítka
**„Vygenerovat PDF“** je nově tlačítko **„Náhled PDF“**. Zobrazí celý protokol
**v modálním okně přímo v aplikaci** (bez stažení souboru), takže si před
finálním vygenerováním zkontrolujete, jak protokol vypadá. Náhled se sestavuje
**stejnou cestou jako výsledné PDF** (včetně přepočtu grafů dle zaškrtnutého
výběru), takže je s výsledným souborem **1:1 shodný**. Přímo z okna náhledu lze
protokol **stáhnout** (tlačítko „Stáhnout PDF“) nebo okno zavřít a pokračovat
v úpravách.

Vykreslení PDF probíhá **plně offline** přímo v aplikaci (bez jakýchkoli
externích knihoven); pouze volitelné generování závěrů pomocí AI vyžaduje
připojení k internetu.

#### Aktualizace protokolu podle limitů (tlačítko „Aktualizovat“, od verze 1.30.1)

Limity na kartě stroje se často upravují **až ve chvíli, kdy je protokol
rozpracovaný** — diagnostik při psaní závěrů zjistí, že je potřeba doladit
mez pásma, vybrat jinou normu ČSN ISO 20816 nebo změnit typ ložiska. Dřív
bylo nutné vygenerovat **celý nový návrh**, čímž se ztratily ručně napsané
závěry a doporučení. Nově je v hlavičce stránky **Protokol z měření** tlačítko
**„Aktualizovat“**, které protokol jen **přepočítá**.

**Co tlačítko udělá** (data odvozená z měření a limitů):

* přepočítá **pásmo A–D u každého měřicího bodu** (rychlost vibrací) podle
  limitů, které jsou na kartě příslušného stroje **uložené právě teď**,
* přepočítá **zrychlení, obálku zrychlení a stav ložiska** u každého ložiska,
* obnoví **meze A/B, B/C a C/D** používané jako hladiny v trendech a značky
  ve spektrech,
* obnoví **nejhorší pásmo** a **automatický stav stroje** (barevný stav
  v seznamu strojů protokolu),
* aktualizuje identifikační údaje z karty stroje (**název, nadřazený uzel,
  otáčky, norma, datum posledního měření**),
* u **verze 3 (vyvažování)** dopočítá **procentuální úspěšnost vyvážení**,
* překreslí **grafy** podle zachovaného výběru (trendy vykreslují hladiny
  limitů, které se právě změnily),
* obnoví přílohu **„použité normy“** podle norem na kartách strojů.

**Co se NIKDY nepřepíše** (ruční vstup diagnostika):

* **závěry, doporučení a popis problému** u jednotlivých strojů,
* **ruční přepis celkového stavu stroje** — zůstává v platnosti a i po
  aktualizaci má přednost před automatikou (přepočítaný automatický stav se
  jen zobrazí jako „Automaticky (…)“),
* **vyloučené body** — při přepočtu se respektují (do stavu stroje nevstupují),
* **výběr grafů** včetně komentářů, značek a přiblížení,
* **hlavička protokolu, úvod, úvod přílohy, obrázek přílohy** a jakékoli další
  údaje protokolu.

Aktualizace tedy **sama nikdy nepřepíše text závěru**. Místo toho pod hlavičkou
vypíše **seznam změn** ve tvaru `stroj – bod: veličina původní pásmo → nové
pásmo` a upozornění u strojů, kde se změnil celkový stav — abyste věděli,
u kterých strojů je vhodné závěr zkontrolovat a případně upravit.

**Praktické poznámky.** Tlačítko posílá na server i **dosud neuložené úpravy
z editoru**, takže rozepsaný text se aktualizací neztratí; přepočítaný návrh se
zároveň uloží. Není-li k dispozici žádný rozpracovaný návrh, tlačítko je
neaktivní. Stroj, který už v databázi `.ndb` není (jiná databáze, smazaný uzel),
zůstane v protokolu **beze změny** a jen se vypíše jako „přeskočeno“. Stroje
**bez nastavených limitů** se vypíšou zvlášť — u nich klasifikace do pásem
nevznikne, dokud limity nedoplníte na kartě stroje nebo nevyberete normu.
Data se čtou a ukládají **per podnik** (`data/podniky/<podnik>/`), takže
aktualizace protokolu jednoho zákazníka nemůže ovlivnit data jiného.

### Celková hodnota (overall) a hornopásmový filtr 1 Hz

U **každého spektra** aplikace počítá **celkovou hodnotu (overall)** — jediné
číslo charakterizující celkovou úroveň vibrací v daném spektru. Overall se počítá
jako **RMS přes čáry spektra**, tedy odmocnina ze součtu čtverců amplitud
všech čar (Parsevalova věta pro RMS amplitudové spektrum):

\[ \text{overall} = \sqrt{\sum_i a_i^2} \]

Před výpočtem se na všechna spektra aplikuje **hornopásmový filtr na 1 Hz**:

- Čáry s frekvencí **pod 1 Hz** (typicky **stejnosměrná – DC – složka** na 0 Hz)
  se **vynulují**, a to jak ve vlastním výpočtu overall, tak i v **zobrazeném
  spektru** (graf spektra i vodopád). DC složka (střední hodnota signálu) tak
  nezkresluje celkovou hodnotu ani vizuální měřítko grafu.
- Hranice filtru je centrálně nastavená v backendu (`HP_CUTOFF_HZ = 1.0`).

Celková hodnota se zobrazuje:

- ve **statistice pod grafem spektra** („Celková hodnota (overall, HP 1 Hz)"),
- v **detailu vybraného spektra** ve vodopádu,
- a jako samostatný **trend overall v čase** ve vodopádovém zobrazení (viz níže),
  což usnadňuje sledování postupné degradace.

### Vodopádový graf FFT spekter (waterfall)

Vodopádový graf zobrazuje **vývoj FFT spekter v čase** pro jeden měřicí bod, takže
lze na první pohled odhalit **postupnou degradaci ložiska** nebo nárůst vibrací na
konkrétních frekvencích napříč jednotlivými měřeními.

Když má vybraný měřicí bod spektrální data, objeví se v záhlaví měření tlačítko
**„Vodopád spekter"**. Po jeho stisknutí se otevře vodopádové zobrazení s tímto
ovládáním:

- **Režim zobrazení** — přepínač **„3D plocha"** / **„2D skládaná"**:
  - **3D plocha** — barevná plocha s osami **Frekvence [Hz] × Čas měření ×
    Amplituda**; plochu lze libovolně otáčet a přibližovat myší.
  - **2D skládaná** — jednotlivá spektra jsou vykreslena nad sebou se svislým
    posunem (nejstarší dole, nejnovější nahoře) a barevně odlišena podle stáří,
    takže je dobře patrný posun a růst vrcholů v čase.
- **Měření** — výběr konkrétní spektrální veličiny bodu (např. ISO SPECTRUM,
  ACC Spectrum, obálková spektra). Pokud má bod více spektrálních měření,
  přepnete se mezi nimi zde.
- **Počet spekter** — kolik posledních měření se do vodopádu načte
  (10 / 20 / 30 / 50 / 100 / 200). Výchozí je posledních **30**.
- **Log. osa amplitudy** — přepne amplitudovou osu na logaritmickou pro lepší
  čitelnost malých složek.

Mezi vodopádem a detailem je graf **„Trend celkové hodnoty (overall) v čase"** —
spojnice celkových hodnot všech načtených spekter. Právě vybraný časový okamžik je
v grafu zvýrazněn; kliknutím na bod trendu se přepne na příslušné spektrum.
Rostoucí trend overall je typickým projevem **postupné degradace ložiska**.

Pod vodopádem je panel **detailu vybraného spektra**:

- **Posuvník „Čas měření"** vybírá konkrétní časový okamžik; vedle něj je
  zobrazeno přesné datum a čas měření.
- Vybrané spektrum lze také zvolit **kliknutím přímo do vodopádu**.
- Detail vykreslí celé spektrum daného okamžiku a vypíše statistiku: **špička**
  (frekvence + amplituda), **maximum**, **celková hodnota (overall, HP 1 Hz)**,
  **RMS spektra** a **počet čar**.

Všechna data se počítají lokálně z databáze `.ndb`; vodopád funguje **offline
bez jakýchkoli externích knihoven** (vykreslení zajišťuje knihovna Plotly
přibalená přímo v aplikaci).

## Požadavky

- **Windows 10 nebo Windows 11 (64-bit):** žádná samostatná instalace Pythonu
  není nutná; plný ZIP obsahuje oficiální přenosný CPython 3.12 v `runtime/`.
- **Linux/macOS nebo vývojářský nouzový režim:** Python 3.8 nebo novější pro
  `spustit.sh` / `spustit.bat`.

**Žádné knihovny se neinstalují.** Aplikace používá pouze to, co je součástí
každé instalace Pythonu — nic se nestahuje z internetu, nic se nekompiluje.

## Spuštění

### Windows

1. Rozbalte ZIP tak, aby instalační kořen byl přesně `HADS/`.
2. Dvojklik na **`HADS.exe`** (doporučený způsob pro zákazníka).
3. Spouštěč najde vlastní instalační kořen i v cestě s českými znaky, mezerami,
   `&` nebo závorkami; skrytě spustí `runtime/pythonw.exe`, vyčká na
   `http://127.0.0.1:<zvolený-port>/api/health` a teprve potom otevře
   prohlížeč. Port vybírá spouštěč automaticky pouze na loopback rozhraní,
   aby kolize s jinou aplikací nebránila startu.
4. Po zavření prohlížeče služba může dál běžet. Další spuštění `HADS.exe` nejdřív
   bezpečně ukončí pouze ověřenou instanci stejné instalace a pak otevře novou
   relaci. Nezastavuje proces jen podle PID ani portu. Při potížích je česká
   zpráva a log v `data/hads_launcher.log`.
5. `HADS.exe --create-shortcut` vytvoří nebo opraví jediný zástupce na Ploše.
   `spustit.bat` zůstává vývojářskou/nouzovou variantou pro systémový Python.

### Linux / macOS

1. Rozbalte složku.
2. V terminálu spusťte:
   ```bash
   cd HADS
   chmod +x spustit.sh
   ./spustit.sh
   ```
3. Aplikace se otevře v prohlížeči na správné lokální adrese
   `http://127.0.0.1:<zvolený-port>`.

Aplikaci ukončíte zavřením okna (Windows) nebo `Ctrl+C` (Linux/macOS).

## Použití

1. Po spuštění se zobrazí **přehled stavu**.
2. V levém panelu rozbalte strom a klikněte na **měřicí bod** (např. `L1H-motor`).
3. Nahoře vyberte **měření** (trend / spektrum / časový signál).
4. U dynamických dat lze v pravém horním rohu vybrat **datum konkrétního měření**.

### Porovnání více měřicích bodů

1. Nad stromem strojů klikněte na tlačítko **„Porovnat"** — u měřicích bodů se
   zobrazí **zaškrtávací políčka**.
2. Zaškrtněte **dva a více měřicích bodů** (např. různé směry téhož ložiska
   nebo body na dvou strojích). Lze porovnat až 24 bodů najednou.
3. V dolní liště stiskněte **„Porovnat →"**.
4. V pohledu porovnání vyberte **veličinu** (např. ISO RMS) — všechny vybrané body
   se vykreslí do **jedné společné časové osy**.
5. Volitelně zapněte **„Normalizovat (0–100 %)"** — křivky se přeškálují na stejný
   rozsah, takže i body s velmi odlišnými hodnotami lze přímo porovnat tvarem vývoje.
6. Pod grafem najdete **přehledovou tabulku** (poslední/min/max/průměr + trend) a
   **korelační matici (Pearson)**. Vysoká kladná korelace (zeleně) znamená, že body
   rostou současně — typický příznak společné příčiny (např. nevyváženost,
   nesouosost). Pro vypnutí režimu klikněte opět na **„Porovnat"**.

### Správa databází

- Novou databázi načtete tlačítkem **„Načíst databázi"** vpravo nahoře — zůstane
  uložená v aplikaci i po restartu.
- Mezi více databázemi přepínáte **rozbalovacím seznamem** vlevo od ikony nastavení.
- Kliknutím na **ozubené kolo** otevřete správu databází, kde můžete:
  - **přepnout** na jinou databázi (šipka),
  - **přejmenovat** databázi na vlastní název (tužka), např. „MND linka B350 – červen 2026",
  - **smazat** databázi z knihovny (koš) — pozor, soubor se trvale odebere z disku.

## Vaše data

- Všechny načtené databáze se ukládají do složky `data/` a zůstávají tam
  i po restartu aplikace.
- Vlastní názvy databází jsou uloženy v souboru `data/library.json`.
- Konfigurace karet strojů (limity, ložiska, identifikace a obrázek stroje) je
  uložena v souboru `data/machine_config.json`.
- Rozpracované protokoly z měření jsou uloženy v souboru `data/report_drafts.json`.
- Aplikace si pamatuje naposledy zvolenou (aktivní) databázi.
- Žádná data neopouští váš počítač — vše běží lokálně.

## Struktura projektu

```
HADS/
├─ HADS.exe                   nativní Windows x64 spouštěč (bez konzole)
├─ assets/hads.ico            ikona HADS použitá EXE i zástupcem
├─ launcher/                  zdroj C, resource a reprodukovatelný MinGW build
├─ runtime/                   oficiální přenosný CPython pro Windows (jen plný ZIP)
├─ spustit.bat / spustit.sh   vývojářské/nouzové spouštěcí skripty
├─ README.md                  tento návod
├─ backend/
│  ├─ server.py               webový server (jen vestavěný Python) + API
│  ├─ ndb_parser.py           čtení a dekódování formátu .ndb
│  ├─ bearings.py             vyhledávání v databázi ložisek
│  ├─ bearings_db.json        databáze ložiskových frekvencí (31 000+)
│  ├─ machine_config.py       ukládání karet strojů (limity, ložiska, AI historie)
│  ├─ ai_eval.py              vyhodnocení AI (OpenAI / Claude), limity dle normy
│  ├─ company.py              údaje o podniku vázané na databázi
│  ├─ report.py               sběr dat protokolu, klasifikace pásem A/B/C/D
│  ├─ report_pdf.py           sestavení stránek PDF protokolu
│  ├─ report_store.py         ukládání rozpracovaných protokolů
│  ├─ pdf_writer.py           vykreslení PDF (jen vestavěný Python)
│  ├─ fonts/                  písma DejaVuSans pro PDF (čeština)
│  └─ version.py              číslo verze aplikace (APP_VERSION)
├─ frontend/
│  ├─ index.html              uživatelské rozhraní
│  ├─ styles.css              vzhled
│  ├─ app.js                  logika a grafy
│  └─ vendor/plotly.min.js    grafická knihovna (offline)
└─ data/                      vaše databáze .ndb
```

## Technické poznámky k formátu .ndb

Soubor `.ndb` je databáze SQLite. Klíčové tabulky:

| Tabulka          | Význam                                              |
|------------------|-----------------------------------------------------|
| `Tbl_Tree`       | hierarchie (Type 1 = závod/skupina, 2 = stroj, 3 = bod) |
| `Tbl_Cell`       | definice měření (`DataType`: 1,2 = trend; 7,8 = spektrum; 9 = čas. signál); sloupec `Limits` (XML) obsahuje prahy + `MaxSeverityId` stav |
| `Tbl_Cell_Stats` | statická data (skalární trendy)                     |
| `Tbl_Cell_Dyns`  | dynamická data (spektra, časové signály)            |
| `Tbl_Severity`   | úrovně závažnosti                                    |

Binární data v BLOBech jsou komprimovaná (zlib):

- **Statický záznam** (64 B): čas (.NET ticks) + hodnota (double na offsetu 16).
- **Spektrum** (9 B/bod): float32 amplituda + 5 rezervních bajtů; krok osy = `DataStep` (Hz).
- **Časový signál** (5 B/bod): float32 vzorek + 1 rezervní bajt; krok = `DataStep` (ms).
- Časová razítka metadat: milisekundy od 1. 1. 2000.

## Přepínatelné panely – bod / protokol / stroj (od verze 1.21.0)

Kartu měřicího bodu, tvorbu protokolu a kartu stroje lze nyní mít otevřené
zároveň jako **panely** a rychle mezi nimi přepínat – podobně jako panely
(taby) v prohlížeči, ale uvnitř aplikace v jednom okně.

**Jak to funguje**

- Kdykoli otevřete měřicí bod, kartu stroje nebo tvorbu protokolu, přidá se
  nahoru nad obsah **záložka panelu** (např. „Bod: L1H-motor“,
  „Stroj: Vrátek Motor1“, „Protokol“).
- Mezi panely přepínáte:
  - **kliknutím** na záložku,
  - klávesou **Ctrl+Tab** (další panel) a **Ctrl+Shift+Tab** (předchozí),
    cyklicky dokola,
  - klávesami **Ctrl+1 / Ctrl+2 / Ctrl+3 …** pro přímý výběr panelu podle
    pořadí.
- Panel zavřete křížkem **×** na záložce (nebo prostředním tlačítkem myši).
  Po zavření aktivního panelu se přepne na sousední; pokud žádný nezbývá,
  zobrazí se přehled.
- Při načtení jiné databáze se otevřené panely automaticky zavřou (patří
  k předchozím datům).

**Poznámka ke klávese Ctrl+Tab.** V samostatném okně aplikace (režim
„nainstalovat/otevřít jako aplikaci“) funguje Ctrl+Tab spolehlivě. V běžném
panelu prohlížeče si tuto klávesu někdy bere prohlížeč pro přepínání svých
vlastních panelů – pro jistotu proto fungují i zkratky **Ctrl+1/2/3** a
přepínání kliknutím.

Vše běží **lokálně a offline** bez externích knihoven.

## Výkon a rychlost načítání (od verze 1.20.0)

U velkých databází (mnoho strojů, měřicích bodů a dlouhé trendy) mohlo
načtení karty stroje nebo měřicího bodu s analýzou trvat i několik desítek
sekund. Verze 1.20.0 přináší několik optimalizací, které dobu načítání
výrazně zkracují:

**1. Cílené indexy v databázi.**
Soubor `.ndb` od výrobce indexuje tabulky převážně jen podle sloupce `ID`,
zatímco aplikace filtruje podle `Parent` (strom, buňky) a `CellId`
(trendová data). Bez vhodného indexu běží dotazy jako plný sken tabulky.
Aplikace proto při otevření databáze jednorázově doplní chybějící indexy
(`IF NOT EXISTS`, data se nemění):

- `ix_tree_parent` na `Tbl_Tree(Parent)`
- `ix_cell_parent` na `Tbl_Cell(Parent)`
- `ix_cellstats_cellid` na `Tbl_Cell_Stats(CellId, TimeFrom)`
- `ix_celldyns_cellid` na `Tbl_Cell_Dyns(CellId)`

U velké databáze (řádově statisíce řádků trendu) to zkrátí načtení bun\u011bk
jednoho stroje z jednotek sekund na desítky milisekund.

**2. Načítání jen jednoho stroje.**
Karta stroje se dříve načítala přes `/api/machines`, který počítal trendy
a adaptivní limity EWMA pro **celou databázi** při každém otevření. Nově
existuje endpoint `/api/machine/{id}`, který spočítá pouze požadovaný stroj.
Stejně tak analýza měřicího bodu už nenačítá celou databázi kvůli jedinému
stroji.

**3. Odstranění problému N+1 dotazů.**
Trendy se dříve načítaly samostatným SQL dotazem pro každou buňku. Nově se
načtou hromadně jedním dotazem (`trend_batch` přes `WHERE CellId IN (...)`)
a rozdělí se v paměti.

**4. Ladění SQLite připojení.**
Při otevření databáze se zapíná režim **WAL** a nastavuje větší stránková
cache a `mmap`, což zrychluje opakované čtení.

**Měření doby načtení.** Server po každém načtení strojů vypisuje do logu
(chybový výstup) řádek `[perf] /api/machine/<id>: <čas> ms`, takže je možné
skutečnou dobu načítání na konkrétní databázi ověřit.

Všechny optimalizace pracují **lokálně a offline**, nemění data v databázi
a nevyžadují žádné externí knihovny.

## Aktualizace aktivní databáze (1.35.0)

Tlačítko **„Aktualizovat databázi“** v horní liště nahrazuje obsah právě
aktivní pracovní databáze novějším souborem `.ndb`, aniž by změnilo její
pracovní název, zobrazovaný název v knihovně nebo data HADS. Zachovány zůstávají
`current.txt`, nastavení a limity podniku, karty strojů, historie a návrhy
protokolů i ostatní JSON data vlastněná HADS.

1. Zavřete zdrojovou měřicí aplikaci a vyčkejte na dokončení synchronizace
   sdílené složky. Nevybírejte databázi, která je právě zapisována.
2. Ověřte, že v HADS je aktivní správný podnik, klikněte na **„Aktualizovat
   databázi“** a v systémovém dialogu vyberte `.ndb`.
3. Dialog HADS ukáže název, velikost a datum vybraného zdroje. Teprve po
   explicitním potvrzení se začne nahrávání; Storno nezmění žádný soubor.
4. Server soubor zapisuje po blocích do dočasného souboru ve `data/`, porovná
   deklarovanou a skutečně přijatou velikost, ověří SQLite, rychlou integritu,
   schéma DDS/HADS a identitu kořenového podniku. Databáze jiného podniku se
   odmítne. Není-li identita zjistitelná pouze na jedné straně, aktualizace se
   z bezpečnostních důvodů také odmítne; pokračovat lze jen tehdy, pokud není
   zjistitelná na obou stranách a schéma je platné.

Před výměnou se ověří prostor pro staging a bezpečnostní rezervu. HADS pak
vytvoří jednorázovou úlohu a přes nativní `HADS.exe` supervizor spustí
`runtime/pythonw.exe` s jediným korektně quotovaným argumentem descriptoru.
Pomocník vlastní log zapíše ještě před načtením descriptoru. Backend přijme
shutdown jen pokud ověří nonce, kanonické cesty, MAC potvrzení a čerstvou
challenge/response od skutečně živého procesu `pythonw.exe`. Na Windows se pro
to otevírá správně 64bitově typovaný Win32 `HANDLE` s oprávněními
`PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE`; nevztahuje se žádná rovnost
mezi PID supervizoru `HADS.exe` a PID jeho potomka `pythonw.exe`.

Stará, upravená nebo předčasně ukončená ready odpověď nemůže vyvolat shutdown.
V takovém případě HADS zůstane spuštěný a dialog ukáže konkrétní český důvod a
cestu k `updates/logs/database_update_<job>.log`; vybraný soubor je ponechán
připravený k bezpečnému opakování. Po úspěšném potvrzení se backend korektně
ukončí. Teprve nezávislý pomocník po jeho úplném skončení přesune původní
`.ndb` a případné `-wal`, `-shm`, `-journal` do rollbacku, ověří SHA-256 i
SQLite a restartuje HADS. Pokud je některý soubor stále držen cizím programem,
pomocník databázi obnoví z rollbacku nebo odmítne výměnu; tyto soubory nikdy
nezavírejte ani nemažte ručně.
