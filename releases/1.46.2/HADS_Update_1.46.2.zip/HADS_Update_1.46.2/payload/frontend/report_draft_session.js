/* HADS – malý, testovatelný model relace rozpracovaného protokolu.
 *
 * Nezávisí na DOM ani síti. app.js jej používá jako okamžitý lokální snapshot
 * před přepnutím záložky; serverový autosave je pouze druhá, trvalá vrstva.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.HadsReportDraftSession = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const PREFIX = "hads.report-draft-session.v1:";

  function key(context) {
    return PREFIX + String(context || "");
  }
  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }
  function load(storage, context) {
    try {
      const raw = storage && storage.getItem(key(context));
      const item = raw ? JSON.parse(raw) : null;
      return item && item.context === context ? item : null;
    } catch (_) { return null; }
  }
  function save(storage, context, value) {
    const item = Object.assign({}, clone(value || {}), {
      context: context,
      saved_at: Date.now(),
    });
    try { if (storage) storage.setItem(key(context), JSON.stringify(item)); } catch (_) {}
    return item;
  }
  function remove(storage, context) {
    try { if (storage) storage.removeItem(key(context)); } catch (_) {}
  }
  function newSessionId() {
    const cryptoApi = (typeof globalThis !== "undefined" && globalThis.crypto);
    if (cryptoApi && cryptoApi.randomUUID) return cryptoApi.randomUUID();
    return "draft-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
  }
  function shouldApplyRemote(options) {
    const o = options || {};
    return o.requestToken === o.activeToken &&
      o.requestRevision === o.currentRevision &&
      !o.hasLocalSnapshot &&
      o.context === o.activeContext;
  }
  return { PREFIX, key, clone, load, save, remove, newSessionId, shouldApplyRemote };
});
