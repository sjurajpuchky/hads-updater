/* Browser-level QA for the compact report measurement selector. */
const fs = require('fs');
const { chromium } = require('playwright');
const appPath = process.argv[2];
const screenshotPath = process.argv[3];
const source = fs.readFileSync(appPath, 'utf8');
const start = source.indexOf('function renderMeasurementSelectors(');
const end = source.indexOf('\n// Sjednocená kompaktní tabulka', start);
if (start < 0 || end < 0) throw new Error('Selector renderer not found');
const renderer = source.slice(start, end);
const report = {
  machine_id: '7',
  protocol_quantities: { velocity: 'ISO RMS', accel: 'ACC', env: 'ENV' },
  rows: [{ place: 'L4', vel_cur: 1.59, direction: 'H' }],
  bearings_summary: [{
    place: 'L4', acc_cur: 0.42, acc_dir: 'V', env_cur: 0.55, env_dir: 'A',
    measurement_directions: {
      H: { options: [
        { id: 'H|2026-08-18T13:38:16#1', label: '18. 8. 2026 13:38:16 • R 1,59 mm/s • Z 0,10 g • O 0,04 g', usable: true },
        { id: 'H|2026-08-17T10:01:00#1', label: '17. 8. 2026 10:01:00 • R 1,12 mm/s', usable: true },
      ], previous_options: [{ id: 'H|2026-08-17T10:01:00#1', label: '17. 8. 2026 10:01:00 • R 1,12 mm/s', usable: true }],
      current_id: 'H|2026-08-18T13:38:16#1', previous_id: 'H|2026-08-17T10:01:00#1',
      current_preview: { 'ISO RMS': 1.59, ACC: .10, ENV: .04 }, previous_preview: { 'ISO RMS': 1.12 } },
      V: { options: [{ id: 'V|2026-08-18T13:36:10#1', label: '18. 8. 2026 13:36:10 • R 1,20 mm/s • Z 0,42 g • O 0,03 g', usable: true }], previous_options: [], current_id: 'V|2026-08-18T13:36:10#1', previous_id: '', current_preview: { 'ISO RMS':1.20, ACC:.42, ENV:.03 }, previous_preview: {} },
      A: { options: [{ id: 'A|2026-08-18T13:37:02#1', label: '18. 8. 2026 13:37:02 • R 1,33 mm/s • Z 0,18 g • O 0,55 g', usable: true }], previous_options: [], current_id: 'A|2026-08-18T13:37:02#1', previous_id: '', current_preview: { 'ISO RMS':1.33, ACC:.18, ENV:.55 }, previous_preview: {} },
    },
  }],
};
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await page.setContent(`<!doctype html><html><head><style>
    body{margin:0;background:#171b21;color:#e8edf2;font:14px system-ui,sans-serif;padding:16px}.report-measurement-selectors{border:1px solid #45515e;border-radius:7px;background:#20242a;overflow:hidden}.report-measurement-selectors>summary{display:flex;gap:10px;padding:8px 10px;cursor:pointer;font-weight:700}.report-measurement-selectors>summary span{color:#aeb8c3;font-weight:400}.report-measurement-content{padding:0 10px 10px;border-top:1px solid #45515e}.rep-measurement-row{padding-top:8px;margin-top:8px;border-top:1px solid #45515e}.rep-measurement-bear-head{display:flex;gap:7px;flex-wrap:wrap}.rep-measurement-bear-head strong{min-width:45px}.rep-measurement-reset{margin-left:auto}.rep-measurement-directions{display:grid;grid-template-columns:1fr;gap:7px;margin-top:7px}.rep-measurement-direction{display:grid;grid-template-columns:auto minmax(0,1fr);gap:4px 6px;color:#c3ced8}.rep-measurement-direction select{min-width:0;width:100%;font:12px system-ui}.rep-measurement-preview{grid-column:1/-1;color:#aeb8c3;font-size:11px}.rep-measurement-previous{opacity:.88}.cb-btn{padding:3px 7px;background:#2c6372;color:#fff;border:0;border-radius:3px;font-size:11px}</style></head><body><main id="root"></main></body></html>`);
  await page.evaluate(({ renderer, report }) => {
    window.escapeHtml = v => String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    window.fmtNum = (v, d) => Number(v).toFixed(d).replace('.', ',');
    // eslint-disable-next-line no-eval
    eval(renderer);
    document.querySelector('#root').innerHTML = renderMeasurementSelectors(report, true);
  }, { renderer, report });
  const details = page.locator('.report-measurement-selectors');
  if (await details.evaluate(node => node.open)) throw new Error('Panel must be initially collapsed');
  await page.locator('.report-measurement-selectors > summary').focus();
  await page.keyboard.press('Enter');
  if (!(await details.evaluate(node => node.open))) throw new Error('Summary is not keyboard operable');
  const choices = await page.locator('.rep-measurement-select[data-kind="current"][data-direction="H"] option').allTextContents();
  if (!choices[0].includes('18. 8. 2026 13:38:16') || !choices[0].includes('R 1,59 mm/s')) throw new Error('Exact H option label missing');
  const hSelect = page.locator('.rep-measurement-select[data-kind="current"][data-direction="H"]');
  await hSelect.selectOption('H|2026-08-17T10:01:00#1');
  if (await hSelect.inputValue() !== 'H|2026-08-17T10:01:00#1') throw new Error('H occurrence selection did not change');
  const state = await page.evaluate(() => ({ scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth, open: document.querySelector('details').open, controls: document.querySelectorAll('.rep-measurement-select').length }));
  if (state.scrollWidth > state.clientWidth || state.controls !== 6) throw new Error('Mobile selector overflow or controls missing: ' + JSON.stringify(state));
  await page.screenshot({ path: screenshotPath, fullPage: true });
  console.log(JSON.stringify({ result: 'ok', ...state, selectedH: await hSelect.inputValue(), screenshotPath }));
  await browser.close();
})().catch(async err => { console.error(err.stack || err); process.exitCode = 1; });
