# -*- coding: utf-8 -*-
"""Regrese HADS 1.31.4: vestavěná norma ČSN ISO 20816-9 Převodovky.

Testy pokrývají skutečný backendový katalog, API bez spuštění HTTP serveru,
slučování vlastních norem a propsání do více přiřazení ložisek. Nezávisí na
``data/custom_norms.json`` v pracovním adresáři.
"""

import json
import math
import os
from pathlib import Path
import sys
import tempfile
import unittest

BACKEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "backend")
sys.path.insert(0, BACKEND_DIR)

import ai_eval  # noqa: E402
import machine_config  # noqa: E402
import report  # noqa: E402
import server  # noqa: E402


GEARBOX_STANDARD = "ČSN ISO 20816-9 Převodovky"
GEARBOX_CLASSES = {
    "VR 3,15": (2.0, 3.15, 5.0),
    "VR 5": (3.15, 5.0, 8.0),
    "VR 8": (5.0, 8.0, 12.5),
    "VR 12,5": (8.0, 12.5, 20.0),
    "VR 20": (12.5, 20.0, 31.5),
}


class BuiltinGearboxNormTests(unittest.TestCase):
    """Katalog a API fungují i bez souboru vlastních norem."""

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.custom_path = Path(self.temp_dir.name) / "custom_norms.json"
        self.original_custom_path = ai_eval._CUSTOM_NORMS_FILE
        ai_eval._CUSTOM_NORMS_FILE = self.custom_path

    def tearDown(self):
        ai_eval._CUSTOM_NORMS_FILE = self.original_custom_path
        self.temp_dir.cleanup()

    @staticmethod
    def _catalog_record(catalog, standard=GEARBOX_STANDARD):
        matches = [item for item in catalog if item["standard"] == standard]
        if len(matches) != 1:
            raise AssertionError("Standard %r se v katalogu nevyskytuje právě jednou: %r"
                                 % (standard, matches))
        return matches[0]

    def _assert_builtin_gearbox_catalog(self, catalog):
        rec = self._catalog_record(catalog)
        self.assertTrue(rec["builtin"])
        actual = {
            cls["machine_class"]: (cls["ab"], cls["warning"], cls["alarm"])
            for cls in rec["classes"]
        }
        self.assertEqual(actual, GEARBOX_CLASSES)

    def test_catalog_and_api_work_when_custom_file_is_missing_or_empty(self):
        """Vestavěná norma nesmí záviset na existenci ani obsahu custom JSON."""
        for content in (None, "[]"):
            with self.subTest(custom_norms_content=content):
                if self.custom_path.exists():
                    self.custom_path.unlink()
                if content is not None:
                    self.custom_path.write_text(content, encoding="utf-8")

                self._assert_builtin_gearbox_catalog(ai_eval.norms_catalog())
                self.assertEqual(ai_eval.list_custom_norms(), [])
                status, body = server.api_handler("/api/norms/catalog", "GET")
                self.assertEqual(status, 200)
                self._assert_builtin_gearbox_catalog(body["catalog"])

    def test_builtin_definition_wins_over_stale_custom_duplicate(self):
        """Stejný standard z custom JSON nemůže přepsat ani zdvojit vestavěný."""
        self.custom_path.write_text(json.dumps([
            {
                "standard": GEARBOX_STANDARD,
                "label": "Zastaralá uživatelská kopie",
                "classes": [{
                    "machine_class": "VR 8",
                    "ab": 999,
                    "warning": 998,
                    "alarm": 997,
                }],
            },
            {
                "standard": "Podniková doplňková norma",
                "classes": [{
                    "machine_class": "Třída A",
                    "ab": 1.0,
                    "warning": 2.0,
                    "alarm": 3.0,
                }],
            },
            {
                # Druhý záznam téhož uživatelského standardu rozšiřuje
                # první; katalog i UI z něj musí vytvořit jediný standard.
                "standard": "Podniková doplňková norma",
                "classes": [{
                    "machine_class": "Třída B",
                    "ab": 3.0,
                    "warning": 4.0,
                    "alarm": 5.0,
                }],
            },
        ], ensure_ascii=False), encoding="utf-8")

        catalog = ai_eval.norms_catalog()
        self._assert_builtin_gearbox_catalog(catalog)
        self.assertEqual(sum(x["standard"] == GEARBOX_STANDARD for x in catalog), 1)
        custom = ai_eval.list_custom_norms()
        self.assertEqual([x["standard"] for x in custom],
                         ["Podniková doplňková norma"])
        self.assertEqual(
            [x["machine_class"] for x in custom[0]["classes"]],
            ["Třída A", "Třída B"],
        )
        custom_rec = self._catalog_record(catalog, "Podniková doplňková norma")
        self.assertFalse(custom_rec["builtin"])
        self.assertEqual(
            {x["machine_class"] for x in custom_rec["classes"]},
            {"Třída A", "Třída B"},
        )
        # Při starém přiřazení standard+třída jsou stále platné vestavěné
        # hodnoty, ne neplatná uživatelská kopie.
        self.assertEqual(
            ai_eval.iso_limits_for_class("VR 8", standard=GEARBOX_STANDARD),
            {"ab": 5.0, "warning": 8.0, "alarm": 12.5},
        )

    def test_all_classes_have_exact_mapping_and_boundary_bands(self):
        """A/B, B/C, C/D musí být přesné včetně hodnot přímo na hranici."""
        for machine_class, (ab, warning, alarm) in GEARBOX_CLASSES.items():
            with self.subTest(machine_class=machine_class):
                limits = ai_eval.iso_limits_for_class(
                    machine_class, standard=GEARBOX_STANDARD)
                self.assertEqual(limits, {
                    "ab": ab, "warning": warning, "alarm": alarm,
                })
                # Hranice patří vždy do vyššího pásma.
                self.assertEqual(
                    report.classify_band(math.nextafter(ab, -math.inf),
                                         warning, alarm, ab), "A")
                self.assertEqual(report.classify_band(ab, warning, alarm, ab), "B")
                self.assertEqual(
                    report.classify_band(math.nextafter(warning, -math.inf),
                                         warning, alarm, ab), "B")
                self.assertEqual(
                    report.classify_band(warning, warning, alarm, ab), "C")
                self.assertEqual(
                    report.classify_band(math.nextafter(alarm, -math.inf),
                                         warning, alarm, ab), "C")
                self.assertEqual(report.classify_band(alarm, warning, alarm, ab), "D")

    def test_multi_norm_assignment_preserves_per_bearing_compatibility(self):
        """Nová norma funguje v režimu více norem a překryv řeší první skupina."""
        cleaned = machine_config._apply_iso_limits(machine_config._sanitize_config({
            "iso_norm": {
                "mode": "multi",
                "assignments": [
                    {
                        "standard": GEARBOX_STANDARD,
                        "machine_class": "VR 8",
                        "bearings": ["l1", "L2"],
                    },
                    {
                        "standard": GEARBOX_STANDARD,
                        "machine_class": "VR 20",
                        "bearings": ["L2", "L3"],
                    },
                ],
            },
            "bearings": {},
        }))
        iso = cleaned["iso_norm"]
        self.assertEqual(
            iso["assignments"],
            [
                {"standard": GEARBOX_STANDARD, "machine_class": "VR 8",
                 "bearings": ["L1", "L2"]},
                {"standard": GEARBOX_STANDARD, "machine_class": "VR 20",
                 "bearings": ["L3"]},
            ],
        )
        self.assertEqual(
            cleaned["bearings"]["L1"]["limits"]["ISO RMS"],
            {"ab": 5.0, "warning": 8.0, "alarm": 12.5},
        )
        self.assertEqual(
            cleaned["bearings"]["L3"]["limits"]["ISO RMS"],
            {"ab": 12.5, "warning": 20.0, "alarm": 31.5},
        )
        self.assertEqual(
            ai_eval.iso_limits_from_norm(iso, bearing_key="L2"),
            {"ab": 5.0, "warning": 8.0, "alarm": 12.5},
        )

    def test_ai_and_report_used_norms_resolve_builtin_assignment(self):
        """AI popis i příloha PDF/DOCX čtou stejný katalogový záznam."""
        iso = {"standard": GEARBOX_STANDARD, "machine_class": "VR 12,5"}
        description = ai_eval._norm_description(iso)
        self.assertIn(GEARBOX_STANDARD, description)
        self.assertIn("A/B 8,0", description)
        self.assertIn("B/C 12,5", description)
        self.assertIn("C/D 20,0", description)
        used = report.collect_used_norms([{
            "name": "Převodovka 1",
            "iso_norm": iso,
        }])
        self.assertEqual(used, [{
            "standard": GEARBOX_STANDARD,
            "machine_class": "VR 12,5",
            "ab": 8.0,
            "warning": 12.5,
            "alarm": 20.0,
            "machines": ["Převodovka 1"],
            "bearings": [],
        }])


if __name__ == "__main__":
    unittest.main(verbosity=2)
