# -*- coding: utf-8 -*-
"""Regrese kontraktu AI odpovědi pro vytváření návrhu protokolu.

Používá pouze lokální stub ``urlopen``. Fixture věrně simuluje odpověď
Messages API pro Claude Haiku, v níž JSON závěru obsahuje objekt místo textu;
to byl tvar, který dříve mohl skončit až ve frontendu v ``escapeHtml``.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

import ai_eval  # noqa: E402
import report  # noqa: E402
import server  # noqa: E402


FIXTURE = ROOT / "tests" / "anthropic_haiku_malformed_report_response.json"
SAFE_MESSAGE = ai_eval.public_response_format_message()


class _StubResponse:
    def __init__(self, body: dict):
        self._raw = json.dumps(body).encode("utf-8")

    def read(self):
        return self._raw

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False


class AiReportResponseContractTests(unittest.TestCase):
    def _valid_text(self):
        return json.dumps({
            "problem": "Provozní stav",
            "zaver": "Hodnoty odpovídají provoznímu stavu.",
            "doporuceni": "Provádět pravidelné kontrolní měření.",
        })

    def test_haiku_messages_fixture_reproduces_object_field_and_is_rejected(self):
        """Deterministická cesta Haiku: content.text -> JSON -> objekt v zaver."""
        fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
        with mock.patch.object(ai_eval, "get_api_key", return_value="stub-key"), \
                mock.patch.object(ai_eval.urllib.request, "urlopen",
                                  return_value=_StubResponse(fixture)):
            with self.assertRaises(ai_eval.AIResponseFormatError) as caught:
                ai_eval.evaluate_brief(
                    {"machine_name": "Ventilátor"}, 25, None,
                    model="claude-haiku-4-5-20251001", report_version=2,
                    use_examples=False)
        self.assertEqual(str(caught.exception), SAFE_MESSAGE)
        self.assertNotIn("body", str(caught.exception))
        self.assertNotIn("objekt", str(caught.exception))

    def test_all_report_prompts_and_supported_model_paths_keep_string_contract(self):
        """Všechny 3 editovatelné prompty i 5 podporovaných cest vrací text."""
        calls = []

        def text_call(*_args, **_kwargs):
            calls.append("text")
            return self._valid_text()

        model_call = {
            "gpt-4o": "_call_openai",
            "gpt-4o-mini": "_call_openai",
            "claude-sonnet-4-6": "_call_anthropic",
            "claude-haiku-4-5-20251001": "_call_anthropic",
            ai_eval.AI_AGENT_MODEL_ID: "_call_anthropic_agent",
        }
        with mock.patch.object(ai_eval, "get_api_key", return_value="stub-key"), \
                mock.patch.object(ai_eval, "_call_openai", side_effect=text_call), \
                mock.patch.object(ai_eval, "_call_anthropic", side_effect=text_call), \
                mock.patch.object(ai_eval, "_call_anthropic_agent", side_effect=text_call):
            for report_version in (1, 2, 3):
                for model, expected_call in model_call.items():
                    result, used_model = ai_eval.evaluate_brief(
                        {"machine_name": "Ventilátor"}, 25, None,
                        model=model, report_version=report_version,
                        use_examples=False)
                    self.assertEqual(used_model, model)
                    self.assertEqual(set(result), {"problem", "zaver", "doporuceni"})
                    self.assertTrue(all(isinstance(value, str)
                                        for value in result.values()))
        self.assertEqual(len(calls), 15)

    def test_non_string_provider_text_is_rejected_before_json_parsing(self):
        malformed = {"content": [{"type": "text", "text": {"leak": "no"}}]}
        with mock.patch.object(ai_eval.urllib.request, "urlopen",
                               return_value=_StubResponse(malformed)):
            with self.assertRaises(ai_eval.AIResponseFormatError):
                ai_eval._call_anthropic("stub-key", "claude-haiku-4-5-20251001",
                                        "system", "user")

    def test_report_builder_keeps_malformed_ai_out_of_editor_pdf_and_docx_data(self):
        fake_db = type("Db", (), {
            "machines": lambda _self, overrides=None: {
                "machines": [{"id": 7, "name": "Ventilátor"}],
            },
        })()
        machine_report = {
            "machine_id": 7, "name": "Ventilátor", "rows": [],
            "iso_norm": {}, "bearings": [],
        }
        with mock.patch.object(report, "select_machines_by_scope",
                               return_value=({7}, "Všechna měření", [])), \
                mock.patch.object(report, "scope_time_window", return_value=None), \
                mock.patch.object(report, "build_machine_report",
                                  return_value=machine_report.copy()), \
                mock.patch.object(report, "collect_machine_graphs", return_value=[]):
            doc = report.build_report_draft(
                fake_db, {}, {}, {"mode": "all"},
                ai_fn=lambda _machine, _rep: {
                    "problem": "Provozní stav",
                    "zaver": {"body": "nepřípustné"},
                    "doporuceni": "Měřte dál.",
                })
        generated = doc["machines"][0]
        self.assertEqual(generated["problem"], "")
        self.assertEqual(generated["zaver"], "")
        self.assertEqual(generated["doporuceni"], "")
        self.assertEqual(doc["ai_ok"], 0)
        self.assertEqual(len(doc["ai_errors"]), 1)
        self.assertIn(SAFE_MESSAGE, doc["ai_errors"][0])
        self.assertNotIn("body", doc["ai_errors"][0])

    def test_report_draft_api_flow_with_haiku_stub_returns_safe_czech_note(self):
        """Celý helper API používá stub upstreamu a nevrátí objekt do návrhu."""
        fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
        fake_db = type("Db", (), {
            "machines": lambda _self, overrides=None: {
                "machines": [{"id": 7, "name": "Ventilátor"}],
            },
            "machine_ai_data": lambda _self, _id, overrides=None, **_kwargs: {
                "machine_name": "Ventilátor",
            },
        })()
        machine_report = {
            "machine_id": 7, "name": "Ventilátor", "rows": [],
            "iso_norm": {}, "bearings": [], "severity": "ok",
        }
        with mock.patch.object(server.machine_config, "get_db_overrides",
                               return_value={}), \
                mock.patch.object(server.company, "get_company", return_value={}), \
                mock.patch.object(server.report_settings, "quantity_map", return_value={}), \
                mock.patch.object(server.report_store, "save_draft", return_value=None), \
                mock.patch.object(ai_eval, "has_any_key", return_value=True), \
                mock.patch.object(ai_eval, "get_api_key", return_value="stub-key"), \
                mock.patch.object(ai_eval.urllib.request, "urlopen",
                                  return_value=_StubResponse(fixture)), \
                mock.patch.object(report, "select_machines_by_scope",
                                  return_value=({7}, "Všechna měření", [])), \
                mock.patch.object(report, "scope_time_window", return_value=None), \
                mock.patch.object(report, "build_machine_report",
                                  return_value=machine_report.copy()), \
                mock.patch.object(report, "collect_machine_graphs", return_value=[]):
            status, payload = server._build_report_draft(
                fake_db, "podnik:test", {"mode": "all"}, True,
                "claude-haiku-4-5-20251001", report_version=2,
                draft_context="test.ndb")
        self.assertEqual(status, 200)
        self.assertEqual(payload["draft"]["machines"][0]["zaver"], "")
        self.assertIn(SAFE_MESSAGE, payload["ai_note"])
        self.assertNotIn("body", payload["ai_note"])

    def test_packaged_1390_contains_the_reproduced_unsafe_conversion_path(self):
        """Forenzní důkaz: release 1.39.0 převáděl objekt na ``str``."""
        archive = ROOT.parent / "HADS_aplikace_v1.39.0.zip"
        self.assertTrue(archive.is_file(), archive)
        with zipfile.ZipFile(archive) as package:
            member = next(name for name in package.namelist()
                          if name.endswith("/backend/ai_eval.py"))
            old_code = package.read(member).decode("utf-8")
        self.assertIn('str(obj.get("zaver", "") or "").strip()', old_code)
        self.assertIn('raw = (text or "").strip()', old_code)


if __name__ == "__main__":
    unittest.main(verbosity=2)
