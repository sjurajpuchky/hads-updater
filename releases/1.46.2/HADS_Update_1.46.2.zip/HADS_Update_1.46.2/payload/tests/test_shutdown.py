"""Regrese bezpečného ukončení backendu bez spuštění HTTP serveru."""
from __future__ import annotations

import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


SERVER = load("shutdown_server_test", ROOT / "backend" / "server.py")


class ShutdownTests(unittest.TestCase):
    origin = "http://127.0.0.1:45321"

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads ukončení Česká cesta & (test) ")
        self.old_lock = SERVER._SERVER_LOCK_FILE
        SERVER._SERVER_LOCK_FILE = Path(self.temp.name) / "hads_server.lock"
        SERVER._SERVER = SimpleNamespace(server_address=("127.0.0.1", 45321), shutdown=mock.Mock())
        SERVER._LIFECYCLE = SERVER.LifecycleController()
        SERVER._UI_SHUTDOWN_NONCES = SERVER.ShutdownNonceStore()
        SERVER._BACKGROUND_CANCEL.clear()
        SERVER._BACKGROUND_TIMERS[:] = []
        SERVER._BACKGROUND_THREADS[:] = []
        SERVER._TEARDOWN_STARTED = False

    def tearDown(self):
        SERVER._SERVER = None
        SERVER._SERVER_LOCK_FILE = self.old_lock
        self.temp.cleanup()

    def _handler(self, path: str, headers: dict | None = None, body: dict | None = None, peer=("127.0.0.1", 9000)):
        raw = json.dumps(body or {}, ensure_ascii=False).encode("utf-8")
        h = object.__new__(SERVER.Handler)
        h.path = path
        h.client_address = peer
        h.headers = {"Content-Length": str(len(raw)), **(headers or {})}
        h._read_body = mock.Mock(return_value=raw)
        h._send_json = mock.Mock()
        return h

    def _session(self, peer=("127.0.0.1", 9000), origin=None):
        h = self._handler("/api/ui/shutdown-session", {
            "Origin": self.origin if origin is None else origin,
            "X-HADS-UI-Session": "request",
        }, {"purpose": "shutdown"}, peer)
        SERVER.Handler.do_POST(h)
        status, data = h._send_json.call_args.args
        self.assertEqual(status, 200)
        return data["nonce"]

    def _shutdown(self, nonce: str | None, peer=("127.0.0.1", 9000), origin=None, header_nonce=None):
        body = {"nonce": nonce} if nonce is not None else {}
        h = self._handler("/api/ui/shutdown", {
            "Origin": self.origin if origin is None else origin,
            "X-HADS-UI-Shutdown-Nonce": nonce if header_nonce is None else header_nonce,
        }, body, peer)
        return h

    def test_same_origin_nonce_is_accepted_after_response_then_scheduled(self):
        nonce = self._session()
        handler = self._shutdown(nonce)
        order = []
        handler._send_json.side_effect = lambda *args: order.append(("response", args[0]))
        timer = mock.Mock()
        timer.start.side_effect = lambda: order.append(("timer", 0))
        with mock.patch.object(SERVER.threading, "Timer", return_value=timer):
            SERVER.Handler.do_POST(handler)
        self.assertEqual(handler._send_json.call_args.args, (202, {"accepted": True}))
        self.assertEqual(order, [("response", 202), ("timer", 0)])
        self.assertEqual(SERVER._LIFECYCLE.state, "shutting_down")

    def test_external_database_acceptance_precedes_reserved_graceful_shutdown(self):
        """The helper handoff sends 202 before backend teardown can begin."""
        h = self._handler("/api/databases/update", {"Content-Length": "0"})
        h.rfile = io.BytesIO()
        order = []
        h._send_json.side_effect = lambda *args, **kwargs: order.append(("response", args[0]))
        with mock.patch.object(SERVER, "handle_update_stream", return_value=(202, {"accepted": True, "job_id": "A" * 32})), \
                mock.patch.object(SERVER, "_schedule_shutdown", side_effect=lambda *_: order.append(("shutdown", 0))):
            SERVER.Handler.do_POST(h)
        self.assertEqual(order, [("response", 202), ("shutdown", 0)])
        self.assertEqual(SERVER._LIFECYCLE.state, "shutting_down")

    def test_nonce_is_one_time_and_wrong_or_missing_nonce_is_rejected(self):
        nonce = self._session()
        missing = self._shutdown(None)
        SERVER.Handler.do_POST(missing)
        self.assertEqual(missing._send_json.call_args.args[0], 403)
        wrong = self._shutdown(nonce, header_nonce="not-the-nonce")
        SERVER.Handler.do_POST(wrong)
        self.assertEqual(wrong._send_json.call_args.args[0], 403)
        valid = self._shutdown(nonce)
        with mock.patch.object(SERVER, "_schedule_shutdown"):
            SERVER.Handler.do_POST(valid)
        self.assertEqual(valid._send_json.call_args.args[0], 202)
        reused = self._shutdown(nonce)
        SERVER.Handler.do_POST(reused)
        self.assertEqual(reused._send_json.call_args.args[0], 403)

    def test_non_loopback_wrong_origin_and_get_are_rejected(self):
        nonloop = self._handler("/api/ui/shutdown-session", {"Origin": self.origin, "X-HADS-UI-Session": "request"}, {"purpose": "shutdown"}, ("192.0.2.4", 1))
        SERVER.Handler.do_POST(nonloop)
        self.assertEqual(nonloop._send_json.call_args.args[0], 403)
        wrong_origin = self._handler("/api/ui/shutdown-session", {"Origin": "http://localhost:45321", "X-HADS-UI-Session": "request"}, {"purpose": "shutdown"})
        SERVER.Handler.do_POST(wrong_origin)
        self.assertEqual(wrong_origin._send_json.call_args.args[0], 200, "localhost is the second exact allowed origin")
        evil_origin = self._handler("/api/ui/shutdown-session", {"Origin": "http://127.0.0.1:45322", "X-HADS-UI-Session": "request"}, {"purpose": "shutdown"})
        SERVER.Handler.do_POST(evil_origin)
        self.assertEqual(evil_origin._send_json.call_args.args[0], 403)
        missing_origin = self._handler("/api/ui/shutdown-session", {"X-HADS-UI-Session": "request"}, {"purpose": "shutdown"})
        SERVER.Handler.do_POST(missing_origin)
        self.assertEqual(missing_origin._send_json.call_args.args[0], 403)
        get = object.__new__(SERVER.Handler); get.path = "/api/ui/shutdown"; get._send_json = mock.Mock()
        SERVER.Handler.do_GET(get)
        self.assertEqual(get._send_json.call_args.args[0], 405)

    def test_critical_operation_refuses_shutdown_without_stopping_app(self):
        SERVER._LIFECYCLE.begin_critical()
        try:
            nonce = self._session()
            h = self._shutdown(nonce)
            with mock.patch.object(SERVER, "_schedule_shutdown") as scheduled:
                SERVER.Handler.do_POST(h)
            self.assertEqual(h._send_json.call_args.args[0], 409)
            scheduled.assert_not_called()
            self.assertEqual(SERVER._LIFECYCLE.state, "running")
        finally:
            SERVER._LIFECYCLE.end_critical()

    def test_active_cache_connection_is_registered_and_explicitly_closed(self):
        """Aktivní parser nesmí zůstat mimo registr údržby databáze."""
        previous_cache = dict(SERVER._db_cache)
        path = Path(self.temp.name) / "Česká aktivní databáze.ndb"
        parser = mock.Mock()
        try:
            SERVER._db_cache.update(
                {"path": None, "db": None, "connection_token": None}
            )
            with mock.patch.object(SERVER, "_default_db_path", return_value=str(path)), \
                    mock.patch.object(SERVER, "NdbDatabase", return_value=parser):
                self.assertIs(SERVER.get_db(), parser)
                self.assertEqual(
                    SERVER._db_operations.registered_connection_count(path), 1
                )
                SERVER._close_active_cache()
            parser.close.assert_called_once()
            self.assertEqual(
                SERVER._db_operations.registered_connection_count(path), 0
            )
        finally:
            SERVER._db_cache.clear()
            SERVER._db_cache.update(previous_cache)

    def test_teardown_closes_db_caches_cancels_background_and_never_kills_process(self):
        db = mock.Mock(); connection = mock.Mock(); db._con = connection
        SERVER._db_cache["db"] = db; SERVER._db_cache["path"] = "něco.ndb"; SERVER._dbkey_cache["něco.ndb"] = "podnik"
        timer = mock.Mock(); thread = mock.Mock(); thread.join = mock.Mock()
        SERVER._BACKGROUND_TIMERS.append(timer); SERVER._BACKGROUND_THREADS.append(thread)
        with mock.patch.object(SERVER, "_remove_server_lock") as remove_lock, mock.patch.object(os, "kill") as kill:
            SERVER._graceful_teardown()
        timer.cancel.assert_called_once(); thread.join.assert_called_once(); db.close.assert_called_once()
        self.assertEqual(SERVER._db_cache, {"path": None, "db": None, "connection_token": None})
        self.assertEqual(SERVER._dbkey_cache, {})
        SERVER._SERVER.shutdown.assert_called_once(); remove_lock.assert_called_once(); kill.assert_not_called()

    def test_lock_is_removed_only_for_this_process_and_simulated_relaunch_can_write_new_lock(self):
        lock = SERVER._SERVER_LOCK_FILE
        lock.write_text(json.dumps({"pid": os.getpid() + 1, "process_identity": "other"}), encoding="utf-8")
        SERVER._remove_server_lock()
        self.assertTrue(lock.exists())
        lock.write_text(json.dumps({"pid": os.getpid(), "process_identity": SERVER._process_identity()}), encoding="utf-8")
        SERVER._remove_server_lock()
        self.assertFalse(lock.exists())
        SERVER._write_server_lock(45322)
        self.assertTrue(lock.exists())
        info = json.loads(lock.read_text(encoding="utf-8"))
        self.assertEqual(info["port"], 45322)
        SERVER._remove_server_lock()

    def test_ui_confirmation_state_and_labels_are_present(self):
        html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
        for label in ("Ukončit HADS", "Zrušit", "Aktivní práce, nahrávání databáze nebo generování protokolu mohou být přerušeny", "HADS byl ukončen", "bezpečně aktualizovat instalační složku"):
            self.assertIn(label, html)
        for token in ("X-HADS-UI-Shutdown-Nonce", "/api/ui/shutdown-session", "window.close()"):
            self.assertIn(token, js)

    def test_no_retired_brand_token_in_sources(self):
        token = "".join(("a", "dash")).encode().lower()
        for item in ROOT.rglob("*"):
            if "__pycache__" in item.parts or ".pytest_cache" in item.parts or not item.is_file():
                continue
            self.assertNotIn(token, item.read_bytes().lower(), str(item))


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
