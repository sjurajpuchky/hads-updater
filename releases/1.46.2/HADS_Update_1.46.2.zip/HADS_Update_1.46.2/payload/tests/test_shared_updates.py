"""Regrese podepsaných aktualizací ze sdílené složky bez živého HTTP serveru."""
from __future__ import annotations

import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path); assert spec and spec.loader
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


SU = load("shared_updates_test", ROOT / "backend" / "shared_updates.py")
UPDATER = load("shared_updater_test", ROOT / "tools" / "hads_updater.py")
SERVER = load("shared_server_test", ROOT / "backend" / "server.py")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    return h.hexdigest()


class SharedUpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads shared update Česky & (test) ")
        self.base = Path(self.temp.name); self.data = self.base / "data"; self.data.mkdir()
        self.repo = self.base / "HADS_aktualizace"; self.repo.mkdir()
        self.private = self.base / "signing-private.pem"; self.public = self.base / "signing-public.pem"
        subprocess.run(["openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:2048", "-out", str(self.private)], check=True, capture_output=True)
        subprocess.run(["openssl", "pkey", "-in", str(self.private), "-pubout", "-out", str(self.public)], check=True, capture_output=True)

    def tearDown(self): self.temp.cleanup()

    def package(self, version: str, traversal: bool = False) -> Path:
        target = self.base / f"HADS_Update_{version}.zip"; payload = b'APP_VERSION = "' + version.encode() + b'"\n'
        manifest = {"product":"HADS", "version":version, "minimum_version":"1.33.1", "preserve":["data/**", "runtime/**"], "release_notes":"test", "files":[{"path":"backend/version.py", "size":len(payload), "sha256":hashlib.sha256(payload).hexdigest()}]}
        with zipfile.ZipFile(target, "w") as z:
            z.writestr(f"HADS_Update_{version}/manifest.json", json.dumps(manifest))
            z.writestr(f"HADS_Update_{version}/hads_updater.py", "# test\n")
            z.writestr(f"HADS_Update_{version}/payload/backend/version.py", payload)
            if traversal: z.writestr(f"HADS_Update_{version}/../escape.txt", "x")
        return target

    def release(self, version: str, minimum: str = "1.33.1", mandatory: bool = False, package: Path | None = None, signer: Path | None = None) -> Path:
        folder = self.repo / version; folder.mkdir(exist_ok=True)
        package = package or self.package(version); copied = folder / package.name; shutil.copy2(package, copied)
        doc = {"product":"HADS", "version":version, "release_date":"2026-08-19", "package_filename":copied.name,
               "byte_size":copied.stat().st_size, "sha256":digest(copied), "minimum_version":minimum, "mandatory":mandatory,
               "title":"Test vydání", "summary":"Bezpečný souhrn", "release_notes":{"new":["Nová funkce"],"improved":["Lepší postup"],"fixed":["Oprava"],"security":["Podpis"],"important":["Pozor"]}}
        raw = SU.canonical_json(doc); (folder / "release.json").write_bytes(raw + b"\n")
        signed = subprocess.run(["openssl", "dgst", "-sha256", "-sign", str(signer or self.private)], input=raw, capture_output=True, check=True).stdout
        (folder / "release.json.sig").write_text(base64.b64encode(signed).decode() + "\n", encoding="ascii")
        return folder

    def test_strict_semver_and_highest_compatible_folder_selection(self):
        self.release("1.9.0", minimum="1.0.0"); self.release("1.10.0", minimum="1.0.0"); self.release("1.34.1", minimum="1.35.0")
        (self.repo / "1.10").mkdir(); (self.repo / "not-a-version").mkdir(); (self.repo / "1.11.0.partial").mkdir()
        found = SU.discover(str(self.repo), "1.8.0", self.public)
        self.assertEqual(found["version"], "1.10.0")
        self.assertGreater(SU.version_tuple("1.10.0"), SU.version_tuple("1.9.0"))
        for invalid in ("1.01.0", "1.2", "1.2.3.4", "v1.2.3", "1.-2.3"):
            with self.assertRaises(SU.SharedUpdateError): SU.version_tuple(invalid)

    def test_same_lower_and_minimum_versions_are_not_offered(self):
        self.release("1.33.1"); self.release("1.33.0"); self.release("1.34.0", minimum="1.34.0")
        self.assertIsNone(SU.discover(str(self.repo), "1.33.1", self.public))

    def test_mandatory_flag_is_preserved_for_update_ui(self):
        self.release("1.34.0", mandatory=True)
        found = SU.discover(str(self.repo), "1.33.1", self.public)
        self.assertTrue(found["mandatory"])

    def test_signature_tamper_and_wrong_key_are_rejected(self):
        folder = self.release("1.34.0")
        doc = json.loads((folder / "release.json").read_text()); doc["title"] = "Změněno"
        (folder / "release.json").write_text(json.dumps(doc), encoding="utf-8")
        self.assertIsNone(SU.discover(str(self.repo), "1.33.1", self.public))
        shutil.rmtree(folder); self.release("1.34.0")
        other = self.base / "other.pem"; subprocess.run(["openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:2048", "-out", str(other)], check=True, capture_output=True)
        folder = self.repo / "1.34.0"; raw = SU.canonical_json(json.loads((folder / "release.json").read_text()))
        wrong = subprocess.run(["openssl", "dgst", "-sha256", "-sign", str(other)], input=raw, capture_output=True, check=True).stdout
        (folder / "release.json.sig").write_text(base64.b64encode(wrong).decode(), encoding="ascii")
        self.assertIsNone(SU.discover(str(self.repo), "1.33.1", self.public))

    def test_hash_size_schema_and_path_mismatch_are_rejected(self):
        folder = self.release("1.34.0"); package = next(folder.glob("*.zip")); package.write_bytes(package.read_bytes() + b"changed")
        self.assertIsNone(SU.discover(str(self.repo), "1.33.1", self.public))
        shutil.rmtree(folder); folder = self.release("1.34.0"); package = next(folder.glob("*.zip")); raw = bytearray(package.read_bytes()); raw[-1] ^= 1; package.write_bytes(raw)
        self.assertIsNone(SU.discover(str(self.repo), "1.33.1", self.public), "stejně velký zásah musí selhat na SHA-256")
        doc = json.loads((folder / "release.json").read_text()); doc["package_filename"] = "../other.zip"
        with self.assertRaises(SU.SharedUpdateError): SU.validate_release(doc, "1.34.0")
        doc["package_filename"] = "safe.zip"; doc["release_notes"] = {"new": []}
        with self.assertRaises(SU.SharedUpdateError): SU.validate_release(doc, "1.34.0")

    def test_settings_unicode_special_path_and_unavailable_source(self):
        special = self.base / "Česká cesta & (Drive)"; special.mkdir()
        saved = SU.save_settings(self.data, str(special), False)
        self.assertEqual(saved["source_path"], str(special.resolve()))
        self.assertFalse(SU.load_settings(self.data)["automatic_startup_check"])
        with self.assertRaises(SU.SharedUpdateError): SU.discover(str(self.base / "odpojená složka"), "1.33.1", self.public)
        with mock.patch.object(SU, "_powershell_folder_picker", return_value=str(special)):
            with mock.patch.object(SU.os, "name", "nt"):
                self.assertEqual(SU.choose_source_folder(), str(special))

    def test_safe_extraction_rejects_traversal_and_symlink(self):
        package = self.package("1.34.0", traversal=True)
        with self.assertRaises(SU.SharedUpdateError): SU._safe_extract_update(package, self.base / "stage", "1.34.0")
        link = self.base / "link.zip"
        with zipfile.ZipFile(link, "w") as z:
            info = zipfile.ZipInfo("HADS_Update_1.34.0/link"); info.create_system = 3; info.external_attr = 0o120777 << 16
            z.writestr(info, "target")
        with self.assertRaises(SU.SharedUpdateError): SU._safe_extract_update(link, self.base / "stage2", "1.34.0")

    def test_staging_streams_and_spawn_failure_keeps_app_running(self):
        self.release("1.34.0"); SU.save_settings(self.data, str(self.repo), True)
        install = self.base / "HADS"; (install / "runtime").mkdir(parents=True)
        with mock.patch.object(SU, "subprocess") as sub:
            sub.Popen.side_effect = OSError("blocked")
            with self.assertRaises(SU.SharedUpdateError): SU.stage_and_spawn(self.data, install, "1.33.1", self.public)
        staging = self.base / SU.STAGE_ROOT
        self.assertFalse(staging.exists() and any(staging.iterdir()))
        self.assertTrue(install.exists())

    def test_successful_stage_rechecks_and_passes_wait_restart_arguments(self):
        self.release("1.34.0"); SU.save_settings(self.data, str(self.repo), True)
        install = self.base / "HADS"; (install / "runtime").mkdir(parents=True)
        calls = []
        result = SU.stage_and_spawn(self.data, install, "1.33.1", self.public, runner=lambda cmd, **kw: calls.append((cmd, kw)))
        self.assertTrue(result["accepted"]); self.assertIn("--wait-pid", calls[0][0]); self.assertIn("--restart", calls[0][0])
        self.assertTrue((Path(result["stage"]) / "trusted_release_notes.json").is_file())
        self.assertFalse(str(Path(result["stage"]).resolve()).startswith(str(self.data.resolve())))
        class BusyLock:
            def acquire(self, blocking=False): return False
            def release(self): raise AssertionError("release se při odmítnutí nevolá")
        with self.assertRaises(SU.StageBusy):
            with mock.patch.object(SU, "_stage_lock", BusyLock()): SU.stage_and_spawn(self.data, install, "1.33.1", self.public)

    def test_streaming_copy_and_changed_during_copy_are_rejected(self):
        source_path = self.base / "large-package.zip"; source_path.write_bytes(b"x" * (2 * 1024 * 1024 + 17))
        expected = digest(source_path); size = source_path.stat().st_size
        class TrackingSource:
            def __init__(self, path, changed=False): self.path = path; self.changed = changed; self.calls = 0; self.maximum = 0
            def stat(self):
                self.calls += 1
                return type("S", (), {"st_size": size, "st_mtime_ns": 1 if self.calls == 1 or not self.changed else 2})()
            def open(self, mode):
                raw = self.path.open(mode); outer = self
                class Handle:
                    def __enter__(self): return self
                    def __exit__(self, *args): raw.close()
                    def read(self, amount=-1):
                        outer.maximum = max(outer.maximum, amount)
                        if amount > 1024 * 1024: raise AssertionError("kopie nesmí načítat celý balíček")
                        return raw.read(amount)
                return Handle()
        normal = TrackingSource(source_path)
        target = self.base / "streamed.zip"; SU._copy_verified(normal, target, size, expected)
        self.assertLessEqual(normal.maximum, 1024 * 1024)
        with self.assertRaises(SU.SharedUpdateError): SU._copy_verified(TrackingSource(source_path, changed=True), self.base / "changed.zip", size, expected)

    def test_post_update_notes_once_and_cleanup(self):
        note = {"format":1,"version":"1.34.0","title":"T","summary":"S","release_notes":{k:[] for k in ("new","improved","fixed","security","important")},"shown_version":""}
        src = self.base / "notes.json"; src.write_text(json.dumps(note), encoding="utf-8")
        SU.save_post_update_notes(self.data, str(src), "1.34.0")
        self.assertTrue(SU.post_update_notes(self.data, "1.34.0")["unseen"])
        self.assertFalse(SU.post_update_notes(self.data, "1.34.0", mark_shown=True)["unseen"])
        old = self.base / SU.STAGE_ROOT / "shared-old"; old.mkdir(parents=True); os.utime(old, (0,0))
        self.assertEqual(SU.cleanup_abandoned_staging(self.data, 1), 1)

    def test_updater_wait_restart_and_release_notes(self):
        with mock.patch.object(UPDATER, "normalize_installation_target", return_value=self.base), \
             mock.patch.object(UPDATER, "_validate_installation", return_value="1.33.1"), \
             mock.patch.object(UPDATER, "_wait_for_pid_exit") as waited, \
             mock.patch.object(UPDATER, "update", return_value=0), \
             mock.patch.object(UPDATER, "_load_installed_version", return_value="1.34.0"), \
             mock.patch.object(UPDATER, "_save_trusted_release_notes") as saved, \
             mock.patch.object(UPDATER, "_restart_application") as restart:
            self.assertEqual(UPDATER.main(["--install", str(self.base), "--wait-pid", "99", "--restart", "--trusted-release-notes", "notes.json"]), 0)
            waited.assert_called_once_with(99, 90.0); saved.assert_called_once(); restart.assert_called_once_with(self.base)

    def test_successful_spawn_schedules_shutdown_only_after_accepted_response(self):
        handler = object.__new__(SERVER.Handler); handler.path = "/api/updates/install"; handler._send_json = mock.Mock()
        timer = mock.Mock(); timer.start = mock.Mock()
        with mock.patch.object(SERVER.shared_updates, "stage_and_spawn", return_value={"accepted": True}),              mock.patch.object(SERVER.threading, "Timer", return_value=timer) as timer_factory:
            SERVER.Handler.do_POST(handler)
        handler._send_json.assert_called_once_with(202, {"accepted": True})
        timer_factory.assert_called_once(); timer.start.assert_called_once()
        # Předchozí větev již přijala ukončení; samostatná chybová větev začíná v běžícím lifecycle.
        SERVER._LIFECYCLE = SERVER.LifecycleController()
        failing = object.__new__(SERVER.Handler); failing.path = "/api/updates/install"; failing._send_json = mock.Mock()
        with mock.patch.object(SERVER.shared_updates, "stage_and_spawn", side_effect=SERVER.shared_updates.SharedUpdateError("selhalo")),              mock.patch.object(SERVER.threading, "Timer") as timer_factory:
            SERVER.Handler.do_POST(failing)
        failing._send_json.assert_called_once_with(400, {"detail": "selhalo"}); timer_factory.assert_not_called()

    def test_startup_check_is_explicitly_background_and_disableable(self):
        source = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")
        self.assertIn("_start_background(_startup_update_check", source)
        settings = SU.save_settings(self.data, str(self.repo), False)
        self.assertFalse(settings["automatic_startup_check"])

    def test_ui_and_public_key_are_present(self):
        html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8"); js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
        for label in ("Zkontrolovat aktualizace", "Nastavit složku aktualizací", "Co je nového", "Nainstalovat aktualizaci", "Později", "Nové funkce", "Vylepšení", "Opravy", "Zabezpečení", "Důležitá upozornění"):
            self.assertIn(label, html + js)
        self.assertIn("BEGIN PUBLIC KEY", (ROOT / "backend" / "release_signing_public.pem").read_text())

if __name__ == "__main__": unittest.main()
