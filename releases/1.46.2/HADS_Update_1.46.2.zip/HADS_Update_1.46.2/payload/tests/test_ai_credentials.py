"""Bezpečnostní regrese pro lokální AI credential store; nespouští HTTP server."""
from __future__ import annotations

import importlib.util
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
import urllib.error
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
import ai_eval
from ai_secrets import LocalSecretStore, SecretStorageError, WINDOWS_BACKEND


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class AiCredentialStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.data = Path(self.temp.name) / "data"
        self.data.mkdir()
        self.old_cfg = ai_eval._CFG_FILE
        ai_eval._CFG_FILE = self.data / "ai_config.json"

    def tearDown(self):
        ai_eval._CFG_FILE = self.old_cfg
        self.temp.cleanup()

    def test_replace_one_provider_preserves_other_and_empty_is_noop(self):
        ai_eval.set_config(provider="openai", api_key="test-openai-secret", model="gpt-4o")
        ai_eval.set_config(provider="anthropic", api_key="test-anthropic-secret")
        ai_eval.set_config(provider="openai", api_key="")
        self.assertEqual(ai_eval.get_api_key("openai"), "test-openai-secret")
        self.assertEqual(ai_eval.get_api_key("anthropic"), "test-anthropic-secret")
        ai_eval.set_config(provider="openai", api_key="replacement-openai-secret")
        self.assertEqual(ai_eval.get_api_key("openai"), "replacement-openai-secret")
        self.assertEqual(ai_eval.get_api_key("anthropic"), "test-anthropic-secret")

    def test_explicit_independent_deletion_and_no_secret_status_or_plain_config(self):
        openai = "openai-not-in-response"
        anthropic = "anthropic-not-in-response"
        ai_eval.set_config(provider="openai", api_key=openai)
        ai_eval.set_config(provider="anthropic", api_key=anthropic)
        response = json.dumps(ai_eval.status())
        self.assertNotIn(openai, response)
        self.assertNotIn(anthropic, response)
        self.assertNotIn(openai, ai_eval._CFG_FILE.read_text(encoding="utf-8"))
        self.assertNotIn(anthropic, ai_eval._CFG_FILE.read_text(encoding="utf-8"))
        ai_eval.delete_provider("openai")
        self.assertFalse(ai_eval.status()["has_openai_key"])
        self.assertTrue(ai_eval.status()["has_anthropic_key"])
        ai_eval.delete_provider("anthropic")
        self.assertFalse(ai_eval.status()["has_anthropic_key"])

    def test_plaintext_migration_is_verified_then_removed(self):
        secret = "legacy-secret-never-returned"
        ai_eval._CFG_FILE.write_text(json.dumps({
            "model": "claude-sonnet-4-6", "openai_api_key": secret, "anthropic_api_key": "",
        }), encoding="utf-8")
        self.assertEqual(ai_eval.get_model(), "claude-sonnet-4-6")
        self.assertEqual(ai_eval.get_api_key("openai"), secret)
        self.assertNotIn(secret, ai_eval._CFG_FILE.read_text(encoding="utf-8"))
        self.assertNotIn(secret, (self.data / "ai_credentials.bin").read_text(encoding="utf-8"))
        self.assertNotIn("openai_api_key", json.loads(ai_eval._CFG_FILE.read_text(encoding="utf-8")))

    def test_mocked_windows_dpapi_roundtrip_and_failure_does_not_create_plaintext(self):
        calls = []
        def fake_dpapi(protect, raw, entropy):
            calls.append((protect, entropy))
            return raw[::-1]
        store = LocalSecretStore(self.data, system_name="Windows", dpapi=fake_dpapi)
        store.save({"openai": "dpapi-test-secret"})
        record = json.loads((self.data / "ai_credentials.bin").read_text(encoding="utf-8"))
        self.assertEqual(record["backend"], WINDOWS_BACKEND)
        self.assertNotIn("dpapi-test-secret", json.dumps(record))
        self.assertEqual(store.load()["openai"], "dpapi-test-secret")
        self.assertEqual([c[0] for c in calls], [True, False])
        before = (self.data / "ai_credentials.bin").read_bytes()
        failing = LocalSecretStore(self.data, system_name="Windows",
                                   dpapi=lambda *args: (_ for _ in ()).throw(SecretStorageError("safe failure")))
        with self.assertRaises(SecretStorageError):
            failing.save({"openai": "new-secret"})
        self.assertEqual((self.data / "ai_credentials.bin").read_bytes(), before)
        self.assertNotIn(b"new-secret", before)

    def test_unreadable_dpapi_metadata_reports_error_without_erasing_blob(self):
        def entropy_bound_dpapi(protect, raw, entropy):
            marker = entropy[:8]
            if protect:
                return marker + raw[::-1]
            if not raw.startswith(marker):
                raise SecretStorageError("wrong stable install identity")
            return raw[8:][::-1]
        store = LocalSecretStore(self.data, system_name="Windows", dpapi=entropy_bound_dpapi)
        store.save({"openai": "dummy-dpapi-metadata-fixture"})
        path = self.data / "ai_credentials.bin"
        record = json.loads(path.read_text(encoding="utf-8"))
        record["install_id"] = "0" * 48
        path.write_text(json.dumps(record), encoding="utf-8")
        before = path.read_bytes()
        with self.assertRaises(SecretStorageError):
            store.load()
        self.assertEqual(path.read_bytes(), before)

    def test_dpapi_blob_recovery_remains_standalone_when_no_machinekey_was_applicable(self):
        # Windows DPAPI LocalMachine intentionally has no fallback machinekey.
        # Startup recovery must restore its hash-verified blob normally rather
        # than demanding a non-existent two-file fallback pair.
        guard = _load("hads_data_protection_dpapi_recovery", ROOT / "backend" / "data_protection.py")
        install = Path(self.temp.name) / "dpapi-install"
        backup = Path(self.temp.name) / "dpapi-backup"
        archived = backup / "data_files" / "ai_credentials.bin"
        archived.parent.mkdir(parents=True)
        raw = b'{"format":1,"backend":"windows-dpapi-local-machine","fixture":true}'
        archived.write_bytes(raw)
        expected = {
            "files": {
                "data/ai_credentials.bin": {
                    "kind": "file", "size": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                }
            }
        }
        restored = guard._restore_missing_from_backup(
            install, backup, ["data/ai_credentials.bin"], expected
        )
        self.assertEqual(restored, ["data/ai_credentials.bin"])
        self.assertEqual((install / "data" / "ai_credentials.bin").read_bytes(), raw)
        self.assertFalse((install / "data" / "ai_credentials.machinekey").exists())

    def test_upstream_error_body_and_public_error_never_echo_secret(self):
        secret = "provider-echoed-secret-must-not-leak"
        error = urllib.error.HTTPError(
            "https://api.openai.com/v1/chat/completions", 401, "Unauthorized",
            {}, io.BytesIO(json.dumps({"error": {"message": secret}}).encode("utf-8")),
        )
        with mock.patch("urllib.request.urlopen", side_effect=error):
            with self.assertRaises(RuntimeError) as caught:
                ai_eval._call_openai(secret, "gpt-4o", "system", "user")
        error.close()
        self.assertNotIn(secret, str(caught.exception))
        self.assertNotIn(secret, ai_eval.public_error_message(caught.exception))

    def test_non_windows_fallback_rejects_a_copied_store_on_another_machine(self):
        import ai_secrets
        with mock.patch.object(ai_secrets, "_fallback_machine_binding", return_value=b"A" * 32):
            store = LocalSecretStore(self.data, system_name="Linux")
            store.save({"openai": "local-machine-bound-secret"})
            self.assertEqual(store.load()["openai"], "local-machine-bound-secret")
        with mock.patch.object(ai_secrets, "_fallback_machine_binding", return_value=b"B" * 32):
            with self.assertRaises(SecretStorageError):
                LocalSecretStore(self.data, system_name="Linux").load()


class AiUiAndApiSecurityTests(unittest.TestCase):
    def test_ui_has_masked_empty_inputs_and_explicit_delete_confirmation(self):
        html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
        self.assertIn('data-settings-tab="aiagents"', html)
        self.assertIn('id="ai-openai-key"', html)
        self.assertIn('id="ai-anthropic-key"', html)
        self.assertGreaterEqual(html.count('type="password"'), 2)
        self.assertIn("window.confirm", js)
        self.assertIn("/api/ai/config/delete", js)
        self.assertIn("input.value = \"\"", js)
        self.assertNotIn("openai_api_key", html + js)

    def test_ai_config_requires_loopback_same_origin_and_one_time_nonce(self):
        server = _load("hads_server_ai_security", ROOT / "backend" / "server.py")
        class FakeServer:
            server_address = ("127.0.0.1", 8123)
        old_server = server._SERVER
        try:
            server._SERVER = FakeServer()
            handler = server.Handler.__new__(server.Handler)
            handler.client_address = ("127.0.0.1", 50)
            handler.headers = {"Host": "127.0.0.1:8123", "Origin": "http://127.0.0.1:8123"}
            self.assertTrue(handler._ai_config_request_is_allowed())
            nonce = server._AI_CONFIG_NONCES.issue(handler.headers["Origin"])
            handler.headers["X-HADS-AI-Config-Nonce"] = nonce
            self.assertTrue(handler._ai_config_nonce_is_valid({"nonce": nonce}))
            self.assertFalse(handler._ai_config_nonce_is_valid({"nonce": nonce}))
            handler.client_address = ("192.168.0.3", 50)
            self.assertFalse(handler._ai_config_request_is_allowed())
            handler.client_address = ("127.0.0.1", 50)
            handler.headers["Origin"] = "https://attacker.invalid"
            self.assertFalse(handler._ai_config_request_is_allowed())
        finally:
            server._SERVER = old_server


class AiPackagingAndInternalExportTests(unittest.TestCase):
    def test_release_archives_exclude_credential_artifacts(self):
        release = _load("hads_release_ai_test", ROOT / "tools" / "build_release.py")
        with tempfile.TemporaryDirectory() as td:
            app = Path(td) / "full.zip"
            update = Path(td) / "update.zip"
            release.build_clean_application(app)
            release.build_update(update)
            for artifact in (app, update):
                with zipfile.ZipFile(artifact) as z:
                    names = z.namelist()
                    self.assertFalse(any(n.endswith("ai_credentials.bin") or n.endswith("ai_credentials.machinekey") for n in names))
                    self.assertFalse(any("/data/" in ("/" + n) for n in names) if artifact == update else False)

    def test_internal_export_rejects_plaintext_and_documents_same_pc_limit(self):
        exporter_path = ROOT / "tools" / "export_internal_ai_credentials.py"
        # Admin-only export helper is deliberately not distributed in the normal
        # full/update/shared release; its source is tested in the maintainer tree.
        if not exporter_path.is_file():
            self.assertFalse((ROOT / "tools" / "export_internal_ai_credentials.py").exists())
            return
        exporter = _load("hads_export_ai_test", exporter_path)
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "HADS"
            (source / "data").mkdir(parents=True)
            bad = source / "data" / "ai_credentials.bin"
            bad.write_text('{"format":1,"backend":"plaintext","openai_api_key":"forbidden"}', encoding="utf-8")
            with self.assertRaises(exporter.ExportError):
                exporter.export_same_windows_computer(source, Path(td) / "export.zip")
            self.assertFalse((Path(td) / "export.zip").exists())
            self.assertIn("--i-understand-same-windows-computer",
                          exporter_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
