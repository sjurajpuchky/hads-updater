"""HTTP and persistence regressions for resilient AI Settings loading.

The server is started only inside individual tests and is shut down in tearDown.
Fixtures use inert strings, never production credentials.
"""
from __future__ import annotations

import http.client
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
import ai_eval
import ai_prompts
from ai_secrets import LocalSecretStore
import server


class AiSettingsHttpTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="HADS česká AI HTTP ")
        self.root = Path(self.temp.name) / "instalace Žlutý závod"
        self.data = self.root / "data"
        self.data.mkdir(parents=True)
        self.old = {
            "server_data": server.DATA_DIR,
            "server_lock": server._SERVER_LOCK_FILE,
            "eval_cfg": ai_eval._CFG_FILE,
            "prompts_data": ai_prompts.DATA_DIR,
            "server_ref": server._SERVER,
        }
        server.DATA_DIR = self.data
        server._SERVER_LOCK_FILE = self.root / "runtime" / "HADS.lock"
        ai_eval._CFG_FILE = self.data / "ai_config.json"
        ai_prompts.DATA_DIR = self.data
        server._SERVER = server.ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        self.port = server._SERVER.server_address[1]
        self.origin = f"http://127.0.0.1:{self.port}"
        self.thread = threading.Thread(target=server._SERVER.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        active = server._SERVER
        if active is not None:
            active.shutdown()
            active.server_close()
        self.thread.join(timeout=5)
        server.DATA_DIR = self.old["server_data"]
        server._SERVER_LOCK_FILE = self.old["server_lock"]
        ai_eval._CFG_FILE = self.old["eval_cfg"]
        ai_prompts.DATA_DIR = self.old["prompts_data"]
        server._SERVER = self.old["server_ref"]
        self.temp.cleanup()

    def request(self, method: str, path: str, *, headers=None, payload=None):
        request_headers = {"Host": f"127.0.0.1:{self.port}"}
        request_headers.update(headers or {})
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        connection.request(method, path, body=payload, headers=request_headers)
        response = connection.getresponse()
        raw = response.read()
        headers_out = dict(response.getheaders())
        connection.close()
        return response.status, headers_out, json.loads(raw.decode("utf-8"))

    def json_post(self, path, value, *, origin=True, extra_headers=None):
        headers = {"Content-Type": "application/json"}
        if origin:
            headers["Origin"] = self.origin
        headers.update(extra_headers or {})
        return self.request("POST", path, headers=headers,
                            payload=json.dumps(value).encode("utf-8"))

    def test_browser_shaped_get_without_origin_loads_status_and_bundled_defaults(self):
        # fetch() for a same-origin GET may omit Origin.  1.37 did not have an
        # override file, therefore this is the post-upgrade empty-file case.
        status, headers, body = self.request("GET", "/api/ai/status")
        self.assertEqual(status, 200)
        self.assertEqual(headers.get("Cache-Control"), "no-store")
        self.assertTrue(body["models"])
        self.assertEqual(body["providers"]["openai"], "not_configured")
        self.assertFalse((self.data / "ai_prompts.json").exists())

        status, headers, body = self.request("GET", "/api/ai/prompts")
        self.assertEqual(status, 200)
        self.assertEqual(headers.get("Cache-Control"), "no-store")
        self.assertGreaterEqual(len(body["templates"]), 3)
        self.assertEqual(body.get("warnings"), [])

    def test_get_accepts_exact_origin_or_referer_and_rejects_bad_host_or_foreign_origin(self):
        for headers in ({"Origin": self.origin}, {"Referer": self.origin + "/"}):
            with self.subTest(headers=headers):
                status, _, _ = self.request("GET", "/api/ai/status", headers=headers)
                self.assertEqual(status, 200)
        status, _, _ = self.request("GET", "/api/ai/prompts", headers={"Host": "localhost:1"})
        self.assertEqual(status, 403)
        status, _, _ = self.request("GET", "/api/ai/prompts", headers={"Origin": "https://foreign.invalid"})
        self.assertEqual(status, 403)

        handler = server.Handler.__new__(server.Handler)
        handler.client_address = ("192.168.1.9", 40000)
        handler.headers = {"Host": f"127.0.0.1:{self.port}"}
        self.assertFalse(handler._ai_read_request_is_allowed())

    def test_mutations_keep_exact_origin_and_one_time_nonce(self):
        status, _, _ = self.json_post("/api/ai/config/session", {"purpose": "ai-config"}, origin=False)
        self.assertEqual(status, 403)
        status, _, session = self.json_post(
            "/api/ai/config/session", {"purpose": "ai-config"},
            extra_headers={"X-HADS-AI-Config-Session": "request"},
        )
        self.assertEqual(status, 200)
        nonce = session["nonce"]
        status, _, saved = self.json_post("/api/ai/config", {"provider": "openai", "model": "gpt-4o-mini", "nonce": nonce},
                                          extra_headers={"X-HADS-AI-Config-Nonce": nonce})
        self.assertEqual(status, 200)
        self.assertIn("model", saved)
        status, _, _ = self.json_post("/api/ai/config", {"provider": "openai", "model": "gpt-4o-mini", "nonce": nonce},
                                      extra_headers={"X-HADS-AI-Config-Nonce": nonce})
        self.assertEqual(status, 403)

        status, _, prompt_session = self.json_post(
            "/api/ai/prompts/session", {"purpose": "ai-prompts"},
            extra_headers={"X-HADS-AI-Prompts-Session": "request"},
        )
        self.assertEqual(status, 200)
        prompt_nonce = prompt_session["nonce"]
        status, _, prompt_saved = self.json_post("/api/ai/prompts", {
            "id": "report_brief_v1", "text": "Ověřený text {report_contract}", "revision": 0,
            "nonce": prompt_nonce,
        }, extra_headers={"X-HADS-AI-Prompts-Nonce": prompt_nonce})
        self.assertEqual(status, 200)
        self.assertGreaterEqual(len(prompt_saved["templates"]), 3)

    def test_corrupt_prompt_override_falls_back_to_defaults_with_warning(self):
        (self.data / "ai_prompts.json").write_text("{not-json", encoding="utf-8")
        status, _, body = self.request("GET", "/api/ai/prompts")
        self.assertEqual(status, 200)
        self.assertGreaterEqual(len(body["templates"]), 3)
        self.assertTrue(body["warnings"])
        self.assertNotIn("{not-json", json.dumps(body))

    def test_valid_local_store_survives_status_load_and_no_secret_is_returned_or_logged(self):
        secret = "fixture-secret-must-not-leak"
        LocalSecretStore(self.data, system_name="Linux").save({"openai": secret})
        status, _, body = self.request("GET", "/api/ai/status")
        self.assertEqual(status, 200)
        rendered = json.dumps(body)
        self.assertTrue(body["has_openai_key"])
        self.assertEqual(body["providers"]["openai"], "configured")
        self.assertNotIn(secret, rendered)
        log = self.root / "runtime" / "HADS_startup.log"
        self.assertNotIn(secret, log.read_text(encoding="utf-8") if log.exists() else "")

    def test_unreadable_or_incomplete_store_is_preserved_and_reported_separately(self):
        LocalSecretStore(self.data, system_name="Linux").save({"openai": "inert-fixture"})
        blob = self.data / "ai_credentials.bin"
        key = self.data / "ai_credentials.machinekey"
        before_blob = blob.read_bytes()
        key.unlink()
        self.assertFalse(key.exists())
        status, _, body = self.request("GET", "/api/ai/status")
        self.assertEqual(status, 200)
        self.assertEqual(body["credential_storage"], "stored_unavailable")
        self.assertEqual(body["providers"]["openai"], "stored_unavailable")
        self.assertEqual(blob.read_bytes(), before_blob)
        self.assertFalse(key.exists(), "status read must not recreate missing pair key")

    def test_environment_has_precedence_and_unicode_cwd_does_not_change_data_root(self):
        alternate = self.root / "jiný adresář č"
        alternate.mkdir()
        original_cwd = Path.cwd()
        try:
            os.chdir(alternate)
            with mock.patch.dict(os.environ, {"OPENAI_API_KEY": "env-fixture-no-leak"}, clear=False):
                status, _, body = self.request("GET", "/api/ai/status")
        finally:
            os.chdir(original_cwd)
        self.assertEqual(status, 200)
        self.assertTrue(body["has_openai_key"])
        self.assertEqual(body["providers"]["openai"], "configured")
        self.assertFalse((alternate / "data" / "ai_config.json").exists())


class AiSettingsFrontendRegressionTests(unittest.TestCase):
    def test_frontend_has_retry_and_safe_czech_failure_states(self):
        html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
        self.assertIn('id="ai-config-retry"', html)
        self.assertIn('id="ai-prompts-retry"', html)
        self.assertIn("Klíč je uložen, ale nelze jej na tomto počítači načíst", js)
        self.assertIn("Klíče ani nastavení nebyly změněny", js)
        self.assertIn("loadAiPrompts již rozlišuje", js)
        self.assertNotIn("ai_credentials.bin", js)


if __name__ == "__main__":
    unittest.main()
