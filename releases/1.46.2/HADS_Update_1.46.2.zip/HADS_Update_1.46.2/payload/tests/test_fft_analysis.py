"""Regrese deterministické interpretace FFT spekter pro podklady AI.

Smyslem je zaručit, že veškerá aritmetika probíhá v aplikaci a je ověřitelná:
model dostane hotovou tabulku nálezů a nemá si co domýšlet. Testy proto hlídají
hlavně to, co by se v protokolu projevilo jako VYMYŠLENÁ závada.
"""
from __future__ import annotations

from pathlib import Path
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

import ai_eval  # noqa: E402
import ai_prompts  # noqa: E402
import fft_analysis as fft  # noqa: E402


STEP = 0.5
SPEED = 24.6
BEARING = {"BPFO": 3.585, "BPFI": 5.415, "BSF": 2.35, "FTF": 0.398}


def _spectrum(components, length=800, floor=0.001):
    """Umělé spektrum: slovník {frekvence: amplituda} na pravidelné mřížce."""
    values = [floor] * length
    for freq, amplitude in components.items():
        values[int(round(freq / STEP))] = amplitude
    return values


def _overall(values):
    return sum(v * v for v in values) ** 0.5


class PeakDetectionTests(unittest.TestCase):
    def test_peaks_are_sorted_by_amplitude_and_deduplicated(self):
        values = _spectrum({SPEED: 3.10, 2 * SPEED: 0.84, 3 * SPEED: 0.12})
        peaks = fft.find_peaks(values, STEP, limit=6)
        self.assertEqual([round(p["amplitude"], 2) for p in peaks],
                         [3.10, 0.84, 0.12])

    def test_one_broad_peak_is_not_reported_three_times(self):
        """Sousední čáry téhož kopce nesmí zabrat celý seznam vrcholů."""
        values = _spectrum({})
        base = int(round(SPEED / STEP))
        values[base - 1] = 2.6
        values[base] = 3.1
        values[base + 1] = 2.8
        values[int(round(2 * SPEED / STEP))] = 0.9
        peaks = fft.find_peaks(values, STEP, limit=4)
        self.assertEqual(len(peaks), 2)
        self.assertAlmostEqual(peaks[0]["amplitude"], 3.1)
        self.assertAlmostEqual(peaks[1]["amplitude"], 0.9)

    def test_distinct_high_frequency_peaks_are_not_swallowed(self):
        """Potlačení okolí se nesmí odvíjet od tolerance shody.

        Při ±2 % by okno na 4 kHz mělo šířku 80 Hz a zahodilo by i zcela
        samostatnou složku vzdálenou 40 Hz.
        """
        values = _spectrum({4000.0: 1.0, 4040.0: 0.8, 100.0: 0.6}, length=10000,
                           floor=0.0)
        freqs = [round(p["freq"]) for p in fft.find_peaks(values, STEP, limit=6)]
        self.assertIn(4000, freqs)
        self.assertIn(4040, freqs)

    def test_highpass_region_is_never_reported_as_a_peak(self):
        values = _spectrum({SPEED: 1.0})
        values[0] = 99.0          # stejnosměrná složka
        peaks = fft.find_peaks(values, STEP, limit=3)
        self.assertTrue(all(p["freq"] >= 1.0 for p in peaks))

    def test_empty_or_degenerate_input_returns_nothing(self):
        self.assertEqual(fft.find_peaks([], STEP), [])
        self.assertEqual(fft.find_peaks([0.0] * 50, STEP), [])
        self.assertEqual(fft.find_peaks([1.0] * 50, 0), [])


class FrequencyMatchingTests(unittest.TestCase):
    def test_defect_frequencies_are_coefficient_times_speed(self):
        freqs = fft.bearing_defect_frequencies(BEARING, SPEED)
        self.assertAlmostEqual(freqs["BPFO"], 3.585 * SPEED)
        self.assertAlmostEqual(freqs["BPFI"], 5.415 * SPEED)

    def test_no_speed_means_no_defect_frequencies_and_no_orders(self):
        self.assertEqual(fft.bearing_defect_frequencies(BEARING, None), {})
        self.assertIsNone(fft.describe_order(100.0, None))
        self.assertEqual(fft.match_frequency(100.0, None, {}, STEP), (None, None))

    def test_running_speed_order_wins_over_a_defect_coincidence(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        self.assertEqual(fft.match_frequency(SPEED, SPEED, defects, STEP)[0], "1× ot")
        self.assertEqual(fft.match_frequency(2 * SPEED, SPEED, defects, STEP)[0], "2× ot")

    def test_defect_harmonics_are_labelled(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        self.assertEqual(
            fft.match_frequency(defects["BPFO"], SPEED, defects, STEP)[0], "BPFO")
        self.assertEqual(
            fft.match_frequency(2 * defects["BPFO"], SPEED, defects, STEP)[0], "2× BPFO")

    def test_unrelated_frequency_is_left_unmatched(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        self.assertEqual(fft.match_frequency(311.7, SPEED, defects, STEP), (None, None))

    def test_wider_bearing_tolerance_accepts_a_slipping_frequency(self):
        """Valivé elementy prokluzují; BPFO se reálně liší o jednotky procent."""
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        drifted = defects["BPFO"] * 1.018          # odchylka 1,8 %
        self.assertIsNone(fft.match_frequency(
            drifted, SPEED, defects, STEP, bearing_tolerance_pct=1.0)[0])
        label, deviation = fft.match_frequency(
            drifted, SPEED, defects, STEP, bearing_tolerance_pct=2.0)
        self.assertEqual(label, "BPFO")
        self.assertAlmostEqual(deviation, 1.8, places=1)

    def test_order_and_bearing_tolerances_are_independent(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        drifted_order = 2 * SPEED * 1.018          # odchylka 1,8 % na 2× ot
        # Volná tolerance ložisek nesmí uvolnit i otáčkové řády.
        self.assertIsNone(fft.match_frequency(
            drifted_order, SPEED, defects, STEP,
            order_tolerance_pct=1.0, bearing_tolerance_pct=5.0)[0])

    def test_window_never_exceeds_the_configured_tolerance(self):
        """Okno se nesmí rozšířit zaokrouhlením na celé čáry.

        U nízkých frekvencí je rozteč čar velká vůči procentu; dřívější
        zaokrouhlení ven dávalo u FTF 8,8 Hz shodu s odchylkou přes 13 %.
        """
        step = 1.0
        values = [0.0] * 200
        values[10] = 0.9                    # čára na 10,0 Hz
        found = fft.amplitude_at(values, step, 8.8, tolerance_pct=2.0)
        self.assertIsNotNone(found)
        # Nejbližší čára je 9,0 Hz; 10,0 Hz je mimo toleranci i mimo nejbližší.
        self.assertAlmostEqual(found["freq"], 9.0)
        self.assertEqual(found["amplitude"], 0.0)

    def test_nearest_line_is_used_when_tolerance_is_narrower_than_resolution(self):
        step = 1.0
        values = [0.0] * 200
        values[9] = 0.7
        found = fft.amplitude_at(values, step, 8.8, tolerance_pct=0.1)
        self.assertAlmostEqual(found["freq"], 9.0)
        self.assertAlmostEqual(found["amplitude"], 0.7)

    def test_tolerance_outside_sane_range_falls_back_to_default(self):
        for bad in (None, "", 0, -1, 99, float("nan")):
            with self.subTest(bad=bad):
                self.assertEqual(fft.clamp_tolerance(bad, 2.0), 2.0)
        self.assertEqual(fft.clamp_tolerance(3.5, 2.0), 3.5)


class SpectralAnalysisTests(unittest.TestCase):
    def _analyze(self, level=fft.LEVEL_FULL):
        values = _spectrum({
            SPEED: 3.10, 2 * SPEED: 0.84, 3 * SPEED: 0.12,
            BEARING["BPFO"] * SPEED: 0.41,
            2 * BEARING["BPFO"] * SPEED: 0.22,
            311.7: 0.30,
        })
        return fft.analyze_spectrum(values, STEP, speed_hz=SPEED, bearing=BEARING,
                                    level=level, overall=_overall(values))

    def test_one_spectral_line_never_carries_two_defect_labels(self):
        """2× BPFO (176,4 Hz) a 3× BSF (173,4 Hz) padnou na tutéž čáru.

        Bez rozřešení kolize by protokol tvrdil poškození valivého elementu,
        které měření nedokládá — tedy přesně vymyšlená závada.
        """
        analysis = self._analyze()
        labels = [row["key"] for row in analysis["defects"]]
        self.assertIn("2× BPFO", labels)
        self.assertNotIn("3× BSF", labels)
        bins = [round(row["freq"] / STEP) for row in analysis["defects"]]
        self.assertEqual(len(bins), len(set(bins)))

    def test_reported_frequency_is_the_measured_line_not_the_target(self):
        analysis = self._analyze()
        first = analysis["harmonics"][0]
        self.assertEqual(first["order"], 1)
        # Cíl je 24,6 Hz, ale změřená čára leží na mřížce 0,5 Hz.
        self.assertAlmostEqual(first["freq"], 24.5)
        self.assertAlmostEqual(first["amplitude"], 3.10)

    def test_running_speed_is_reported_even_when_small(self):
        values = _spectrum({SPEED: 0.05, 300.0: 5.0})
        analysis = fft.analyze_spectrum(values, STEP, speed_hz=SPEED,
                                        bearing=BEARING, level=fft.LEVEL_FULL,
                                        overall=_overall(values))
        orders = [row["order"] for row in analysis["harmonics"]]
        self.assertIn(1, orders)

    def test_unreadably_small_amplitudes_are_never_listed(self):
        """Řádek „= 0.00“ není nález; model by jej jinak začal vysvětlovat."""
        values = _spectrum({SPEED: 0.0001, 300.0: 5.0}, floor=0.0)
        analysis = fft.analyze_spectrum(values, STEP, speed_hz=SPEED,
                                        bearing=BEARING, level=fft.LEVEL_FULL,
                                        overall=_overall(values))
        rows = analysis["harmonics"] + analysis["defects"]
        self.assertTrue(all(row["amplitude"] >= fft.MIN_REPORTABLE_AMPLITUDE
                            for row in rows), rows)
        self.assertEqual(analysis["harmonics"], [])

    def test_noise_level_harmonics_are_left_out(self):
        analysis = self._analyze()
        # 4×–6× ot jsou v tomto spektru jen šum a nemají se vypisovat.
        self.assertEqual([row["order"] for row in analysis["harmonics"]], [1, 2, 3])

    def test_minimal_level_reports_nothing_from_the_spectrum(self):
        analysis = self._analyze(level=fft.LEVEL_MINIMAL)
        self.assertEqual(analysis["peaks"], [])
        self.assertEqual(analysis["harmonics"], [])
        self.assertEqual(analysis["defects"], [])

    def test_reduced_level_keeps_matched_findings(self):
        analysis = self._analyze(level=fft.LEVEL_REDUCED)
        self.assertEqual(analysis["harmonics"], [])
        self.assertEqual(analysis["defects"], [])
        matched = [p["match"] for p in analysis["peaks"] if p["match"]]
        self.assertIn("BPFO", matched)

    def test_detail_level_follows_the_worst_band(self):
        self.assertEqual(fft.detail_level_for_band("A"), fft.LEVEL_MINIMAL)
        self.assertEqual(fft.detail_level_for_band("B"), fft.LEVEL_REDUCED)
        self.assertEqual(fft.detail_level_for_band("C"), fft.LEVEL_FULL)
        self.assertEqual(fft.detail_level_for_band("D"), fft.LEVEL_FULL)
        # Neznámé pásmo raději víc podkladů než tvrzení bez opory.
        self.assertEqual(fft.detail_level_for_band(None), fft.LEVEL_REDUCED)

    def test_machine_budget_trims_and_reports_how_much(self):
        analyses = [self._analyze() for _ in range(40)]
        dropped = fft.apply_machine_budget(analyses, budget=50)
        total = sum(fft.row_count(item) for item in analyses)
        self.assertLessEqual(total, 50)
        self.assertGreater(dropped, 0)

    def test_budget_does_nothing_when_it_fits(self):
        analyses = [self._analyze()]
        self.assertEqual(fft.apply_machine_budget(analyses, budget=500), 0)


class PromptRenderingTests(unittest.TestCase):
    def test_limits_show_their_source_and_the_unused_device_limits(self):
        text = "\n".join(ai_eval._quantity_lines({
            "name": "ISO RMS", "unit": "mm/s", "last_value": 4.82,
            "last_time": "2026-01-03T08:00", "ab": 2.3, "warning": 4.5,
            "alarm": 7.1, "db_warning": 3.0, "db_alarm": 6.0,
            "limit_source": "norm", "band": "C", "recent_trend": [],
        }))
        self.assertIn("pásmo C", text)
        self.assertIn("z normy", text)
        # Prompt používá desetinnou tečku (shodně se zbytkem podkladů pro AI).
        self.assertIn("A/B = 2.30", text)
        self.assertIn("varování B/C = 4.50", text)
        self.assertIn("NEPOUŽITY", text)

    def test_device_limits_are_not_repeated_when_they_are_the_valid_ones(self):
        text = "\n".join(ai_eval._quantity_lines({
            "name": "ACC RMS", "unit": "g", "last_value": 1.2,
            "warning": 2.0, "alarm": 4.0, "db_warning": 2.0, "db_alarm": 4.0,
            "limit_source": "db", "band": "A", "recent_trend": [],
        }))
        self.assertIn("z databáze přístroje", text)
        self.assertNotIn("NEPOUŽITY", text)

    def test_quantity_without_limits_is_declared_unclassifiable(self):
        text = "\n".join(ai_eval._quantity_lines({
            "name": "ENV RMS", "last_value": 0.9, "limit_source": "none",
            "band": None, "recent_trend": [],
        }))
        self.assertIn("nelze klasifikovat", text)
        self.assertIn("pásmo neurčeno", text)

    def test_inexact_match_shows_its_real_deviation(self):
        text = "\n".join(ai_eval._spectrum_lines({
            "name": "ACC ENV SPEC", "overall": 1.0,
            "analysis": {"level": "full", "peaks": [], "harmonics": [],
                         "defects": [{"key": "BPFO", "freq": 89.6,
                                      "amplitude": 0.41,
                                      "deviation_pct": 1.8}]},
        }))
        # Podklady pro AI používají desetinnou tečku, stejně jako zbytek promptu.
        self.assertIn("odch. +1.8 %", text)

    def test_exact_match_is_not_cluttered_with_a_zero_deviation(self):
        text = "\n".join(ai_eval._spectrum_lines({
            "name": "ACC ENV SPEC", "overall": 1.0,
            "analysis": {"level": "full", "peaks": [], "harmonics": [],
                         "defects": [{"key": "BPFO", "freq": 88.2,
                                      "amplitude": 0.41,
                                      "deviation_pct": 0.05}]},
        }))
        self.assertNotIn("odch.", text)

    def test_spectrum_without_findings_stays_short(self):
        text = "\n".join(ai_eval._spectrum_lines({
            "name": "ISO SPECTRUM", "overall": 0.8, "time": "2026-01-03T08:00",
            "analysis": {"level": "minimal", "peaks": [], "harmonics": [],
                         "defects": []},
        }))
        self.assertIn("overall", text)
        self.assertNotIn("vrcholy", text)


class SidebandTests(unittest.TestCase):
    """Postranní pásma rozlišují vnitřní kroužek od valivého elementu."""

    def _carrier_with_sidebands(self, spacing, pairs=3, carrier=200.0):
        comp = {carrier: 1.0}
        for k in range(1, pairs + 1):
            comp[carrier - spacing * k] = 0.4
            comp[carrier + spacing * k] = 0.4
        return _spectrum(comp, length=1200)

    def test_spacing_identifies_the_modulating_element(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        values = self._carrier_with_sidebands(SPEED)
        found = fft.find_sidebands(values, STEP, 200.0,
                                   [("1× ot", SPEED), ("FTF", defects["FTF"])])
        self.assertEqual(found["label"], "1× ot")
        self.assertGreaterEqual(found["pairs"], 2)

        values = self._carrier_with_sidebands(defects["FTF"])
        found = fft.find_sidebands(values, STEP, 200.0,
                                   [("1× ot", SPEED), ("FTF", defects["FTF"])])
        self.assertEqual(found["label"], "FTF")

    def test_asymmetric_component_is_not_modulation(self):
        values = _spectrum({200.0: 1.0, 200.0 + SPEED: 0.4}, length=1200)
        self.assertIsNone(fft.find_sidebands(values, STEP, 200.0,
                                             [("1× ot", SPEED)]))

    def test_single_weak_pair_is_rejected(self):
        """Jedna dvojice je při více kandidátech snadno dílem náhody."""
        values = self._carrier_with_sidebands(SPEED, pairs=1)
        self.assertIsNone(fft.find_sidebands(values, STEP, 200.0,
                                             [("1× ot", SPEED)]))

    def test_spacing_narrower_than_two_lines_is_refused(self):
        values = self._carrier_with_sidebands(0.5, pairs=3)
        self.assertIsNone(fft.find_sidebands(values, STEP, 200.0,
                                             [("úzký", 0.5)]))


class SpectrumPatternTests(unittest.TestCase):
    def test_harmonic_series_and_2x_ratio(self):
        comp = {SPEED * n: 1.0 / n for n in range(1, 8)}
        pattern = fft.spectrum_pattern(_spectrum(comp), STEP, SPEED)
        self.assertGreaterEqual(pattern["harmonic_count"], 4)
        self.assertAlmostEqual(pattern["ratio_2x_1x"], 0.5, places=2)
        self.assertTrue(pattern["running_speed_confirmed"])

    def test_subharmonics_separate_looseness_from_misalignment(self):
        loose = _spectrum({SPEED * o: 0.5 for o in (0.5, 1, 1.5, 2, 2.5, 3)})
        loose[int(SPEED / STEP)] = 1.0
        pattern = fft.spectrum_pattern(loose, STEP, SPEED)
        self.assertTrue(pattern["subharmonic_orders"])

        misaligned = _spectrum({SPEED: 1.0, 2 * SPEED: 0.8, 3 * SPEED: 0.4})
        pattern = fft.spectrum_pattern(misaligned, STEP, SPEED)
        self.assertEqual(pattern["subharmonic_orders"], [])

    def test_rubbing_shows_fractional_orders(self):
        comp = {SPEED: 1.0, SPEED / 3: 0.5, SPEED / 4: 0.4, 2 * SPEED: 0.5}
        pattern = fft.spectrum_pattern(_spectrum(comp), STEP, SPEED)
        self.assertTrue(pattern["fractional_orders"])

    def test_unconfirmed_running_speed_is_flagged(self):
        """Bez 2× a 3× nelze potvrdit, že zadaná frekvence je opravdu 1×."""
        pattern = fft.spectrum_pattern(_spectrum({SPEED: 1.0}), STEP, SPEED)
        self.assertFalse(pattern["running_speed_confirmed"])

    def test_elevated_noise_floor_is_measured(self):
        clean = _spectrum({SPEED: 1.0}, floor=0.0005)
        noisy = _spectrum({SPEED: 1.0}, floor=0.2)
        self.assertLess(fft.spectrum_pattern(clean, STEP, SPEED)["noise_floor_ratio"],
                        fft.spectrum_pattern(noisy, STEP, SPEED)["noise_floor_ratio"])

    def test_subsynchronous_band_is_reported_not_diagnosed(self):
        comp = {SPEED: 1.0, SPEED * 0.44: 0.6}
        pattern = fft.spectrum_pattern(_spectrum(comp), STEP, SPEED)
        self.assertIn("subsynchronous", pattern)
        self.assertAlmostEqual(pattern["subsynchronous"]["order"], 0.44, places=1)


class MissingKinematicsTests(unittest.TestCase):
    """U převodovek a ventilátorů často neznáme počty zubů ani lopatek."""

    def test_dominant_integer_order_implies_a_count(self):
        comp = {SPEED: 1.0, SPEED * 11: 0.9}
        values = _spectrum(comp, length=1400)
        found = fft.dominant_orders(values, STEP, SPEED,
                                    role=fft.ROLE_VELOCITY,
                                    peaks=fft.find_peaks(values, STEP, limit=6))
        self.assertTrue(found)
        self.assertEqual(found[0]["order"], 11)
        self.assertIn("lopat", found[0]["implies"])

    def test_teeth_are_only_claimed_when_a_gearbox_is_configured(self):
        """U ventilátoru je „47 zubů“ smyšlenka — řád je fakt, mechanismus ne."""
        comp = {SPEED: 1.0, SPEED * 47: 0.9}
        values = _spectrum(comp, length=3000)
        peaks = fft.find_peaks(values, STEP, limit=6)
        without = fft.dominant_orders(values, STEP, SPEED,
                                      role=fft.ROLE_ACCELERATION, peaks=peaks)
        self.assertEqual(without[0]["order"], 47)
        self.assertIsNone(without[0]["implies"])
        with_gearbox = fft.dominant_orders(values, STEP, SPEED,
                                           role=fft.ROLE_ACCELERATION,
                                           peaks=peaks, drive_type="ozubení")
        self.assertIn("zub", with_gearbox[0]["implies"])

    def test_blades_are_claimed_only_in_the_velocity_spectrum(self):
        comp = {SPEED: 1.0, SPEED * 20: 0.9}
        values = _spectrum(comp, length=1400)
        peaks = fft.find_peaks(values, STEP, limit=6)
        velocity = fft.dominant_orders(values, STEP, SPEED,
                                       role=fft.ROLE_VELOCITY, peaks=peaks)
        self.assertIn("lopat", velocity[0]["implies"])

    def test_harmonic_of_an_accepted_candidate_is_not_a_second_family(self):
        """46× je druhá harmonická lopatkové frekvence 23×, ne další rodina."""
        comp = {SPEED: 1.0, SPEED * 23: 1.0, SPEED * 46: 0.8}
        values = _spectrum(comp, length=3000)
        peaks = fft.find_peaks(values, STEP, limit=8)
        found = fft.dominant_orders(values, STEP, SPEED,
                                    role=fft.ROLE_ACCELERATION, peaks=peaks)
        self.assertEqual([item["order"] for item in found], [23])

    def test_candidate_must_be_a_real_peak(self):
        """Bez vazby na dominantní vrchol projde jako rodina kdejaký řád."""
        comp = {SPEED: 1.0, SPEED * 11: 0.9}
        values = _spectrum(comp, length=1400)
        self.assertEqual(
            fft.dominant_orders(values, STEP, SPEED, role=fft.ROLE_VELOCITY,
                                peaks=[{"freq": 999.0, "amplitude": 1.0}]), [])

    def test_member_of_a_long_harmonic_run_is_not_a_family(self):
        """Uvolnění dá řadu harmonických — to není kinematická složka."""
        comp = {SPEED * n: 0.9 for n in range(1, 15)}
        found = fft.dominant_orders(_spectrum(comp, length=1400), STEP, SPEED)
        self.assertEqual(found, [])

    def test_belt_drive_shows_harmonics_below_running_speed(self):
        base = SPEED * 0.37
        peaks = [{"freq": base * k, "amplitude": 0.5 / k} for k in (1, 2, 3)]
        found = fft.subsynchronous_family(peaks, SPEED)
        self.assertIsNotNone(found)
        self.assertEqual(found["members"], 3)
        self.assertLess(found["order"], 1.0)

    def test_single_subsynchronous_peak_is_not_a_belt(self):
        self.assertIsNone(fft.subsynchronous_family(
            [{"freq": SPEED * 0.37, "amplitude": 0.5}], SPEED))


class InductionMotorTests(unittest.TestCase):
    def test_poles_and_slip_are_derived_from_speed(self):
        rec = fft.induction_motor_context(24.4)      # 4-pól, sync 25 Hz
        self.assertEqual(rec["poles"], 4)
        self.assertAlmostEqual(rec["synchronous_hz"], 25.0)
        self.assertTrue(rec["plausible"])
        self.assertAlmostEqual(rec["pole_pass_hz"], (25.0 - 24.4) * 4, places=3)

    def test_two_pole_motor(self):
        rec = fft.induction_motor_context(49.2)
        self.assertEqual(rec["poles"], 2)
        self.assertTrue(rec["plausible"])

    def test_driven_machine_behind_a_belt_is_marked_implausible(self):
        """23 Hz neodpovídá žádným synchronním otáčkám — není to hřídel motoru."""
        rec = fft.induction_motor_context(23.0)
        self.assertFalse(rec["plausible"])


class RangeAdequacyTests(unittest.TestCase):
    def test_low_fmax_is_reported_against_bearing_frequencies(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        rec = fft.range_adequacy(0.5, 400, SPEED, defects)   # F_max 200 Hz
        self.assertTrue(any("poruchové" in w for w in rec["warnings"]))

    def test_coarse_lines_block_sideband_resolution(self):
        rec = fft.range_adequacy(10.0, 200, SPEED, {})
        self.assertTrue(any("postranních pásem" in w for w in rec["warnings"]))

    def test_adequate_range_still_notes_the_bearing_natural_band(self):
        rec = fft.range_adequacy(0.5, 12801, SPEED, {})      # F_max 6400 Hz
        self.assertAlmostEqual(rec["f_max"], 6400.5, places=1)
        self.assertFalse(any("vlastních frekvencí" in w for w in rec["warnings"]))

    def test_degenerate_input_returns_nothing(self):
        self.assertEqual(fft.range_adequacy(0, 0), {})

    # --- role spektra rozhoduje, které výtky vůbec dávají smysl -----------
    # Ložisko 22232CC má BPFI 10,822× ot; při 23 Hz je to 249 Hz a tři
    # harmonické se vejdou do 750 Hz. Obálka s F_max 1600 Hz je tedy zcela
    # dostatečná a výtka o pásmu vlastních frekvencí do 2000 Hz je u ní
    # nesmysl — demodulace vysoké frekvence z principu odstraňuje.
    def test_envelope_with_ample_range_gets_no_bearing_natural_warning(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        rec = fft.range_adequacy(0.5, 3200, SPEED, defects,
                                 role=fft.ROLE_ENVELOPE)   # F_max 1600 Hz
        self.assertEqual(rec["warnings"], [])

    def test_velocity_spectrum_is_never_blamed_for_bearing_bands(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        rec = fft.range_adequacy(1.0, 1600, SPEED, defects,
                                 role=fft.ROLE_VELOCITY)   # F_max 1600 Hz
        self.assertFalse(any("vlastních frekvencí" in w for w in rec["warnings"]))
        self.assertFalse(any("poruchové" in w for w in rec["warnings"]))

    def test_acceleration_spectrum_still_needs_the_bearing_natural_band(self):
        rec = fft.range_adequacy(0.5, 2000, SPEED, {},
                                 role=fft.ROLE_ACCELERATION)  # F_max 1000 Hz
        self.assertTrue(any("vlastních frekvencí" in w for w in rec["warnings"]))

    def test_order_coverage_is_asked_only_of_the_velocity_spectrum(self):
        # F_max 200 Hz = jen 8,7× otáčky.
        velocity = fft.range_adequacy(0.5, 400, SPEED, {},
                                      role=fft.ROLE_VELOCITY)
        envelope = fft.range_adequacy(0.5, 400, SPEED, {},
                                      role=fft.ROLE_ENVELOPE)
        self.assertTrue(any("20×" in w for w in velocity["warnings"]))
        self.assertFalse(any("20×" in w for w in envelope["warnings"]))

    def test_defect_harmonics_are_asked_of_envelope_not_velocity(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        envelope = fft.range_adequacy(0.5, 400, SPEED, defects,
                                      role=fft.ROLE_ENVELOPE)
        velocity = fft.range_adequacy(0.5, 400, SPEED, defects,
                                      role=fft.ROLE_VELOCITY)
        self.assertTrue(any("poruchové" in w for w in envelope["warnings"]))
        self.assertFalse(any("poruchové" in w for w in velocity["warnings"]))

    def test_unknown_role_keeps_the_pre_role_behaviour_except_resonance(self):
        # U nerozpoznaného názvu nevíme, zda je spektrum demodulované, takže
        # se o pásmu vlastních frekvencí raději mlčí; ostatní výtky platí.
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        rec = fft.range_adequacy(0.5, 400, SPEED, defects)   # F_max 200 Hz
        self.assertTrue(any("poruchové" in w for w in rec["warnings"]))
        self.assertTrue(any("20×" in w for w in rec["warnings"]))
        self.assertFalse(any("vlastních frekvencí" in w for w in rec["warnings"]))


class DirectionProfileTests(unittest.TestCase):
    def test_unbalance_signature_radial_over_axial(self):
        rec = fft.direction_profile({"H": 4.0, "V": 3.2, "A": 0.8})
        self.assertIn("radiální > axiální (očekávané)", rec["traits"])
        self.assertIn("H > V (očekávané)", rec["traits"])

    def test_misalignment_signature_axial_at_least_radial(self):
        rec = fft.direction_profile({"H": 2.0, "V": 1.6, "A": 2.4})
        self.assertIn("axiální ≥ radiální", rec["traits"])

    def test_looseness_signature_vertical_over_horizontal(self):
        rec = fft.direction_profile({"H": 1.0, "V": 2.2, "A": 0.5})
        self.assertIn("V ≥ H", rec["traits"])

    def test_single_direction_gives_no_profile(self):
        self.assertIsNone(fft.direction_profile({"H": 1.0}))


class SpectrumRoleTests(unittest.TestCase):
    """Nízkofrekvenční dynamika patří k rychlosti, ložiska ke zrychlení."""

    def test_role_is_derived_from_the_quantity_name(self):
        cases = {
            "ISO SPECTRUM": fft.ROLE_VELOCITY,
            "VEL SPECTRUM": fft.ROLE_VELOCITY,
            "ACC Spectrum": fft.ROLE_ACCELERATION,
            # „ACC ENV“ obsahuje obojí a musí vyjít jako obálka.
            "ACC ENV SPEC 500 Hz": fft.ROLE_ENVELOPE,
            "ACC ENV SPEC 1 kHz": fft.ROLE_ENVELOPE,
        }
        for name, role in cases.items():
            with self.subTest(name=name):
                self.assertEqual(fft.spectrum_role(name), role)
        self.assertIsNone(fft.spectrum_role("NĚCO JINÉHO"))

    def _bearing_spectrum(self):
        defects = fft.bearing_defect_frequencies(BEARING, SPEED)
        comp = {SPEED: 1.0, 2 * SPEED: 0.5, 3 * SPEED: 0.3,
                defects["BPFO"]: 0.6, 2 * defects["BPFO"]: 0.3}
        return _spectrum(comp), defects

    def test_velocity_spectrum_never_reports_bearing_defects(self):
        values, _ = self._bearing_spectrum()
        analysis = fft.analyze_spectrum(values, STEP, speed_hz=SPEED,
                                        bearing=BEARING, overall=_overall(values),
                                        role=fft.ROLE_VELOCITY)
        self.assertEqual(analysis["defects"], [])
        # Řády naopak ve spektru rychlosti být musí.
        self.assertTrue(analysis["harmonics"])
        self.assertIsNotNone(analysis["pattern"].get("ratio_2x_1x"))

    def test_envelope_spectrum_never_analyses_running_speed_orders(self):
        values, _ = self._bearing_spectrum()
        analysis = fft.analyze_spectrum(values, STEP, speed_hz=SPEED,
                                        bearing=BEARING, overall=_overall(values),
                                        role=fft.ROLE_ENVELOPE)
        self.assertEqual(analysis["harmonics"], [])
        self.assertIsNone(analysis["pattern"].get("ratio_2x_1x"))
        self.assertTrue(analysis["defects"])

    def test_acceleration_spectrum_reports_defects(self):
        values, _ = self._bearing_spectrum()
        analysis = fft.analyze_spectrum(values, STEP, speed_hz=SPEED,
                                        bearing=BEARING, overall=_overall(values),
                                        role=fft.ROLE_ACCELERATION)
        self.assertTrue(analysis["defects"])
        self.assertIsNone(analysis["belt"])

    def test_blade_order_only_in_velocity_gear_order_only_in_acceleration(self):
        blades = _spectrum({SPEED: 1.0, SPEED * 11: 0.9}, length=1400)
        teeth = _spectrum({SPEED: 1.0, SPEED * 47: 0.9}, length=3000)
        self.assertTrue(fft.dominant_orders(blades, STEP, SPEED,
                                            role=fft.ROLE_VELOCITY))
        self.assertEqual(fft.dominant_orders(teeth, STEP, SPEED,
                                             role=fft.ROLE_VELOCITY), [])
        self.assertTrue(fft.dominant_orders(teeth, STEP, SPEED,
                                            role=fft.ROLE_ACCELERATION))
        self.assertEqual(fft.dominant_orders(blades, STEP, SPEED,
                                             role=fft.ROLE_ACCELERATION), [])


class KinematicFrequencyTests(unittest.TestCase):
    """Zadaná kinematika mění odhad ze spektra na přesný výpočet."""

    def test_blade_count_gives_blade_pass_frequency(self):
        rows = fft.kinematic_frequencies({"blade_count": 12}, SPEED)
        blade = next(r for r in rows if "BPF" in r["label"])
        self.assertAlmostEqual(blade["freq"], 12 * SPEED)
        self.assertEqual(blade["role"], fft.ROLE_VELOCITY)

    def test_teeth_give_gear_mesh_in_the_acceleration_domain(self):
        rows = fft.kinematic_frequencies({"gear_teeth_driver": 31}, SPEED)
        gear = next(r for r in rows if "GMF" in r["label"])
        self.assertAlmostEqual(gear["freq"], 31 * SPEED)
        self.assertEqual(gear["role"], fft.ROLE_ACCELERATION)

    def test_poles_give_line_frequency_and_pole_pass(self):
        rows = fft.kinematic_frequencies(
            {"pole_count": 4, "line_freq_hz": 50.0}, 24.4)
        labels = {r["label"]: r["freq"] for r in rows}
        self.assertAlmostEqual(labels["2F_L"], 100.0)
        # synchronní 25 Hz, skluz 0,6 Hz, F_P = 0,6 × 4
        self.assertAlmostEqual(labels["F_P (průchod pólů)"], 2.4, places=3)

    def test_implausible_slip_refuses_to_compute_pole_pass(self):
        """23 Hz při 4 pólech dává skluz 8 % — F_P by byla smyšlená."""
        rows = fft.kinematic_frequencies(
            {"pole_count": 4, "line_freq_hz": 50.0}, 23.0)
        labels = [r["label"] for r in rows]
        self.assertNotIn("F_P (průchod pólů)", labels)
        warning = next(r for r in rows if r.get("warning"))
        self.assertIn("skluz", warning["warning"])
        self.assertIsNone(warning["freq"])

    def test_belt_frequency_from_pulley_and_belt_length(self):
        rows = fft.kinematic_frequencies(
            {"belt_length_mm": 1250.0, "pulley_driver_mm": 200.0}, SPEED)
        belt = next(r for r in rows if "řemen" in r["label"])
        expected = 3.141592653589793 * 200.0 * SPEED / 1250.0
        self.assertAlmostEqual(belt["freq"], expected)

    def test_nothing_configured_gives_nothing(self):
        self.assertEqual(fft.kinematic_frequencies({}, SPEED), [])
        self.assertEqual(fft.kinematic_frequencies({"blade_count": 12}, None), [])

    def test_rows_read_amplitudes_only_in_the_matching_role(self):
        values = _spectrum({SPEED: 1.0, 12 * SPEED: 0.8}, length=1400)
        kin = {"blade_count": 12}
        velocity = fft.kinematic_rows(values, STEP, kin, SPEED,
                                      fft.ROLE_VELOCITY, _overall(values))
        envelope = fft.kinematic_rows(values, STEP, kin, SPEED,
                                      fft.ROLE_ENVELOPE, _overall(values))
        self.assertTrue(velocity)
        self.assertEqual(envelope, [])

    def test_configured_count_replaces_the_estimate(self):
        values = _spectrum({SPEED: 1.0, 12 * SPEED: 0.9}, length=1400)
        analysis = fft.analyze_spectrum(values, STEP, speed_hz=SPEED,
                                        overall=_overall(values),
                                        role=fft.ROLE_VELOCITY,
                                        kinematics={"blade_count": 12})
        self.assertTrue(analysis["kinematic"])
        # Odhad „odpovídalo by počtu lopatek“ už nemá co dodat.
        self.assertEqual(analysis["families"], [])

    def test_mismatch_between_configured_and_detected_is_reported(self):
        families = [{"order": 23, "freq": 23 * SPEED, "amplitude": 0.8}]
        rec = fft.blade_count_mismatch(families, {"blade_count": 12})
        self.assertEqual(rec["configured"], 12)
        self.assertIn(23, rec["detected"])

    def test_matching_count_is_not_a_mismatch(self):
        families = [{"order": 12, "freq": 12 * SPEED, "amplitude": 0.8}]
        self.assertIsNone(fft.blade_count_mismatch(families, {"blade_count": 12}))


class WaveformTests(unittest.TestCase):
    """Ořezaná vlna odliší přidírání od spektrálně podobného uvolnění."""

    def _sine(self, cycles=40, n=4096, amplitude=1.0):
        import math as _m
        return [amplitude * _m.sin(2 * _m.pi * cycles * i / n) for i in range(n)]

    def test_clean_sine_is_neither_clipped_nor_impulsive(self):
        rec = fft.waveform_metrics(self._sine())
        self.assertFalse(rec["clipped"])
        self.assertFalse(rec["impulsive"])
        self.assertAlmostEqual(rec["crest_factor"], 2 ** 0.5, places=1)

    def test_flattened_wave_is_detected(self):
        clipped = [max(-0.5, min(0.5, v)) for v in self._sine()]
        rec = fft.waveform_metrics(clipped)
        self.assertTrue(rec["clipped"])

    def test_impacts_raise_the_crest_factor(self):
        signal = [0.02] * 4096
        for i in range(0, 4096, 256):
            signal[i] = 3.0
        rec = fft.waveform_metrics(signal)
        self.assertTrue(rec["impulsive"])

    def test_impact_periodicity_is_measured_in_hertz(self):
        n, step_ms = 8192, 1.0            # 1 ms krok -> 8,192 s záznamu
        signal = [0.01] * n
        for i in range(0, n, 512):        # ráz každých 512 ms -> 1,95 Hz
            signal[i] = 2.0
        rec = fft.waveform_metrics(signal, step_ms)
        self.assertAlmostEqual(rec["duration_s"], 8.192, places=2)
        self.assertAlmostEqual(rec["impact_freq_hz"], 1.0 / 0.512, delta=0.4)

    def test_too_short_record_is_ignored(self):
        self.assertEqual(fft.waveform_metrics([1.0, 2.0]), {})


class BearingStageTests(unittest.TestCase):
    def test_discrete_defect_frequencies_with_harmonics_mean_stage_three(self):
        rec = fft.bearing_stage({"defect_matches": 3, "defect_harmonics": 2,
                                 "accel_band": "C"})
        self.assertEqual(rec["stage"], 3)
        self.assertTrue(rec["reasons"])

    def test_elevated_acceleration_without_defects_is_stage_two(self):
        rec = fft.bearing_stage({"defect_matches": 0, "accel_band": "B"})
        self.assertEqual(rec["stage"], 2)

    def test_broadband_noise_without_discrete_frequencies_is_stage_four(self):
        rec = fft.bearing_stage({"defect_matches": 0, "noise_floor_ratio": 0.3,
                                 "accel_band": "C", "velocity_band": "C"})
        self.assertEqual(rec["stage"], 4)

    def test_rising_envelope_alone_is_stage_one(self):
        rec = fft.bearing_stage({"defect_matches": 0, "envelope_rising": True,
                                 "accel_band": "A", "envelope_band": "A"})
        self.assertEqual(rec["stage"], 1)

    def test_clean_bearing_gets_no_stage(self):
        self.assertIsNone(fft.bearing_stage({"defect_matches": 0,
                                             "accel_band": "A",
                                             "envelope_band": "A"}))

    def test_lone_defect_frequency_is_not_enough_for_stage_three(self):
        """Osamocená složka bez násobku a bez modulace je slabá indikace."""
        rec = fft.bearing_stage({"defect_matches": 1, "defect_harmonics": 0,
                                 "sidebands": 0, "accel_band": "A",
                                 "envelope_band": "A"})
        self.assertIsNone(rec)


class PriorityAndCertaintyTests(unittest.TestCase):
    def test_band_d_or_stage_four_is_critical(self):
        self.assertEqual(fft.priority(worst_band="D")[0], fft.PRIORITY_CRITICAL)
        self.assertEqual(fft.priority(stage=4)[0], fft.PRIORITY_CRITICAL)

    def test_stage_three_and_high_ratio_are_high_priority(self):
        self.assertEqual(fft.priority(stage=3)[0], fft.PRIORITY_HIGH)
        self.assertEqual(fft.priority(ratio_2x_1x=1.8)[0], fft.PRIORITY_HIGH)
        self.assertEqual(fft.priority(worst_band="C", rising=True)[0],
                         fft.PRIORITY_HIGH)

    def test_healthy_machine_is_low_priority(self):
        level, reasons = fft.priority(worst_band="A")
        self.assertEqual(level, fft.PRIORITY_LOW)
        self.assertTrue(reasons)

    def test_missing_phase_caps_certainty_at_medium(self):
        """HADS fázi z .ndb nemá, takže VYSOKÁ jistota je nedosažitelná."""
        level, reasons = fft.certainty_ceiling(
            speed_known=True, speed_confirmed=True, directions=3, has_phase=False)
        self.assertEqual(level, fft.CERTAINTY_MEDIUM)
        self.assertTrue(any("fáze" in r for r in reasons))

    def test_unknown_speed_forces_low_certainty(self):
        level, _ = fft.certainty_ceiling(speed_known=False)
        self.assertEqual(level, fft.CERTAINTY_LOW)

    def test_single_direction_or_range_warning_lowers_certainty(self):
        self.assertEqual(fft.certainty_ceiling(
            speed_known=True, speed_confirmed=True, directions=1)[0],
            fft.CERTAINTY_LOW)
        self.assertEqual(fft.certainty_ceiling(
            speed_known=True, speed_confirmed=True, directions=3,
            range_warnings=2)[0], fft.CERTAINTY_LOW)


class TrendRateTests(unittest.TestCase):
    """Rychlost změny, ne rozdíl krajních hodnot (metodologie E.1)."""

    def test_steady_growth_is_expressed_per_30_days(self):
        # +0,01 za den při průměru 1,0 → zhruba +30 % za 30 dní
        samples = [(day, 1.0 + 0.01 * (day - 45)) for day in range(0, 91, 15)]
        rate = fft.trend_rate(samples)
        self.assertAlmostEqual(rate["pct_per_30d"], 30.0, delta=1.0)
        self.assertEqual(rate["points"], 7)

    def test_single_outlier_does_not_dominate(self):
        """Nejmenší čtverce, ne rozdíl prvního a posledního bodu."""
        flat = [(day, 1.0) for day in (0, 15, 30, 45, 60)]
        with_spike = flat[:-1] + [(60, 1.0)]
        spike_at_start = [(0, 3.0)] + flat[1:]
        self.assertAlmostEqual(fft.trend_rate(with_spike)["pct_per_30d"], 0.0,
                               delta=0.5)
        # Výkyv na kraji sníží sklon, ale nezvrátí jej na dvojnásobek.
        self.assertLess(abs(fft.trend_rate(spike_at_start)["pct_per_30d"]), 120.0)

    def test_short_span_is_refused_not_extrapolated(self):
        """Odečty z jednoho dne dávají po přepočtu na 30 dní nesmysly."""
        same_day = [(0.0, 0.86), (0.1, 1.08), (0.23, 0.96)]
        self.assertIsNone(fft.trend_rate(same_day))

    def test_too_few_points_gives_nothing(self):
        self.assertIsNone(fft.trend_rate([(0.0, 1.0), (30.0, 2.0)]))

    def test_degenerate_values_are_ignored(self):
        self.assertIsNone(fft.trend_rate([]))
        self.assertIsNone(fft.trend_rate([(0, 0.0), (30, 0.0), (60, 0.0)]))


class ReferenceComparisonTests(unittest.TestCase):
    def test_ratio_and_verdict(self):
        self.assertEqual(fft.compare_to_reference(2.0, 1.0)["verdict"],
                         "výrazně nad referencí")
        self.assertEqual(fft.compare_to_reference(1.2, 1.0)["verdict"],
                         "nad referencí")
        self.assertEqual(fft.compare_to_reference(1.0, 1.0)["verdict"],
                         "na úrovni reference")
        self.assertEqual(fft.compare_to_reference(0.5, 1.0)["verdict"],
                         "pod referencí")

    def test_percent_is_relative_to_reference(self):
        self.assertAlmostEqual(fft.compare_to_reference(1.5, 1.0)["pct"], 50.0)

    def test_missing_or_zero_reference_gives_nothing(self):
        self.assertIsNone(fft.compare_to_reference(1.0, None))
        self.assertIsNone(fft.compare_to_reference(1.0, 0.0))
        self.assertIsNone(fft.compare_to_reference(None, 1.0))


class AssessmentBasisTests(unittest.TestCase):
    def test_order_follows_the_methodology(self):
        basis = fft.assessment_basis(has_trend=True, has_baseline=True,
                                     has_sister=True, has_norm=True)
        self.assertEqual(basis["available"],
                         ["trend", "baseline", "sesterský stroj", "norma"])
        self.assertEqual(basis["best"], "trend")
        self.assertFalse(basis["norm_only"])

    def test_norm_alone_is_flagged(self):
        basis = fft.assessment_basis(has_norm=True)
        self.assertTrue(basis["norm_only"])
        self.assertEqual(basis["best"], "norma")

    def test_no_basis_at_all(self):
        basis = fft.assessment_basis()
        self.assertEqual(basis["available"], [])
        self.assertIsNone(basis["best"])
        self.assertFalse(basis["norm_only"])

    def test_baseline_outranks_sister_and_norm(self):
        basis = fft.assessment_basis(has_baseline=True, has_sister=True,
                                     has_norm=True)
        self.assertEqual(basis["best"], "baseline")


class ReferencePromptTests(unittest.TestCase):
    def test_missing_basis_is_stated_explicitly(self):
        _system, user = ai_eval.build_prompt(
            {"machine_name": "Test", "points": [],
             "assessment_basis": fft.assessment_basis()}, None, None)
        self.assertIn("OPORY HODNOCENÍ: ŽÁDNÁ", user)

    def test_norm_only_warns_that_it_is_the_weakest(self):
        _system, user = ai_eval.build_prompt(
            {"machine_name": "Test", "points": [],
             "assessment_basis": fft.assessment_basis(has_norm=True)}, None, None)
        self.assertIn("POUZE norma", user)

    def test_sister_rows_carry_direction(self):
        _system, user = ai_eval.build_prompt({
            "machine_name": "Test", "points": [],
            "sister": {"machine_name": "Sestra", "compared": 12, "rows": [
                {"bearing_key": "L3", "direction": "H", "quantity": "ACC RMS",
                 "value": 1.07, "reference": 0.29, "pct": 275.0,
                 "verdict": "výrazně nad referencí"}]},
        }, None, None)
        self.assertIn("L3H / ACC RMS", user)
        self.assertIn("vybral diagnostik", user)

    def test_unavailable_sister_is_reported(self):
        _system, user = ai_eval.build_prompt({
            "machine_name": "Test", "points": [],
            "sister": {"machine_id": 999, "unavailable": "stroj nenalezen"},
        }, None, None)
        self.assertIn("stroj nenalezen", user)

    def test_baseline_comparison_is_rendered_for_a_quantity(self):
        text = "\n".join(ai_eval._quantity_lines({
            "name": "ISO RMS", "unit": "mm/s", "last_value": 1.4,
            "limit_source": "db", "warning": 4.5, "alarm": 7.1, "band": "A",
            "recent_trend": [],
            "baseline": {"value": 0.86, "time": "2026-01-03T08:00",
                         "compare": fft.compare_to_reference(1.4, 0.86)},
        }))
        self.assertIn("baseline 0.86 mm/s", text)
        self.assertIn("výrazně nad referencí", text)


class ToleranceSettingsTests(unittest.TestCase):
    """Globální nastavení tolerancí; ukládá se do data/, ne do programu."""

    def setUp(self):
        import fft_settings
        self.module = fft_settings
        self.temp = tempfile.TemporaryDirectory(prefix="hads-fft-settings-")
        self.data = Path(self.temp.name) / "data"
        self.data.mkdir()
        self.old = fft_settings.DATA_DIR
        fft_settings.DATA_DIR = self.data

    def tearDown(self):
        self.module.DATA_DIR = self.old
        self.temp.cleanup()

    def test_defaults_split_orders_from_bearing_frequencies(self):
        current = self.module.tolerances()
        self.assertEqual(current["order_tolerance_pct"], fft.ORDER_TOLERANCE_PCT)
        self.assertEqual(current["bearing_tolerance_pct"], fft.BEARING_TOLERANCE_PCT)
        self.assertLess(current["order_tolerance_pct"],
                        current["bearing_tolerance_pct"])
        self.assertTrue(self.module.get()["is_default"])

    def test_saved_values_are_used_and_live_only_under_data(self):
        self.module.save({"tolerances": {"order_tolerance_pct": 0.8,
                                         "bearing_tolerance_pct": 3.0}})
        self.assertEqual(self.module.tolerances(),
                         {"order_tolerance_pct": 0.8, "bearing_tolerance_pct": 3.0})
        written = sorted(p.relative_to(self.data).as_posix()
                         for p in self.data.rglob("*") if p.is_file())
        self.assertEqual(written, ["fft_settings.json"])

    def test_nonsense_values_never_break_spectral_analysis(self):
        self.module.save({"tolerances": {"order_tolerance_pct": -5,
                                         "bearing_tolerance_pct": "hodně"}})
        self.assertEqual(self.module.tolerances(), dict(self.module.DEFAULTS))

    def test_corrupt_file_falls_back_to_defaults(self):
        (self.data / "fft_settings.json").write_text("{ rozbité", encoding="utf-8")
        self.assertEqual(self.module.tolerances(), dict(self.module.DEFAULTS))

    def test_file_saved_with_bom_is_still_honoured(self):
        self.module.save({"tolerances": {"order_tolerance_pct": 0.8,
                                         "bearing_tolerance_pct": 3.0}})
        path = self.data / "fft_settings.json"
        path.write_bytes(b"\xef\xbb\xbf" + path.read_bytes())
        self.assertEqual(self.module.tolerances()["bearing_tolerance_pct"], 3.0)

    def test_reset_restores_defaults(self):
        self.module.save({"tolerances": {"order_tolerance_pct": 5.0,
                                         "bearing_tolerance_pct": 5.0}})
        self.assertTrue(self.module.reset()["is_default"])


class MethodologyPromptTests(unittest.TestCase):
    def test_every_report_template_embeds_the_shared_methodology(self):
        for version in (1, 2, 3):
            with self.subTest(version=version):
                system = ai_prompts.render_snapshot(ai_prompts.report_snapshot(version))
                self.assertIn("BPFO", system)          # metodologie
                self.assertIn("JSON", system)          # neměnný kontrakt

    def test_methodology_template_may_not_reference_itself(self):
        with self.assertRaises(ai_prompts.PromptValidationError):
            ai_prompts.validate_template(ai_prompts.METHODOLOGY_ID,
                                         "Text {methodology}")

    def test_report_contract_stays_mandatory(self):
        with self.assertRaises(ai_prompts.PromptValidationError):
            ai_prompts.validate_template("report_brief_v2", "Jen {methodology}")

    def test_older_override_without_the_placeholder_still_gets_methodology(self):
        """Šablona upravená ve starší verzi HADS nesmí obejít metodologii.

        `{methodology}` je volitelný — kdyby byl povinný, každý existující
        uživatelský přepis by se po aktualizaci stal neplatným a tiše by se
        zahodil ve prospěch výchozí šablony.
        """
        legacy = "Moje vlastní zadání. {report_contract}"
        ai_prompts.validate_template("report_brief_v2", legacy)
        rendered = ai_prompts.render_template("report_brief_v2", legacy,
                                              "METODOLOGIE ZDE")
        self.assertTrue(rendered.startswith("METODOLOGIE ZDE"))
        self.assertIn("Moje vlastní zadání.", rendered)

    def test_placeholder_position_is_respected_when_present(self):
        rendered = ai_prompts.render_template(
            "report_brief_v2", "Nejdřív zadání. {methodology} {report_contract}",
            "METODOLOGIE ZDE")
        self.assertTrue(rendered.startswith("Nejdřív zadání."))
        self.assertIn("METODOLOGIE ZDE", rendered)

    def test_methodology_may_not_be_repeated(self):
        with self.assertRaises(ai_prompts.PromptValidationError):
            ai_prompts.validate_template(
                "report_brief_v2", "{methodology} {methodology} {report_contract}")

    def test_snapshot_freezes_methodology_for_the_whole_run(self):
        """Editace metodologie v jiné kartě nesmí změnit prompt mezi stroji."""
        snapshot = ai_prompts.report_snapshot(2)
        frozen = ai_prompts.PromptSnapshot(
            identifier=snapshot.identifier, text=snapshot.text,
            revision=snapshot.revision, digest=snapshot.digest,
            modified=snapshot.modified, methodology="ZAMRZLÁ METODOLOGIE",
        )
        self.assertIn("ZAMRZLÁ METODOLOGIE", ai_prompts.render_snapshot(frozen))

    def test_audit_records_methodology_by_hash_only(self):
        snapshot = ai_prompts.report_snapshot(2)
        audit = ai_prompts.audit_metadata(snapshot)
        ids = [item["id"] for item in audit["templates"]]
        self.assertIn(ai_prompts.METHODOLOGY_ID, ids)
        self.assertNotIn(snapshot.methodology, repr(audit))


if __name__ == "__main__":
    unittest.main()
