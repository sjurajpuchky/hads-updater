# -*- coding: utf-8 -*-
"""Regresní testy pro mapování limitů DDS statických objektů na pásma C/D.

KONTEXT (HADS v1.31.1)
-----------------------
U DDS statických objektů (BEARING RMS, ACC RMS, ENV RMS apod.) může být v
XML uloženo VÍCE než 2 platné limitní hodnoty (typicky proto, že přístroj/
DDS software uložil i informativní mez A/B), aniž by seděl doprovodný blok
<alarmId> (nebo vůbec chyběl). Před opravou záložní heuristika v
`ndb_parser.parse_cell_limits()` v takovém případě vzala DVĚ NEJNIŽŠÍ
hodnoty jako meze Varování/Alarm (pásma B/C a C/D) — např. u BEARING RMS se
3 mezemi [0.4, 0.8, 1.2] to dávalo mez C/D=0.8 (2. nejnižší) místo správných
0,8/1,2. Ve výsledku by hodnota 0,95 mm/s RMS byla nesprávně klasifikována
jako pásmo D (Ohrožení) místo správného pásma C (Výstraha).

OPRAVA: pásma C a D vždy určují DVĚ NEJVYŠŠÍ platné limitní hodnoty, bez
ohledu na pořadí/duplicity/počet mezí (2, 3, 4+). Při přesně 2 platných
mezích je výsledek shodný jako dřív (zpětná kompatibilita zachována).

Tyto testy pokrývají:
  1) jednotkové testy `parse_cell_limits` — neuspořádané, duplicitní,
     neplatné (poškozený hex) hodnoty, 1/2/3/4+ platných mezí,
  2) `NdbDatabase._db_limit_pair` — převod na dvojici (warning, alarm),
  3) `report.classify_band` — správné zařazení hodnoty do pásma A/B/C/D,
  4) end-to-end přes syntetickou .ndb databázi a `NdbDatabase.machines()`
     (cesta dashboardu/karty stroje) — ověřuje `db_warning`/`db_alarm`
     i výslednou závažnost bodu (severity_id),
  5) `report.build_machine_report` (cesta protokolu/refresh) — ověřuje, že
     nová logika protokolu BEARING RMS nepoužije (stav protokolu se od 1.31.2
     odvozuje výhradně z nakonfigurovaných H veličin); opravené DDS meze
     přitom nadále pokrývá cesta dashboardu/karty stroje výše,
  6) že ISO normy (karta stroje → ISO RMS) nejsou opravou zasaženy — jejich
     meze se čtou přímo z katalogu norem (ai_eval.iso_limits_for_class),
     nikdy z DDS heuristiky.

Spusťte samostatně:
    python3 -m pytest tests/test_dds_band_limits.py -v
nebo bez pytest:
    python3 tests/test_dds_band_limits.py
"""
import os
import sys
import unittest

BACKEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backend")
TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BACKEND_DIR)
sys.path.insert(0, TESTS_DIR)

from ndb_parser import parse_cell_limits, NdbDatabase   # noqa: E402
import report as report_mod                              # noqa: E402
from ndb_fixture_builder import build_fixture_ndb, make_limits_xml  # noqa: E402


def _remove_sqlite_file(path):
    """Odstraní databázový soubor i případné WAL/SHM pomocné soubory."""
    for suffix in ("", "-wal", "-shm", "-journal"):
        p = path + suffix
        if os.path.exists(p):
            os.remove(p)


class TestParseCellLimitsFallbackHeuristic(unittest.TestCase):
    """Jednotkové testy záložní heuristiky (bez platného <alarmId>)."""

    def test_task_example_bearing_rms_three_limits(self):
        """Zadání úlohy: BEARING RMS [0.4, 0.8, 1.2] => C=0.8, D=1.2."""
        xml = make_limits_xml([0.4, 0.8, 1.2])
        parsed = parse_cell_limits(xml)
        self.assertEqual(parsed["warning"], 0.8)   # mez B/C = pásmo C
        self.assertEqual(parsed["danger"], 1.2)    # mez C/D = pásmo D

    def test_exactly_two_limits_mapping_unchanged(self):
        """Při přesně 2 platných mezích zachováno dosavadní mapování."""
        xml = make_limits_xml([0.8, 1.2])
        parsed = parse_cell_limits(xml)
        self.assertEqual(parsed["warning"], 0.8)
        self.assertEqual(parsed["danger"], 1.2)

    def test_two_limits_unordered_in_xml(self):
        """Pořadí mezí v XML nesmí ovlivnit výsledek (1.2 uloženo první)."""
        xml = make_limits_xml([1.2, 0.8])
        parsed = parse_cell_limits(xml)
        self.assertEqual(parsed["warning"], 0.8)
        self.assertEqual(parsed["danger"], 1.2)

    def test_three_limits_unordered_in_xml(self):
        """Neuspořádané pořadí u 3 mezí — výsledek musí být stejný jako
        u uspořádaného vstupu (dvě nejvyšší hodnoty)."""
        xml = make_limits_xml([1.2, 0.4, 0.8])
        parsed = parse_cell_limits(xml)
        self.assertEqual(parsed["warning"], 0.8)
        self.assertEqual(parsed["danger"], 1.2)

    def test_duplicate_thresholds(self):
        """Duplicitní hodnoty se nesmí počítat dvakrát jako 'druhá nejvyšší'."""
        xml = make_limits_xml([0.8, 0.8, 1.2, 0.4])
        parsed = parse_cell_limits(xml)
        self.assertEqual(parsed["warning"], 0.8)
        self.assertEqual(parsed["danger"], 1.2)

    def test_four_or_more_limits(self):
        """4+ platných mezí — vždy jen dvě nejvyšší určují C/D."""
        xml = make_limits_xml([0.4, 0.8, 1.2, 1.6])
        parsed = parse_cell_limits(xml)
        self.assertEqual(parsed["warning"], 1.2)
        self.assertEqual(parsed["danger"], 1.6)

    def test_single_valid_limit(self):
        """Jediná platná mez -> použije se jako Alarm (C/D), Varování None."""
        xml = make_limits_xml([1.2])
        parsed = parse_cell_limits(xml)
        self.assertIsNone(parsed["warning"])
        self.assertEqual(parsed["danger"], 1.2)

    def test_invalid_hex_values_are_ignored(self):
        """Neplatné (nedekódovatelné) hodnoty se musí vyřadit před výběrem
        dvou nejvyšších platných mezí."""
        xml = make_limits_xml([0.4, None, 0.8, 1.2, None])
        parsed = parse_cell_limits(xml)
        self.assertEqual(parsed["warning"], 0.8)
        self.assertEqual(parsed["danger"], 1.2)

    def test_all_same_value(self):
        """Všechny meze stejné -> jen jedna unikátní hodnota -> Alarm."""
        xml = make_limits_xml([1.2, 1.2, 1.2])
        parsed = parse_cell_limits(xml)
        self.assertIsNone(parsed["warning"])
        self.assertEqual(parsed["danger"], 1.2)

    def test_no_valid_thresholds_returns_none(self):
        xml = make_limits_xml([None, None])
        parsed = parse_cell_limits(xml)
        self.assertIsNone(parsed)

    def test_empty_limits_returns_none(self):
        self.assertIsNone(parse_cell_limits(None))
        self.assertIsNone(parse_cell_limits(""))

    def test_valid_alarm_id_path_untouched_three_limits(self):
        """Když <alarmId> sedí (reálný HADS ISO RMS formát), heuristika se
        nepoužije — musí dát správně alert/danger podle severity id 3/4."""
        xml = make_limits_xml([4.5, 7.1, 9.0], severities=[1, 1, 3, 4])
        parsed = parse_cell_limits(xml)
        self.assertIsNone(parsed["warning"])   # sev 2 se v tomto vzorku nevyskytuje
        self.assertEqual(parsed["alert"], 7.1)
        self.assertEqual(parsed["danger"], 9.0)

    def test_valid_alarm_id_path_two_limits(self):
        """Reálný formát BEARING RMS s korektním alarmId (2 meze, sev 3/4)."""
        xml = make_limits_xml([0.8, 1.2], severities=[1, 3, 4])
        parsed = parse_cell_limits(xml)
        self.assertEqual(parsed["alert"], 0.8)
        self.assertEqual(parsed["danger"], 1.2)


class TestDbLimitPair(unittest.TestCase):
    """Testy `_db_limit_pair` — převod dekódovaných limitů na (warning, alarm)
    dvojici, kterou používá zbytek aplikace (UI, karta, protokol)."""

    def test_task_example_end_to_end(self):
        xml = make_limits_xml([0.4, 0.8, 1.2])
        parsed = parse_cell_limits(xml)
        pair = NdbDatabase._db_limit_pair(parsed)
        self.assertEqual(pair, (0.8, 1.2))

    def test_two_limits_end_to_end_unchanged(self):
        xml = make_limits_xml([0.8, 1.2])
        parsed = parse_cell_limits(xml)
        pair = NdbDatabase._db_limit_pair(parsed)
        self.assertEqual(pair, (0.8, 1.2))

    def test_duplicates_and_unordered_end_to_end(self):
        xml = make_limits_xml([1.2, 0.4, 0.8, 0.8])
        parsed = parse_cell_limits(xml)
        pair = NdbDatabase._db_limit_pair(parsed)
        self.assertEqual(pair, (0.8, 1.2))

    def test_none_limits(self):
        self.assertEqual(NdbDatabase._db_limit_pair(None), (None, None))


class TestClassifyBandWithFixedLimits(unittest.TestCase):
    """`report.classify_band` musí s opravenými mezemi (0.8/1.2) klasifikovat
    hodnotu 0.95 do pásma C (Výstraha), NE do pásma D (chyba před opravou)."""

    def test_value_between_corrected_bounds_is_band_c(self):
        band = report_mod.classify_band(0.95, warning=0.8, alarm=1.2)
        self.assertEqual(band, "C")
        self.assertEqual(report_mod.band_severity(band), "alarm")  # žlutá/Upozornění

    def test_value_above_alarm_is_band_d(self):
        band = report_mod.classify_band(1.35, warning=0.8, alarm=1.2)
        self.assertEqual(band, "D")
        self.assertEqual(report_mod.band_severity(band), "warn")  # červená/Výstraha

    def test_regression_old_wrong_bounds_would_misclassify(self):
        """Dokumentuje PŮVODNÍ CHYBU: před opravou by se pro DDS objekt se 3
        mezemi [0.4, 0.8, 1.2] použily jako (warning, alarm) dvojice
        (0.4, 1.2) - dvě NEJNIžŠÍ hodnoty namísto dvou nejvyšších. Hodnota
        0.5 mm/s RMS by tak vyšla jako pásmo D (nad chybnou mezí alarmu
        odvozenou ze starého kódu, pokud by byl alarm=0.8) - obecně platí,
        že špatné meze vedou k jiné klasifikaci než správné. Tento test
        ověřuje přímo, že opravená dvojice (0.8, 1.2) klasifikuje hodnotu
        0.95 jako C, zatímco chybná dvojice (0.4, 0.8) - která by vzešla ze
        staré (nesprávné) heuristiky vzniklé výběrem dvou nejnižších hodnot
        [0.4, 0.8, 1.2] - klasifikuje stejnou hodnotu jako D."""
        wrong_band = report_mod.classify_band(0.95, warning=0.4, alarm=0.8)
        correct_band = report_mod.classify_band(0.95, warning=0.8, alarm=1.2)
        self.assertEqual(wrong_band, "D")
        self.assertEqual(correct_band, "C")
        self.assertNotEqual(wrong_band, correct_band)


class TestEndToEndSyntheticNdb(unittest.TestCase):
    """End-to-end test přes syntetickou .ndb a NdbDatabase.machines() —
    ověřuje cestu dashboardu i karty stroje (obě používají machines())."""

    def setUp(self):
        self.tmp_path = os.path.join(TESTS_DIR, "_tmp_fixture_dds.ndb")
        self._dbs = []

    def tearDown(self):
        for db in self._dbs:
            try:
                db.close()
            except Exception:
                pass
        _remove_sqlite_file(self.tmp_path)

    def _build_and_load(self, value, limits_xml):
        specs = [{"name": "BEARING RMS", "value": value, "limits_xml": limits_xml}]
        build_fixture_ndb(self.tmp_path, specs)
        db = NdbDatabase(self.tmp_path)
        self._dbs.append(db)
        return db

    def test_dashboard_and_card_use_corrected_bounds(self):
        """DDS BEARING RMS se 3 mezemi [0.4, 0.8, 1.2], hodnota 0.95.

        Dashboard (machines()) i karta stroje (machine()) sdílí stejnou
        implementaci — testujeme obě volání.
        """
        xml = make_limits_xml([0.4, 0.8, 1.2])
        db = self._build_and_load(0.95, xml)

        # -- dashboard / přehled stavu --
        res = db.machines()
        m = res["machines"][0]
        bearing = m["bearings"][0]
        q = bearing["quantities"][0]
        self.assertEqual(q["name"], "BEARING RMS")
        self.assertEqual(q["db_warning"], 0.8)
        self.assertEqual(q["db_alarm"], 1.2)
        self.assertEqual(q["warning"], 0.8)
        self.assertEqual(q["alarm"], 1.2)
        # hodnota 0.95 je mezi 0.8 a 1.2 -> pásmo C -> severity_id 3 (Výstraha),
        # NIKDY 4 (Ohrožení), jak by dala chybná stará heuristika
        self.assertEqual(bearing["severity_id"], 3)

        # -- karta stroje (machine()) --
        card_res = db.machine(m["id"])
        card_bearing = card_res["machine"]["bearings"][0]
        self.assertEqual(card_bearing["severity_id"], 3)
        card_q = card_bearing["quantities"][0]
        self.assertEqual((card_q["warning"], card_q["alarm"]), (0.8, 1.2))

    def test_two_limits_case_end_to_end_unchanged(self):
        """Kontrolní případ s přesně 2 mezemi musí dát identický výsledek
        jako dřív (žádná regrese pro běžná/existující data)."""
        xml = make_limits_xml([0.8, 1.2])
        db = self._build_and_load(0.95, xml)
        res = db.machines()
        q = res["machines"][0]["bearings"][0]["quantities"][0]
        self.assertEqual((q["db_warning"], q["db_alarm"]), (0.8, 1.2))

    def test_report_path_ignores_unselected_bearing_rms(self):
        """Od 1.31.2 protokol BEARING RMS nepoužije, i když DDS limity zůstávají
        správně dekódované a používané dashboardem/kartou stroje."""
        xml = make_limits_xml([0.4, 0.8, 1.2])
        db = self._build_and_load(0.95, xml)
        m = db.machine(2)["machine"]
        rep = report_mod.build_machine_report(db, m, all_over={})
        bsum = rep["bearings_summary"][0]
        # BEARING RMS není jedna z protokolových tří veličin (rychlost,
        # zrychlení, obálka), proto sám nevytvoří pásmo ani stav.
        self.assertEqual(bsum.get("bearing_state"), "")
        row = rep["rows"][0]
        # Ověříme, že report se sestavil bez chyby a nevyužil BEARING RMS pro
        # rychlost (ta není vybranou veličinou).
        self.assertIn("place", row)
        self.assertIsNone(row.get("vel_cur"))
        self.assertEqual(rep.get("severity"), "none")

    def test_dashboard_unordered_and_duplicate_xml_robust(self):
        """Robustnost dashboardu/karty i při neuspořádaných/duplicitních
        mezích v reálném XML souboru (simulace nekonzistentního DDS exportu)."""
        xml = make_limits_xml([1.2, 0.4, 0.8, 0.8])
        db = self._build_and_load(0.95, xml)
        res = db.machines()
        q = res["machines"][0]["bearings"][0]["quantities"][0]
        self.assertEqual((q["db_warning"], q["db_alarm"]), (0.8, 1.2))


class TestIsoOverrideNotAffected(unittest.TestCase):
    """ISO 20816 override (karta stroje -> norma) musí zůstat netknutá –
    její meze (ab/warning/alarm) NIKDY nejdou přes DDS heuristiku."""

    def test_iso_limits_for_class_reads_from_catalog_not_dds_heuristic(self):
        import ai_eval as aie
        lim = aie.iso_limits_for_class(
            "Skupina 1 (velké stroje, tuhý základ)", standard="ČSN ISO 20816-3")
        # musí vrátit slovník s warning/alarm/ab přímo z katalogu norem,
        # nezávisle na jakékoli DDS/.ndb limitní XML nebo na opravě výše
        self.assertIsInstance(lim, dict)
        self.assertIn("warning", lim)
        self.assertIn("alarm", lim)
        self.assertEqual(lim["warning"], 4.5)
        self.assertEqual(lim["alarm"], 7.1)

    def test_iso_rms_quantity_overrides_dds_bounds_in_machines(self):
        """Když je stroji přiřazena ISO norma, veličina 'ISO RMS' musí použít
        meze normy, NE meze odvozené z DDS limitní heuristiky, i když .ndb
        obsahuje 3+ mezí u ISO RMS buňky."""
        tmp_path = os.path.join(TESTS_DIR, "_tmp_fixture_iso.ndb")
        try:
            xml = make_limits_xml([0.4, 0.8, 1.2])  # DDS meze - nemají se použít
            specs = [{"name": "ISO RMS", "value": 5.0, "limits_xml": xml}]
            build_fixture_ndb(tmp_path, specs)
            db = NdbDatabase(tmp_path)
            overrides = {"2": {"iso_norm": {
                "standard": "ČSN ISO 20816-3",
                "machine_class": "Skupina 1 (velké stroje, tuhý základ)",
            }}}
            res = db.machines(overrides=overrides)
            q = res["machines"][0]["bearings"][0]["quantities"][0]
            self.assertEqual(q["name"], "ISO RMS")
            self.assertTrue(q.get("from_norm"))
            # meze pocházejí z normy, ne z (0.8, 1.2) odvozených z DDS XML
            self.assertNotEqual((q["warning"], q["alarm"]), (0.8, 1.2))
        finally:
            try:
                db.close()
            except Exception:
                pass
            _remove_sqlite_file(tmp_path)


if __name__ == "__main__":
    unittest.main()
