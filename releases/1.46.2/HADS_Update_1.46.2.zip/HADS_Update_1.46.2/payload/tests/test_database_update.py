"""Regrese bezpečné aktualizace aktivní .ndb bez spuštění HTTP serveru."""

from __future__ import annotations

import hashlib
import io
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock


APP_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(APP_ROOT / "backend"))
sys.path.insert(0, str(APP_ROOT / "tests"))

from database_update import (  # noqa: E402
    ActiveDatabaseUpdater,
    DatabaseBusy,
    DatabaseOperationLock,
    UpdateError,
    _retry_windows_path_action,
    ensure_space,
    read_locked,
    sha256_file,
    stream_multipart_ndb,
    validate_ndb,
    write_locked,
)
from ndb_fixture_builder import build_fixture_ndb  # noqa: E402
from ndb_parser import NdbDatabase  # noqa: E402


def _cell(value):
    return [{"name": "ISO RMS", "value": value, "limits_xml": None}]


class TrackingStream(io.BytesIO):
    def __init__(self, data):
        super().__init__(data)
        self.max_read = 0

    def read(self, size=-1):
        self.max_read = max(self.max_read, size if size >= 0 else 0)
        return super().read(size)


class DatabaseUpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads db update ")
        self.data = Path(self.temp.name) / "data"
        self.data.mkdir()
        self.active_name = "Aktivní závod.nDb"
        self.target = self.data / self.active_name
        build_fixture_ndb(self.target, _cell(1.0), plant_name="Český závod")
        self.cache = None
        self.close_count = 0
        self.reopen_count = 0
        self.invalidated = []
        self.lock = DatabaseOperationLock()

    def tearDown(self):
        if self.cache is not None:
            self.cache.close()
            self.cache = None
        self.temp.cleanup()

    def _updater(self, active=True):
        def close():
            self.close_count += 1
            if self.cache is not None:
                self.cache.close()
                self.cache = None

        def reopen():
            self.reopen_count += 1
            self.cache = NdbDatabase(str(self.target))

        return ActiveDatabaseUpdater(
            self.data,
            lambda: self.active_name if active else None,
            close,
            reopen,
            self.invalidated.append,
            self.lock,
        )

    def _upload(self, value, plant="Český závod", name="Novější měření.ndb"):
        source = self.data / (".upload-" + name + ".tmp")
        build_fixture_ndb(source, _cell(value), plant_name=plant)
        return {
            "path": source,
            "received_size": source.stat().st_size,
            "sha256": sha256_file(source),
            "source_name": name,
            "source_last_modified": "1787071200000",
        }

    def test_successful_same_company_replacement_exposes_new_measurement_and_preserves_name(self):
        upload = self._upload(9.5)
        result = self._updater().replace(upload)
        self.assertTrue(result["ok"])
        self.assertFalse(result["no_update"])
        self.assertTrue(self.target.exists())
        self.assertFalse((self.data / "Novější měření.ndb").exists())
        self.assertGreaterEqual(self.close_count, 1)
        self.assertGreaterEqual(self.reopen_count, 1)
        self.assertEqual(self.invalidated, [self.active_name])
        self.assertEqual(self.cache.trend(100)[-1]["value"], 9.5)

    def test_different_company_is_rejected_without_replacing_target(self):
        before = sha256_file(self.target)
        with self.assertRaisesRegex(UpdateError, "jinému podniku"):
            self._updater().replace(self._upload(2.0, plant="Jiný podnik"))
        self.assertEqual(sha256_file(self.target), before)

    def test_invalid_and_schema_mismatch_files_are_rejected_read_only(self):
        bad = self.data / ".bad.tmp"
        bad.write_bytes(b"not sqlite" * 30)
        with self.assertRaisesRegex(UpdateError, "SQLite"):
            validate_ndb(bad)
        mismatch = self.data / ".mismatch.tmp"
        con = sqlite3.connect(mismatch)
        con.execute("CREATE TABLE something (id INTEGER)")
        con.commit()
        con.close()
        with self.assertRaisesRegex(UpdateError, "schéma"):
            validate_ndb(mismatch)

    def test_no_active_database_and_identical_source_need_no_replacement(self):
        with self.assertRaisesRegex(UpdateError, "Není aktivní"):
            self._updater(active=False).replace(self._upload(3.0))
        clone = self.data / ".identical.tmp"
        shutil.copy2(self.target, clone)
        upload = {
            "path": clone,
            "received_size": clone.stat().st_size,
            "sha256": sha256_file(clone),
            "source_name": "stejná databáze.ndb",
        }
        result = self._updater().replace(upload)
        self.assertTrue(result["no_update"])
        self.assertEqual(self.close_count, 0)
        self.assertFalse(clone.exists())

    def test_swap_failure_restores_byte_identical_old_database_and_cache(self):
        # Zachycení po standardní inicializaci a bezpečném checkpointu:
        # rollback má vrátit právě tuto pracovní kopii po bajtech.
        initial = NdbDatabase(str(self.target))
        initial.close()
        con = sqlite3.connect(self.target)
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        con.close()
        for suffix in ("-wal", "-shm", "-journal"):
            Path(str(self.target) + suffix).unlink(missing_ok=True)
        before = self.target.read_bytes()
        with self.assertRaisesRegex(UpdateError, "původní databáze"):
            self._updater().replace(self._upload(7.0), simulate_failure_after_swap=True)
        self.assertEqual(self.target.read_bytes(), before)
        self.assertIsNotNone(self.cache)
        self.assertEqual(self.cache.trend(100)[-1]["value"], 1.0)

    def test_sidecars_are_cleaned_and_source_file_name_never_becomes_active_name(self):
        Path(str(self.target) + "-journal").write_bytes(b"stale")
        result = self._updater().replace(self._upload(4.0, name="Zdroj s mezerami.ndb"))
        self.assertEqual(result["filename"], self.active_name)
        # Starý journal zmizel před swapem. Nově otevřená běžná cache může
        # legitimně vytvořit vlastní WAL/SHM, ale nikdy nesmí zůstat starý
        # obsah vedle nové hlavní databáze.
        self.assertFalse(Path(str(self.target) + "-journal").exists())
        for suffix in ("-wal", "-shm"):
            sidecar = Path(str(self.target) + suffix)
            if sidecar.exists():
                self.assertNotEqual(sidecar.read_bytes(), b"stale")

    def test_hads_owned_configuration_history_drafts_and_current_marker_are_unchanged(self):
        marker_files = {
            self.data / "current.txt": "Aktivní závod.nDb\n",
            self.data / "library.json": '{"Aktivní závod.nDb":"Vlastní název"}',
            self.data / "podniky" / "český-závod" / "machine_config.json": '{"limit":7}',
            self.data / "podniky" / "český-závod" / "report_history.json": '{"historie":["x"]}',
            self.data / "podniky" / "český-závod" / "report_drafts.json": '{"návrh":true}',
            self.data / "podniky" / "český-závod" / "report_settings.json": '{"technik":"A"}',
        }
        before = {}
        for path, text in marker_files.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
            before[path] = path.read_bytes()
        self._updater().replace(self._upload(4.2))
        self.assertEqual({path: path.read_bytes() for path in before}, before)

    def test_multipart_declared_size_mismatch_and_chunked_streaming(self):
        original = b"SQLite format 3\x00" + (b"x" * (2 * 1024 * 1024 + 19))
        boundary = "----hads-test-boundary"
        body = (
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"declared_size\"\r\n\r\n{len(original) + 1}\r\n".encode()
            + f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"Žluťoučký.nDb\"\r\n\r\n".encode()
            + original
            + f"\r\n--{boundary}--\r\n".encode()
        )
        with self.assertRaisesRegex(UpdateError, "není úplný"):
            stream_multipart_ndb(
                TrackingStream(body), len(body), f"multipart/form-data; boundary={boundary}", self.data
            )
        body = body.replace(str(len(original) + 1).encode(), str(len(original)).encode(), 1)
        stream = TrackingStream(body)
        uploaded = stream_multipart_ndb(
            stream, len(body), f"multipart/form-data; boundary={boundary}", self.data
        )
        self.assertEqual(uploaded["received_size"], len(original))
        self.assertEqual(Path(uploaded["path"]).read_bytes(), original)
        self.assertLessEqual(stream.max_read, 1024 * 1024)

    def test_insufficient_disk_is_reported_before_write(self):
        usage = shutil._ntuple_diskusage(total=10**9, used=999_000_000, free=1)
        with mock.patch("database_update.shutil.disk_usage", return_value=usage):
            with self.assertRaisesRegex(UpdateError, "dost volného místa"):
                ensure_space(self.data, 10_000)

    def test_writer_waits_for_current_reader_then_replaces(self):
        updater = self._updater()
        upload = self._upload(6.0)
        entered = threading.Event()
        released = threading.Event()
        done = threading.Event()

        def reader():
            with read_locked(self.lock):
                entered.set()
                released.wait(2)

        def writer():
            updater.replace(upload)
            done.set()

        r = threading.Thread(target=reader)
        w = threading.Thread(target=writer)
        r.start()
        self.assertTrue(entered.wait(1))
        w.start()
        time.sleep(0.08)
        self.assertFalse(done.is_set())
        released.set()
        r.join(2)
        w.join(2)
        self.assertTrue(done.is_set())
        self.assertEqual(self.cache.trend(100)[-1]["value"], 6.0)

    def test_windows_retry_releases_hads_owned_handle_and_then_succeeds(self):
        calls = []

        def action():
            calls.append(1)
            if len(calls) < 3:
                error = PermissionError(13, "sdílecí zámek")
                error.winerror = 32
                raise error

        _retry_windows_path_action(
            Path(str(self.target) + "-wal"),
            "test uvolnění HADS-owned WAL",
            action,
            delays=(0.0, 0.0),
        )
        self.assertEqual(len(calls), 3)

    def test_registered_connection_is_closed_before_sidecar_commit(self):
        closed = []
        extra = self.lock.register_connection(
            self.target, lambda: closed.append("temporary report"), "testovací report"
        )
        self.assertEqual(self.lock.registered_connection_count(self.target), 1)
        result = self._updater().replace(self._upload(5.4))
        self.assertTrue(result["ok"])
        self.assertEqual(closed, ["temporary report"])
        self.assertEqual(self.lock.registered_connection_count(self.target), 0)
        # token je po výhradní údržbě idempotentně neplatný
        self.lock.unregister_connection(extra)

    def test_externally_locked_sidecar_aborts_before_swap_and_keeps_bytes(self):
        # Přesná regrese z Windows: cizí proces drží aktivní WAL soubor.
        sidecar = Path(str(self.target) + "-wal")
        sidecar.write_bytes(b"externally locked wal")
        main_before = self.target.read_bytes()
        sidecar_before = sidecar.read_bytes()

        import database_update
        real_replace = database_update.os.replace

        def windows_locked(source, destination):
            if str(source) == str(sidecar):
                error = PermissionError(13, "soubor používá jiný proces", str(sidecar))
                error.winerror = 32
                raise error
            return real_replace(source, destination)

        with mock.patch.object(
            database_update._retry_windows_path_action,
            "__kwdefaults__", {"delays": (0.0, 0.0)}
        ), mock.patch("database_update.os.replace", side_effect=windows_locked):
            with self.assertRaisesRegex(UpdateError, "používán jiným programem"):
                self._updater().replace(self._upload(5.5))
        self.assertEqual(self.target.read_bytes(), main_before)
        self.assertEqual(sidecar.read_bytes(), sidecar_before)

    def test_new_read_is_rejected_while_maintenance_waits_for_old_read(self):
        entered = threading.Event()
        release = threading.Event()
        writer_entered = threading.Event()

        def old_reader():
            with read_locked(self.lock):
                entered.set()
                release.wait(2)

        reader = threading.Thread(target=old_reader)
        reader.start()
        self.assertTrue(entered.wait(1))
        def writer():
            with write_locked(self.lock, timeout=2):
                writer_entered.set()

        # Čekající výhradní údržba zakáže nové čtenáře, dokud starý report
        # nedoběhne; tím nemůže mezi reporty proklouznout commit.
        waiter = threading.Thread(target=writer)
        waiter.start()
        time.sleep(0.04)
        with self.assertRaises(DatabaseBusy):
            with read_locked(self.lock, timeout=0.03):
                pass
        release.set()
        reader.join(1)
        self.assertTrue(writer_entered.wait(1))
        waiter.join(1)

    def test_replacement_never_replays_old_wal_measurement(self):
        # Simulace pracovního WAL: po úspěšné výměně musí parser vidět pouze
        # nahraný snímek, nikdy hodnotu z dřívějšího vedlejšího souboru.
        old = NdbDatabase(str(self.target))
        old._con.execute("UPDATE Tbl_Tree SET Name='Původní WAL stroj' WHERE ID=2")
        old._con.commit()
        old.close()
        result = self._updater().replace(self._upload(8.8))
        self.assertTrue(result["ok"])
        self.assertEqual(self.cache.trend(100)[-1]["value"], 8.8)

    def test_ui_has_button_confirmation_and_browser_metadata(self):
        html = (APP_ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
        js = (APP_ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
        self.assertIn("Aktualizovat databázi", html)
        self.assertIn("Aktivní pracovní kopie", html)
        self.assertIn("source_last_modified", js)
        self.assertIn("/api/databases/update", js)
        self.assertIn("declared_size", js)
        self.assertIn("Vybraný soubor zůstává připraven k opakování", js)


if __name__ == "__main__":
    unittest.main()
