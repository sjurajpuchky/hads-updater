"use strict";

/*
 * Browserová regrese bez serveru a bez AI volání.  Pouští skutečnou funkci
 * generateReportDraft z frontendu proti lokálním odpovědím API:
 *   1) platný návrh se zobrazí,
 *   2) bezpečný částečný návrh z backendu zobrazí českou AI poznámku,
 *   3) poškozený objekt ve starém/neočekávaném draftu skončí bezpečnou hláškou,
 *      nikoli "...replace is not a function".
 */
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { chromium } = require("playwright");

const appPath = process.argv[2] || path.join(__dirname, "..", "frontend", "app.js");
const errorPng = process.argv[3] || path.join(process.cwd(), "HADS_1.39.1_ai_contract_error_browser.png");
const successPng = process.argv[4] || path.join(process.cwd(), "HADS_1.39.1_ai_contract_success_browser.png");
const source = fs.readFileSync(appPath, "utf8");
const guardStart = source.indexOf("const REPORT_AI_RESPONSE_SHAPE_ERROR =");
const guardEnd = source.indexOf("function fillReportEditor(doc)", guardStart);
const generateStart = source.indexOf("async function generateReportDraft()");
const generateEnd = source.indexOf("// Vypíše výsledek aktualizace", generateStart);
assert(guardStart >= 0 && guardEnd > guardStart, "AI guard must precede editor rendering");
assert(generateStart >= 0 && generateEnd > generateStart, "report generation function must be found");
const guardCode = source.slice(guardStart, guardEnd);
const generateCode = source.slice(generateStart, generateEnd);

const safeMessage =
  "AI odpověď nemá podporovaný tvar pro návrh protokolu. Zkuste akci zopakovat nebo změňte model.";

(async () => {
  const browser = await chromium.launch({ headless: true });
  try {
    const context = await browser.newContext({ viewport: { width: 900, height: 560 } });
    const page = await context.newPage();
    await page.setContent(`<!doctype html><html lang="cs"><head><meta charset="utf-8">
      <style>
       body { font: 16px/1.4 Arial,sans-serif; margin:32px; background:#f4f6f8; color:#17202a }
       button { margin-right:12px; padding:10px 14px; border:0; border-radius:6px; background:#0969da; color:#fff; cursor:pointer }
       #report-gen-status,#toast,#editor { margin-top:18px; padding:14px; border-radius:6px; background:#fff; border:1px solid #d0d7de }
       #toast.error { background:#fff1f0; border-color:#ff8182; color:#a40e26 }
       #toast.ok { background:#dafbe1; border-color:#4ac26b; color:#116329 }
       #editor { min-height:55px; white-space:pre-wrap }
      </style></head><body>
      <input id="report-scope-mode" value="all"><input id="report-use-ai" type="checkbox" checked>
      <input id="report-version" value="2"><input id="report-show-previous" type="checkbox">
      <select id="report-model"><option value="claude-haiku-4-5-20251001" selected>Claude Haiku 4.5</option></select>
      <textarea id="report-ai-context"></textarea>
      <button id="report-generate-btn">Vytvořit návrh protokolu</button>
      <button id="mode-success">Platný návrh</button><button id="mode-safe-warning">Bezpečná AI chyba</button>
      <div id="report-gen-status" aria-live="polite"></div><div id="toast" role="alert"></div><div id="editor"></div>
      </body></html>`, { waitUntil: "domcontentloaded" });

    await page.evaluate(({ guardCode, generateCode, safeMessage }) => {
      // Shared report state and helpers are deliberately small but preserve the
      // production function's observable control flow.
      window.REPORT = { draft: null, sessionId: null, revision: 0, localSnapshot: false, expandedMachines: new Set() };
      window.REPORT_SESSION = { newSessionId: () => "qa-session" };
      window.collectReportScope = () => ({ mode: "all" });
      window.collectGraphSelectionsMap = () => ({});
      window._stampReportDraft = (draft) => draft;
      window.snapshotReportDraft = () => {};
      window.flushReportDraft = () => {};
      window._showReportRefreshStatus = () => {};
      window.setReportEditorVisible = () => {};
      window._setReportBtns = () => {};
      window.toast = (text, isError) => {
        const el = document.getElementById("toast");
        el.textContent = String(text || "");
        el.className = isError ? "error" : "ok";
      };
      eval(guardCode);
      window.fillReportEditor = (doc) => {
        assertReportAiTextContract(doc);
        document.getElementById("editor").textContent = doc.machines.map((m) => m.zaver).join("\\n");
      };
      const valid = {
        machines: [{ name: "Ventilátor", problem: "Provozní stav", zaver: "Hodnoty odpovídají provoznímu stavu.", doporuceni: "Kontrolní měření." }],
      };
      const backendSafeWarning = {
        machines: [{ name: "Ventilátor", problem: "", zaver: "", doporuceni: "" }],
      };
      const malformedLegacy = {
        machines: [{ name: "Ventilátor", problem: "Provozní stav", zaver: { body: "nesmí se zobrazit" }, doporuceni: "Kontrola" }],
      };
      window.qaMode = "success";
      window.api = async () => {
        if (window.qaMode === "safe-warning") return { draft: backendSafeWarning, ai_note: safeMessage };
        if (window.qaMode === "malformed") return { draft: malformedLegacy };
        return { draft: valid };
      };
      eval(generateCode);
      document.getElementById("report-generate-btn").addEventListener("click", generateReportDraft);
      document.getElementById("mode-success").addEventListener("click", () => { window.qaMode = "success"; });
      document.getElementById("mode-safe-warning").addEventListener("click", () => { window.qaMode = "safe-warning"; });
    }, { guardCode, generateCode, safeMessage });

    // Success flow: a normal user click produces a visible editor result.
    await page.click("#mode-success");
    await page.click("#report-generate-btn");
    await page.waitForFunction(() => document.querySelector("#editor").textContent.includes("Hodnoty odpovídají"));
    assert.match(await page.locator("#report-gen-status").textContent(), /^Návrh vytvořen/);
    assert.equal(await page.locator("#toast").textContent(), "Návrh protokolu vytvořen.");
    await page.screenshot({ path: successPng });

    // Backend's safe response: completed report remains editable and only the
    // public Czech reason is shown.  No fixture/provider field leaks to UI.
    await page.click("#mode-safe-warning");
    await page.click("#report-generate-btn");
    await page.waitForFunction((message) => document.querySelector("#toast").textContent === message, safeMessage);
    assert.match(await page.locator("#report-gen-status").textContent(), /^Návrh vytvořen/);
    assert.equal(await page.locator("#editor").textContent(), "");
    assert.equal(await page.locator("#toast").textContent(), safeMessage);
    assert.doesNotMatch(await page.locator("#toast").textContent(), /body|nesmí se zobrazit|replace is not a function/i);

    // Off-happy-path defense: a malformed old/untrusted draft must make the
    // production catch path show the same public message, not a TypeError.
    await page.evaluate(() => { window.qaMode = "malformed"; });
    await page.click("#report-generate-btn");
    await page.waitForFunction((message) => document.querySelector("#toast").textContent === message, safeMessage);
    assert.equal(await page.locator("#toast").textContent(), safeMessage);
    assert.doesNotMatch(await page.locator("#toast").textContent(), /replace is not a function|body|nesmí se zobrazit/i);
    await page.screenshot({ path: errorPng });

    const metrics = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
      status: document.querySelector("#report-gen-status").textContent,
      toast: document.querySelector("#toast").textContent,
    }));
    assert(metrics.scrollWidth <= metrics.clientWidth, "QA view must not overflow horizontally");
    console.log(JSON.stringify({ result: "ok", ...metrics, errorPng, successPng }));
    await context.close();
  } finally {
    await browser.close();
  }
})().catch((error) => {
  console.error(error && error.stack || error);
  process.exitCode = 1;
});
