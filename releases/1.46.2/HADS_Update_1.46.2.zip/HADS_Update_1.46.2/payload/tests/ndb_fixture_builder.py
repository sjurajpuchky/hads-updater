"""Pomocná knihovna pro testy: postaví minimální syntetickou .ndb (SQLite)
databázi se schématem shodným s reálným HADS exportem, ale jen s tabulkami a
sloupci, které `ndb_parser.NdbDatabase` potřebuje.

Použití: build_fixture_ndb(path, cells=[...]) vytvoří jeden stroj se zadanými
statickými buňkami (DDS objekty) na jednom měřicím bodě/ložisku, s danou
poslední hodnotou a limitní XML sestavenou z `thresholds` (+ volitelně
`severities`, aby šlo simulovat i cestu s platným `alarmId`).

Držíme se stejného binárního formátu jako reálné .ndb soubory (viz
ndb_parser.py): Tbl_Cell_Stats.Data je zlib-komprimované pole 64bajtových
záznamů (int64 .NET ticks + double hodnota na offsetu 16), Tbl_Cell.Limits je
XML s <limits><SDS_DOUBLE><dVal>DX<hex></dVal></SDS_DOUBLE>...</limits> a
volitelným <alarmId><SDS_INT><iVal>...</iVal></SDS_INT>...</alarmId>.
"""
import sqlite3
import struct
import zlib
import os

# .NET ticks pro 2000-01-01 (shodně s ndb_parser._EPOCH_2000 / net_ticks_2000)
_NET_TICKS_2000 = 125911584000000000
_TICKS_PER_MS = 10000


def _enc_double_hex(v: float) -> str:
    return "DX" + struct.pack("<d", v).hex().upper()


def make_limits_xml(thresholds, severities=None):
    """Sestaví limitní XML shodné s HADS formátem.

    `thresholds` - seznam prahových hodnot (float), v pořadí jak by byly
    uložené v XML (může být neuspořádané / s duplicitami / s None pro
    neplatnou hodnotu - None se needukoduje jako <dVal>, ale jako neplatný
    hex, aby šlo testovat i poškozená data).
    `severities` - volitelný seznam alarmId (int) - pokud None, blok
    <alarmId> se vůbec nevygeneruje (simuluje chybějící/nepárující alarmId,
    tedy záložní heuristiku v parse_cell_limits).
    """
    dval_parts = []
    for t in thresholds:
        if t is None:
            # neplatná hodnota - poškozený hex (parser ho odfiltruje jako None)
            dval_parts.append("<SDS_DOUBLE><dVal>DXZZZZZZZZZZZZZZZZ</dVal></SDS_DOUBLE>")
        else:
            dval_parts.append(f"<SDS_DOUBLE><dVal>{_enc_double_hex(t)}</dVal></SDS_DOUBLE>")
    xml = "<LimPackVect><limVect><LimitsPack><type>4</type>\n"
    xml += f"<limits>{''.join(dval_parts)}</limits>\n"
    if severities is not None:
        ival_parts = "".join(f"<SDS_INT><iVal>{s}</iVal></SDS_INT>" for s in severities)
        xml += f"<alarmId>{ival_parts}</alarmId>\n"
    xml += "</LimitsPack></limVect></LimPackVect>"
    return xml


def make_static_blob(points):
    """Zakóduje seznam (ms_from_2000, value) do zlib-komprimovaného BLOBu
    ve formátu Tbl_Cell_Stats.Data (64bajtové záznamy)."""
    raw = bytearray()
    for ms, val in points:
        ticks = _NET_TICKS_2000 + ms * _TICKS_PER_MS
        rec = bytearray(64)
        rec[0:8] = struct.pack("<q", ticks)
        rec[16:24] = struct.pack("<d", float(val))
        raw += rec
    return zlib.compress(bytes(raw))


_SCHEMA = """
CREATE TABLE Tbl_Info (ID INTEGER PRIMARY KEY, Version TEXT, DDS_Version TEXT,
    Route_Format TEXT, OnlineLock INTEGER, XmlInfo TEXT);
CREATE TABLE Tbl_Routes (ID INTEGER PRIMARY KEY, Name TEXT, Guid TEXT,
    CellCount INTEGER, CellList TEXT, Params TEXT);
CREATE TABLE Tbl_Severity (ID INTEGER PRIMARY KEY, Name TEXT, Color INTEGER,
    Severity INTEGER);
CREATE TABLE Tbl_Tree (ID INTEGER PRIMARY KEY, Name TEXT, Parent INTEGER,
    SortId INTEGER, Type INTEGER, Speed_Hz REAL, Speed_Factor REAL,
    Tacho_Factor REAL, Stopped INTEGER, IcoId INTEGER, Labels TEXT,
    Bands TEXT, IgnrInhBands TEXT, Groups TEXT, XmlParams TEXT, Modified INTEGER);
CREATE TABLE Tbl_Cell (ID INTEGER PRIMARY KEY, Name TEXT, Parent INTEGER,
    SortId INTEGER, DataType INTEGER, SubType INTEGER, MeasConditions TEXT,
    Modified INTEGER, DbFlags INTEGER, LastMeasured INTEGER, IntervalType INTEGER,
    Interval INTEGER, ToRoute INTEGER, RouteEntry INTEGER, MaxSeverityId INTEGER,
    GraphView TEXT, Labels TEXT, Bands TEXT, Limits TEXT, IgnrInhBands TEXT,
    XmlParams TEXT, Ref TEXT, LastValSeverityId INTEGER);
CREATE TABLE Tbl_Cell_Stats (ID INTEGER PRIMARY KEY, CellId INTEGER,
    TimeFrom INTEGER, TimeTo INTEGER, Data BLOB, Size INTEGER, Count INTEGER,
    CRC INTEGER, Flags INTEGER);
"""


def build_fixture_ndb(path, cell_specs, machine_name="TestMachine",
                       point_name="L1H", plant_name="TestPlant"):
    """Vytvoří minimální .ndb s jedním strojem, jedním měřicím bodem a
    zadanými statickými buňkami (DDS objekty).

    `cell_specs`: list dictů {"name": "BEARING RMS", "value": float,
                              "limits_xml": str|None}
    Vrací mapu {cell_name: cell_id}.
    """
    if os.path.exists(path):
        os.remove(path)
    con = sqlite3.connect(path)
    con.executescript(_SCHEMA)

    # Tbl_Severity - standardní 4 úrovně
    con.executemany(
        "INSERT INTO Tbl_Severity (ID, Name, Color, Severity) VALUES (?,?,?,?)",
        [(1, "Ok", 0x00FF00, 1), (2, "Varování", 0xFFFF00, 2),
         (3, "Výstraha", 0xFFA500, 3), (4, "Ohrožení", 0xFF0000, 4)],
    )
    con.execute(
        "INSERT INTO Tbl_Info (ID, Version, DDS_Version, Route_Format) "
        "VALUES (1, '1.0', '1.31', 'route')"
    )
    con.execute("INSERT INTO Tbl_Routes (ID, Name) VALUES (1, 'TestRoute')")

    # Tbl_Tree: Plant(Type=1) -> Machine(Type=2) -> Point(Type=3)
    plant_id, machine_id, point_id = 1, 2, 3
    con.execute(
        "INSERT INTO Tbl_Tree (ID, Name, Parent, SortId, Type, Speed_Hz) "
        "VALUES (?,?,?,?,?,?)", (plant_id, plant_name, 0, 0, 1, None),
    )
    con.execute(
        "INSERT INTO Tbl_Tree (ID, Name, Parent, SortId, Type, Speed_Hz) "
        "VALUES (?,?,?,?,?,?)", (machine_id, machine_name, plant_id, 0, 2, 25.0),
    )
    con.execute(
        "INSERT INTO Tbl_Tree (ID, Name, Parent, SortId, Type, Speed_Hz) "
        "VALUES (?,?,?,?,?,?)", (point_id, point_name, machine_id, 0, 3, None),
    )

    cell_id_map = {}
    next_cell_id = 100
    now_ms = 800_000_000_000  # libovolný pevný čas (ms od 2000) pro reprodukovatelnost
    for spec in cell_specs:
        cid = next_cell_id
        next_cell_id += 1
        cell_id_map[spec["name"]] = cid
        con.execute(
            "INSERT INTO Tbl_Cell (ID, Name, Parent, SortId, DataType, Limits, "
            "LastMeasured, MaxSeverityId) VALUES (?,?,?,?,?,?,?,?)",
            (cid, spec["name"], point_id, 0, 1, spec.get("limits_xml"),
             now_ms, spec.get("max_severity_id", 1)),
        )
        blob = make_static_blob([(now_ms, spec["value"])])
        con.execute(
            "INSERT INTO Tbl_Cell_Stats (CellId, TimeFrom, TimeTo, Data) "
            "VALUES (?,?,?,?)", (cid, now_ms, now_ms, blob),
        )

    con.commit()
    con.close()
    return cell_id_map
