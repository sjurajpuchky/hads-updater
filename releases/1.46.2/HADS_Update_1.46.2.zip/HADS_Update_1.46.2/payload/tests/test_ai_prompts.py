"""Regrese editoru AI promptů pro návrhy protokolů; bez HTTP listeneru."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import stat
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

import ai_eval
import ai_prompts
import data_store
import report_history
import server


class AiPromptsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads-ai-prompts-")
        self.data = Path(self.temp.name) / "data"
        self.data.mkdir()
        self.old_prompt_dir = ai_prompts.DATA_DIR
        self.old_data_dir = data_store._DATA_DIR
        self.old_podniky_dir = data_store._PODNIKY_DIR
        ai_prompts.DATA_DIR = self.data
        data_store._DATA_DIR = self.data
        data_store._PODNIKY_DIR = self.data / "podniky"

    def tearDown(self):
        ai_prompts.DATA_DIR = self.old_prompt_dir
        data_store._DATA_DIR = self.old_data_dir
        data_store._PODNIKY_DIR = self.old_podniky_dir
        self.temp.cleanup()

    def test_defaults_exactly_keep_report_prompt_contracts(self):
        # Otisky se od 1.40.0 mění: každá verze protokolu nově obsahuje
        # společnou metodologii diagnostiky vloženou přes {methodology}.
        # Od 1.44.0 nese šablona i strukturu závěru (počet a pořadí bodů),
        # kterou dřív vnucoval kód mimo dosah editace.
        expected = {
            1: (6049, "04e18e5eadc0a9e7612697ff68642e00bf32bf37af08b8ee9f574f3ca7996c78"),
            2: (6853, "f3f2d1d7637f0857fcecaf1f38a6930f5e8ccb853afef106927c01bd83a413ca"),
            3: (6920, "80c02692ffc48bd35bd4b72527d6eb265844f742d51285201b5b004d2907f1a4"),
        }
        for version, (length, digest) in expected.items():
            snapshot = ai_prompts.report_snapshot(version)
            rendered = ai_prompts.render_snapshot(snapshot)
            self.assertEqual(len(rendered), length)
            self.assertEqual(hashlib.sha256(rendered.encode("utf-8")).hexdigest(), digest)
            system, _user = ai_eval.build_brief_prompt({}, None, None, report_version=version,
                                                        use_examples=False)
            self.assertEqual(system, rendered)
            self.assertFalse(snapshot.modified)
            # Neměnný JSON kontrakt i metodologie musí být v každé verzi.
            self.assertIn("JSON", rendered)
            self.assertIn("BPFO", rendered)
            # Pravidla, která pracují s deterministicky spočtenými nálezy.
            self.assertIn("postranní pásma", rendered)
            self.assertIn("2×/1×", rendered)
            self.assertIn("SMĚROVOST", rendered)
            # Rozdělení rolí spekter je závazné pravidlo, ne doporučení.
            self.assertIn("KTERÉ SPEKTRUM K ČEMU SLOUŽÍ", rendered)
            self.assertIn("spektrum RYCHLOSTI", rendered)
            self.assertIn("OBÁLKY zrychlení", rendered)
            # Pořadí opor hodnocení; norma je až poslední.
            self.assertIn("ČÍM HODNOTU UKOTVIT", rendered)
            self.assertIn("sesterský", rendered)

    def test_override_is_used_by_real_report_ai_call_and_audit_is_hash_only(self):
        base = ai_prompts.public_config()
        identifier = "report_brief_v2"
        text = "Vlastní styl: použij stručné věty v češtině. {report_contract}"
        saved = ai_prompts.save_override(identifier, text, base["revision"])
        snapshot = ai_prompts.report_snapshot(2)
        captured = {}

        def fake_openai(key, model, system, user, image=None):
            captured.update(key=key, model=model, system=system, user=user, image=image)
            return '{"problem":"Stav","zaver":"Bez závady.","doporuceni":"Měřte dále."}'

        with mock.patch.object(ai_eval, "get_api_key", return_value="test-key"), \
                mock.patch.object(ai_eval, "_call_openai", side_effect=fake_openai):
            result, used_model = ai_eval.evaluate_brief(
                {"machine_name": "Pohon"}, 25, None, model="gpt-4o-mini",
                report_version=2, use_examples=False, prompt_snapshot=snapshot)
        self.assertEqual(used_model, "gpt-4o-mini")
        self.assertEqual(result["problem"], "Stav")
        self.assertIn("Vlastní styl", captured["system"])
        self.assertIn("Žádný text mimo JSON", captured["system"])
        self.assertNotIn("test-key", captured["system"])
        self.assertEqual(saved["revision"], 1)
        audit = ai_prompts.audit_metadata(snapshot)
        audit_serialized = json.dumps(audit, ensure_ascii=False)
        self.assertNotIn(text, audit_serialized)
        self.assertEqual(audit["configuration_revision"], 1)
        self.assertEqual(audit["templates"][0]["sha256"], snapshot.digest)

    def test_each_report_variant_reads_its_corresponding_effective_override(self):
        revision = ai_prompts.public_config()["revision"]
        for version in (1, 2, 3):
            identifier = ai_prompts.prompt_id_for_report_version(version)
            marker = "ŠABLONA-VARIANTA-%d" % version
            saved = ai_prompts.save_override(
                identifier, marker + " {report_contract}", revision)
            revision = saved["revision"]
            system, _user = ai_eval.build_brief_prompt(
                {}, None, None, report_version=version, use_examples=False)
            # Od 1.40.0 předchází uživatelské šabloně společná metodologie,
            # takže se marker už nehledá na začátku, ale kdekoli v promptu.
            self.assertIn(marker, system)
            self.assertEqual(
                ai_prompts.report_snapshot(version).identifier, identifier)

    def test_save_load_reset_atomic_permissions_and_conflict(self):
        config = ai_prompts.public_config()
        replacement = "Český prompt s Unicode: žluťoučký kůň. {report_contract}"
        calls = []
        real_replace = ai_prompts.os.replace

        def recording_replace(source, target):
            calls.append((Path(source), Path(target)))
            return real_replace(source, target)

        with mock.patch.object(ai_prompts.os, "replace", side_effect=recording_replace):
            saved = ai_prompts.save_override("report_brief_v1", replacement, config["revision"])
        prompt_file = self.data / "ai_prompts.json"
        self.assertTrue(prompt_file.is_file())
        self.assertEqual(saved["revision"], 1)
        self.assertTrue(calls and ".tmp-" in calls[0][0].name)
        self.assertFalse(list(self.data.glob("ai_prompts.json.tmp-*")))
        self.assertEqual(ai_prompts.get_snapshot("report_brief_v1").text, replacement)
        if hasattr(stat, "S_IMODE"):
            self.assertEqual(stat.S_IMODE(prompt_file.stat().st_mode) & 0o077, 0)
        with self.assertRaises(ai_prompts.PromptConflictError):
            ai_prompts.save_override("report_brief_v1", replacement, 0)
        reset = ai_prompts.reset_override("report_brief_v1", saved["revision"])
        self.assertEqual(reset["revision"], 2)
        self.assertFalse(ai_prompts.get_snapshot("report_brief_v1").modified)

    def test_validation_literal_braces_unknown_missing_unbalanced_and_long_text(self):
        with self.assertRaisesRegex(ai_prompts.PromptValidationError, "Chybí povinný"):
            ai_prompts.validate_template("report_brief_v1", "Jen text")
        with self.assertRaisesRegex(ai_prompts.PromptValidationError, "Neznámý"):
            ai_prompts.validate_template("report_brief_v1", "X {unknown}")
        with self.assertRaisesRegex(ai_prompts.PromptValidationError, "Neplatný"):
            ai_prompts.validate_template("report_brief_v1", "X {Report_contract}")
        with self.assertRaisesRegex(ai_prompts.PromptValidationError, "Neuzavřená"):
            ai_prompts.validate_template("report_brief_v1", "X {report_contract")
        rendered = ai_prompts.render_template(
            "report_brief_v1", "Doslova {{JSON}} a {report_contract} — český náhled.")
        self.assertIn("{JSON}", rendered)
        self.assertIn("český náhled", rendered)
        too_long = "x" * ai_prompts.MAX_TEMPLATE_CHARS + "{report_contract}"
        with self.assertRaisesRegex(ai_prompts.PromptValidationError, "příliš dlouhý"):
            ai_prompts.validate_template("report_brief_v1", too_long)

    def test_corrupt_or_invalid_file_falls_back_without_affecting_examples_or_credentials(self):
        prompt_file = self.data / "ai_prompts.json"
        examples_file = self.data / "ai_examples.json"
        credentials_file = self.data / "ai_credentials.bin"
        examples_file.write_text('{"examples":[{"input":"beze změny"}]}', encoding="utf-8")
        credentials_file.write_bytes(b"opaque-fixture")
        prompt_file.write_text("{ špatný json", encoding="utf-8")
        public = ai_prompts.public_config()
        self.assertTrue(public["warnings"])
        self.assertFalse(public["templates"][0]["is_modified"])
        self.assertEqual(examples_file.read_text(encoding="utf-8"), '{"examples":[{"input":"beze změny"}]}')
        self.assertEqual(credentials_file.read_bytes(), b"opaque-fixture")
        prompt_file.write_text(json.dumps({"format": 1, "revision": 9, "overrides": {
            "report_brief_v1": {"text": "neplatné bez kontraktu"}}}), encoding="utf-8")
        public = ai_prompts.public_config()
        self.assertEqual(public["revision"], 9)
        self.assertTrue(public["warnings"])
        self.assertFalse(public["templates"][0]["is_modified"])

    def test_preview_is_local_and_history_retains_prompt_audit(self):
        preview = ai_prompts.preview("report_brief_v3", "Ukázka {report_contract}")
        self.assertIn("anonymizováno", preview["sample_context"])
        self.assertIn("Ukázka", preview["system_prompt"])
        audit = ai_prompts.audit_metadata(ai_prompts.report_snapshot(3))
        summary = report_history.add_entry("podnik:Test", {
            "report_title": "Protokol",
            "report_version": 3,
            "machines": [{}],
            "ai_prompt_audit": audit,
        })
        loaded = report_history.get_entry("podnik:Test", summary["id"])
        self.assertEqual(summary["ai_prompt_audit"], audit)
        self.assertEqual(loaded["doc"]["ai_prompt_audit"], audit)

    def test_report_draft_snapshots_prompt_once_and_records_generation_audit(self):
        captured = {}

        class FakeDb:
            # **kwargs pokrývá spectrum_detail/speed_hz doplněné v 1.40.0
            def machine_ai_data(self, machine_id, overrides=None, **kwargs):
                self.machine_id = machine_id
                self.kwargs = kwargs
                return {"machine_name": "Ventilátor"}

        def fake_evaluate(*args, **kwargs):
            captured["snapshot"] = kwargs["prompt_snapshot"]
            return {"problem": "Stav", "zaver": "Závěr", "doporuceni": "Měřit."}, "gpt-4o-mini"

        def fake_build(_db, _overrides, _company, _scope, ai_fn=None, **_kwargs):
            result = ai_fn({"id": 17}, {"card": {}, "severity": "B", "severity_label": "B"})
            return {"machines": [result], "report_version": 2}

        with mock.patch.object(server.machine_config, "get_db_overrides", return_value={}), \
                mock.patch.object(server.company, "get_company", return_value={}), \
                mock.patch.object(server.report_settings, "quantity_map", return_value={}), \
                mock.patch.object(server.ai_eval, "has_any_key", return_value=True), \
                mock.patch.object(server.ai_eval, "evaluate_brief", side_effect=fake_evaluate), \
                mock.patch.object(server.report_mod, "build_report_draft", side_effect=fake_build), \
                mock.patch.object(server.report_mod, "report_state_context", return_value=""), \
                mock.patch.object(server.report_store, "save_draft", side_effect=lambda _fn, doc, _ctx: doc):
            status, payload = server._build_report_draft(
                FakeDb(), "podnik:Test", "all", True, "gpt-4o-mini",
                report_version=2, draft_context="fixture")
        self.assertEqual(status, 200)
        audit = payload["draft"]["ai_prompt_audit"]
        self.assertEqual(audit["configuration_revision"], captured["snapshot"].revision)
        self.assertEqual(audit["templates"][0]["sha256"], captured["snapshot"].digest)
        self.assertEqual(audit["templates"][0]["id"], "report_brief_v2")

    def test_api_validation_conflict_security_nonce_and_no_store(self):
        status, response = server._api_handler("/api/ai/prompts", "GET")
        self.assertEqual(status, 200)
        self.assertNotIn("api_key", json.dumps(response).lower())
        status, response = server._api_handler(
            "/api/ai/prompts/preview", "POST",
            json.dumps({"id": "report_brief_v1", "text": "bez kontraktu"}).encode())
        self.assertEqual(status, 400)
        self.assertIn("Chybí", response["detail"])

        old_server = server._SERVER
        server._SERVER = SimpleNamespace(server_address=("127.0.0.1", 8123))
        try:
            handler = object.__new__(server.Handler)
            handler.client_address = ("127.0.0.1", 40000)
            handler.headers = {"Host": "127.0.0.1:8123", "Origin": "http://127.0.0.1:8123"}
            self.assertTrue(handler._ai_prompt_request_is_allowed())
            handler.client_address = ("192.168.1.11", 40000)
            self.assertFalse(handler._ai_prompt_request_is_allowed())
            handler.client_address = ("127.0.0.1", 40000)
            handler.headers = {"Host": "127.0.0.1:8123", "Origin": "https://example.invalid"}
            self.assertFalse(handler._ai_prompt_request_is_allowed())
            nonce = server._AI_PROMPT_NONCES.issue("http://127.0.0.1:8123")
            handler.headers = {
                "Host": "127.0.0.1:8123",
                "Origin": "http://127.0.0.1:8123",
                "X-HADS-AI-Prompts-Nonce": nonce,
            }
            self.assertTrue(handler._ai_prompt_nonce_is_valid({"nonce": nonce}))
            self.assertFalse(handler._ai_prompt_nonce_is_valid({"nonce": nonce}))
        finally:
            server._SERVER = old_server

        class ResponseRecorder:
            def __init__(self):
                self.headers = []
                self.wfile = io.BytesIO()
            def send_response(self, status):
                self.status = status
            def send_header(self, key, value):
                self.headers.append((key, value))
            def end_headers(self):
                pass

        recorder = ResponseRecorder()
        server.Handler._send_json(recorder, 200, {"ok": True}, no_store=True)
        self.assertIn(("Cache-Control", "no-store"), recorder.headers)

    def test_settings_ui_contains_safe_editor_and_stale_response_guard(self):
        html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
        css = (ROOT / "frontend" / "styles.css").read_text(encoding="utf-8")
        self.assertIn("AI prompty", html)
        self.assertIn("data-settings-tab=\"aiprompts\"", html)
        self.assertIn("AI_PROMPTS_REQUEST", js)
        self.assertIn("/api/ai/prompts/preview", js)
        self.assertIn("confirm(", js)
        self.assertIn("textContent", js)
        self.assertIn('"Cascadia Mono"', css)
        self.assertIn("min-height: 250px", css)


if __name__ == "__main__":
    unittest.main()
