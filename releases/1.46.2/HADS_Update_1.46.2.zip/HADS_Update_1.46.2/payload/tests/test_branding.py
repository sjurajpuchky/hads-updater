"""Regrese personalizace vydavatele protokolů (logo + patička).

Ověřuje tři vlastnosti, na kterých stojí bezpečnost této funkce:
  * personalizace žije výhradně v ``data/`` — aktualizace programu ji nesmí
    smazat ani přepsat,
  * nahrané logo se přijme jen jako skutečný, vykreslitelný JPEG,
  * PDF i DOCX používají aktuální nastavení, tedy i u protokolu znovu
    vygenerovaného ze starého návrhu.
"""
from __future__ import annotations

import base64
import io
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

import branding
import pdf_writer
import report as report_mod
import report_docx
import report_pdf


def _jpeg(width=120, height=40, components=3):
    """Minimální JPEG, který ``pdf_writer._jpeg_info`` přečte jako SOF0."""
    # SOF0: precision, výška, šířka, počet složek + popis složek (3 B na složku)
    sof = struct.pack(">BHHB", 8, height, width, components) + b"\x00" * (components * 3)
    return (b"\xff\xd8"
            + b"\xff\xc0" + struct.pack(">H", len(sof) + 2) + sof
            + b"\xff\xd9")


def _data_url(payload, mime="image/jpeg"):
    return "data:%s;base64,%s" % (mime, base64.b64encode(payload).decode("ascii"))


class BrandingStorageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads-branding-")
        self.data = Path(self.temp.name) / "data"
        self.data.mkdir()
        self.old_data_dir = branding.DATA_DIR
        branding.DATA_DIR = self.data

    def tearDown(self):
        branding.DATA_DIR = self.old_data_dir
        self.temp.cleanup()

    def test_defaults_match_shipped_report_constants(self):
        """Instalace bez personalizace se chová přesně jako před 1.40.0."""
        self.assertEqual(branding.footer(), dict(report_mod.DEFAULT_FOOTER))
        self.assertEqual(branding.approved_by(), report_mod.DEFAULT_APPROVED_BY)
        self.assertTrue(branding.get()["is_default"])

    def test_settings_live_only_under_data(self):
        branding.save({"issuer": {"company": "Vibro Diagnostika s.r.o."}})
        written = sorted(p.relative_to(self.data).as_posix()
                         for p in self.data.rglob("*") if p.is_file())
        self.assertEqual(written, ["branding/settings.json"])

    def test_blank_field_falls_back_to_default_never_empty_footer(self):
        branding.save({"issuer": {"company": "  ", "web": "www.vibro.cz"}})
        foot = branding.footer()
        self.assertEqual(foot["company"], report_mod.DEFAULT_FOOTER["company"])
        self.assertEqual(foot["web"], "www.vibro.cz")

    def test_control_characters_and_length_are_normalised(self):
        branding.save({"issuer": {"company": "Vibro\r\n\tdiag" + "x" * 400}})
        company = branding.footer()["company"]
        self.assertNotIn("\n", company)
        self.assertNotIn("\t", company)
        self.assertTrue(company.startswith("Vibro diag"))
        self.assertLessEqual(len(company), 120)

    def test_settings_saved_with_utf8_bom_are_still_honoured(self):
        """Poznámkový blok i některé synchronizace přidají BOM.

        Bez tolerance BOM by se personalizace tiše vrátila na výchozí hodnoty
        a zákazník by v protokolu znovu uviděl dodavatele.
        """
        branding.save({"issuer": {"company": "Vibro Diagnostika s.r.o."}})
        path = self.data / "branding" / "settings.json"
        path.write_bytes(b"\xef\xbb\xbf" + path.read_bytes())
        self.assertEqual(branding.footer()["company"], "Vibro Diagnostika s.r.o.")

    def test_settings_written_by_hads_never_contain_a_bom(self):
        branding.save({"issuer": {"company": "Vibro Diagnostika s.r.o."}})
        self.assertFalse((self.data / "branding" / "settings.json")
                         .read_bytes().startswith(b"\xef\xbb\xbf"))

    def test_corrupt_settings_file_never_breaks_report_generation(self):
        (self.data / "branding").mkdir()
        (self.data / "branding" / "settings.json").write_text("{ tohle není JSON",
                                                              encoding="utf-8")
        self.assertEqual(branding.footer(), dict(report_mod.DEFAULT_FOOTER))

    def test_reset_restores_defaults_but_keeps_logo(self):
        branding.save({"issuer": {"company": "Vibro Diagnostika s.r.o."}})
        branding.save_logo(_data_url(_jpeg()))
        branding.reset()
        self.assertTrue(branding.get()["is_default"])
        self.assertEqual(branding.get()["logo"]["source"], "custom")


class BrandingLogoValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads-branding-logo-")
        self.data = Path(self.temp.name) / "data"
        self.data.mkdir()
        self.old_data_dir = branding.DATA_DIR
        branding.DATA_DIR = self.data

    def tearDown(self):
        branding.DATA_DIR = self.old_data_dir
        self.temp.cleanup()

    def test_valid_jpeg_is_stored_and_reported(self):
        rec = branding.save_logo(_data_url(_jpeg(240, 60)))
        self.assertEqual(rec["logo"]["source"], "custom")
        self.assertEqual((rec["logo"]["width"], rec["logo"]["height"]), (240, 60))
        self.assertEqual(branding.logo_bytes(), _jpeg(240, 60))

    def test_non_jpeg_payloads_are_rejected_with_czech_reason(self):
        png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 40
        cases = [
            (_data_url(png, "image/png"), "JPEG"),
            (_data_url(png), "JPEG"),                      # lživý mime typ
            ("nejsem data url", "formátu"),
            (_data_url(b""), "prázdný"),
        ]
        for payload, fragment in cases:
            with self.subTest(fragment=fragment):
                with self.assertRaises(ValueError) as ctx:
                    branding.save_logo(payload)
                self.assertIn(fragment, str(ctx.exception))

    def test_cmyk_and_oversized_logos_are_rejected(self):
        with self.assertRaises(ValueError):
            branding.save_logo(_data_url(_jpeg(components=4)))
        with self.assertRaises(ValueError):
            branding.save_logo(_data_url(b"\xff\xd8" + b"\x00" * (branding.MAX_LOGO_BYTES + 1)))

    def test_rejected_upload_keeps_previous_logo(self):
        branding.save_logo(_data_url(_jpeg(200, 50)))
        with self.assertRaises(ValueError):
            branding.save_logo(_data_url(b"rozbite"))
        self.assertEqual(branding.logo_bytes(), _jpeg(200, 50))

    def test_logo_stays_small_enough_for_the_updater_backup(self):
        """Aktualizátor zálohuje jen soubory do 10 MB (CONFIG_BACKUP_MAX_BYTES)."""
        self.assertLessEqual(branding.MAX_LOGO_BYTES, 10 * 1024 * 1024)

    def test_delete_falls_back_to_builtin_logo(self):
        branding.save_logo(_data_url(_jpeg()))
        rec = branding.delete_logo()
        self.assertNotEqual(rec["logo"]["source"], "custom")
        self.assertEqual(branding.logo_bytes(), branding._builtin_logo_bytes())


class BrandingInReportsTests(unittest.TestCase):
    """Vykreslení musí brát aktuální personalizaci, ne hodnotu uloženou v návrhu."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads-branding-report-")
        self.data = Path(self.temp.name) / "data"
        self.data.mkdir()
        self.old_data_dir = branding.DATA_DIR
        branding.DATA_DIR = self.data
        branding.save({"issuer": {
            "company": "Vibro Diagnostika s.r.o.",
            "address": "Nádražní 5, 100 00 Praha",
            "web": "www.vibrodiagnostika.cz",
            "brand": "VIBRODIAG",
        }})
        # Historický návrh nese ještě starou patičku dodanou s programem.
        self.doc = {
            "report_title": "Zpráva z měření vibrací",
            "header_left": "Vibrační diagnostika",
            "company_name": "Zákazník a.s.",
            "footer": dict(report_mod.DEFAULT_FOOTER),
            "report_version": 1,
            "machines": [],
            "intro": "Úvod.",
            "used_norms": [],
        }

    def tearDown(self):
        branding.DATA_DIR = self.old_data_dir
        self.temp.cleanup()

    def test_pdf_footer_uses_current_branding_not_stored_draft(self):
        values = report_pdf._footer_values(self.doc)
        self.assertEqual(values["company"], "Vibro Diagnostika s.r.o.")
        self.assertEqual(values["web"], "www.vibrodiagnostika.cz")
        self.assertEqual(values["brand"], "VIBRODIAG")

    def test_docx_footer_uses_current_branding_and_renders(self):
        self.assertEqual(report_docx._footer_values(self.doc)["company"],
                         "Vibro Diagnostika s.r.o.")
        blob = report_docx.render(self.doc)
        with zipfile.ZipFile(io.BytesIO(blob)) as archive:
            footer = "".join(archive.read(name).decode("utf-8")
                             for name in archive.namelist()
                             if name.startswith("word/footer"))
        self.assertIn("Vibro Diagnostika s.r.o.", footer)
        self.assertNotIn(report_mod.DEFAULT_FOOTER["company"], footer)

    def test_custom_logo_is_embedded_in_pdf_output(self):
        branding.save_logo(_data_url(_jpeg(300, 80)))
        blob = report_pdf.render(self.doc)
        self.assertIn(_jpeg(300, 80), blob)

    def test_new_draft_seeds_footer_and_approver_from_branding(self):
        branding.save({"issuer": {"company": "Vibro Diagnostika s.r.o.",
                                  "approved_by": "Ing. Jan Novák"}})
        self.assertEqual(report_mod.issuer_footer()["company"],
                         "Vibro Diagnostika s.r.o.")
        self.assertEqual(report_mod.issuer_approved_by(), "Ing. Jan Novák")


class BrandingIsProtectedDataTests(unittest.TestCase):
    """Aktualizace nesmí personalizaci ztratit: musí být v inventáři data/."""

    def test_data_protection_inventory_covers_branding_files(self):
        import data_protection

        with tempfile.TemporaryDirectory(prefix="hads-branding-guard-") as temp:
            install = Path(temp)
            logo_dir = install / "data" / "branding"
            logo_dir.mkdir(parents=True)
            (logo_dir / "settings.json").write_text(
                json.dumps({"issuer": {"company": "Vibro"}}), encoding="utf-8")
            (logo_dir / "logo.jpg").write_bytes(_jpeg())
            files = data_protection.inventory(install)["files"]
        self.assertIn("data/branding/settings.json", files)
        self.assertIn("data/branding/logo.jpg", files)

    def test_persistence_registry_advertises_branding(self):
        import data_store

        globals_listed = data_store.persistence_registry()["global"]
        self.assertIn("branding/settings.json", globals_listed)
        self.assertIn("branding/logo.jpg", globals_listed)


if __name__ == "__main__":
    unittest.main()
