# -*- coding: utf-8 -*-
"""Regrese relace konceptu protokolu: navigace, kontext a závody autosave."""

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

import data_store  # noqa: E402
import report_store  # noqa: E402


class ReportDraftStoreContextTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_data = data_store._DATA_DIR
        self.old_podniky = data_store._PODNIKY_DIR
        data_store._DATA_DIR = Path(self.temp.name) / "data"
        data_store._PODNIKY_DIR = data_store._DATA_DIR / "podniky"

    def tearDown(self):
        data_store._DATA_DIR = self.old_data
        data_store._PODNIKY_DIR = self.old_podniky
        self.temp.cleanup()

    def test_contexts_do_not_leak_between_databases_or_companies(self):
        report_store.save_draft(
            "podnik:Moravia Cans 104", {"report_title": "A"},
            "Moravia-Cans-104-ranní.ndb")
        report_store.save_draft(
            "podnik:Moravia Cans 104", {"report_title": "B"},
            "Moravia-Cans-104-odpolední.ndb")
        report_store.save_draft(
            "podnik:Jiný podnik", {"report_title": "C"}, "stejny-nazev.ndb")
        report_store.save_draft(
            "podnik:Moravia Cans 104", {"report_title": "D"}, "stejny-nazev.ndb")

        self.assertEqual(
            report_store.get_draft("podnik:Moravia Cans 104",
                                   "Moravia-Cans-104-ranní.ndb")["report_title"], "A")
        self.assertEqual(
            report_store.get_draft("podnik:Moravia Cans 104",
                                   "Moravia-Cans-104-odpolední.ndb")["report_title"], "B")
        self.assertEqual(
            report_store.get_draft("podnik:Jiný podnik", "stejny-nazev.ndb")["report_title"], "C")
        self.assertEqual(
            report_store.get_draft("podnik:Moravia Cans 104",
                                   "stejny-nazev.ndb")["report_title"], "D")
        self.assertIsNone(report_store.get_draft(
            "podnik:Moravia Cans 104", "neexistující-export.ndb"))

    def test_late_autosave_cannot_replace_newer_same_session_revision(self):
        context = "Moravia-Cans-104.ndb"
        newer = {
            "intro": "novější rozepsaný úvod", "_draft_session_id": "session-1",
            "_draft_revision": 8,
        }
        older = {
            "intro": "starý síťový požadavek", "_draft_session_id": "session-1",
            "_draft_revision": 7,
        }
        report_store.save_draft("podnik:Moravia", newer, context)
        returned = report_store.save_draft("podnik:Moravia", older, context)
        self.assertEqual(returned["intro"], newer["intro"])
        self.assertEqual(
            report_store.get_draft("podnik:Moravia", context)["intro"], newer["intro"])

    def test_existing_single_draft_remains_readable_until_first_context_save(self):
        data_store.save(report_store._KIND, "podnik:Legacy", {"intro": "starý koncept"})
        self.assertEqual(
            report_store.get_draft("podnik:Legacy", "legacy.ndb")["intro"], "starý koncept")
        report_store.save_draft("podnik:Legacy", {"intro": "nový koncept"}, "legacy.ndb")
        raw = data_store.load(report_store._KIND, "podnik:Legacy")
        self.assertEqual(raw["format"], 2)
        self.assertEqual(raw["drafts"]["legacy.ndb"]["intro"], "nový koncept")


class FrontendReportDraftSessionTests(unittest.TestCase):
    def test_node_regression_for_navigation_context_and_stale_response(self):
        test_file = ROOT / "tests" / "test_report_draft_session_frontend.js"
        result = subprocess.run(
            ["node", str(test_file)], cwd=ROOT, text=True, capture_output=True,
            encoding="utf-8", errors="replace", timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
