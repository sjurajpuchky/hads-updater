# -*- coding: utf-8 -*-
"""Regrese 1.39.0: kanonický per-direction výběr protokolu."""
import copy
import io
import os
import shutil
import subprocess
import tempfile
import sys
import unittest
import zipfile

ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, os.path.join(ROOT, "backend"))
import report
import report_refresh
import report_pdf
import report_docx
import ai_eval

Q = {"velocity": "ISO RMS", "accel": "ACC", "env": "ENV"}

class Db:
    def __init__(self): self.trends, self.machine_list = {}, []
    def trend(self, cid): return list(self.trends.get(cid, []))
    def machines(self, overrides=None): return {"machines": self.machine_list}

def point(t, value, order=0): return {"t": t, "value": value, "_order": (order, 0)}

def make_ventilator(db):
    points = [{"id": 1, "name": "L4H", "direction": "H"},
              {"id": 2, "name": "L4V", "direction": "V"},
              {"id": 3, "name": "L4A", "direction": "A"}]
    # Každý směr má vlastní čas. Přesně reprodukuje hlášený případ: H=1.59
    # je novější než A=1.33; stará shared-time logika tak mohla vybrat jen A.
    values = {
      "ISO RMS": [
        [("2026-08-18T13:38:16", 1.59), ("2026-08-17T10:01:00", 1.12)],
        [("2026-08-18T13:36:10", 1.20), ("2026-08-17T10:00:00", 1.10)],
        [("2026-08-18T13:37:02", 1.33), ("2026-08-17T09:59:00", 1.05)],
      ],
      "ACC": [
        [("2026-08-18T13:38:16", 0.10)],
        [("2026-08-18T13:36:10", 0.42)],
        [("2026-08-18T13:37:02", 0.18)],
      ],
      "ENV": [
        [("2026-08-18T13:38:16", 0.04)],
        [("2026-08-18T13:36:10", 0.03)],
        [("2026-08-18T13:37:02", 0.55)],
      ],
    }
    quantities=[]
    for qi, (name, per_direction) in enumerate(values.items()):
        cells=[]
        for di, samples in enumerate(per_direction):
            cid=100+qi*10+di
            db.trends[cid] = [point(t, v, i) for i, (t, v) in enumerate(reversed(samples))]
            cells.append({"cell_id": cid, "point_id": points[di]["id"]})
        quantities.append({"name":name,"cells":cells,"warning":1.4,"alarm":2.0,"ab":0.7,"classify":True})
    bearing={"bearing_key":"L4","label":"L4","points":points,"quantities":quantities,"bearing":{},"classify":True}
    machine={"id":7,"name":"ventilátor30","parent_name":"Podnik","speed_hz":None,"iso_norm":None,"card":{},"bearings":[bearing]}
    db.machine_list=[machine]
    return machine

class DirectionSelectionTests(unittest.TestCase):
    def setUp(self):
        self.db=Db(); self.machine=make_ventilator(self.db)

    def build(self, selection=None):
        return report.build_machine_report(self.db, self.machine, {}, qmap=Q,
                                           measurement_selection=selection)

    def test_ventilator30_l4_latest_per_direction_wins_h_159_everywhere(self):
        rep=self.build()
        row, bearing=rep["rows"][0], rep["bearings_summary"][0]
        self.assertEqual((row["vel_cur"], row["direction"]), (1.59, "H"))
        # Zrychlení a obálka se berou pouze z H, i když je V/A vyšší.
        self.assertEqual((bearing["acc_cur"], bearing["acc_dir"]), (0.10, "H"))
        self.assertEqual((bearing["env_cur"], bearing["env_dir"]), (0.04, "H"))
        selected = bearing["measurement_selection"]
        self.assertEqual(selected["schema"], 2)
        self.assertEqual(selected["current"]["H"], "H|2026-08-18T13:38:16#1")
        self.assertEqual(selected["current"]["A"], "A|2026-08-18T13:37:02#1")
        self.assertEqual(bearing["measurement_selection_audit"]["current"]["H"]["time"],
                         "2026-08-18T13:38:16")
        context=report.report_measurement_context(rep)
        self.assertIn("rychlost 1.59 mm/s (H)", context)
        prompt=ai_eval.build_brief_prompt({}, None, None,
            canonical_report_context=context, use_examples=False)[1]
        self.assertIn("rychlost 1.59 mm/s (H)", prompt)
        doc={"machines":[copy.deepcopy(rep)], "report_version":2,
             "show_previous":True, "footer":dict(report.DEFAULT_FOOTER),"used_norms":[]}
        xml=zipfile.ZipFile(io.BytesIO(report_docx.render(copy.deepcopy(doc)))).read("word/document.xml").decode()
        self.assertIn("1,59 (H)", xml)
        self.assertIn("zrychlení a obálka pouze z H", xml)
        pdftotext = shutil.which("pdftotext")
        if pdftotext:
            with tempfile.TemporaryDirectory() as td:
                path=os.path.join(td, "report.pdf")
                with open(path, "wb") as handle: handle.write(report_pdf.render(copy.deepcopy(doc)))
                text=subprocess.run([pdftotext, path, "-"], check=True, capture_output=True).stdout.decode("utf-8")
            self.assertIn("1,59 (H)", text)
            self.assertIn("zrychlen", text)

    def test_changing_only_h_changes_preview_and_can_change_winner(self):
        selected={"L4":{"schema":2,
          "current":{"H":"H|2026-08-17T10:01:00#1"}, "previous":{}}}
        rep=self.build(selected)
        row=rep["rows"][0]; direction=rep["bearings_summary"][0]["measurement_directions"]["H"]
        self.assertEqual((row["vel_cur"], row["direction"]), (1.33, "A"))
        self.assertEqual(direction["current_preview"]["ISO RMS"], 1.12)
        self.assertEqual(direction["previous_id"], "")

    def test_options_have_exact_czech_time_values_and_same_time_ordinals(self):
        # Druhý H vzorek se stejným TimeFrom zůstane samostatně volitelný.
        self.db.trends[100].append(point("2026-08-18T13:38:16", 1.58, 9))
        rep=self.build()
        opts=rep["bearings_summary"][0]["measurement_directions"]["H"]["options"]
        labels=[o["label"] for o in opts]
        self.assertTrue(any("18. 8. 2026 13:38:16" in label and "R 1,59 mm/s" in label for label in labels))
        self.assertEqual(len([o for o in opts if o["time"] == "2026-08-18T13:38:16"]), 2)
        self.assertTrue(any(o["id"].endswith("#2") for o in opts))

    def test_previous_is_per_direction_and_none_does_not_affect_current(self):
        rep=self.build({"L4":{"schema":2, "current":{}, "previous":{"H":"__none__"}}})
        row=rep["rows"][0]
        self.assertEqual((row["vel_cur"], row["direction"]), (1.59, "H"))
        self.assertEqual((row["vel_prev"], row["vel_prev_dir"]), (1.10, "V"))
        self.assertEqual(rep["bearings_summary"][0]["measurement_selection"]["previous"]["H"], "__none__")

    def test_previous_never_accepts_current_or_future_occurrence(self):
        rep=self.build({"L4":{"schema":2,
            "current":{"H":"H|2026-08-17T10:01:00#1"},
            # This is later than the selected current H and must not become
            # a false "comparison" measurement.
            "previous":{"H":"H|2026-08-18T13:38:16#1"}}})
        direction=rep["bearings_summary"][0]["measurement_directions"]["H"]
        self.assertEqual(direction["previous_id"], "")
        self.assertEqual(direction["previous_options"], [])
        self.assertIn("H", rep["bearings_summary"][0]["measurement_fallback_directions"])

    def test_old_shared_id_migrates_only_provable_direction_and_missing_falls_back(self):
        rep=self.build({"L4":{"current_id":"2026-08-18T13:38:16#1"}})
        b=rep["bearings_summary"][0]
        self.assertTrue(b["measurement_migration_notice"])
        self.assertEqual(b["measurement_selection"]["current"]["H"], "H|2026-08-18T13:38:16#1")
        self.assertEqual(b["measurement_selection"]["current"]["A"], "A|2026-08-18T13:37:02#1")
        stale={"L4":{"schema":2, "current":{"H":"H|gone#1"}, "previous":{}}}
        fallback=self.build(stale)["bearings_summary"][0]
        self.assertEqual(fallback["measurement_fallback_directions"], ["H"])
        self.assertEqual(fallback["measurement_selection"]["current"]["H"], "H|2026-08-18T13:38:16#1")

    def test_refresh_keeps_schema_selection_and_canonical_result(self):
        selection={"L4":{"schema":2,"current":{"H":"H|2026-08-17T10:01:00#1"},"previous":{}}}
        before=self.build(selection)
        doc={"machines":[copy.deepcopy(before)],"scope":{"mode":"all"},"report_version":2,"show_previous":False}
        refreshed,_=report_refresh.refresh_report_draft(self.db, doc, {}, qmap=Q)
        after=refreshed["machines"][0]
        self.assertEqual(after["rows"][0]["vel_cur"], 1.33)
        self.assertEqual(after["measurement_selection_schema"], 2)
        self.assertEqual(after["measurement_selection"]["L4"]["current"]["H"], "H|2026-08-17T10:01:00#1")

if __name__ == "__main__": unittest.main(verbosity=2)
