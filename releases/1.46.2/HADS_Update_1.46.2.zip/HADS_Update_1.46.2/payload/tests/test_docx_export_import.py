"""
Testy pro DOCX export/import (HADS v1.31.0).

Pokrývá:
  - platnost generovaného OOXML (.docx) — všechny XML části musí být
    dobře formované a archiv musí obsahovat povinné části
  - vizuální/obsahovou konzistenci mezi report_pdf.py a report_docx.py
    (společné vstupní údaje se musí objevit v obou výstupech)
  - bezpečnost tagovaného importu: lze importovat POUZE pole
    `zaver` / `doporuceni`, NIKDY technické/naměřené hodnoty
  - podporu rozděleného textu přes více <w:t> run (jak to dělá Word
    po ručních úpravách) při zpětné extrakci
  - odolnost vůči poškozeným / neplatným / neotagovaným souborům
  - two-step workflow (preview → selective apply), žádné automatické
    zapsání beze zvolení uživatele

Spusťte samostatně:
    python3 -m pytest tests/test_docx_export_import.py -v
nebo bez pytest:
    python3 tests/test_docx_export_import.py
"""
import copy
import io
import json
import os
import sys
import unittest
import xml.dom.minidom
import zipfile

BACKEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backend")
sys.path.insert(0, BACKEND_DIR)

import docx_writer as dw          # noqa: E402
import report_docx                # noqa: E402
import docx_import                # noqa: E402

FIXTURE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixture_doc.json")


def load_fixture_doc():
    with open(FIXTURE_PATH, encoding="utf-8") as f:
        return json.load(f)


REQUIRED_DOCX_PARTS = {
    "[Content_Types].xml",
    "_rels/.rels",
    "docProps/core.xml",
    "docProps/app.xml",
    "word/document.xml",
    "word/styles.xml",
    "word/_rels/document.xml.rels",
}


class DocxWriterLowLevelTests(unittest.TestCase):
    """Testy samotného stdlib OOXML generátoru (docx_writer.py)."""

    def test_minimal_document_is_valid_zip_with_required_parts(self):
        doc = dw.DocxDocument()
        doc.add_paragraph([dw.Run("Ahoj světe")])
        data = doc.save_bytes()
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = set(z.namelist())
            missing = REQUIRED_DOCX_PARTS - names
            self.assertFalse(missing, "Chybí povinné části DOCX: %s" % missing)

    def test_all_xml_parts_are_well_formed(self):
        doc = dw.DocxDocument()
        doc.add_paragraph([dw.Run("Test", bold=True)])
        table = dw.Table(
            rows=[dw.Row([dw.Cell([dw.Paragraph([dw.Run("A")])]),
                          dw.Cell([dw.Paragraph([dw.Run("B")])])])],
        )
        doc.add_table(table)
        data = doc.save_bytes()
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for name in z.namelist():
                if name.endswith(".xml") or name.endswith(".rels"):
                    content = z.read(name)
                    try:
                        xml.dom.minidom.parseString(content)
                    except Exception as e:
                        self.fail("XML část %s není dobře formovaná: %s" % (name, e))

    def test_hidden_tag_run_is_vanish_and_invisible_color(self):
        run = dw.hidden_tag("[[HADS:zaver:123:START]]")
        run_xml = run.to_xml()
        # skrytý běh musí obsahovat w:vanish (skryté ve Wordu) a bílou barvu
        self.assertIn("vanish", run_xml)
        self.assertIn("FFFFFF", run_xml)
        self.assertIn("[[HADS:zaver:123:START]]", run_xml)
        self.assertTrue(run.hidden)

    def test_document_roundtrips_through_libreoffice_if_available(self):
        """Pokud je k dispozici LibreOffice, ověří že DOCX lze skutečně otevřít
        (konverze do PDF headless) – jen QA, netestuje obsah."""
        import shutil
        import subprocess
        import tempfile

        soffice = shutil.which("soffice") or shutil.which("libreoffice")
        if not soffice:
            self.skipTest("LibreOffice není v sandboxu k dispozici – přeskočeno.")
        doc = dw.DocxDocument()
        doc.add_paragraph([dw.Run("QA test dokument")])
        data = doc.save_bytes()
        with tempfile.TemporaryDirectory() as td:
            docx_path = os.path.join(td, "t.docx")
            with open(docx_path, "wb") as f:
                f.write(data)
            r = subprocess.run(
                [soffice, "--headless", "--convert-to", "pdf", "--outdir", td, docx_path],
                capture_output=True, timeout=60,
            )
            self.assertEqual(r.returncode, 0, r.stderr.decode(errors="replace"))
            self.assertTrue(os.path.exists(os.path.join(td, "t.pdf")))


class ReportDocxRenderTests(unittest.TestCase):
    """Testy report_docx.render(doc) — mirror návrhu PDF."""

    def test_render_produces_valid_docx_for_each_report_version(self):
        base_doc = load_fixture_doc()
        for version in (1, 2, 3):
            doc = copy.deepcopy(base_doc)
            doc["report_version"] = version
            data = report_docx.render(doc)
            self.assertIsInstance(data, bytes)
            self.assertGreater(len(data), 1000)
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                names = set(z.namelist())
                self.assertFalse(REQUIRED_DOCX_PARTS - names)
                xml_content = z.read("word/document.xml")
                xml.dom.minidom.parseString(xml_content)  # musí být well-formed

    def test_render_contains_company_and_machine_identifying_text(self):
        doc = load_fixture_doc()
        data = report_docx.render(doc)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            xml_text = z.read("word/document.xml").decode("utf-8")
        for m in doc["machines"]:
            self.assertIn(m["name"], xml_text)
        if doc.get("company_name"):
            self.assertIn(doc["company_name"], xml_text)

    def test_render_embeds_hidden_tags_for_zaver_and_doporuceni(self):
        doc = load_fixture_doc()
        doc["report_version"] = 2
        for m in doc["machines"]:
            m["zaver"] = "Jedinečný testovací závěr XYZ123"
            m["doporuceni"] = "Jedinečné testovací doporučení ABC456"
        data = report_docx.render(doc)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            xml_text = z.read("word/document.xml").decode("utf-8")
        for m in doc["machines"]:
            mid = m["machine_id"]
            self.assertIn("[[HADS:zaver:%s:START]]" % mid, xml_text)
            self.assertIn("[[HADS:zaver:%s:END]]" % mid, xml_text)
            self.assertIn("[[HADS:doporuceni:%s:START]]" % mid, xml_text)
            self.assertIn("[[HADS:doporuceni:%s:END]]" % mid, xml_text)

    def test_empty_conclusion_shows_placeholder_outside_tags(self):
        doc = load_fixture_doc()
        doc["report_version"] = 2
        for m in doc["machines"]:
            m["zaver"] = ""
            m["doporuceni"] = ""
        data = report_docx.render(doc)
        preview, _ = docx_import.extract_preview(data, doc)
        # prázdná pole se nesmí naimportovat jako "placeholder" text
        for item in preview:
            self.assertNotIn("bez textu", item["new_text"])
            self.assertNotIn("doplňte", item["new_text"])


class DocxImportSafetyTests(unittest.TestCase):
    """Kritické bezpečnostní testy: import smí číst POUZE zaver/doporuceni."""

    def setUp(self):
        self.doc = load_fixture_doc()
        self.doc["report_version"] = 2
        for i, m in enumerate(self.doc["machines"]):
            m["zaver"] = "Původní závěr stroje %d." % i
            m["doporuceni"] = "Původní doporučení stroje %d." % i
        self.docx_bytes = report_docx.render(self.doc)

    def test_extract_tagged_fields_only_returns_zaver_and_doporuceni(self):
        fields = docx_import.extract_tagged_fields(self.docx_bytes)
        for (machine_id, field) in fields.keys():
            self.assertIn(field, ("zaver", "doporuceni"))

    def test_preview_recovers_original_text_unchanged(self):
        items, summary = docx_import.extract_preview(self.docx_bytes, self.doc)
        self.assertEqual(summary["matched_count"], len(self.doc["machines"]) * 2)
        self.assertEqual(summary["changed_count"], 0)
        for it in items:
            self.assertFalse(it["changed"])
            self.assertTrue(it["matched"])

    def test_preview_never_writes_to_current_doc(self):
        doc_before = copy.deepcopy(self.doc)
        docx_import.extract_preview(self.docx_bytes, self.doc)
        self.assertEqual(self.doc, doc_before, "extract_preview nesmí měnit doc (jen náhled)")

    def test_apply_selected_only_touches_selected_keys(self):
        items, _ = docx_import.extract_preview(self.docx_bytes, self.doc)
        # simuluj, že by import obsahoval upravený text (jinak by "changed"=False)
        for it in items:
            it["new_text"] = it["new_text"] + " EDIT"
        mid0 = str(self.doc["machines"][0]["machine_id"])
        selected = [mid0 + "|zaver"]
        new_doc, applied = docx_import.apply_selected(self.doc, items, selected)
        self.assertEqual(applied, 1)
        self.assertTrue(new_doc["machines"][0]["zaver"].endswith("EDIT"))
        # nevybrané pole téhož stroje se NESMÍ změnit
        self.assertFalse(new_doc["machines"][0]["doporuceni"].endswith("EDIT"))
        # ani druhý stroj
        self.assertFalse(new_doc["machines"][1]["zaver"].endswith("EDIT"))
        self.assertFalse(new_doc["machines"][1]["doporuceni"].endswith("EDIT"))

    def test_apply_selected_never_touches_technical_values(self):
        """Kritický bezpečnostní test: technické/naměřené hodnoty (rows,
        bearings_summary, band, dates, limity) se import NIKDY nesmí dotknout,
        i když jsou vybrány všechny klíče."""
        doc = self.doc
        # zapamatuj si "otisk" všech technických polí před importem
        tech_snapshot = json.dumps(
            [{k: v for k, v in m.items() if k not in ("zaver", "doporuceni")}
             for m in doc["machines"]],
            sort_keys=True, default=str,
        )
        items, _ = docx_import.extract_preview(self.docx_bytes, doc)
        for it in items:
            it["new_text"] = "ZMĒNĒNO PRO TEST"
        all_keys = [it["machine_id"] + "|" + it["field"] for it in items]
        # pro jistotu i pár "podvržených" klíčů mimo povolená pole – apply_selected
        # je musí ignorovat, protože jsou hardcoded jen na zaver/doporuceni
        all_keys += [str(doc["machines"][0]["machine_id"]) + "|rows",
                     str(doc["machines"][0]["machine_id"]) + "|bearings_summary",
                     str(doc["machines"][0]["machine_id"]) + "|date_measured"]
        new_doc, applied = docx_import.apply_selected(doc, items, all_keys)
        tech_snapshot_after = json.dumps(
            [{k: v for k, v in m.items() if k not in ("zaver", "doporuceni")}
             for m in new_doc["machines"]],
            sort_keys=True, default=str,
        )
        self.assertEqual(tech_snapshot, tech_snapshot_after,
                          "Technické/naměřené hodnoty se změnily po importu z DOCX!")
        # ale zaver/doporuceni se změnit MĒLY (byly vybrané a validní)
        for m in new_doc["machines"]:
            self.assertEqual(m["zaver"], "ZMĒNĒNO PRO TEST")
            self.assertEqual(m["doporuceni"], "ZMĒNĒNO PRO TEST")

    def test_apply_selected_ignores_keys_not_in_items(self):
        """Klíč, který neodpovídá žádné položce z preview (např. vymyšlený
        podvržený klíč), nesmí nic zapsat."""
        items, _ = docx_import.extract_preview(self.docx_bytes, self.doc)
        new_doc, applied = docx_import.apply_selected(
            self.doc, items, ["999999|zaver", "999999|doporuceni"])
        self.assertEqual(applied, 0)
        self.assertEqual(new_doc, self.doc)

    def test_unmatched_machine_id_is_flagged_not_applied(self):
        doc_missing_machine = copy.deepcopy(self.doc)
        doc_missing_machine["machines"] = doc_missing_machine["machines"][:1]  # odeber jeden stroj
        items, summary = docx_import.extract_preview(self.docx_bytes, doc_missing_machine)
        self.assertTrue(len(summary["unmatched"]) >= 1)
        unmatched_items = [it for it in items if not it["matched"]]
        self.assertTrue(len(unmatched_items) >= 2)  # zaver + doporuceni daného stroje
        # apply_selected nesmí nic udělat, ani kdyby to bylo "vybráno"
        keys = [it["machine_id"] + "|" + it["field"] for it in unmatched_items]
        new_doc, applied = docx_import.apply_selected(doc_missing_machine, items, keys)
        self.assertEqual(applied, 0)


class DocxImportSplitRunTests(unittest.TestCase):
    """Word po ručních úpravách běžně rozdělí text do více <w:t> run uvnitř
    jednoho <w:p>. Import to musí správně sloučit zpět."""

    def setUp(self):
        self.doc = load_fixture_doc()
        self.doc["report_version"] = 2
        self.docx_bytes = report_docx.render(self.doc)

    def _replace_document_xml(self, transform):
        with zipfile.ZipFile(io.BytesIO(self.docx_bytes)) as zin:
            xml_text = zin.read("word/document.xml").decode("utf-8")
            new_xml = transform(xml_text)
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
                for item in zin.namelist():
                    content = zin.read(item)
                    if item == "word/document.xml":
                        content = new_xml.encode("utf-8")
                    zout.writestr(item, content)
            return buf.getvalue()

    def test_text_split_across_multiple_runs_is_reconstructed(self):
        mid = self.doc["machines"][0]["machine_id"]
        tag_open = "[[HADS:doporuceni:%s:START]]" % mid

        def split_transform(xml_text):
            idx = xml_text.find(tag_open)
            self.assertGreater(idx, -1)
            # najdi následující <w:t>...</w:t> po tagu a rozděl jeho obsah
            # na dva samostatné <w:r><w:t> běhy, jak to typicky dělá Word
            t_start = xml_text.find("<w:t", idx)
            t_open_end = xml_text.find(">", t_start) + 1
            t_close = xml_text.find("</w:t>", t_open_end)
            text = xml_text[t_open_end:t_close]
            if len(text) < 4:
                return xml_text  # nic k rozdělení
            mid_point = len(text) // 2
            part1, part2 = text[:mid_point], text[mid_point:]
            replacement = (
                '<w:r><w:t xml:space="preserve">%s</w:t></w:r>'
                '<w:r><w:t xml:space="preserve">%s</w:t></w:r>' % (part1, part2)
            )
            # nahraď celý <w:r>...<w:t>text</w:t>...</w:r> jen tou částí s textem
            full_t = xml_text[t_start:t_close + len("</w:t>")]
            return xml_text[:t_start] + ('<w:t xml:space="preserve">%s</w:t>' % part1) + \
                "</w:r><w:r>" + ('<w:t xml:space="preserve">%s</w:t>' % part2) + \
                xml_text[t_close + len("</w:t>"):]

        edited_bytes = self._replace_document_xml(split_transform)
        # nesmí spadnout a musí extrahovat neprázdný text pro dané pole
        fields = docx_import.extract_tagged_fields(edited_bytes)
        key = (str(mid), "doporuceni")
        self.assertIn(key, fields)
        self.assertTrue(len(fields[key]) > 0)


class DocxImportErrorHandlingTests(unittest.TestCase):
    """Odolnost proti poškozeným / nevalidním / neotagovaným souborům."""

    def test_non_zip_file_raises_docx_import_error(self):
        with self.assertRaises(docx_import.DocxImportError):
            docx_import.extract_tagged_fields(b"toto neni zip ani docx")

    def test_zip_without_document_xml_raises_docx_import_error(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("hello.txt", "obsah")
        with self.assertRaises(docx_import.DocxImportError):
            docx_import.extract_tagged_fields(buf.getvalue())

    def test_untagged_docx_returns_empty_dict_safely(self):
        doc = dw.DocxDocument()
        doc.add_paragraph([dw.Run("Obyčejný dokument bez značek.")])
        data = doc.save_bytes()
        fields = docx_import.extract_tagged_fields(data)
        self.assertEqual(fields, {})

    def test_preview_on_untagged_docx_reports_zero_tagged(self):
        doc = dw.DocxDocument()
        doc.add_paragraph([dw.Run("Bez značek.")])
        data = doc.save_bytes()
        current_doc = load_fixture_doc()
        items, summary = docx_import.extract_preview(data, current_doc)
        self.assertEqual(summary["tagged_count"], 0)
        self.assertEqual(items, [])


class DocxPreviewApplyWorkflowTests(unittest.TestCase):
    """End-to-end: preview -> selective apply, nikdy automatický zápis."""

    def test_apply_without_calling_preview_first_still_only_applies_provided_items(self):
        """I když volající obejde preview a poskytne vlastní `items`, apply
        smí zapsat jen zaver/doporuceni a jen pro vybrané klíče."""
        doc = load_fixture_doc()
        mid = str(doc["machines"][0]["machine_id"])
        fabricated_items = [
            {"machine_id": mid, "field": "zaver", "new_text": "Vlastní text",
             "matched": True, "changed": True},
            {"machine_id": mid, "field": "doporuceni", "new_text": "Vlastní doporučení",
             "matched": True, "changed": True},
        ]
        new_doc, applied = docx_import.apply_selected(
            doc, fabricated_items, [mid + "|zaver"])
        self.assertEqual(applied, 1)
        self.assertEqual(new_doc["machines"][0]["zaver"], "Vlastní text")
        self.assertNotEqual(new_doc["machines"][0]["doporuceni"], "Vlastní doporučení")

    def test_empty_selection_applies_nothing(self):
        doc = load_fixture_doc()
        items, _ = docx_import.extract_preview(report_docx.render(doc), doc)
        new_doc, applied = docx_import.apply_selected(doc, items, [])
        self.assertEqual(applied, 0)
        self.assertEqual(new_doc, doc)


if __name__ == "__main__":
    unittest.main(verbosity=2)
