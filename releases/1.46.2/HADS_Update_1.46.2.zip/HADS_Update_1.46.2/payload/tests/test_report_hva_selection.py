# -*- coding: utf-8 -*-
"""Kompatibilita 1.37/1.38 shared selection se schématem 2 per H/V/A."""
import copy
import os
import sys
import unittest

ROOT=os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, os.path.join(ROOT, "backend"))
import report
import report_refresh

Q={"velocity":"ISO RMS", "accel":"ACC", "env":"ENV"}
class Db:
    def __init__(self): self.trends={}; self.machine_list=[]
    def trend(self, cell_id): return list(self.trends.get(cell_id, []))
    def machines(self, overrides=None): return {"machines":self.machine_list}
def p(t,v,order=0): return {"t":t,"value":v,"_order":(order,0)}
def machine(db):
    pts=[{"id":1,"name":"L4H","direction":"H"},{"id":2,"name":"L4V","direction":"V"},{"id":3,"name":"L4A","direction":"A"}]
    qs=[]
    for qi,name in enumerate(Q.values()):
        cells=[]
        for di,pt in enumerate(pts):
            cid=100+qi*10+di; cells.append({"cell_id":cid,"point_id":pt["id"]})
            db.trends[cid]=[p("2026-08-20T09:00:00", 1+qi+di),p("2026-08-20T14:30:15", 4+qi+di)]
        qs.append({"name":name,"cells":cells,"warning":3,"alarm":6,"ab":1.5})
    b={"bearing_key":"L4","label":"L4","points":pts,"quantities":qs,"bearing":{}}
    m={"id":7,"name":"Stroj","parent_name":"Podnik","card":{},"bearings":[b]}; db.machine_list=[m]
    return m
class HvaSelectionTests(unittest.TestCase):
    def setUp(self): self.db=Db(); self.m=machine(self.db)
    def build(self, selection=None): return report.build_machine_report(self.db,self.m,{},qmap=Q,measurement_selection=selection)
    def test_legacy_shared_id_is_conservatively_migrated(self):
        rep=self.build({"L4":{"current_id":"2026-08-20T09:00:00#1"}})
        b=rep["bearings_summary"][0]
        self.assertTrue(b["measurement_migration_notice"])
        self.assertEqual(b["measurement_selection"]["schema"],2)
        self.assertEqual(b["measurement_selection"]["current"]["H"],"H|2026-08-20T09:00:00#1")
    def test_duplicate_timestamp_is_stable_within_only_its_direction(self):
        self.db.trends[100].append(p("2026-08-20T14:30:15",90,9))
        rep=self.build(); opts=rep["bearings_summary"][0]["measurement_directions"]["H"]["options"]
        self.assertEqual(len([o for o in opts if o["time"]=="2026-08-20T14:30:15"]),2)
        self.assertTrue(any(o["id"].endswith("#2") for o in opts))
    def test_refresh_preserves_per_direction_ids(self):
        old=self.build({"L4":{"schema":2,"current":{"H":"H|2026-08-20T09:00:00#1"},"previous":{}}})
        doc={"machines":[copy.deepcopy(old)],"scope":{"mode":"all"}}
        new,_=report_refresh.refresh_report_draft(self.db,doc,{},qmap=Q)
        self.assertEqual(new["machines"][0]["measurement_selection"]["L4"]["current"]["H"],"H|2026-08-20T09:00:00#1")
if __name__=="__main__": unittest.main(verbosity=2)
