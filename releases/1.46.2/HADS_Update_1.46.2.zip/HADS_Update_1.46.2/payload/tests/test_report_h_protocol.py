# -*- coding: utf-8 -*-
"""Cílené regresní testy protokolu: rychlost max. H/V/A, ložisko z H.

Rychlost vibrací popisuje chování stroje, proto se bere nejhorší
z vybraných směrů. Zrychlení a obálka popisují stav jednoho ložiska,
proto se od 1.43.0 berou výhradně z horizontálního směru.
"""

import copy
import io
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from html.parser import HTMLParser
from pathlib import Path

BACKEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "backend")
sys.path.insert(0, BACKEND_DIR)

import report  # noqa: E402
import report_docx  # noqa: E402
import report_pdf  # noqa: E402
import report_refresh  # noqa: E402
from ndb_parser import bearing_key  # noqa: E402


QMAP = {"velocity": "VEL PROTOKOL", "accel": "ACC PROTOKOL",
        "env": "ENV PROTOKOL"}
_TS = "2026-08-01T10:00:00"


class FakeDb:
    """Malé deterministické DB rozhraní použitelné pro build i refresh."""

    def __init__(self):
        self.trends = {}
        self.machine_list = []

    def trend(self, cell_id):
        return list(self.trends.get(cell_id, []))

    def machines(self, overrides=None):
        return {"machines": self.machine_list}


def _add_value(db, cell_id, value, previous=None):
    if value is None:
        return
    pts = []
    if previous is not None:
        pts.append({"t": "2026-07-01T10:00:00", "value": previous})
    pts.append({"t": _TS, "value": value})
    db.trends[cell_id] = pts


def _bearing(db, label, base, values, include_h=True, extras=None):
    """Sestaví ložisko H/V/A; `values` je {název: {H,V,A: hodnota}}."""
    points = [
        {"id": base + 1, "name": label + "H", "direction": "H"},
        {"id": base + 2, "name": label + "V", "direction": "V"},
        {"id": base + 3, "name": label + "A", "direction": "A"},
    ]
    quantities = []
    cell_seed = base * 100
    for qi, (name, by_dir) in enumerate((values or {}).items()):
        cells = []
        ids = []
        for di, point in enumerate(points):
            direction = point["direction"]
            value = by_dir.get(direction)
            # include_h=False modeluje chybějící H; V/A zůstávají platnými
            # kandidáty pro novou max. H/V/A sémantiku.
            if value is None or (direction == "H" and not include_h):
                continue
            cid = cell_seed + qi * 10 + di
            _add_value(db, cid, value, previous=(value / 2.0
                                                  if name == "VEL PROTOKOL"
                                                  else None))
            cells.append({"cell_id": cid, "point_id": point["id"],
                          "direction": direction})
            ids.append(cid)
        quantities.append({
            "name": name, "cell_ids": ids, "cells": cells,
            "warning": 2.0, "alarm": 4.0, "ab": 1.0, "classify": True,
        })
    for qi, (name, by_dir) in enumerate((extras or {}).items(), start=20):
        cells = []
        for di, point in enumerate(points):
            value = by_dir.get(point["direction"])
            if value is None:
                continue
            cid = cell_seed + qi * 10 + di
            _add_value(db, cid, value)
            cells.append({"cell_id": cid, "point_id": point["id"]})
        quantities.append({
            "name": name, "cells": cells, "warning": 2.0, "alarm": 4.0,
            "ab": 1.0, "classify": True,
        })
    return {
        "bearing_key": label, "label": label, "points": points,
        "quantities": quantities, "bearing": {}, "classify": True,
    }


def _machine(*bearings):
    return {
        "id": 10, "name": "Testovací stroj", "parent_name": "Test",
        "speed_hz": None, "iso_norm": None, "card": {}, "bearings": list(bearings),
    }


class ProtocolHvaSemanticsTests(unittest.TestCase):
    def _report(self, bearing):
        db = FakeDb()
        # Pomocník je volán s db vytvořeným uvnitř jen kvůli čitelnosti testů.
        raise AssertionError("Použijte _build()")

    @staticmethod
    def _build(values, extras=None, include_h=True, more_bearings=None):
        db = FakeDb()
        bearings = [_bearing(db, "L1", 100, values, include_h=include_h,
                             extras=extras)]
        for spec in more_bearings or []:
            bearings.append(_bearing(db, *spec))
        machine = _machine(*bearings)
        db.machine_list = [machine]
        return db, machine, report.build_machine_report(db, machine, {}, qmap=QMAP)

    def test_velocity_takes_worst_direction_but_bearing_takes_only_h(self):
        vals = {
            "VEL PROTOKOL": {"H": 0.5, "V": 9.0, "A": 10.0},
            "ACC PROTOKOL": {"H": 0.5, "V": 9.0, "A": 10.0},
            "ENV PROTOKOL": {"H": 0.5, "V": 9.0, "A": 10.0},
        }
        _, _, rep = self._build(vals)
        self.assertEqual([r["direction"] for r in rep["rows"]], ["A"])
        # Vysoké V/A zrychlení nesmí zhoršit stav ložiska; platí jen H.
        self.assertEqual(rep["bearings_summary"][0]["acc_cur"], 0.5)
        self.assertEqual(rep["bearings_summary"][0]["env_cur"], 0.5)
        self.assertEqual((rep["bearings_summary"][0]["acc_dir"],
                          rep["bearings_summary"][0]["env_dir"]), ("H", "H"))
        self.assertEqual(rep["bearings_summary"][0]["bearing_state"], "A")
        # D zůstává, ale výhradně z rychlosti.
        self.assertEqual((rep["worst_band"], rep["severity"]), ("D", "warn"))

    def test_unselected_acceleration_and_bearing_quantity_are_ignored(self):
        """Ani vysoké ACC/BEARING mimo qmap nesmí zvýšit stav protokolu."""
        vals = {
            "VEL PROTOKOL": {"H": 0.5},
            "ACC PROTOKOL": {"H": 0.5},
            "ENV PROTOKOL": {"H": 0.5},
        }
        extra = {
            "ACC JINÁ VELIČINA": {"H": 99.0},
            "BEARING RMS": {"H": 99.0},
        }
        _, _, rep = self._build(vals, extras=extra)
        self.assertEqual(rep["bearings_summary"][0]["bearing_state"], "A")
        self.assertEqual(rep["severity"], "ok")

    def test_worst_of_acceleration_and_envelope_sets_bearing_state(self):
        vals = {
            "VEL PROTOKOL": {"H": 0.5},
            "ACC PROTOKOL": {"H": 2.5},  # C
            "ENV PROTOKOL": {"H": 4.5},  # D
        }
        _, _, rep = self._build(vals)
        b = rep["bearings_summary"][0]
        self.assertEqual((b["acc_band"], b["env_band"]), ("C", "D"))
        self.assertEqual((b["bearing_state"], rep["worst_band"],
                          rep["severity"]), ("D", "D", "warn"))

    def test_missing_h_uses_v_a_for_velocity_but_leaves_bearing_empty(self):
        vals = {
            "VEL PROTOKOL": {"V": 99.0, "A": 99.0},
            "ACC PROTOKOL": {"V": 99.0, "A": 99.0},
            "ENV PROTOKOL": {"V": 99.0, "A": 99.0},
        }
        _, _, rep = self._build(vals, include_h=False)
        row, b = rep["rows"][0], rep["bearings_summary"][0]
        self.assertEqual(row["direction"], "V")  # tie V/A -> stabilně V
        self.assertEqual(row["vel_cur"], 99.0)
        # Bez H nelze stav ložiska určit - raději prázdno než cizí směr.
        self.assertIsNone(b["acc_cur"])
        self.assertIsNone(b["env_cur"])
        self.assertEqual(b["bearing_state"], "")
        self.assertEqual((rep["worst_band"], rep["severity"]), ("D", "warn"))

    def test_multiple_bearings_keep_independent_hva_values_and_machine_worst(self):
        l1 = {
            "VEL PROTOKOL": {"H": 0.5, "V": 99.0},
            "ACC PROTOKOL": {"H": 0.5, "V": 99.0},
            "ENV PROTOKOL": {"H": 0.5, "V": 99.0},
        }
        l2 = {
            "VEL PROTOKOL": {"H": 0.5},
            "ACC PROTOKOL": {"H": 2.5},
            "ENV PROTOKOL": {"H": 0.5},
        }
        db = FakeDb()
        machine = _machine(_bearing(db, "L1", 100, l1),
                           _bearing(db, "L2", 200, l2))
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        self.assertEqual([r["direction"] for r in rep["rows"]], ["V", "H"])
        # L1 má vysoké hodnoty jen ve V, takže stav ložiska zůstává v A.
        self.assertEqual([b["bearing_state"] for b in rep["bearings_summary"]],
                         ["A", "C"])
        self.assertEqual([b["acc_cur"] for b in rep["bearings_summary"]],
                         [0.5, 2.5])
        self.assertEqual((rep["worst_band"], rep["severity"]), ("D", "warn"))

    def test_refresh_uses_same_hva_logic_and_preserves_manual_texts(self):
        vals = {
            "VEL PROTOKOL": {"H": 0.5, "V": 0.4},
            "ACC PROTOKOL": {"H": 0.5, "V": 0.4},
            "ENV PROTOKOL": {"H": 0.5, "V": 0.4},
        }
        db, machine, rep = self._build(vals)
        rep.update({
            "zaver": "Ručně upravený závěr.",
            "doporuceni": "Ručně upravené doporučení.",
            "problem": "Ručně upravený popis.",
            "severity_override": "ok",
            "severity": "ok",
            "severity_manual": True,
        })
        # Zvedneme H obálku nad C/D; refresh musí přepočítat totéž max. H/V/A.
        h_env = next(q for q in machine["bearings"][0]["quantities"]
                     if q["name"] == "ENV PROTOKOL")["cells"][0]["cell_id"]
        _add_value(db, h_env, 4.5)
        new_doc, info = report_refresh.refresh_report_draft(
            db, {"machines": [rep], "intro": "ruční úvod"}, {}, qmap=QMAP)
        fresh = new_doc["machines"][0]
        self.assertEqual(fresh["bearings_summary"][0]["bearing_state"], "D")
        self.assertEqual(fresh["auto_severity"], "warn")
        self.assertEqual(fresh["severity"], "ok")  # ruční override zůstává
        self.assertTrue(fresh["severity_manual"])
        self.assertEqual(fresh["zaver"], "Ručně upravený závěr.")
        self.assertEqual(fresh["doporuceni"], "Ručně upravené doporučení.")
        self.assertEqual(fresh["problem"], "Ručně upravený popis.")
        self.assertGreaterEqual(info["points_changed"], 1)

    def test_descriptor_point_name_uses_latest_occurrence_and_hva_maximum(self):
        """Historie H se nebere přes čas; u rychlosti vyhraje vyšší V/A."""
        db = FakeDb()
        points = [
            {"id": 201, "name": "L2H-motor", "bearing_key": "L2"},
            {"id": 202, "name": "l2v_motor", "bearing_key": "L2"},
            {"id": 203, "name": "L2A – motor", "bearing_key": "L2"},
        ]
        quantities = []
        for offset, qname in enumerate(QMAP.values()):
            cells = []
            for p in points:
                cid = 500 + offset * 10 + p["id"] - 200
                if p["id"] == 201:
                    db.trends[cid] = [
                        {"t": "2026-07-01T10:00:00", "value": 7.2169},
                        {"t": _TS, "value": 1.3233 if qname == "VEL PROTOKOL" else 0.8},
                    ]
                else:
                    _add_value(db, cid, 99.0)
                cells.append({"cell_id": cid, "point_id": p["id"]})
            quantities.append({
                "name": qname, "cells": cells, "warning": 2.0, "alarm": 4.0,
                "ab": 1.0, "classify": True,
            })
        bearing = {
            "bearing_key": "L2", "label": "L2", "points": points,
            "quantities": quantities, "bearing": {}, "classify": True,
        }
        machine = _machine(bearing)
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        row, summary = rep["rows"][0], rep["bearings_summary"][0]
        self.assertEqual((row["point_id"], summary["point_id"]), (201, 201))
        self.assertEqual(row["point_mapping"], "")
        self.assertEqual((row["vel_cur"], row["direction"]), (99.0, "V"))
        self.assertNotEqual(row["vel_cur"], 7.2169)
        # Bod 201 je jediný H; 99,0 z V/A se do ložiskových sloupců nedostane.
        self.assertEqual((summary["acc_cur"], summary["env_cur"]), (0.8, 0.8))
        self.assertEqual(rep["severity"], "warn")

    def test_ambiguous_h_mapping_does_not_discard_identifiable_hva_candidates(self):
        db = FakeDb()
        points = [
            {"id": 1, "name": "L2H-motor", "bearing_key": "L2"},
            {"id": 2, "name": "L2H-gearbox", "bearing_key": "L2"},
            {"id": 3, "name": "L2V-motor", "bearing_key": "L2"},
        ]
        quantities = []
        for qi, qname in enumerate(QMAP.values()):
            cells = []
            for p in points:
                cid = 800 + qi * 10 + p["id"]
                _add_value(db, cid, 1.0 if p["id"] != 3 else 99.0)
                cells.append({"cell_id": cid, "point_id": p["id"]})
            quantities.append({"name": qname, "cells": cells, "warning": 2.0,
                               "alarm": 4.0, "ab": 1.0, "classify": True})
        machine = _machine({
            "bearing_key": "L2", "label": "L2", "points": points,
            "quantities": quantities, "bearing": {}, "classify": True,
        })
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        self.assertEqual(rep["rows"][0]["point_mapping"], "ambiguous_h")
        self.assertEqual((rep["rows"][0]["vel_cur"], rep["rows"][0]["direction"]), (99.0, "V"))
        # H je nejednoznačné, takže zrychlení ani obálku nelze přiřadit
        # jednomu měřicímu místu; rychlost se z čitelného V určí dál.
        self.assertIsNone(rep["bearings_summary"][0]["acc_cur"])
        self.assertIsNone(rep["bearings_summary"][0]["env_cur"])
        self.assertEqual(rep["severity"], "warn")

    def test_bearing_key_accepts_descriptor_separators_but_not_fuzzy_direction(self):
        self.assertEqual(bearing_key(" l2h – motor "), ("L2", "L2", "H"))
        self.assertEqual(bearing_key("L2H_motor"), ("L2", "L2", "H"))
        # H v popisu se nesmí zaměnit za směr – tento bod není H.
        self.assertEqual(bearing_key("L2-motor H"), ("L2", "L2", None))


class ProtocolHvaExportTests(unittest.TestCase):
    def _doc_and_rep(self):
        db = FakeDb()
        vals = {
            "VEL PROTOKOL": {"H": 0.5, "V": 99.0},
            "ACC PROTOKOL": {"H": 2.5, "V": 99.0},   # C z H
            "ENV PROTOKOL": {"H": 4.5, "V": 99.0},   # D z H
        }
        machine = _machine(_bearing(db, "L1", 100, vals))
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        rep.update({"zaver": "Test", "doporuceni": "Test", "graphs": []})
        doc = {
            "header_left": "Vibrační diagnostika", "report_title": "Test H",
            "footer": dict(report.DEFAULT_FOOTER), "report_version": 2,
            "machines": [rep], "intro": "Test.", "appendix_intro": "",
            "company_name": "", "company_address": "", "measured_at": "",
            "order_number": "", "contract_number": "", "date_created": "",
            "date_measured": "", "measured_by": "", "measured_by2": "",
            "approved_by": "", "used_norms": [],
        }
        return doc, rep

    def test_pdf_and_docx_render_the_same_hva_values_and_state(self):
        doc, rep = self._doc_and_rep()
        self.assertEqual(rep["bearings_summary"][0]["bearing_state"], "D")
        self.assertEqual(rep["severity"], "warn")

        docx_data = report_docx.render(copy.deepcopy(doc))
        with zipfile.ZipFile(io.BytesIO(docx_data)) as z:
            docx_xml = z.read("word/document.xml").decode("utf-8")
        for expected in ("CELKOVÉ HODNOTY: RYCHLOST MAX. H/V/A, LOŽISKO Z H", "Pásmo",
                         "Stav ložiska",
                         "99,00 (V)", ">D<"):
            self.assertIn(expected, docx_xml)

        pdftotext = shutil.which("pdftotext")
        if not pdftotext:
            self.skipTest("pdftotext není dostupný pro obsahovou kontrolu PDF.")
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "report.pdf")
            with open(path, "wb") as f:
                f.write(report_pdf.render(copy.deepcopy(doc)))
            result = subprocess.run([pdftotext, path, "-"],
                                    check=True, capture_output=True,
                                    timeout=30)
        pdf_text = result.stdout.decode("utf-8", errors="replace")
        for expected in ("CELKOVÉ HODNOTY: RYCHLOST MAX. H/V/A, LOŽISKO Z H", "Pásmo",
                         "Stav ložiska",
                         "99,00 (V)", "D"):
            self.assertIn(expected, pdf_text)


class ProtocolCategoryClassificationRegressionTests(unittest.TestCase):
    """HADS 1.36.2: sémantika i kompaktní vzhled stavů protokolu."""

    @staticmethod
    def _screenshot_report():
        db = FakeDb()
        values = {
            "VEL PROTOKOL": {"H": 1.8403},
            "ACC PROTOKOL": {"H": 0.535},
            "ENV PROTOKOL": {"H": 0.8567},
        }
        bearing = _bearing(db, "L3", 300, values)
        limits = {
            "VEL PROTOKOL": (1.44, 1.8),
            "ACC PROTOKOL": (1.03, 1.3),
            "ENV PROTOKOL": (1.76, 2.18),
        }
        for q in bearing["quantities"]:
            q["warning"], q["alarm"] = limits[q["name"]]
            q["ab"] = None
        machine = _machine(bearing)
        db.machine_list = [machine]
        return db, machine, report.build_machine_report(db, machine, {}, qmap=QMAP)

    def test_screenshot_values_have_independent_states(self):
        _db, _machine_obj, rep = self._screenshot_report()
        row = rep["rows"][0]
        bearing = rep["bearings_summary"][0]
        self.assertEqual(row["vel_band"], "D")
        self.assertNotIn(bearing["acc_band"], ("C", "D"))
        self.assertNotIn(bearing["env_band"], ("C", "D"))
        # Zrychlení a obálka mají jen dvě meze (ab=None). Dřív se hranice A/B
        # dopočítávala jako polovina výstrahy, takže 0,535 g hluboko pod
        # limitem 1,03 g vyrobilo neexistující B. Bez odhadu je pásmo A.
        self.assertEqual((bearing["acc_band"], bearing["env_band"]), ("A", "A"))
        self.assertEqual(bearing["bearing_state"], "A")
        self.assertEqual(rep["worst_band"], "D")
        self.assertEqual(rep["severity"], "warn")  # D výhradně z rychlosti

    def test_acceleration_c_and_envelope_b_make_bearing_c(self):
        db = FakeDb()
        vals = {
            "VEL PROTOKOL": {"H": 0.5},
            "ACC PROTOKOL": {"H": 2.5},  # C
            "ENV PROTOKOL": {"H": 1.5},  # B
        }
        machine = _machine(_bearing(db, "L1", 100, vals))
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        b = rep["bearings_summary"][0]
        self.assertEqual((b["acc_band"], b["env_band"], b["bearing_state"]),
                         ("C", "B", "C"))

    def test_acceleration_a_and_envelope_d_make_bearing_d(self):
        db = FakeDb()
        vals = {
            "VEL PROTOKOL": {"H": 0.5},
            "ACC PROTOKOL": {"H": 0.5},  # A
            "ENV PROTOKOL": {"H": 4.5},  # D
        }
        machine = _machine(_bearing(db, "L1", 100, vals))
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        b = rep["bearings_summary"][0]
        self.assertEqual((b["acc_band"], b["env_band"], b["bearing_state"]),
                         ("A", "D", "D"))

    def test_velocity_d_does_not_make_bearing_d_when_acc_and_env_are_a(self):
        db = FakeDb()
        vals = {
            "VEL PROTOKOL": {"H": 4.5},  # D
            "ACC PROTOKOL": {"H": 0.5},  # A
            "ENV PROTOKOL": {"H": 0.5},  # A
        }
        machine = _machine(_bearing(db, "L1", 100, vals))
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        self.assertEqual(rep["rows"][0]["vel_band"], "D")
        self.assertEqual(rep["bearings_summary"][0]["bearing_state"], "A")
        self.assertEqual((rep["worst_band"], rep["severity"]), ("D", "warn"))

    def test_acceleration_or_envelope_alone_control_their_own_and_overall_state(self):
        db = FakeDb()
        vals = {
            "VEL PROTOKOL": {"H": 0.4},
            "ACC PROTOKOL": {"H": 2.5},  # C
            "ENV PROTOKOL": {"H": 4.5},  # D
        }
        machine = _machine(_bearing(db, "L1", 100, vals))
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        b = rep["bearings_summary"][0]
        self.assertEqual((rep["rows"][0]["vel_band"], b["acc_band"], b["env_band"]),
                         ("A", "C", "D"))
        self.assertEqual((b["bearing_state"], rep["severity"]), ("D", "warn"))

    def test_previous_high_category_measurement_cannot_leak_into_latest_state(self):
        db = FakeDb()
        vals = {
            "VEL PROTOKOL": {"H": 0.5},
            "ACC PROTOKOL": {"H": 0.5},
            "ENV PROTOKOL": {"H": 0.5},
        }
        bearing = _bearing(db, "L1", 100, vals)
        acc_cell = next(q for q in bearing["quantities"] if q["name"] == "ACC PROTOKOL")["cells"][0]["cell_id"]
        db.trends[acc_cell] = [
            {"t": "2026-01-01T10:00:00", "value": 9.0},  # historicky D
            {"t": _TS, "value": 0.5},                     # zobrazené, A
        ]
        machine = _machine(bearing)
        db.machine_list = [machine]
        rep = report.build_machine_report(db, machine, {}, qmap=QMAP)
        self.assertEqual(rep["bearings_summary"][0]["acc_cur"], 0.5)
        self.assertEqual(rep["bearings_summary"][0]["acc_band"], "A")
        self.assertEqual(rep["bearings_summary"][0]["bearing_state"], "A")

    def test_manual_category_override_reset_refresh_export_and_ai_context(self):
        db, machine, rep = self._screenshot_report()
        row, b = rep["rows"][0], rep["bearings_summary"][0]
        row["vel_band_override"] = "C"
        b["acc_band_override"] = "D"
        b["env_band_override"] = "B"
        report.recompute_machine_state(rep)
        self.assertEqual((row["vel_band"], b["acc_band"], b["env_band"]),
                         ("C", "D", "B"))
        self.assertEqual(b["bearing_state"], "D")
        context = report.report_state_context(rep)
        self.assertIn("pásmo rychlosti C (ručně)", context)
        self.assertIn("zrychlení D (ručně)", context)
        self.assertIn("stav ložiska (zrychlení/obálka) D", context)

        # Návrh/history ukládají tentýž slovník; export musí nést čitelnou
        # auditní značku a ne pouhý celkový stav.
        rep.update({"zaver": "Test", "doporuceni": "Test", "graphs": []})
        doc = {
            "header_left": "Vibrační diagnostika", "report_title": "Test",
            "footer": dict(report.DEFAULT_FOOTER), "report_version": 2,
            "machines": [copy.deepcopy(rep)], "intro": "", "appendix_intro": "",
            "company_name": "", "company_address": "", "measured_at": "",
            "order_number": "", "contract_number": "", "date_created": "",
            "date_measured": "", "measured_by": "", "measured_by2": "",
            "approved_by": "", "used_norms": [],
        }
        history_snapshot = copy.deepcopy(doc)
        self.assertEqual(history_snapshot["machines"][0]["bearings_summary"][0]["acc_band_override"], "D")
        with zipfile.ZipFile(io.BytesIO(report_docx.render(copy.deepcopy(doc)))) as z:
            xml = z.read("word/document.xml").decode("utf-8")
        self.assertIn("ručně", xml)
        self.assertIn("Stav ložiska", xml)
        pdftotext = shutil.which("pdftotext")
        if pdftotext:
            with tempfile.TemporaryDirectory() as td:
                pdf_path = os.path.join(td, "manual.pdf")
                with open(pdf_path, "wb") as f:
                    f.write(report_pdf.render(copy.deepcopy(doc)))
                pdf_text = subprocess.run([pdftotext, pdf_path, "-"], check=True,
                                          capture_output=True, timeout=30).stdout.decode("utf-8", errors="replace")
            self.assertIn("pásmo označené hvězdičkou", pdf_text)

        # Obnovení limitů zachová explicitní A–D; Automaticky se vrátí
        # k čerstvě vypočtenému pásmu.
        refreshed, _info = report_refresh.refresh_report_draft(
            db, {"machines": [rep]}, {}, qmap=QMAP)
        fresh = refreshed["machines"][0]
        self.assertEqual(fresh["rows"][0]["vel_band_override"], "C")
        self.assertEqual(fresh["bearings_summary"][0]["acc_band_override"], "D")
        fresh["rows"][0]["vel_band_override"] = ""
        fresh["bearings_summary"][0]["acc_band_override"] = ""
        fresh["bearings_summary"][0]["env_band_override"] = ""
        report.recompute_machine_state(fresh)
        self.assertEqual(fresh["rows"][0]["vel_band"], "D")
        self.assertNotIn(fresh["bearings_summary"][0]["acc_band"], ("C", "D"))
        self.assertNotIn(fresh["bearings_summary"][0]["env_band"], ("C", "D"))

    def test_compact_editor_markup_keeps_only_speed_band_and_bearing_state(self):
        app = (Path(__file__).resolve().parents[1] / "frontend" / "app.js").read_text(
            encoding="utf-8")
        self.assertIn("<th>Pásmo</th>", app)
        self.assertIn("<th>Stav ložiska</th>", app)
        self.assertIn('data-state-menu="${kind}"', app)
        self.assertIn('_reportStateCell("velocity"', app)
        self.assertIn('_reportStateCell("bearing"', app)
        self.assertNotIn("<th>Stav zrychlení</th>", app)
        self.assertNotIn("<th>Stav obálky</th>", app)
        self.assertNotIn("<th>Celkový stav</th>", app)

    def test_closed_compact_cells_are_original_style_badges_only(self):
        """DOM regrese 1.36.2: zavřená buňka nesmí nést popisek ani „ručně“.

        JS se vykoná nad reálnými render funkcemi a výsledný HTML fragment se
        zkontroluje parserem. Umožňuje to ohlídat bug s přetečeným textem bez
        nutnosti spouštět HTTP server.
        """
        app_path = Path(__file__).resolve().parents[1] / "frontend" / "app.js"
        node = shutil.which("node")
        if not node:
            self.skipTest("node není dostupný pro DOM regresi editoru.")
        script = r"""
const fs = require("fs");
const source = fs.readFileSync(process.argv[2], "utf8");
const start = source.indexOf("const REPORT_MANUAL_BANDS =");
const end = source.indexOf("// Druhy grafů", start);
if (start < 0 || end < 0) throw new Error("Nenalezen render blok tabulky.");
global.escapeHtml = (v) => String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
global.fmtNum = (v) => Number(v).toFixed(2).replace(".", ",");
global._autoSeverityFromBand = () => "warn";
global.SEV_MODEL_LABELS = {warn:"Varování"};
eval(source.slice(start, end));
const report = {
 rows:[{place:"L3", direction:"H", vel_cur:1.8403, vel_auto_band:"D", vel_band:"D"}],
 bearings_summary:[{place:"L3", acc_cur:.535, env_cur:.8567, acc_auto_band:"B", env_auto_band:"B", acc_band:"B", env_band:"B", bearing_state:"B"}],
 excluded_points:[]
};
process.stdout.write(renderOverallTable(report, 2, {withPrev:true}));
"""
        with tempfile.TemporaryDirectory() as td:
            script_path = Path(td) / "compact_dom.js"
            script_path.write_text(script, encoding="utf-8")
            html = subprocess.run([node, str(script_path), str(app_path)], check=True,
                                  capture_output=True, text=True, timeout=30).stdout

        class ClosedBadgeParser(HTMLParser):
            def __init__(self):
                super().__init__(); self.badges=[]; self._summary=None; self.headers=[]
            def handle_starttag(self, tag, attrs):
                a=dict(attrs)
                if tag == "summary" and "data-state-badge" in a:
                    self._summary={"kind":a["data-state-badge"], "text":"", "aria":a.get("aria-label","")}
                if tag == "th": self._summary = {"header":"", "text":""}
            def handle_data(self, data):
                if self._summary is not None: self._summary["text"] += data
            def handle_endtag(self, tag):
                if tag == "summary" and self._summary and "kind" in self._summary:
                    self.badges.append(self._summary); self._summary=None
                elif tag == "th" and self._summary and "header" in self._summary:
                    self.headers.append(self._summary["text"].strip()); self._summary=None
        parsed=ClosedBadgeParser(); parsed.feed(html)
        self.assertEqual(parsed.headers, ["Zahrnout", "Ložisko",
                         "Porovnávací rychlost max. H/V/A",
                         "Rychlost max. H/V/A", "Pásmo",
                         "Zrychlení H", "Obálka H",
                         "Stav ložiska"])
        self.assertEqual([(b["kind"], b["text"].strip()) for b in parsed.badges], [("velocity", "D"), ("bearing", "B")])
        for badge in parsed.badges:
            self.assertRegex(badge["text"].strip(), r"^[ABCD—]$")
            self.assertNotIn("Pásmo rychlosti", badge["text"])
            self.assertNotIn("Stav ložiska", badge["text"])
            self.assertNotIn("ručně", badge["text"])
        css=(app_path.parent / "styles.css").read_text(encoding="utf-8")
        self.assertIn(".oc-band-A { background: #19a874; }", css)
        self.assertIn(".oc-band-D { background: #e23b3b; }", css)
        self.assertIn(".oc-table {\n  width: 100%; min-width: 760px;", css)
        self.assertIn(".oc-wrap { }", css)
        self.assertIn(".oc-wrap { overflow-x: auto;", css)
        self.assertIn(".oc-state-menu[open] .oc-state-popover", css)
        self.assertIn(".oc-state-menu > summary::-webkit-details-marker { display: none; }", css)

    def test_manual_badge_uses_non_layout_audit_marker_only(self):
        app = (Path(__file__).resolve().parents[1] / "frontend" / "app.js").read_text(encoding="utf-8")
        css = (Path(__file__).resolve().parents[1] / "frontend" / "styles.css").read_text(encoding="utf-8")
        self.assertIn('oc-state-manual', app)
        self.assertIn('.oc-state-manual::after', css)
        self.assertNotIn('oc-manual', app)


if __name__ == "__main__":
    unittest.main(verbosity=2)
