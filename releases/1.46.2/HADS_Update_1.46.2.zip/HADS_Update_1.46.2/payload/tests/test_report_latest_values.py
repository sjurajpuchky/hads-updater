# -*- coding: utf-8 -*-
"""Regrese NDB historie pro aktuální max. H/V/A semantiku protokolu.

Test vytváří skutečnou syntetickou SQLite/NDB databázi. Statistické BLOBy jsou
vkládány schválně mimo časové pořadí, aby se ověřilo, že protokol respektuje
zvolený přesný výskyt a z jeho H/V/A kandidátů vybere maximum, nikoli hodnotu
z jiného dne nebo podle pořadí zápisu.
"""

import copy
import io
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
import zipfile

BACKEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "backend")
TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BACKEND_DIR)
sys.path.insert(0, TESTS_DIR)

from ndb_parser import NdbDatabase  # noqa: E402
import report  # noqa: E402
import report_docx  # noqa: E402
import report_pdf  # noqa: E402
import report_refresh  # noqa: E402
from ndb_fixture_builder import _SCHEMA, make_limits_xml, make_static_blob  # noqa: E402


Q_VEL = "ISO RMS"
Q_ACC = "ACC RMS 10 - 6400 Hz"
Q_ENV = "ACC ENV RMS 500 Hz"
LIMITS = make_limits_xml([1.0, 2.0, 4.0])
# ms od 2000: 2026-01-02 až 2026-01-04 – hodnoty jsou záměrně daleko od sebe.
T_OLD = 820_627_200_000       # 2026-01-02 00:00:00
T_SCOPE = 820_713_600_000     # 2026-01-03 00:00:00
T_OUTSIDE = 820_800_000_000   # 2026-01-04 00:00:00


def _remove_sqlite(path):
    for suffix in ("", "-wal", "-shm", "-journal"):
        try:
            os.remove(path + suffix)
        except FileNotFoundError:
            pass


def _insert_stat(con, cell_id, time_from, points, data_is_null=False):
    """Vloží jeden řádek Tbl_Cell_Stats; pořadí volání určuje rowid."""
    blob = None if data_is_null else make_static_blob(points)
    con.execute(
        "INSERT INTO Tbl_Cell_Stats (CellId, TimeFrom, TimeTo, Data) "
        "VALUES (?,?,?,?)", (cell_id, time_from, time_from, blob),
    )


def build_history_ndb(path):
    """Vytvoří dva stroje, tři H ložiska, H/V směry a více veličin.

    U A/L1H/ISO RMS platí: novější čas má nižší rowid a starší čas vyšší
    rowid. Hodnota 4.0 je ještě novější, ale mimo scope data 3.1.2026.
    """
    _remove_sqlite(path)
    con = sqlite3.connect(path)
    con.executescript(_SCHEMA)
    con.executemany(
        "INSERT INTO Tbl_Severity (ID, Name, Color, Severity) VALUES (?,?,?,?)",
        [(1, "Ok", 0x00FF00, 1), (2, "Varování", 0xFFFF00, 2),
         (3, "Výstraha", 0xFFA500, 3), (4, "Ohrožení", 0xFF0000, 4)],
    )
    con.execute("INSERT INTO Tbl_Info (ID, Version, DDS_Version, Route_Format) "
                "VALUES (1, '1.0', '1.31', 'route')")
    con.execute("INSERT INTO Tbl_Routes (ID, Name) VALUES (1, 'History route')")
    trees = [
        (1, "Podnik A", 0, 0, 1, None),
        (2, "Stroj A", 1, 0, 2, 25.0),
        (3, "Stroj B", 1, 1, 2, 25.0),
        (10, "L1H", 2, 0, 3, None),
        (11, "L1V", 2, 1, 3, None),
        (12, "L2H", 2, 2, 3, None),
        (20, "L1H", 3, 0, 3, None),
    ]
    con.executemany(
        "INSERT INTO Tbl_Tree (ID, Name, Parent, SortId, Type, Speed_Hz) "
        "VALUES (?,?,?,?,?,?)", trees,
    )

    next_id = [100]

    def add_cell(point_id, name, last_measured=T_SCOPE):
        cid = next_id[0]
        next_id[0] += 1
        con.execute(
            "INSERT INTO Tbl_Cell (ID, Name, Parent, SortId, DataType, Limits, "
            "LastMeasured, MaxSeverityId) VALUES (?,?,?,?,?,?,?,?)",
            (cid, name, point_id, cid, 1, LIMITS, last_measured, 1),
        )
        return cid

    # Stroj A, L1H: vybrané H veličiny.
    a_l1_vel = add_cell(10, Q_VEL)
    # rowid 1: NOVĚJŠÍ hodnota, rowid 2: STARŠÍ hodnota – pořadí nesmí vyhrát.
    _insert_stat(con, a_l1_vel, T_SCOPE, [(T_SCOPE, 3.0)])
    _insert_stat(con, a_l1_vel, T_OLD, [(T_OLD, 99.0)])
    # Ještě novější, ale mimo datumový scope.
    _insert_stat(con, a_l1_vel, T_OUTSIDE, [(T_OUTSIDE, 4.0)])

    a_l1_acc = add_cell(10, Q_ACC)
    # Jediný vzorek kanálu v jednom výskytu. Dvojice zcela shodných časů
    # v témže kanálu je bez session ID explicitně nejednoznačná a má vlastní
    # regresi v test_report_hva_selection.
    _insert_stat(con, a_l1_acc, T_SCOPE, [(T_SCOPE, 2.5)])
    a_l1_env = add_cell(10, Q_ENV)
    _insert_stat(con, a_l1_env, T_SCOPE, [(T_SCOPE, 0.5)])
    # NULL řádek a NaN jsou neplatná měření; nesmějí přebít 0.5.
    _insert_stat(con, a_l1_env, T_OUTSIDE, [], data_is_null=True)
    _insert_stat(con, a_l1_env, T_OUTSIDE, [(T_OUTSIDE, float("nan"))])
    a_l1_extra = add_cell(10, "BEARING RMS")
    _insert_stat(con, a_l1_extra, T_SCOPE, [(T_SCOPE, 777.0)])

    # Stroj A, L1V: vysoké hodnoty musí být platným max. H/V/A kandidátem.
    for name in (Q_VEL, Q_ACC, Q_ENV):
        cid = add_cell(11, name)
        _insert_stat(con, cid, T_SCOPE, [(T_SCOPE, 999.0)])

    # Stroj A, L2H: druhé ložisko ověří oddělení bodů.
    for name, value in ((Q_VEL, 0.75), (Q_ACC, 0.8), (Q_ENV, 0.9)):
        cid = add_cell(12, name)
        _insert_stat(con, cid, T_SCOPE, [(T_SCOPE, value)])

    # Stroj B, L1H: třetí samostatné místo/stroj, nesmí se smíchat se Strojem A.
    for name, value in ((Q_VEL, 1.25), (Q_ACC, 1.5), (Q_ENV, 1.75)):
        cid = add_cell(20, name)
        _insert_stat(con, cid, T_SCOPE, [(T_SCOPE, value)])

    con.commit()
    con.close()


class _FakeTrendDb:
    """Adaptér pro nemožné nenumerické hodnoty mimo binární NDB formát."""

    def trend(self, cell_id):
        return [
            {"t": "2026-01-03T00:00:00", "value": None},
            {"t": "2026-01-03T00:00:01", "value": "necislo"},
            {"t": "2026-01-03T00:00:02", "value": float("inf")},
            {"t": "2026-01-03T00:00:03", "value": 2.25},
        ]


class LatestValueHelperTests(unittest.TestCase):
    def test_null_text_and_nonfinite_values_are_not_last_valid_measurement(self):
        cur, prev, ts = report._current_previous(_FakeTrendDb(), [1])
        self.assertEqual(cur, 2.25)
        self.assertIsNone(prev)
        self.assertEqual(ts, "2026-01-03T00:00:03")


class LatestValueNdbProtocolTests(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.td.name, "history.ndb")
        build_history_ndb(self.path)
        self.db = NdbDatabase(self.path)

    def tearDown(self):
        try:
            self.db.close()
        finally:
            self.td.cleanup()

    def _draft(self):
        return report.build_report_draft(
            self.db, {}, {"name": "Podnik A"},
            {"mode": "date", "date": "2026-01-03"},
            report_version=2,
        )

    @staticmethod
    def _machine(doc, name):
        return next(m for m in doc["machines"] if m["name"] == name)

    def test_ndb_history_uses_timestamp_scope_and_hva_maximum(self):
        """Kompletní NDB cesta: parser → machines → build_machine_report."""
        # Parser musí vrátit trend v chronologickém pořadí, i když tabulkové
        # řádky byly zapsány mimo časové pořadí.
        machine_a = self.db.machine(2)["machine"]
        l1 = next(b for b in machine_a["bearings"] if b["label"] == "L1")
        vel_cell = next(q for q in l1["quantities"] if q["name"] == Q_VEL)["cells"][0]["cell_id"]
        self.assertEqual([p["value"] for p in self.db.trend(vel_cell)], [99.0, 3.0, 4.0])

        doc = self._draft()
        self.assertEqual(doc["scope"], {"mode": "date", "date": "2026-01-03"})
        self.assertEqual({m["name"] for m in doc["machines"]}, {"Stroj A", "Stroj B"})

        a = self._machine(doc, "Stroj A")
        self.assertEqual(a["last_measured"], "03.01.2026")
        self.assertEqual([r["direction"] for r in a["rows"]], ["V", "H"])
        by_place = {r["place"]: r for r in a["rows"]}
        self.assertEqual((by_place["L1"]["vel_cur"], by_place["L1"]["direction"]), (999.0, "V"))
        self.assertIsNone(by_place["L1"]["vel_prev"])  # starší den je mimo scope
        self.assertEqual(by_place["L2"]["vel_cur"], 0.75)
        b_l1 = next(b for b in a["bearings_summary"] if b["place"] == "L1")
        # 999,0 je pouze ve V; ložiskové sloupce berou H.
        self.assertEqual((b_l1["acc_cur"], b_l1["env_cur"]), (2.5, 0.5))
        self.assertEqual((b_l1["acc_dir"], b_l1["env_dir"]), ("H", "H"))
        self.assertEqual(b_l1["acc_band"], "C")
        # 4.0 (mimo scope) a 777 (jiná veličina) nesmějí proniknout.
        all_values = str(a["rows"]) + str(a["bearings_summary"])
        for forbidden in ("4.0", "777.0"):
            self.assertNotIn(forbidden, all_values)

        b = self._machine(doc, "Stroj B")
        self.assertEqual(b["rows"][0]["vel_cur"], 1.25)
        self.assertNotIn("Stroj B", a["name"])

    def test_refresh_and_pdf_docx_mirror_the_same_editor_values(self):
        doc = self._draft()
        editor_a = self._machine(doc, "Stroj A")
        refreshed, info = report_refresh.refresh_report_draft(self.db, doc, {})
        refreshed_a = self._machine(refreshed, "Stroj A")
        self.assertEqual(refreshed["scope"], doc["scope"])
        self.assertEqual(refreshed_a["rows"], editor_a["rows"])
        self.assertEqual(refreshed_a["bearings_summary"], editor_a["bearings_summary"])
        self.assertEqual(info["machines_updated"], 2)

        docx_data = report_docx.render(copy.deepcopy(refreshed))
        with zipfile.ZipFile(io.BytesIO(docx_data)) as z:
            xml = z.read("word/document.xml").decode("utf-8")
        for expected in ("CELKOVÉ HODNOTY: RYCHLOST MAX. H/V/A, LOŽISKO Z H", "999,00 (V)"):
            self.assertIn(expected, xml)
        for forbidden in ("4,00", "777,00"):
            self.assertNotIn(forbidden, xml)

        pdftotext = shutil.which("pdftotext")
        if not pdftotext:
            self.skipTest("pdftotext není dostupný pro obsahovou kontrolu PDF.")
        with tempfile.TemporaryDirectory() as td:
            pdf_path = os.path.join(td, "report.pdf")
            with open(pdf_path, "wb") as f:
                f.write(report_pdf.render(copy.deepcopy(refreshed)))
            result = subprocess.run([pdftotext, pdf_path, "-"], check=True,
                                    capture_output=True, timeout=30)
        text = result.stdout.decode("utf-8", errors="replace")
        for expected in ("CELKOVÉ HODNOTY: RYCHLOST MAX. H/V/A, LOŽISKO Z H", "999,00 (V)"):
            self.assertIn(expected, text)
        for forbidden in ("4,00", "777,00"):
            self.assertNotIn(forbidden, text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
