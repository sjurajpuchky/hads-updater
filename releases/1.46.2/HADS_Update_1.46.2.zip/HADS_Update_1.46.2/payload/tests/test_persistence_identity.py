"""Semantic cross-version persistence regressions for HADS 1.38.2.

These tests deliberately exercise the public settings API after a real NDB
bootstrap.  They are not file-presence tests: a technician must be returned by
the same GET used by Settings -> Technici.
"""
from __future__ import annotations

import http.client
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT / "tests"))
import ai_eval
import ai_knowledge
import ai_prompts
import data_store
import server
from ndb_fixture_builder import build_fixture_ndb


class PersistenceIdentityHttpTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="HADS persistence 1.38.2 ")
        self.root = Path(self.temp.name) / "instalace po aktualizaci"
        self.data = self.root / "data"; self.data.mkdir(parents=True)
        self.old = {
            "server_data": server.DATA_DIR, "state": server._STATE_FILE,
            "library": server._LIBRARY_FILE, "lock": server._SERVER_LOCK_FILE,
            "server": server._SERVER, "store_data": data_store._DATA_DIR,
            "store_podniky": data_store._PODNIKY_DIR, "eval_cfg": ai_eval._CFG_FILE,
            "knowledge": ai_knowledge._FILE, "prompts": ai_prompts.DATA_DIR,
        }
        server.DATA_DIR = self.data
        server._STATE_FILE = self.data / "current.txt"
        server._LIBRARY_FILE = self.data / "library.json"
        server._SERVER_LOCK_FILE = self.root / "runtime" / "HADS.lock"
        data_store._DATA_DIR = self.data
        data_store._PODNIKY_DIR = self.data / "podniky"
        ai_eval._CFG_FILE = self.data / "ai_config.json"
        ai_knowledge._FILE = self.data / "ai_examples.json"
        ai_prompts.DATA_DIR = self.data
        server._dbkey_cache.clear(); server._persistence_context.update(filename=None, result=None)
        server._close_active_cache()
        server._SERVER = server.ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        self.port = server._SERVER.server_address[1]
        self.thread = threading.Thread(target=server._SERVER.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        active = server._SERVER
        if active:
            active.shutdown(); active.server_close()
        self.thread.join(timeout=5)
        server._close_active_cache()
        server.DATA_DIR = self.old["server_data"]
        server._STATE_FILE = self.old["state"]
        server._LIBRARY_FILE = self.old["library"]
        server._SERVER_LOCK_FILE = self.old["lock"]
        server._SERVER = self.old["server"]
        data_store._DATA_DIR = self.old["store_data"]
        data_store._PODNIKY_DIR = self.old["store_podniky"]
        ai_eval._CFG_FILE = self.old["eval_cfg"]
        ai_knowledge._FILE = self.old["knowledge"]
        ai_prompts.DATA_DIR = self.old["prompts"]
        server._dbkey_cache.clear(); server._persistence_context.update(filename=None, result=None)
        self.temp.cleanup()

    def _ndb(self, name="Duslo.nDb", plant="Duslo"):
        build_fixture_ndb(self.data / name, [{"name": "ISO RMS", "value": 1.1}], plant_name=plant)
        (self.data / "current.txt").write_text(name + "\n", encoding="utf-8")
        return name

    def _route_guid(self, name, value):
        with sqlite3.connect(self.data / name) as con:
            con.execute("UPDATE Tbl_Routes SET Guid=?", (value,))

    def _request(self, method, path, body=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        headers = {"Host": "127.0.0.1:%d" % self.port}
        if body is not None: headers["Content-Type"] = "application/json"
        conn.request(method, path, body=body, headers=headers)
        response = conn.getresponse(); raw = response.read(); conn.close()
        return response.status, json.loads(raw.decode("utf-8"))

    def _legacy_folder(self, name, key, techs, company="Duslo"):
        folder = self.data / "podniky" / name; folder.mkdir(parents=True, exist_ok=True)
        (folder / "_key.txt").write_text(key, encoding="utf-8")
        (folder / "company.json").write_text(json.dumps({"name": company}), encoding="utf-8")
        (folder / "report_settings.json").write_text(
            json.dumps({"technicians": techs, "quantities": {"velocity": "ISO RMS"}}),
            encoding="utf-8")
        return folder

    def test_1381_predecessor_folder_is_loaded_by_actual_settings_api_after_bootstrap(self):
        # Exact shipped 1.38.1 shape: context was keyed by podnik:<name>.
        self._ndb(); self._legacy_folder("Duslo", "podnik:Duslo", ["Anna", "Petr"])
        status, body = self._request("GET", "/api/report/settings")
        self.assertEqual(status, 200)
        self.assertEqual(body["settings"]["technicians"], ["Anna", "Petr"])
        status, check = self._request("GET", "/api/persistence/status")
        self.assertEqual(status, 200)
        technicians = next(row for row in check["categories"] if row["id"] == "technicians")
        self.assertEqual(technicians["count"], 2)
        self.assertIn(check["context"]["state"], {"recovered", "known"})
        # Reopening/restarting cannot duplicate list entries or remap context.
        server._invalidate_db_caches()
        status, body = self._request("GET", "/api/report/settings")
        self.assertEqual(body["settings"]["technicians"], ["Anna", "Petr"])

    def test_empty_current_folder_recovers_one_verified_orphan_and_merges_technicians(self):
        self._ndb()
        # The precise failure mode: an empty new folder blocked old code's move.
        current = self._legacy_folder("Duslo", "podnik:Duslo", [])
        orphan = self._legacy_folder("Duslo.nDb", "Duslo.nDb", ["Anna", "Petr"])
        status, body = self._request("GET", "/api/report/settings")
        self.assertEqual(status, 200)
        self.assertEqual(body["settings"]["technicians"], ["Anna", "Petr"])
        self.assertTrue(current.exists() and orphan.exists(), "recovery must not delete source data")
        status, check = self._request("GET", "/api/persistence/status")
        self.assertIn(check["context"]["code"], {"ID_RECOVERED_ORPHAN", "ID_MERGED_SAFE"})

    def test_pre_per_company_root_layout_migrates_and_is_semantically_reachable(self):
        self._ndb()
        (self.data / "report_settings.json").write_text(json.dumps({
            "podnik:Duslo": {"technicians": ["Eva"]}
        }), encoding="utf-8")
        status, body = self._request("GET", "/api/report/settings")
        self.assertEqual(status, 200)
        self.assertEqual(body["settings"]["technicians"], ["Eva"])

    def test_same_display_name_ambiguous_orphans_do_not_merge(self):
        self._ndb("novy.nDb", "Duslo")
        # Two folders both claim the exact historic company alias.  The
        # evidence is therefore real, but contradictory; neither may be
        # chosen just because the display name happens to agree.
        self._legacy_folder("stary-a", "podnik:Duslo", ["Anna"], "Duslo")
        self._legacy_folder("stary-b", "podnik:Duslo", ["Bohumil"], "Duslo")
        status, body = self._request("GET", "/api/report/settings")
        self.assertEqual(status, 200)
        self.assertEqual(body["settings"]["technicians"], [])
        status, check = self._request("GET", "/api/persistence/status")
        self.assertEqual(check["context"]["state"], "ambiguous")
        self.assertEqual((self.data / "podniky" / "stary-a" / "report_settings.json").exists(), True)
        self.assertEqual((self.data / "podniky" / "stary-b" / "report_settings.json").exists(), True)

    def test_filename_rename_keeps_intrinsic_identity_but_different_company_does_not_inherit(self):
        self._ndb("Duslo.nDb", "Duslo")
        self._legacy_folder("Duslo", "podnik:Duslo", ["Anna"], "Duslo")
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], ["Anna"])
        # Same bytes/identity under a renamed file must resolve to the registry.
        (self.data / "renamed.nDb").write_bytes((self.data / "Duslo.nDb").read_bytes())
        self._request("POST", "/api/databases/activate", json.dumps({"filename": "renamed.nDb"}))
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], ["Anna"])
        # A different intrinsic company, even reusing the old filename alias,
        # must start clean rather than inherit Duslo's technicians.
        self._ndb("replacement.nDb", "Jiný podnik")
        self._request("POST", "/api/databases/activate", json.dumps({"filename": "replacement.nDb"}))
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], [])

    def test_same_display_name_different_intrinsic_identity_never_merges(self):
        first = self._ndb("duslo-a.nDb", "Duslo")
        self._route_guid(first, "11111111-1111-1111-1111-111111111111")
        self._legacy_folder("Duslo", "podnik:Duslo", ["Anna"], "Duslo")
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], ["Anna"])
        second = self._ndb("duslo-b.nDb", "Duslo")
        self._route_guid(second, "22222222-2222-2222-2222-222222222222")
        self._request("POST", "/api/databases/activate", json.dumps({"filename": second}))
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], [])

    def test_same_filename_database_replacement_for_same_company_keeps_settings(self):
        name = self._ndb("Duslo.nDb", "Duslo")
        self._route_guid(name, "11111111-1111-1111-1111-111111111111")
        self._legacy_folder("Duslo", "podnik:Duslo", ["Anna"], "Duslo")
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], ["Anna"])
        # Simulate the supported database replacement: the active filename and
        # intrinsic company label stay, but the supplier writes a fresh NDB.
        self._ndb(name, "Duslo")
        self._route_guid(name, "22222222-2222-2222-2222-222222222222")
        self._request("POST", "/api/databases/activate", json.dumps({"filename": name}))
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], ["Anna"])

    def test_same_filename_replacement_for_different_company_never_inherits(self):
        name = self._ndb("active.nDb", "Duslo")
        self._route_guid(name, "11111111-1111-1111-1111-111111111111")
        self._legacy_folder("Duslo", "podnik:Duslo", ["Anna"], "Duslo")
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], ["Anna"])
        self._ndb(name, "Jiný podnik")
        self._route_guid(name, "22222222-2222-2222-2222-222222222222")
        self._request("POST", "/api/databases/activate", json.dumps({"filename": name}))
        self.assertEqual(self._request("GET", "/api/report/settings")[1]["settings"]["technicians"], [])


class PersistenceIdentityFrontendBindingTests(unittest.TestCase):
    """Keep the proven API recovery connected to the Settings rendering path."""

    def test_settings_frontend_reads_actual_api_and_renders_recovered_technicians(self):
        app = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
        html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
        self.assertIn('const rs = await api("/api/report/settings");', app)
        self.assertIn(
            "SETTINGS_TECHS = Array.isArray(s.technicians) ? s.technicians.slice() : [];",
            app,
        )
        self.assertIn("_renderSettingsTechList();", app)
        self.assertIn('id="set-tech-list"', html)


if __name__ == "__main__":
    unittest.main(verbosity=2)
