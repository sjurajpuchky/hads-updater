# -*- coding: utf-8 -*-
"""DOM kontrakt kompaktního per-direction výběru měření 1.39.0."""
import json
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class MeasurementSelectorFrontendTests(unittest.TestCase):
    def test_collapsed_selector_has_per_direction_exact_options_and_previews(self):
        """Renderer must expose only the intended compact, accessible controls."""
        script = r"""
const fs = require("fs");
const source = fs.readFileSync(process.argv[1], "utf8");
const start = source.indexOf("function renderMeasurementSelectors(");
const end = source.indexOf("\n// Sjednocená kompaktní tabulka", start);
if (start < 0 || end < 0) throw new Error("Nenalezen renderer výběru měření.");
global.escapeHtml = (v) => String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
global.fmtNum = (v, d) => Number(v).toFixed(d).replace(".", ",");
eval(source.slice(start, end));
const opt = (id, label, values) => ({id, label, values, usable:true});
const hNew = opt("H|2026-08-18T13:38:16#1", "18. 8. 2026 13:38:16 • R 1,59 mm/s • Z 0,10 g • O 0,04 g",
                  {"ISO RMS":1.59, "ACC":.10, "ENV":.04});
const hOld = opt("H|2026-08-17T10:01:00#1", "17. 8. 2026 10:01:00 • R 1,12 mm/s",
                  {"ISO RMS":1.12});
const a = opt("A|2026-08-18T13:37:02#1", "18. 8. 2026 13:37:02 • R 1,33 mm/s • Z 0,18 g • O 0,55 g",
              {"ISO RMS":1.33, "ACC":.18, "ENV":.55});
const recH = { options:[hNew,hOld], previous_options:[hOld], current_id:hNew.id,
  previous_id:hOld.id, current_preview:hNew.values, previous_preview:hOld.values };
const recA = { options:[a], previous_options:[], current_id:a.id,
  previous_id:"", current_preview:a.values, previous_preview:{} };
const report = {protocol_quantities:{velocity:"ISO RMS",accel:"ACC",env:"ENV"},
 rows:[{place:"L4",vel_cur:1.59,direction:"H"}],
 bearings_summary:[{place:"L4",acc_cur:.18,acc_dir:"A",env_cur:.55,env_dir:"A",
   measurement_directions:{H:recH,A:recA}}]};
process.stdout.write(renderMeasurementSelectors(report, true));
"""
        app = ROOT / "frontend" / "app.js"
        result = subprocess.run(
            ["node", "-e", script, str(app)], cwd=ROOT, text=True,
            capture_output=True, encoding="utf-8", timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        html = result.stdout
        # Native <details> is closed without an open attribute and is keyboard
        # operable through its <summary>; no fabricated cross-direction session.
        self.assertIn('<details class="report-measurement-selectors" data-machine-id="">', html)
        self.assertNotIn('report-measurement-selectors" open', html)
        self.assertIn("<summary>Výběr měření ložisek", html)
        self.assertIn('data-direction="H"', html)
        self.assertIn('data-direction="A"', html)
        self.assertNotIn('data-direction="V"', html)
        self.assertIn("18. 8. 2026 13:38:16", html)
        self.assertIn("R 1,59 mm/s", html)
        self.assertIn("aria-live=\"polite\"", html)
        self.assertIn("Vybraný výskyt: R 1,59 mm/s", html)
        self.assertIn("Porovnávaný výskyt: R 1,12 mm/s", html)
        # The current H must not appear in its previous dropdown; only its
        # strictly preceding H occurrence is offered next to Žádná.
        previous = html.split('data-kind="previous" data-direction="H"', 1)[1].split("</select>", 1)[0]
        self.assertIn("Žádná", previous)
        self.assertIn("17. 8. 2026 10:01:00", previous)
        self.assertNotIn("18. 8. 2026 13:38:16", previous)

    def test_live_refresh_wiring_uses_direction_ids_and_stale_response_token(self):
        app = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
        self.assertIn('selected[kind][direction] = sel.value || ""', app)
        self.assertIn("REPORT.measurementSelectionToken", app)
        self.assertIn("if (token !== REPORT.measurementSelectionToken", app)
        self.assertIn('api("/api/report/refresh"', app)
        self.assertIn("schema: 2, current: {}, previous: {}", app)
        self.assertIn('panel.dataset.machineId === String(m.machine_id)', app)
        self.assertIn("window.scrollTo(0, scrollY)", app)


if __name__ == "__main__":
    unittest.main(verbosity=2)
