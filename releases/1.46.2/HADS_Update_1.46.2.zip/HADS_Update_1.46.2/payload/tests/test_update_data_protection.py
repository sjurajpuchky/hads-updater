"""End-to-end regression for 1.37.0 -> current HADS user-data protection.

No HTTP listener is started.  The test uses actual release archives, updater
code and persistent-store modules rather than a marker-only fixture.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]
APP_PARENT = ROOT.parent


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    # dataclass annotations resolve through sys.modules on newer Python.
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def tree_hash(root: Path) -> dict[str, str]:
    return {
        item.relative_to(root).as_posix(): hashlib.sha256(item.read_bytes()).hexdigest()
        for item in sorted(root.rglob("*")) if item.is_file()
    }


class RepresentativeDataUpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="HADS česká cesta & data ", dir=APP_PARENT)
        self.base = Path(self.temp.name)
        predecessor = APP_PARENT / "HADS_aplikace_v1.37.0.zip"
        if not predecessor.is_file():
            self.skipTest("Regrese vyžaduje skutečný plný balíček HADS 1.37.0.")
        with zipfile.ZipFile(predecessor) as archive:
            archive.extractall(self.base)
        self.install = self.base / "HADS_aplikace_v1.37.0" / "clean_seed" / "HADS"
        self._populate_representative_data()
        self.release = load("build_release_for_data_test", ROOT / "tools" / "build_release.py")
        self.update_zip = self.base / f"HADS_Update_{self.release.VERSION}.zip"
        self.release.build_update(self.update_zip)
        with zipfile.ZipFile(self.update_zip) as archive:
            archive.extractall(self.base)
        self.update_root = self.base / f"HADS_Update_{self.release.VERSION}"
        self.updater = load("hads_updater_real_1370", self.update_root / "hads_updater.py")

    def tearDown(self):
        self.temp.cleanup()

    def _populate_representative_data(self):
        data = self.install / "data"
        (data / "První závod.ndb").write_bytes(b"SQLite format 3\x00fixture-one" + b"x" * 5000)
        (data / "Druhý závod.ndb").write_bytes(b"SQLite format 3\x00fixture-two" + b"y" * 6000)
        (data / "První závod.ndb-wal").write_bytes(b"wal fixture")
        (data / "current.txt").write_text("Druhý závod.ndb\n", encoding="utf-8")
        (data / "library.json").write_text(json.dumps(
            {"První závod.ndb": "První provoz", "Druhý závod.ndb": "Druhý provoz"},
            ensure_ascii=False), encoding="utf-8")
        companies = {
            "podnik:První závod": {"name": "První závod", "technician": "Anna"},
            "podnik:Druhý závod": {"name": "Druhý závod", "technician": "Bohumil"},
        }
        for key, company in companies.items():
            slug = key.split(":", 1)[1]
            folder = data / "podniky" / slug
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "_key.txt").write_text(key, encoding="utf-8")
            (folder / "company.json").write_text(json.dumps(company, ensure_ascii=False), encoding="utf-8")
            (folder / "machine_config.json").write_text(json.dumps(
                {"M1": {"bearings": {"L1": {"bearing": {"designation": "6205"}}}}},
                ensure_ascii=False), encoding="utf-8")
            (folder / "report_settings.json").write_text(json.dumps(
                {"technicians": [company["technician"]], "quantities": {"velocity": "ISO RMS"}},
                ensure_ascii=False), encoding="utf-8")
            (folder / "report_drafts.json").write_text(json.dumps(
                {"draft": {
                    "title": "Návrh " + slug, "manual": "C", "show_previous": True,
                    "session": {"active_machine": "M1", "revision": 37},
                    "machines": [{"measurement_selection": {
                        "L4": {
                            "current_id": "2026-08-20T14:30:15#1",
                            "previous_id": "2026-08-20T09:00:00#1",
                        }
                    }}],
                }}, ensure_ascii=False), encoding="utf-8")
            (folder / "report_history.json").write_text(json.dumps(
                [{"id": slug, "title": "Historie " + slug, "doc": {
                    "conclusion": "v pořádku", "show_previous": True,
                    "machines": [{"measurement_selection": {
                        "L4": {
                            "current_id": "2026-08-20T14:30:15#1",
                            "previous_id": "2026-08-20T09:00:00#1",
                        }
                    }}],
                }}],
                ensure_ascii=False), encoding="utf-8")
        (data / "custom_norms.json").write_text(json.dumps(
            [{"name": "Vlastní norma", "classes": [{"name": "A", "warning": 3, "alarm": 5}]}],
            ensure_ascii=False), encoding="utf-8")
        (data / "ai_examples.json").write_text(json.dumps(
            {"examples": [{"input": "dummy", "output": "diagnostika"}]}, ensure_ascii=False), encoding="utf-8")
        self.custom_prompt_bytes = (
            b'{"format":1,"defaults_revision":"1.37.0","revision":41,'
            b'"overrides":{"report_brief_v2":{"text":"Vlastni styl {report_contract}"}}}\n'
        )
        (data / "ai_prompts.json").write_bytes(self.custom_prompt_bytes)
        (data / "shared_updates.json").write_text(json.dumps(
            {"format": 1, "source_path": "C:/sdílené", "automatic_startup_check": False,
             "last_check": None, "last_status": "fixture"}, ensure_ascii=False), encoding="utf-8")
        (data / "ai_config.json").write_text(json.dumps({"schema": 2, "model": "gpt-4o-mini"}), encoding="utf-8")
        # Skutečný přenositelný šifrovaný blob s neprodukční testovací hodnotou.
        # Tím ověřujeme současně blob, lokální fallback key i schopnost údaje
        # po výměně programu znovu dešifrovat; žádné reálné tajemství se nepoužije.
        self.secrets_before = load("ai_secrets_before_update", self.install / "backend" / "ai_secrets.py")
        self.secrets_before.LocalSecretStore(data, system_name="Linux").save(
            {"openai": "dummy-update-fixture-not-a-real-key"}
        )
        # Root legacy files are intentionally kept: startup migration must not
        # lose them before it creates per-company copies.
        (data / "report_history.json").write_text(json.dumps(
            {"podnik:Legacy": [{"id": "legacy", "title": "Historie legacy"}]}, ensure_ascii=False), encoding="utf-8")

    def test_actual_packaged_update_preserves_full_inventory_and_semantics(self):
        before = tree_hash(self.install / "data")
        self.assertEqual(self.updater.update(self.update_root, self.install), 0)
        self.assertEqual(tree_hash(self.install / "data"), before)
        backups = list((self.install / "updates" / "backups").glob("*/backup.json"))
        self.assertEqual(len(backups), 1)
        backup = backups[0].parent
        self.assertTrue((backup / "data_files" / "ai_credentials.bin").is_file())
        self.assertTrue((backup / "data_files" / "ai_credentials.machinekey").is_file())
        self.assertFalse(any(".ndb" in p.name.casefold() for p in (backup / "data_files").rglob("*")))
        guard = load("data_guard_after_real_update", self.install / "backend" / "data_protection.py")
        checked = guard.validate_pending_startup(self.install)
        self.assertTrue(checked and checked["ok"])
        self.assertEqual(json.loads((self.install / "data" / "podniky" / "První závod" / "report_settings.json").read_text(encoding="utf-8"))["technicians"], ["Anna"])
        self.assertEqual(json.loads((self.install / "data" / "podniky" / "Druhý závod" / "report_history.json").read_text(encoding="utf-8"))[0]["title"], "Historie Druhý závod")
        draft = json.loads((self.install / "data" / "podniky" / "První závod" / "report_drafts.json").read_text(encoding="utf-8"))["draft"]
        history = json.loads((self.install / "data" / "podniky" / "Druhý závod" / "report_history.json").read_text(encoding="utf-8"))[0]["doc"]
        expected_selection = {"L4": {"current_id": "2026-08-20T14:30:15#1", "previous_id": "2026-08-20T09:00:00#1"}}
        self.assertEqual(draft["machines"][0]["measurement_selection"], expected_selection)
        self.assertEqual(draft["session"], {"active_machine": "M1", "revision": 37})
        self.assertTrue(draft["show_previous"])
        self.assertEqual(history["machines"][0]["measurement_selection"], expected_selection)
        self.assertTrue(history["show_previous"])
        self.assertEqual(json.loads((self.install / "data" / "ai_config.json").read_text(encoding="utf-8"))["model"], "gpt-4o-mini")
        self.assertEqual((self.install / "data" / "ai_prompts.json").read_bytes(), self.custom_prompt_bytes)
        secrets_after = load("ai_secrets_after_update", self.install / "backend" / "ai_secrets.py")
        self.assertEqual(
            secrets_after.LocalSecretStore(self.install / "data", system_name="Linux").load()["openai"],
            "dummy-update-fixture-not-a-real-key",
        )
        self.assertEqual(self.updater.rollback(self.install), 0)
        self.assertEqual(tree_hash(self.install / "data"), before)
        self.assertEqual((self.install / "data" / "ai_prompts.json").read_bytes(), self.custom_prompt_bytes)

    def test_data_recovery_preview_never_overwrites_divergent_file_without_confirmation(self):
        self.assertEqual(self.updater.update(self.update_root, self.install), 0)
        missing = self.install / "data" / "podniky" / "První závod" / "report_drafts.json"
        changed = self.install / "data" / "podniky" / "Druhý závod" / "report_history.json"
        missing.unlink()
        changed.write_text('[{"title":"novější práce uživatele"}]', encoding="utf-8")
        preview = self.updater.data_recovery_preview(self.install)
        self.assertIn("data/podniky/První závod/report_drafts.json", preview["recoverable_missing"])
        self.assertIn("data/podniky/Druhý závod/report_history.json", preview["conflicts"])
        restored = self.updater.recover_data(self.install, confirm_overwrite=False)
        self.assertTrue(missing.exists())
        self.assertEqual(json.loads(changed.read_text(encoding="utf-8"))[0]["title"], "novější práce uživatele")
        self.assertIn("data/podniky/Druhý závod/report_history.json", restored["skipped"])

    def test_credential_pair_recovery_is_complete_unambiguous_and_never_fills_half_pair(self):
        self.assertEqual(self.updater.update(self.update_root, self.install), 0)
        credentials = self.install / "data" / "ai_credentials.bin"
        machine_key = self.install / "data" / "ai_credentials.machinekey"
        original_blob, original_key = credentials.read_bytes(), machine_key.read_bytes()

        # Both components missing: exactly one updater inventory can restore the
        # hash-verified pair; no broad-disk lookup is used.
        credentials.unlink()
        machine_key.unlink()
        preview = self.updater.data_recovery_preview(self.install)
        self.assertIn("data/ai_credentials.bin", preview["recoverable_missing"])
        self.assertIn("data/ai_credentials.machinekey", preview["recoverable_missing"])
        restored = self.updater.recover_data(self.install, confirm_overwrite=False)
        self.assertIn("data/ai_credentials.bin", restored["restored"])
        self.assertIn("data/ai_credentials.machinekey", restored["restored"])
        self.assertEqual(credentials.read_bytes(), original_blob)
        self.assertEqual(machine_key.read_bytes(), original_key)

        # A current half-pair is ambiguous/conflicting.  Recovery must preserve
        # it, not silently add/recreate the other half.
        machine_key.unlink()
        preview = self.updater.data_recovery_preview(self.install)
        self.assertIn("credentials", preview["incomplete_pairs"])
        self.assertNotIn("data/ai_credentials.machinekey", preview["recoverable_missing"])
        self.updater.recover_data(self.install, confirm_overwrite=False)
        self.assertEqual(credentials.read_bytes(), original_blob)
        self.assertFalse(machine_key.exists())

    def test_actual_137_upgrade_without_prompt_file_serves_bundled_defaults(self):
        # 1.37 installations predate the prompt editor, so no override file is
        # a normal upgrade state, not data loss or an HTTP error.
        prompt_path = self.install / "data" / "ai_prompts.json"
        prompt_path.unlink()
        before = tree_hash(self.install / "data")
        self.assertEqual(self.updater.update(self.update_root, self.install), 0)
        self.assertEqual(tree_hash(self.install / "data"), before)
        prompts = load("ai_prompts_after_137_without_override", self.install / "backend" / "ai_prompts.py")
        self.assertGreaterEqual(len(prompts.public_config()["templates"]), 3)
        self.assertFalse(prompt_path.exists())

    def test_full_archive_has_no_mergeable_hads_root_and_guarded_installer(self):
        full = self.base / f"HADS_aplikace_v{self.release.VERSION}.zip"
        self.release.build_clean_application(full)
        with zipfile.ZipFile(full) as archive:
            names = archive.namelist()
        self.assertTrue(all(not name.startswith("HADS/data/") for name in names))
        self.assertIn(f"HADS_aplikace_v{self.release.VERSION}/Instalovat HADS.bat", names)
        installer = next(name for name in names if name.endswith("Instalovat HADS.bat"))
        with zipfile.ZipFile(full) as archive:
            self.assertIn("existují data HADS", archive.read(installer).decode("utf-8"))


class CompanyFolderIdentityRepairTests(unittest.TestCase):
    """DB rename/slug repair must preserve all files rather than merge-delete."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="HADS podnik mapping ")
        self.base = Path(self.temp.name)
        self.store = load("data_store_identity_repair", ROOT / "backend" / "data_store.py")
        self.store._DATA_DIR = self.base / "data"
        self.store._PODNIKY_DIR = self.store._DATA_DIR / "podniky"
        self.store._PODNIKY_DIR.mkdir(parents=True)

    def tearDown(self):
        self.temp.cleanup()

    def test_rename_moves_entire_directory_and_collision_leaves_source_intact(self):
        old = self.store._PODNIKY_DIR / "stary.ndb"
        old.mkdir()
        (old / "_key.txt").write_text("stary.ndb", encoding="utf-8")
        (old / "report_history.json").write_text('[{"title":"Historie"}]', encoding="utf-8")
        (old / "unrecognized-user-file.txt").write_text("must survive", encoding="utf-8")
        self.assertTrue(self.store.rename_podnik("stary.ndb", "podnik:Nový závod"))
        target = self.store._PODNIKY_DIR / "Nový závod"
        self.assertEqual((target / "unrecognized-user-file.txt").read_text(encoding="utf-8"), "must survive")
        collision = self.store._PODNIKY_DIR / "kolize.ndb"; collision.mkdir()
        (collision / "report_history.json").write_text('[{"title":"Staré"}]', encoding="utf-8")
        self.assertFalse(self.store.rename_podnik("kolize.ndb", "podnik:Nový závod"))
        self.assertTrue((collision / "report_history.json").exists())

    def test_unique_orphan_mapping_repairs_old_filename_without_duplication(self):
        orphan = self.store._PODNIKY_DIR / "db_2025"
        orphan.mkdir()
        (orphan / "_key.txt").write_text("db_2025.ndb", encoding="utf-8")
        (orphan / "company.json").write_text('{"name":"Závod Žlutý"}', encoding="utf-8")
        (orphan / "report_settings.json").write_text('{"technicians":["Eva"]}', encoding="utf-8")
        result = self.store.repair_orphan_mapping("podnik:Závod Žlutý", aliases=("db_2025.ndb",))
        target = self.store._PODNIKY_DIR / "Závod Žlutý"
        self.assertEqual(result["status"], "repaired")
        self.assertFalse(orphan.exists())
        self.assertEqual(json.loads((target / "report_settings.json").read_text(encoding="utf-8"))["technicians"], ["Eva"])


if __name__ == "__main__":
    unittest.main()
