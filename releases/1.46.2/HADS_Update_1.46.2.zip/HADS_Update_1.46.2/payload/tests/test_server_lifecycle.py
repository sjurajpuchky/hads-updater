"""Lock and authenticated-shutdown units; intentionally never start HTTPServer."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

def load_server():
    spec = importlib.util.spec_from_file_location("hads_server_lifecycle", ROOT / "backend" / "server.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class ServerLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = load_server()

    def test_lock_format_is_atomic_and_contains_identity_not_public_api_token(self):
        s = self.server
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "Česká složka & (HADS)"; data = root / "data"; data.mkdir(parents=True)
            old = (s.BASE_DIR, s.DATA_DIR, s._SERVER_LOCK_FILE, s._SHUTDOWN_TOKEN, s._process_identity)
            try:
                s.BASE_DIR = root; s.DATA_DIR = data; s._SERVER_LOCK_FILE = data / "hads_server.lock"
                s._SHUTDOWN_TOKEN = "a" * 64; s._process_identity = lambda: "proc-start:77"
                s._write_server_lock(8123)
                rec = json.loads(s._SERVER_LOCK_FILE.read_text(encoding="utf-8"))
                self.assertEqual(rec["format"], 2); self.assertEqual(rec["port"], 8123)
                self.assertEqual(rec["installation_root"], str(root.resolve()))
                self.assertEqual(rec["process_identity"], "proc-start:77")
                self.assertEqual(rec["shutdown_token"], "a" * 64)
                status, body = s._api_handler("/api/health", "GET")
                self.assertEqual((status, body["ok"]), (200, True))
                self.assertNotIn("shutdown_token", body)
            finally:
                s.BASE_DIR, s.DATA_DIR, s._SERVER_LOCK_FILE, s._SHUTDOWN_TOKEN, s._process_identity = old

    def test_shutdown_token_and_loopback_are_strict(self):
        s = self.server; old = s._SHUTDOWN_TOKEN
        try:
            s._SHUTDOWN_TOKEN = "sekret-123"
            self.assertTrue(s._valid_shutdown_token("sekret-123"))
            self.assertFalse(s._valid_shutdown_token("sekret-124"))
            self.assertFalse(s._valid_shutdown_token(None))
            self.assertTrue(s._is_loopback_peer(("127.0.0.1", 42)))
            self.assertTrue(s._is_loopback_peer(("::1", 42, 0, 0)))
            self.assertFalse(s._is_loopback_peer(("192.168.1.3", 42)))
            self.assertFalse(s._is_loopback_peer(None))
        finally:
            s._SHUTDOWN_TOKEN = old

    def test_shutdown_is_scheduled_outside_request_thread(self):
        s = self.server
        class Fake:
            def __init__(self): self.called = False
            def shutdown(self): self.called = True
        fake = Fake(); old = s._SERVER
        try:
            s._SERVER = fake; s._schedule_shutdown()
            import time
            end = time.monotonic() + 1
            while not fake.called and time.monotonic() < end: time.sleep(.01)
            self.assertTrue(fake.called)
        finally:
            s._SERVER = old

if __name__ == "__main__":
    unittest.main()

class StartupFailureRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = load_server()

    def test_port_bind_failure_happens_before_lock_and_does_not_start_http_server(self):
        """Regression for the opaque launcher timeout: bind failure exits immediately."""
        from unittest import mock
        s = self.server
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); data = root / "data"; data.mkdir()
            old = (s.BASE_DIR, s.DATA_DIR, s._SERVER_LOCK_FILE)
            try:
                s.BASE_DIR, s.DATA_DIR, s._SERVER_LOCK_FILE = root, data, data / "hads_server.lock"
                with mock.patch.object(s, "ThreadingHTTPServer", side_effect=OSError(10048, "address already in use")):
                    with self.assertRaises(OSError):
                        s.main()
                self.assertFalse(s._SERVER_LOCK_FILE.exists())
            finally:
                s.BASE_DIR, s.DATA_DIR, s._SERVER_LOCK_FILE = old
