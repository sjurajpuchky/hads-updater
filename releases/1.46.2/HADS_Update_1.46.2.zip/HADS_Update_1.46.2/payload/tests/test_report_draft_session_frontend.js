"use strict";
const assert = require("assert");
const Session = require("../frontend/report_draft_session.js");

class MemoryStorage {
  constructor() { this.values = new Map(); }
  getItem(key) { return this.values.has(key) ? this.values.get(key) : null; }
  setItem(key, value) { this.values.set(key, String(value)); }
  removeItem(key) { this.values.delete(key); }
}

const storage = new MemoryStorage();
const a = "company:104:Moravia Cans 104|ndb:moravia-ranni.ndb";
const b = "company:104:Moravia Cans 104|ndb:moravia-odpoledni.ndb";
const sameFilenameOtherCompany = "company:9:Jiný podnik|ndb:moravia-ranni.ndb";
Session.save(storage, a, {
  draft: {
    intro: "rozepsaný úvod", header_left: "HADS", include_graphs: true,
    machines: [{ problem: "L2", zaver: "Závěr", doporuceni: "Doporučení",
      severity_override: "C", graphs: [{ markers: [{ x: 1, text: "1X" }] }] }],
  },
  setup: { checked_machine_ids: [104, 105], model: "gpt-4o-mini" },
  session_id: "one", revision: 5,
});
Session.save(storage, b, {
  draft: { intro: "jiný export" }, setup: { checked_machine_ids: [9] },
  session_id: "two", revision: 1,
});

// Simuluje návrat z karty stroje: neuložený input i výběr strojů zůstávají.
assert.equal(Session.load(storage, a).draft.intro, "rozepsaný úvod");
assert.deepEqual(Session.load(storage, a).setup.checked_machine_ids, [104, 105]);
assert.equal(Session.load(storage, a).setup.model, "gpt-4o-mini");
assert.equal(Session.load(storage, a).draft.machines[0].severity_override, "C");
assert.equal(Session.load(storage, a).draft.machines[0].graphs[0].markers[0].text, "1X");
assert.equal(Session.load(storage, b).draft.intro, "jiný export");
assert.equal(Session.load(storage, sameFilenameOtherCompany), null);

// Odpověď GET zahájená před editací se nesmí použít přes novější DOM/snapshot.
assert.equal(Session.shouldApplyRemote({
  requestToken: 2, activeToken: 2, requestRevision: 4, currentRevision: 5,
  hasLocalSnapshot: true, context: a, activeContext: a,
}), false);
assert.equal(Session.shouldApplyRemote({
  requestToken: 3, activeToken: 3, requestRevision: 5, currentRevision: 5,
  hasLocalSnapshot: false, context: a, activeContext: a,
}), true);
console.log("frontend report draft session: ok");
