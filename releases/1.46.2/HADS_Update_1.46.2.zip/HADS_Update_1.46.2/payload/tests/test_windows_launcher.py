"""Static/unit checks for the native launcher; no HTTP server is started."""
from __future__ import annotations
import json
from pathlib import Path
import re
import struct
import unittest

ROOT = Path(__file__).resolve().parents[1]

class WindowsLauncherTests(unittest.TestCase):
    def test_native_pe64_gui_metadata_and_icon_resources(self):
        exe = (ROOT / "HADS.exe").read_bytes()
        self.assertEqual(exe[:2], b"MZ")
        pe = struct.unpack_from("<I", exe, 0x3C)[0]
        self.assertEqual(exe[pe:pe + 4], b"PE\0\0")
        machine, sections = struct.unpack_from("<HH", exe, pe + 4)
        self.assertEqual(machine, 0x8664)
        self.assertGreaterEqual(sections, 3)
        optional = pe + 24
        self.assertEqual(struct.unpack_from("<H", exe, optional)[0], 0x20B)
        self.assertEqual(struct.unpack_from("<H", exe, optional + 68)[0], 2)  # GUI subsystem
        low = exe.lower()
        # Nativní spouštěč se verzuje samostatně a překládá se jen tehdy, když
        # se změní jeho vlastní zdroj; nemusí tedy sdílet číslo vydání
        # aplikace. Očekávané číslo proto čteme z jeho resource skriptu, aby
        # kontrola zůstala pravdivá i u vydání, které launcher nemění.
        rc = (ROOT / "launcher" / "hads_launcher.rc").read_text(encoding="utf-8")
        launcher_version = re.search(r'VALUE "FileVersion", "([0-9.]+)', rc).group(1)
        for label in ("HADS", "FileDescription", "ProductName", launcher_version):
            self.assertIn(label.encode("utf-16le").lower(), low)
        self.assertIn(b"\x00\x01\x00", (ROOT / "assets" / "hads.ico").read_bytes()[:6])

    def test_launcher_source_has_safe_restart_shortcut_and_waiting_design(self):
        source = (ROOT / "launcher" / "hads_launcher.c").read_text(encoding="utf-8")
        for required in ("GetModuleFileNameW", "CreateProcessW", "CREATE_NO_WINDOW",
                         "api/health", "api/internal/shutdown", "GetProcessTimes",
                         "SHGetKnownFolderPath", "IShellLinkW_SetWorkingDirectory",
                         "IShellLinkW_SetIconLocation", "HADS.exe", "--create-shortcut",
                         "--no-browser", "choose_loopback_port", "STARTF_USESTDHANDLES",
                         "hads_server.log", "backend_ukončen_pred_health", "GetExitCodeProcess",
                         "--replace-database", "run_replace_supervisor",
                         "CREATE_BREAKAWAY_FROM_JOB", "database_supervisor_", "helper_exit"):
            self.assertIn(required, source)
        self.assertIn("wait_backend_lock_release", source)
        self.assertIn("receipt_reports_restart", source)
        self.assertIn("česk", (ROOT / "README.md").read_text(encoding="utf-8").casefold())
        self.assertNotIn("hads_shutdown.token", source)
        self.assertIn("STARTUP_WAIT_MS", source)
        self.assertNotIn('HADS_PORT",L"8000"', source)
        self.assertIn('HADS.lnk', source)  # fixed known desktop filename avoids duplicates
        self.assertNotIn('\\Desktop\\HADS.lnk', source)  # known folder, including OneDrive redirect
        self.assertIn("TerminateProcess(p,1)", source)
        self.assertIn("same_process(&r)", source)  # never terminate by PID alone

    def test_build_uses_cross_compiler_reproducibly_without_console(self):
        build = (ROOT / "launcher" / "build_windows_launcher.sh").read_text(encoding="utf-8")
        self.assertIn("x86_64-w64-mingw32-gcc", build)
        self.assertIn("-mwindows", build)
        self.assertIn("--no-insert-timestamp", build)
        self.assertIn("-static", build)

    def test_full_package_declarations_keep_runtime_out_of_updates(self):
        release = (ROOT / "tools" / "build_release.py").read_text(encoding="utf-8")
        self.assertIn('"HADS.exe"', release)
        self.assertIn("runtime_source", release)
        updater = (ROOT / "tools" / "hads_updater.py").read_text(encoding="utf-8")
        self.assertIn('"HADS.exe"', updater)
        self.assertNotIn('"runtime"', updater.split("CONTROLLED_ROOTS", 1)[1].split("\n", 1)[0])

    def test_portable_runtime_layout_has_stdlib_and_required_native_extensions(self):
        import zipfile
        runtime = ROOT / "runtime"
        self.assertEqual((runtime / "python312._pth").read_text(encoding="utf-8"), "python312.zip\n.\n")
        with zipfile.ZipFile(runtime / "python312.zip") as archive:
            names = set(archive.namelist())
        for member in ("encodings/__init__.pyc", "http/server.pyc", "sqlite3/__init__.pyc", "threading.pyc", "hmac.pyc", "ipaddress.pyc"):
            self.assertIn(member, names)
        for native in ("pythonw.exe", "python312.dll", "_sqlite3.pyd", "sqlite3.dll", "vcruntime140.dll"):
            self.assertTrue((runtime / native).is_file(), native)


if __name__ == "__main__":
    unittest.main()
