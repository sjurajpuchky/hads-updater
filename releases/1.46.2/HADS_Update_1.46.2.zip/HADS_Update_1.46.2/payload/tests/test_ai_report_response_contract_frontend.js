"use strict";
const assert = require("assert");
const fs = require("fs");
const vm = require("vm");

const source = fs.readFileSync(require("path").join(__dirname, "..", "frontend", "app.js"), "utf8");
const start = source.indexOf("const REPORT_AI_RESPONSE_SHAPE_ERROR =");
const end = source.indexOf("function fillReportEditor(doc)", start);
assert(start >= 0 && end > start, "AI response-contract guard must remain before editor rendering");
const sandbox = {};
vm.createContext(sandbox);
vm.runInContext(source.slice(start, end), sandbox);

const malformed = {machines: [{problem: "OK", zaver: {body: "bad"}, doporuceni: "Měřte."}]};
const legacyEscapeHtml = (s) => (s || "").replace(/[&<>"']/g, () => "");
assert.throws(
  () => legacyEscapeHtml(malformed.machines[0].zaver),
  /replace is not a function/,
  "1.39.0 exact escape expression must deterministically fail on the object payload"
);
assert.throws(
  () => sandbox.assertReportAiTextContract(malformed),
  (error) => error && error.message ===
    "AI odpověď nemá podporovaný tvar pro návrh protokolu. Zkuste akci zopakovat nebo změňte model.",
  "frontend must reject an object before it reaches escapeHtml/innerHTML"
);
assert.doesNotThrow(() => sandbox.assertReportAiTextContract({
  machines: [{problem: "OK", zaver: "Text", doporuceni: "Měřte."}],
}));
console.log("frontend AI report response contract: ok");
