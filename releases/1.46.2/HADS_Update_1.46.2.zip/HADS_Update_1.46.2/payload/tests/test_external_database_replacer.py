"""Regression tests for 1.34.4's supervised post-backend-exit replacement."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT / "tests"))
from database_update import (  # noqa: E402
    DatabaseBusy, DatabaseUpdateCoordinator, UpdateError, acknowledge_database_update_receipt,
    pending_database_update_receipt, recover_abandoned_database_update, sha256_file,
)
import database_update as DB_UPDATE  # noqa: E402
import process_identity as PROCESS_IDENTITY  # noqa: E402
import server as SERVER  # noqa: E402
from ndb_fixture_builder import build_fixture_ndb  # noqa: E402


def load_helper():
    spec = importlib.util.spec_from_file_location("hads_database_replacer_test", ROOT / "tools" / "hads_database_replacer.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


HELPER = load_helper()


class ExternalDatabaseReplacerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="HADS Česká cesta & (výměna) ")
        self.root = Path(self.temp.name) / "HADS"
        self.data = self.root / "data"
        self.jobs = self.root / "updates" / "database_jobs"
        self.data.mkdir(parents=True)
        (self.root / "backend").mkdir()
        (self.root / "HADS.exe").write_bytes(b"test launcher")
        self.target = self.data / "Edwards.nDb"
        build_fixture_ndb(self.target, [{"name": "ISO RMS", "value": 1.0, "limits_xml": None}], plant_name="Český závod")
        self.staged = self.jobs / "staging" / "new.ndb"
        self.staged.parent.mkdir(parents=True)
        build_fixture_ndb(self.staged, [{"name": "ISO RMS", "value": 9.0, "limits_xml": None}], plant_name="Český závod")

    def tearDown(self):
        self.temp.cleanup()

    def job(self, **changes):
        job_id = "A" * 32
        result = self.jobs / "results" / f"{job_id}.json"
        job = {
            "format": 3, "job_id": job_id, "created_at": time.time(), "expires_at": time.time() + 60,
            "installation_root": str(self.root.resolve()),
            "installation_fingerprint": __import__("hashlib").sha256(str(self.root.resolve()).casefold().encode()).hexdigest(),
            "target_path": str(self.target.resolve()), "staged_path": str(self.staged.resolve()),
            "target_size": self.target.stat().st_size, "target_sha256": sha256_file(self.target),
            "source_size": self.staged.stat().st_size, "source_sha256": sha256_file(self.staged),
            "expected_company_identity": "Český závod", "source_name": "Nová data Žluťoučký.ndb",
            "source_last_modified": "1787071200000", "backend_pid": os.getpid(),
            "backend_process_identity": HELPER.process_identity(os.getpid()) or "proc-start:1",
            "backend_version": "1.34.4", "restart_executable": str((self.root / "HADS.exe").resolve()),
            "log_path": str((self.root / "updates" / "logs" / "database_update_test.log").resolve()),
            "result_path": str(result.resolve()), "active_lock_path": str((self.jobs / "active.json").resolve()),
            "ready_path": str((self.jobs / "ready" / f"{job_id}.json").resolve()),
            "challenge_path": str((self.jobs / "challenges" / f"{job_id}.json").resolve()),
            "response_path": str((self.jobs / "responses" / f"{job_id}.json").resolve()),
            "cancel_path": str((self.jobs / "cancelled" / f"{job_id}.json").resolve()),
            "helper_nonce": "a" * 64,
            "parent_wait_seconds": 1, "lock_retry_seconds": 0.2,
        }
        job.update(changes)
        return job

    def _ready_payload(self, job, *, helper_pid=None, helper_identity=None):
        helper_pid = os.getpid() if helper_pid is None else helper_pid
        helper_identity = HELPER.process_identity(helper_pid) if helper_identity is None else helper_identity
        return {
            "format": 2, "job_id": job["job_id"], "helper_nonce": job["helper_nonce"],
            "helper_pid": helper_pid, "helper_process_identity": helper_identity,
            "installation_root": job["installation_root"], "target_path": job["target_path"],
            "staged_path": job["staged_path"], "log_path": job["log_path"],
            "ready_proof": HELPER.handshake_mac(
                job["helper_nonce"], "ready-v2", job["job_id"], helper_pid,
                helper_identity, job["installation_root"], job["target_path"], job["staged_path"],
            ),
        }

    def _respond_to_challenge(self, job):
        """Simulate the living pythonw child after the backend emits challenge."""
        def responder():
            path = Path(job["challenge_path"])
            deadline = time.monotonic() + 2
            while time.monotonic() < deadline and not path.is_file():
                time.sleep(.01)
            if not path.is_file():
                return
            value = json.loads(path.read_text(encoding="utf-8"))
            identity = HELPER.process_identity(os.getpid())
            response = {
                "format": 2, "job_id": job["job_id"], "helper_nonce": job["helper_nonce"],
                "helper_pid": os.getpid(), "helper_process_identity": identity,
                "response_proof": HELPER.handshake_mac(
                    job["helper_nonce"], "response-v2", job["job_id"], value["challenge"],
                    os.getpid(), identity,
                ),
            }
            output = Path(job["response_path"])
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(response), encoding="utf-8")
        thread = threading.Thread(target=responder, daemon=True)
        thread.start()
        return thread

    def test_helper_waits_for_exact_parent_before_same_company_swap_and_removes_old_sidecars(self):
        for suffix, raw in (("-wal", b"old WAL"), ("-shm", b"old SHM")):
            Path(str(self.target) + suffix).write_bytes(raw)
        child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(.18)"])
        job = self.job(backend_pid=child.pid, backend_process_identity=HELPER.process_identity(child.pid), parent_wait_seconds=3)
        before_wait = time.monotonic()
        HELPER.wait_for_exact_parent(child.pid, job["backend_process_identity"], 3)
        child.wait(timeout=1)
        self.assertGreaterEqual(time.monotonic() - before_wait, .10)
        result = HELPER.perform(job, self.root.resolve())
        self.assertTrue(result["success"])
        self.assertEqual(sha256_file(self.target), job["source_sha256"])
        self.assertFalse(Path(str(self.target) + "-wal").exists())
        self.assertFalse(Path(str(self.target) + "-shm").exists())

    def test_winerror_32_after_parent_exit_retries_then_succeeds(self):
        attempts = []
        real_replace = HELPER.os.replace
        def locked(source, destination):
            if str(source).endswith("-wal") and len(attempts) < 2:
                attempts.append(1)
                exc = PermissionError(13, "sharing violation", str(source)); exc.winerror = 32
                raise exc
            return real_replace(source, destination)
        Path(str(self.target) + "-wal").write_bytes(b"old WAL")
        with mock.patch.object(HELPER.os, "replace", side_effect=locked):
            result = HELPER.perform(self.job(lock_retry_seconds=1), self.root.resolve())
        self.assertTrue(result["success"])
        self.assertEqual(len(attempts), 2)

    def test_success_preserves_current_display_and_company_json_and_receipt_is_one_time(self):
        protected = {
            self.data / "current.txt": b"Edwards.nDb\n",
            self.data / "library.json": b'{"Edwards.nDb":"Vlastni nazev"}',
            self.data / "podniky" / "cesky-zavod" / "machine_config.json": b'{"limit":7}',
        }
        for path, raw in protected.items():
            path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(raw)
        result = HELPER.perform(self.job(), self.root.resolve())
        self.assertTrue(result["success"])
        self.assertEqual({p: p.read_bytes() for p in protected}, protected)
        receipt_id = "B" * 32
        receipt_path = self.jobs / "results" / f"{receipt_id}.json"; receipt_path.parent.mkdir(parents=True, exist_ok=True)
        receipt_payload = {"job_id": receipt_id, "success": True, "source_name": "zdroj.ndb"}
        receipt_path.write_text(json.dumps(receipt_payload), encoding="utf-8")
        self.assertEqual(pending_database_update_receipt(self.root)["job_id"], receipt_id)
        acknowledge_database_update_receipt(self.root, receipt_id)
        self.assertIsNone(pending_database_update_receipt(self.root))

    def test_external_lock_timeout_restores_exact_main_and_sidecars(self):
        wal = Path(str(self.target) + "-wal"); wal.write_bytes(b"byte exact old wal")
        before_main, before_wal = self.target.read_bytes(), wal.read_bytes()
        real_replace = HELPER.os.replace
        def locked(source, destination):
            if str(source).endswith("-wal"):
                exc = PermissionError(13, "sharing violation", str(source)); exc.winerror = 33
                raise exc
            return real_replace(source, destination)
        with mock.patch.object(HELPER.os, "replace", side_effect=locked):
            result = HELPER.perform(self.job(lock_retry_seconds=.1), self.root.resolve())
        self.assertFalse(result["success"])
        self.assertTrue(result["old_verified_restored"])
        self.assertEqual(self.target.read_bytes(), before_main)
        self.assertEqual(wal.read_bytes(), before_wal)

    def test_failure_after_old_main_move_restores_byte_identical_main_and_sidecars(self):
        wal = Path(str(self.target) + "-wal"); wal.write_bytes(b"old WAL bytes")
        before = {p: p.read_bytes() for p in (self.target, wal)}
        real_replace = HELPER.os.replace
        def fail_staged(source, destination):
            if Path(source) == self.staged and Path(destination) == self.target:
                raise OSError("injected failure after main move")
            return real_replace(source, destination)
        with mock.patch.object(HELPER.os, "replace", side_effect=fail_staged):
            result = HELPER.perform(self.job(), self.root.resolve())
        self.assertFalse(result["success"])
        self.assertTrue(result["old_verified_restored"])
        self.assertEqual({p: p.read_bytes() for p in before}, before)

    def test_pid_reuse_identity_and_traversal_or_symlink_descriptors_are_rejected(self):
        with self.assertRaisesRegex(HELPER.HelperError, "jinému procesu|změnil identitu"):
            HELPER.wait_for_exact_parent(os.getpid(), "proc-start:not-the-current-one", .1)
        job = self.job(staged_path=str((self.root / "outside.ndb").resolve()))
        descriptor = self.jobs / ("job_" + job["job_id"] + ".json")
        descriptor.write_text(json.dumps(job), encoding="utf-8")
        with self.assertRaisesRegex(HELPER.HelperError, "Staging databáze je mimo"):
            HELPER.load_job(str(descriptor))
        # Even an in-root symlink never becomes an accepted target.
        outside = self.root / "outside.ndb"; shutil.copy2(self.target, outside)
        self.target.unlink(); self.target.symlink_to(outside)
        job = self.job()
        descriptor.write_text(json.dumps(job), encoding="utf-8")
        with self.assertRaisesRegex(HELPER.HelperError, "mimo povolenou|symbolický odkaz"):
            HELPER.load_job(str(descriptor))

    def test_preflight_spawn_failure_leaves_backend_target_and_sidecars_untouched_and_rejects_double_click(self):
        (self.root / "tools").mkdir()
        shutil.copy2(ROOT / "tools" / "hads_database_replacer.py", self.root / "tools" / "hads_database_replacer.py")
        upload = self.data / ".upload.tmp"
        shutil.copy2(self.staged, upload)
        wal = Path(str(self.target) + "-wal"); wal.write_bytes(b"untouched")
        before = (self.target.read_bytes(), wal.read_bytes())
        coordinator = DatabaseUpdateCoordinator(
            self.root, self.data, lambda: self.target.name,
            backend_identity=lambda: HELPER.process_identity(os.getpid()), installation_fingerprint=lambda: __import__("hashlib").sha256(str(self.root.resolve()).casefold().encode()).hexdigest(),
            version="1.34.3", popen=mock.Mock(side_effect=OSError("cannot spawn")),
        )
        with self.assertRaises(OSError):
            coordinator.prepare_and_spawn({"path": upload, "received_size": upload.stat().st_size, "sha256": sha256_file(upload), "source_name": "zdroj.ndb"})
        self.assertEqual((self.target.read_bytes(), wal.read_bytes()), before)
        self.assertFalse((self.jobs / "active.json").exists())
        # An existing handoff lock is an explicit concurrent/double-click rejection.
        (self.jobs).mkdir(parents=True, exist_ok=True)
        (self.jobs / "active.json").write_text("{}", encoding="utf-8")
        upload2 = self.data / ".upload2.tmp"; shutil.copy2(self.staged, upload2)
        with self.assertRaises(DatabaseBusy):
            coordinator.prepare_and_spawn({"path": upload2, "received_size": upload2.stat().st_size, "sha256": sha256_file(upload2), "source_name": "zdroj.ndb"})

    def _handshake_coordinator(self, callback):
        (self.root / "tools").mkdir(exist_ok=True)
        shutil.copy2(ROOT / "tools" / "hads_database_replacer.py", self.root / "tools" / "hads_database_replacer.py")
        upload = self.data / ".handshake-upload.tmp"; shutil.copy2(self.staged, upload)
        return (
            DatabaseUpdateCoordinator(
                self.root, self.data, lambda: self.target.name,
                backend_identity=lambda: HELPER.process_identity(os.getpid()),
                installation_fingerprint=lambda: __import__("hashlib").sha256(str(self.root.resolve()).casefold().encode()).hexdigest(),
                version="1.34.4", popen=callback,
            ),
            {"path": upload, "received_size": upload.stat().st_size, "sha256": sha256_file(upload), "source_name": "žluťoučký & nový.ndb"},
        )

    def test_no_shutdown_handoff_when_child_exits_before_ready_or_ready_nonce_is_forged(self):
        class Dead:
            def poll(self): return 87
            def terminate(self): pass
        coordinator, uploaded = self._handshake_coordinator(lambda *_args, **_kwargs: Dead())
        before = self.target.read_bytes()
        with self.assertRaisesRegex(UpdateError, "ukončil před potvrzením"):
            coordinator.prepare_and_spawn(uploaded)
        self.assertEqual(self.target.read_bytes(), before)
        self.assertFalse((self.jobs / "active.json").exists())

        def forged(command, **_kwargs):
            descriptor = Path(command[-1]); job = json.loads(descriptor.read_text(encoding="utf-8"))
            log = Path(job["log_path"]); log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text("phase=helper_started\\n", encoding="utf-8")
            ready = dict(format=2, job_id=job["job_id"], helper_nonce="0" * 64,
                         helper_pid=os.getpid(), helper_process_identity=HELPER.process_identity(os.getpid()),
                         installation_root=job["installation_root"], target_path=job["target_path"],
                         staged_path=job["staged_path"], log_path=job["log_path"],
                         ready_proof="forged")
            Path(job["ready_path"]).parent.mkdir(parents=True, exist_ok=True)
            Path(job["ready_path"]).write_text(json.dumps(ready), encoding="utf-8")
            return type("Alive", (), {"poll": lambda self: None, "terminate": lambda self: None})()
        coordinator, uploaded = self._handshake_coordinator(forged)
        with self.assertRaisesRegex(UpdateError, "neodpovídá"):
            coordinator.prepare_and_spawn(uploaded)
        self.assertFalse((self.jobs / "active.json").exists())

    def test_valid_ready_handshake_precedes_external_handoff_and_abandoned_job_becomes_receipt(self):
        def ready(command, **_kwargs):
            descriptor = Path(command[-1]); job = json.loads(descriptor.read_text(encoding="utf-8"))
            log = Path(job["log_path"]); log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text("2026 phase=helper_started\\n", encoding="utf-8")
            payload = self._ready_payload(job)
            path = Path(job["ready_path"]); path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(payload), encoding="utf-8")
            self._respond_to_challenge(job)
            return type("Alive", (), {"poll": lambda self: None, "terminate": lambda self: None})()
        coordinator, uploaded = self._handshake_coordinator(ready)
        accepted = coordinator.prepare_and_spawn(uploaded)
        self.assertTrue(accepted["accepted"])
        descriptor = self.jobs / ("job_" + accepted["job_id"] + ".json")
        job = json.loads(descriptor.read_text(encoding="utf-8"))
        # Simulates a killed detached helper after ready and a later manual
        # launcher restart; recovery must show a concrete one-time receipt.
        job["backend_pid"] = 99999999; job["backend_process_identity"] = "proc-start:gone"
        descriptor.write_text(json.dumps(job), encoding="utf-8")
        recovered = recover_abandoned_database_update(self.root)
        self.assertTrue(recovered and recovered["abandoned"])
        self.assertIn("database_update_", recovered["log_path"])

    def test_1344_supervisor_pythonw_pid_mismatch_is_accepted_only_after_live_challenge(self):
        """HADS.exe supervisor PID deliberately differs from pythonw.exe PID."""
        supervisor = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(3)"])
        try:
            def ready(command, **_kwargs):
                job = json.loads(Path(command[-1]).read_text(encoding="utf-8"))
                log = Path(job["log_path"]); log.parent.mkdir(parents=True, exist_ok=True)
                log.write_text("phase=helper_started\n", encoding="utf-8")
                ready_path = Path(job["ready_path"]); ready_path.parent.mkdir(parents=True, exist_ok=True)
                ready_path.write_text(json.dumps(self._ready_payload(job)), encoding="utf-8")
                self._respond_to_challenge(job)
                return supervisor

            coordinator, uploaded = self._handshake_coordinator(ready)
            accepted = coordinator.prepare_and_spawn(uploaded)
            self.assertTrue(accepted["accepted"])
            self.assertNotEqual(supervisor.pid, os.getpid())
        finally:
            supervisor.terminate()
            supervisor.wait(timeout=2)

    def test_stale_tampered_response_and_early_exit_never_accept_handoff(self):
        def stale_response(command, **_kwargs):
            job = json.loads(Path(command[-1]).read_text(encoding="utf-8"))
            log = Path(job["log_path"]); log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text("phase=helper_started\n", encoding="utf-8")
            ready_path = Path(job["ready_path"]); ready_path.parent.mkdir(parents=True, exist_ok=True)
            ready_path.write_text(json.dumps(self._ready_payload(job)), encoding="utf-8")
            response = Path(job["response_path"]); response.parent.mkdir(parents=True, exist_ok=True)
            response.write_text(json.dumps({
                "format": 2, "job_id": job["job_id"], "helper_nonce": job["helper_nonce"],
                "helper_pid": os.getpid(), "helper_process_identity": HELPER.process_identity(os.getpid()),
                "response_proof": "00" * 32,
            }), encoding="utf-8")
            return type("Alive", (), {"poll": lambda self: None, "terminate": lambda self: None})()

        coordinator, uploaded = self._handshake_coordinator(stale_response)
        with mock.patch.object(DB_UPDATE, "HELPER_READY_TIMEOUT_SECONDS", .15), \
                self.assertRaisesRegex(UpdateError, "challenge"):
            coordinator.prepare_and_spawn(uploaded)
        self.assertFalse((self.jobs / "active.json").exists())

        child = subprocess.Popen([sys.executable, "-c", "pass"])
        child.wait(timeout=2)
        def early_exit(command, **_kwargs):
            job = json.loads(Path(command[-1]).read_text(encoding="utf-8"))
            log = Path(job["log_path"]); log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text("phase=helper_started\n", encoding="utf-8")
            identity = HELPER.process_identity(child.pid) or "proc-start:gone"
            payload = self._ready_payload(job, helper_pid=child.pid, helper_identity=identity)
            path = Path(job["ready_path"]); path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(payload), encoding="utf-8")
            return type("Alive", (), {"poll": lambda self: None, "terminate": lambda self: None})()

        coordinator, uploaded = self._handshake_coordinator(early_exit)
        with mock.patch.object(DB_UPDATE, "HELPER_READY_TIMEOUT_SECONDS", .15), \
                self.assertRaisesRegex(UpdateError, "živého procesu"):
            coordinator.prepare_and_spawn(uploaded)
        self.assertFalse((self.jobs / "active.json").exists())

    def test_windows_backend_and_helper_share_typed_64bit_creation_identity(self):
        """Regression for real 1.34.6 logs: backend must not serialize unknown."""
        class Function:
            def __init__(self, callback):
                self.callback = callback
            def __call__(self, *args):
                return self.callback(*args)

        class Kernel:
            def __init__(self):
                self.OpenProcess = Function(lambda *_: 0x1234567887654321)
                def times(_handle, created, *_rest):
                    value = (7 << 32) | 9
                    record = ctypes.cast(created, ctypes.POINTER(wintypes.FILETIME)).contents
                    record.dwLowDateTime = value & 0xffffffff
                    record.dwHighDateTime = value >> 32
                    return 1
                self.GetProcessTimes = Function(times)
                self.WaitForSingleObject = Function(lambda *_: 0x102)
                self.CloseHandle = Function(lambda *_: 1)

        import ctypes
        from ctypes import wintypes
        with mock.patch.object(PROCESS_IDENTITY.os, "name", "nt"), \
                mock.patch.object(PROCESS_IDENTITY.ctypes, "WinDLL", return_value=Kernel(), create=True):
            identity, live = PROCESS_IDENTITY.windows_process_state(4242)
            # server.py and the detached helper delegate to precisely the same
            # module; this is the formerly divergent backend/helper pair.
            self.assertEqual(SERVER._process_identity(), identity)
            self.assertEqual(HELPER.process_identity(os.getpid()), identity)
        self.assertEqual(identity, "win-create:30064771081")
        self.assertTrue(live)

    def test_backend_identity_query_failure_rejects_before_lock_stage_or_spawn(self):
        """No production replacement job may contain the historical unknown value."""
        (self.root / "tools").mkdir()
        shutil.copy2(ROOT / "tools" / "hads_database_replacer.py", self.root / "tools" / "hads_database_replacer.py")
        upload = self.data / ".identity-query-failed.tmp"
        shutil.copy2(self.staged, upload)
        popen = mock.Mock()
        coordinator = DatabaseUpdateCoordinator(
            self.root, self.data, lambda: self.target.name,
            backend_identity=lambda: None,
            installation_fingerprint=lambda: __import__("hashlib").sha256(str(self.root.resolve()).casefold().encode()).hexdigest(),
            version="1.35.0", popen=popen,
        )
        with self.assertRaisesRegex(UpdateError, "Nelze bezpečně ověřit identitu"):
            coordinator.prepare_and_spawn({
                "path": upload, "received_size": upload.stat().st_size,
                "sha256": sha256_file(upload), "source_name": "zdroj.ndb",
            })
        popen.assert_not_called()
        self.assertTrue(upload.is_file())
        self.assertFalse((self.jobs / "active.json").exists())

    def test_real_unknown_descriptor_is_rejected_and_matching_identity_passes_parent_wait(self):
        """The exact logged mismatch is rejected; a shared win-create value is safe."""
        descriptor = self.jobs / ("job_" + "A" * 32 + ".json")
        unknown = self.job(backend_process_identity="unknown")
        descriptor.write_text(json.dumps(unknown), encoding="utf-8")
        with self.assertRaisesRegex(HELPER.HelperError, "bezpečnou identitu"):
            HELPER.load_job(str(descriptor))

        expected = "win-create:134316092856045975"
        # The first state is the running exact backend, then it exits. This
        # demonstrates that the same canonical value proceeds beyond the
        # parent wait without weakening PID-reuse detection.
        with mock.patch.object(HELPER, "process_identity", side_effect=[expected, expected]), \
                mock.patch.object(HELPER, "process_running", side_effect=[True, False]):
            HELPER.wait_for_exact_parent(27688, expected, 1)

    def test_helper_main_restarts_hads_after_success_and_verified_failure(self):
        def invoke(argv):
            original_out, original_err = sys.stdout, sys.stderr
            try:
                return HELPER.main(argv)
            finally:
                redirected_out, redirected_err = sys.stdout, sys.stderr
                sys.stdout, sys.stderr = original_out, original_err
                for stream in {redirected_out, redirected_err} - {original_out, original_err}:
                    try:
                        stream.close()
                    except OSError:
                        pass

        job = self.job(backend_pid=99999999, backend_process_identity="proc-start:1")
        descriptor = self.jobs / ("job_" + job["job_id"] + ".json")
        descriptor.write_text(json.dumps(job), encoding="utf-8")
        def receipt_exists_before_restart(*_args, **_kwargs):
            self.assertTrue(Path(job["result_path"]).is_file())
            receipt = json.loads(Path(job["result_path"]).read_text(encoding="utf-8"))
            self.assertTrue(receipt["success"])
            return mock.Mock()
        with mock.patch.object(HELPER, "wait_for_challenge"), \
                mock.patch.object(HELPER.subprocess, "Popen", side_effect=receipt_exists_before_restart) as restart:
            self.assertEqual(invoke([str(descriptor)]), 0)
        restart.assert_called_once()
        receipt = json.loads(Path(job["result_path"]).read_text(encoding="utf-8"))
        self.assertTrue(receipt["success"]); self.assertTrue(receipt["restart_spawned"])

        # New isolated job: injected final-main failure runs verified rollback
        # and still restarts the original HADS.
        build_fixture_ndb(self.staged, [{"name": "ISO RMS", "value": 10.0, "limits_xml": None}], plant_name="Český závod")
        job = self.job(backend_pid=99999998, backend_process_identity="proc-start:1")
        descriptor = self.jobs / ("job_" + job["job_id"] + ".json")
        descriptor.write_text(json.dumps(job), encoding="utf-8")
        real_replace = HELPER.os.replace
        def fail_new(source, destination):
            if Path(source) == self.staged and Path(destination) == self.target:
                raise OSError("simulated move failure")
            return real_replace(source, destination)
        with mock.patch.object(HELPER, "wait_for_challenge"), \
                mock.patch.object(HELPER.os, "replace", side_effect=fail_new), \
                mock.patch.object(HELPER.subprocess, "Popen") as restart:
            self.assertEqual(invoke([str(descriptor)]), 1)
        restart.assert_called_once()
        receipt = json.loads(Path(job["result_path"]).read_text(encoding="utf-8"))
        self.assertFalse(receipt["success"]); self.assertTrue(receipt["old_verified_restored"])

    def test_helper_owns_bootstrap_log_before_descriptor_validation(self):
        # This is intentionally a separate process: the helper replaces
        # stdout/stderr at its first instruction and must leave an independent
        # diagnostic even when the descriptor does not exist or cannot load.
        copied = self.root / "tools" / "hads_database_replacer.py"
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / "tools" / "hads_database_replacer.py", copied)
        shutil.copy2(ROOT / "backend" / "process_identity.py", self.root / "backend" / "process_identity.py")
        missing = self.jobs / ("job_" + "C" * 32 + ".json")
        run = subprocess.run(
            [sys.executable, "-u", str(copied), str(missing)],
            cwd=self.root,
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(run.returncode, 1)
        log = self.root / "updates" / "logs" / ("database_update_" + "C" * 32 + ".log")
        text = log.read_text(encoding="utf-8")
        self.assertIn("phase=helper_started", text)
        self.assertIn("phase=fatal", text)
        self.assertLess(text.index("phase=helper_started"), text.index("phase=fatal"))


if __name__ == "__main__":
    unittest.main()
