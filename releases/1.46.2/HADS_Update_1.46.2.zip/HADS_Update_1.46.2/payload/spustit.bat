@echo off
REM ============================================================
REM  HADS - Sprava diagnostickych dat (Windows)
REM  Spusti lokalni webovou aplikaci a otevre ji v prohlizeci.
REM  Pouziva pouze vestaveny Python - NIC se neinstaluje.
REM ============================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo  HADS - spoustim aplikaci...
echo.

REM --- Najdi funkcni prikaz Pythonu (py / python / python3) ---
set "PYCMD="
for %%P in (py python python3) do (
  if not defined PYCMD (
    %%P --version >nul 2>&1
    if !errorlevel! equ 0 set "PYCMD=%%P"
  )
)

if not defined PYCMD (
  echo [CHYBA] Python nebyl nalezen.
  echo Nainstalujte Python 3.8+ z https://www.python.org/downloads/
  echo Pri instalaci zaskrtnete "Add Python to PATH".
  echo.
  pause
  exit /b 1
)

echo Pouzivam: %PYCMD%
%PYCMD% --version
echo.
echo  Aplikace se otevre v prohlizeci na http://127.0.0.1:8000
echo  Zavrenim tohoto okna aplikaci ukoncite.
echo.

cd backend
%PYCMD% server.py

echo.
pause
