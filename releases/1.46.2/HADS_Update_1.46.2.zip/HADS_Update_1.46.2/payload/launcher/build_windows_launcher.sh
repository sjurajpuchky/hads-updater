#!/usr/bin/env sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$HERE/.." && pwd)
: "${SOURCE_DATE_EPOCH:=0}"
export SOURCE_DATE_EPOCH
cd "$HERE"
x86_64-w64-mingw32-windres --use-temp-file -O coff "$HERE/hads_launcher.rc" "$HERE/hads_launcher.res"
x86_64-w64-mingw32-gcc -std=c11 -O2 -s -mwindows -municode -static -static-libgcc \
  -Wl,--no-insert-timestamp -Wl,--dynamicbase -Wl,--nxcompat -Wl,--high-entropy-va \
  -o "$ROOT/HADS.exe" "$HERE/hads_launcher.c" "$HERE/hads_launcher.res" \
  -lole32 -lshell32 -luuid -lws2_32 -ladvapi32
rm -f "$HERE/hads_launcher.res"
