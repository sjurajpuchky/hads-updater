/* Native Windows 10/11 launcher for HADS.  Deliberately depends only on Win32. */
#define WIN32_LEAN_AND_MEAN
#define COBJMACROS
#include <windows.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <shellapi.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <wincrypt.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <wchar.h>

#define APP L"HADS"
#define STARTUP_WAIT_MS 30000
#define SERVER_LOG_TAIL_BYTES 8192

typedef struct { DWORD pid; unsigned short port; wchar_t identity[80]; wchar_t root_hash[80]; wchar_t token[65]; } LockRec;

typedef struct { HANDLE process; DWORD pid; unsigned short port; } LaunchResult;

static void make_path(wchar_t *out, size_t cap, const wchar_t *root, const wchar_t *suffix) { swprintf(out, cap, L"%ls\\%ls", root, suffix); }
static BOOL ensure_data_dir(const wchar_t *root) { wchar_t p[MAX_PATH*4]; make_path(p,_countof(p),root,L"data"); return CreateDirectoryW(p,NULL) || GetLastError()==ERROR_ALREADY_EXISTS; }
static void log_line(const wchar_t *root, const wchar_t *text) {
    wchar_t path[MAX_PATH * 4]; FILE *f; if(!ensure_data_dir(root)) return;
    make_path(path,_countof(path),root,L"data\\hads_launcher.log"); f = _wfopen(path, L"a+, ccs=UTF-8");
    if (f) { SYSTEMTIME st; GetLocalTime(&st); fwprintf(f, L"%04u-%02u-%02u %02u:%02u:%02u %ls\n",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond,text); fclose(f); }
}
static void launcher_logf(const wchar_t *root, const wchar_t *fmt, ...) { wchar_t line[2048]; va_list ap; va_start(ap,fmt); _vsnwprintf(line,_countof(line)-1,fmt,ap); line[_countof(line)-1]=0; va_end(ap); log_line(root,line); }
static void fail(const wchar_t *root, const wchar_t *msg) { log_line(root, msg); MessageBoxW(NULL, msg, APP, MB_OK | MB_ICONERROR); }
static BOOL get_root(wchar_t *out, DWORD cap) { DWORD n=GetModuleFileNameW(NULL,out,cap); wchar_t *slash; if(!n||n>=cap-1)return FALSE; slash=wcsrchr(out,L'\\');if(!slash)return FALSE;*slash=0;return TRUE; }
static BOOL file_exists(const wchar_t *p) { DWORD a=GetFileAttributesW(p);return a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY); }
static BOOL qarg(wchar_t *out,size_t cap,const wchar_t *v) { return _snwprintf(out,cap,L"\"%ls\"",v)>0; }

static BOOL sha256_root(const wchar_t *root, wchar_t *out, DWORD cap) {
    wchar_t normalized[MAX_PATH*4]; char utf8[MAX_PATH*12]; DWORD bytes=0; HCRYPTPROV prov=0; HCRYPTHASH hash=0; BYTE digest[32]; DWORD dlen=sizeof(digest);
    if(!GetFullPathNameW(root,_countof(normalized),normalized,NULL))return FALSE; CharLowerBuffW(normalized,(DWORD)wcslen(normalized));
    bytes=WideCharToMultiByte(CP_UTF8,0,normalized,-1,utf8,sizeof(utf8),NULL,NULL);if(!bytes)return FALSE;
    if(!CryptAcquireContextW(&prov,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))return FALSE;
    if(!CryptCreateHash(prov,CALG_SHA_256,0,0,&hash)||!CryptHashData(hash,(const BYTE*)utf8,bytes-1,0)||!CryptGetHashParam(hash,HP_HASHVAL,digest,&dlen,0)){if(hash)CryptDestroyHash(hash);CryptReleaseContext(prov,0);return FALSE;}
    for(DWORD i=0;i<dlen&&i*2+2<cap;i++)swprintf(out+i*2,3,L"%02x",digest[i]);CryptDestroyHash(hash);CryptReleaseContext(prov,0);return TRUE;
}
static BOOL token_hex(wchar_t *out,DWORD cap) { BYTE b[32];HCRYPTPROV p=0;if(cap<65||!CryptAcquireContextW(&p,NULL,NULL,PROV_RSA_AES,CRYPT_VERIFYCONTEXT))return FALSE;BOOL ok=CryptGenRandom(p,sizeof(b),b);CryptReleaseContext(p,0);if(!ok)return FALSE;for(int i=0;i<32;i++)swprintf(out+i*2,3,L"%02x",b[i]);return TRUE; }
static BOOL get_string(const wchar_t *json,const wchar_t *name,wchar_t *out,size_t cap) { wchar_t key[100],*p;_snwprintf(key,_countof(key),L"\"%ls\"",name);p=wcsstr((wchar_t*)json,key);if(!p)return FALSE;p=wcschr(p+wcslen(key),L':');if(!p)return FALSE;while(*++p==L' ');if(*p++!=L'\"')return FALSE;size_t n=0;while(*p&&*p!=L'\"'&&n+1<cap){if(*p==L'\\'&&p[1])p++;out[n++]=*p++;}out[n]=0;return *p==L'\"'; }
static BOOL get_number(const wchar_t *json,const wchar_t *name,DWORD *out) { wchar_t key[100],*p;_snwprintf(key,_countof(key),L"\"%ls\"",name);p=wcsstr((wchar_t*)json,key);if(!p)return FALSE;p=wcschr(p+wcslen(key),L':');if(!p)return FALSE;*out=(DWORD)wcstoul(p+1,NULL,10);return *out>0; }
static BOOL read_lock(const wchar_t *root,LockRec *rec) {
    wchar_t path[MAX_PATH*4];HANDLE h;DWORD size,got,chars;char *buf;wchar_t *wide;make_path(path,_countof(path),root,L"data\\hads_server.lock");
    if(GetFileAttributesW(path)==INVALID_FILE_ATTRIBUTES||(GetFileAttributesW(path)&FILE_ATTRIBUTE_REPARSE_POINT))return FALSE;h=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return FALSE;size=GetFileSize(h,NULL);if(size==INVALID_FILE_SIZE||size>65536){CloseHandle(h);return FALSE;}buf=(char*)HeapAlloc(GetProcessHeap(),0,size+1);if(!buf){CloseHandle(h);return FALSE;}BOOL ok=ReadFile(h,buf,size,&got,NULL);CloseHandle(h);if(!ok){HeapFree(GetProcessHeap(),0,buf);return FALSE;}buf[got]=0;chars=MultiByteToWideChar(CP_UTF8,0,buf,got,NULL,0);wide=(wchar_t*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,(chars+1)*sizeof(wchar_t));if(!wide){HeapFree(GetProcessHeap(),0,buf);return FALSE;}MultiByteToWideChar(CP_UTF8,0,buf,got,wide,chars);HeapFree(GetProcessHeap(),0,buf);ZeroMemory(rec,sizeof(*rec));DWORD port=0;ok=get_number(wide,L"pid",&rec->pid)&&get_number(wide,L"port",&port)&&port<=65535&&get_string(wide,L"process_identity",rec->identity,_countof(rec->identity))&&get_string(wide,L"installation_fingerprint",rec->root_hash,_countof(rec->root_hash))&&get_string(wide,L"shutdown_token",rec->token,_countof(rec->token));rec->port=(unsigned short)port;HeapFree(GetProcessHeap(),0,wide);return ok;
}
static BOOL same_process(const LockRec *r) { HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,r->pid);FILETIME c,e,k,u;wchar_t id[80];if(!p)return FALSE;DWORD code=0;BOOL ok=GetExitCodeProcess(p,&code)&&code==STILL_ACTIVE;if(ok&&GetProcessTimes(p,&c,&e,&k,&u)){ULARGE_INTEGER v;v.LowPart=c.dwLowDateTime;v.HighPart=c.dwHighDateTime;swprintf(id,_countof(id),L"win-create:%llu",v.QuadPart);ok=wcscmp(id,r->identity)==0;}else ok=FALSE;CloseHandle(p);return ok; }
static void delete_lock(const wchar_t *root) { wchar_t p[MAX_PATH*4];make_path(p,_countof(p),root,L"data\\hads_server.lock");DeleteFileW(p); }
static BOOL http_shutdown(const LockRec *r,const wchar_t *token) { WSADATA w;SOCKET s=INVALID_SOCKET;struct sockaddr_in a;char req[512],answer[128],tok[130];int n;if(WSAStartup(MAKEWORD(2,2),&w)!=0)return FALSE;WideCharToMultiByte(CP_UTF8,0,token,-1,tok,sizeof(tok),NULL,NULL);s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);if(s==INVALID_SOCKET){WSACleanup();return FALSE;}DWORD to=1200;setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,(char*)&to,sizeof(to));setsockopt(s,SOL_SOCKET,SO_SNDTIMEO,(char*)&to,sizeof(to));ZeroMemory(&a,sizeof(a));a.sin_family=AF_INET;a.sin_port=htons(r->port);a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);if(connect(s,(struct sockaddr*)&a,sizeof(a))==SOCKET_ERROR){closesocket(s);WSACleanup();return FALSE;}_snprintf(req,sizeof(req),"POST /api/internal/shutdown HTTP/1.1\r\nHost: 127.0.0.1\r\nX-HADS-Shutdown-Token: %s\r\nContent-Length: 0\r\nConnection: close\r\n\r\n",tok);send(s,req,(int)strlen(req),0);n=recv(s,answer,sizeof(answer)-1,0);closesocket(s);WSACleanup();if(n<=0)return FALSE;answer[n]=0;return strstr(answer," 202 ")!=NULL; }
static BOOL stop_existing(const wchar_t *root) { LockRec r;wchar_t expected[80];if(!read_lock(root,&r))return TRUE;if(!sha256_root(root,expected,_countof(expected))||_wcsicmp(expected,r.root_hash)!=0){delete_lock(root);return TRUE;}if(!same_process(&r)){delete_lock(root);return TRUE;}if(!r.token[0]||!http_shutdown(&r,r.token))return FALSE;HANDLE p=OpenProcess(SYNCHRONIZE|PROCESS_TERMINATE|PROCESS_QUERY_LIMITED_INFORMATION,FALSE,r.pid);if(!p)return FALSE;DWORD waited=WaitForSingleObject(p,8000);if(waited==WAIT_TIMEOUT&&same_process(&r)){TerminateProcess(p,1);waited=WaitForSingleObject(p,3000);}CloseHandle(p);if(waited!=WAIT_OBJECT_0)return FALSE;delete_lock(root);return TRUE; }

static BOOL choose_loopback_port(unsigned short *port) { WSADATA w;SOCKET s;struct sockaddr_in a;int n=sizeof(a);if(WSAStartup(MAKEWORD(2,2),&w)!=0)return FALSE;s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);if(s==INVALID_SOCKET){WSACleanup();return FALSE;}ZeroMemory(&a,sizeof(a));a.sin_family=AF_INET;a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);a.sin_port=0;BOOL ok=bind(s,(struct sockaddr*)&a,sizeof(a))==0&&getsockname(s,(struct sockaddr*)&a,&n)==0&&ntohs(a.sin_port)!=0;if(ok)*port=ntohs(a.sin_port);closesocket(s);WSACleanup();return ok; }
static BOOL health_ready(unsigned short port) { WSADATA w;SOCKET s;struct sockaddr_in a;char req[]="GET /api/health HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n",ans[128];int n;if(WSAStartup(MAKEWORD(2,2),&w)!=0)return FALSE;s=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);if(s==INVALID_SOCKET){WSACleanup();return FALSE;}DWORD to=800;setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,(char*)&to,sizeof(to));ZeroMemory(&a,sizeof(a));a.sin_family=AF_INET;a.sin_port=htons(port);a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);if(connect(s,(struct sockaddr*)&a,sizeof(a))==SOCKET_ERROR){closesocket(s);WSACleanup();return FALSE;}send(s,req,(int)strlen(req),0);n=recv(s,ans,sizeof(ans)-1,0);closesocket(s);WSACleanup();if(n<=0)return FALSE;ans[n]=0;return strstr(ans," 200 ")!=NULL; }

static BOOL contains_secret_word(const wchar_t *s) { return wcsstr(s,L"TOKEN")||wcsstr(s,L"token")||wcsstr(s,L"HADS_SHUTDOWN"); }
static void log_backend_tail(const wchar_t *root) {
    wchar_t path[MAX_PATH*4],wide[SERVER_LOG_TAIL_BYTES+1];char bytes[SERVER_LOG_TAIL_BYTES+1];FILE *f;size_t n;make_path(path,_countof(path),root,L"data\\hads_server.log");f=_wfopen(path,L"rb");if(!f)return;fseek(f,0,SEEK_END);long end=ftell(f);if(end>(long)SERVER_LOG_TAIL_BYTES)fseek(f,end-SERVER_LOG_TAIL_BYTES,SEEK_SET);else fseek(f,0,SEEK_SET);n=fread(bytes,1,SERVER_LOG_TAIL_BYTES,f);fclose(f);bytes[n]=0;int chars=MultiByteToWideChar(CP_UTF8,0,bytes,(int)n,wide,_countof(wide)-1);if(!chars)return;wide[chars]=0;wchar_t *line=wcstok(wide,L"\r\n");wchar_t *kept[8];int count=0;while(line){if(*line&&!contains_secret_word(line)){if(count<8)kept[count++]=line;else{for(int i=1;i<8;i++)kept[i-1]=kept[i];kept[7]=line;}}line=wcstok(NULL,L"\r\n");}for(int i=0;i<count;i++)launcher_logf(root,L"backend: %ls",kept[i]); }
static BOOL create_shortcut(const wchar_t *root,wchar_t *error,size_t ec) { HRESULT hr=CoInitializeEx(NULL,COINIT_APARTMENTTHREADED);BOOL uninit=SUCCEEDED(hr);PWSTR desktop=NULL;IShellLinkW *link=NULL;IPersistFile *persist=NULL;wchar_t exe[MAX_PATH*4],lnk[MAX_PATH*4];if(FAILED(SHGetKnownFolderPath(&FOLDERID_Desktop,0,NULL,&desktop))){_snwprintf(error,ec,L"Nelze zjistit plochu aktuálního uživatele.");goto done;}make_path(exe,_countof(exe),root,L"HADS.exe");swprintf(lnk,_countof(lnk),L"%ls\\HADS.lnk",desktop);if(FAILED(CoCreateInstance(&CLSID_ShellLink,NULL,CLSCTX_INPROC_SERVER,&IID_IShellLinkW,(void**)&link))){_snwprintf(error,ec,L"Nelze vytvořit zástupce HADS.");goto done;}if(FAILED(IShellLinkW_SetPath(link,exe))||FAILED(IShellLinkW_SetWorkingDirectory(link,root))||FAILED(IShellLinkW_SetIconLocation(link,exe,0))||FAILED(IShellLinkW_SetDescription(link,L"HADS"))||FAILED(IShellLinkW_QueryInterface(link,&IID_IPersistFile,(void**)&persist))||FAILED(IPersistFile_Save(persist,lnk,TRUE))){_snwprintf(error,ec,L"Nelze uložit zástupce HADS na plochu.");goto done;}if(persist)IPersistFile_Release(persist);if(link)IShellLinkW_Release(link);if(desktop)CoTaskMemFree(desktop);if(uninit)CoUninitialize();return TRUE;done:if(persist)IPersistFile_Release(persist);if(link)IShellLinkW_Release(link);if(desktop)CoTaskMemFree(desktop);if(uninit)CoUninitialize();return FALSE; }
static BOOL launch_server(const wchar_t *root,unsigned short port,LaunchResult *result) {
    wchar_t py[MAX_PATH*4],script[MAX_PATH*4],cmd[MAX_PATH*8],token[65],port_text[16],server_log[MAX_PATH*4];STARTUPINFOW si;PROCESS_INFORMATION pi;SECURITY_ATTRIBUTES sa;HANDLE log;
    ZeroMemory(result,sizeof(*result));make_path(py,_countof(py),root,L"runtime\\pythonw.exe");if(!file_exists(py))make_path(py,_countof(py),root,L"runtime\\python.exe");if(!file_exists(py)){fail(root,L"Nebylo nalezeno přenosné prostředí Pythonu v runtime/. Podrobnosti jsou v data\\hads_launcher.log.");return FALSE;}if(!token_hex(token,_countof(token))){fail(root,L"Nelze bezpečně připravit spuštění HADS.");return FALSE;}make_path(script,_countof(script),root,L"backend\\server.py");if(!file_exists(script)){fail(root,L"Chybí backend\\server.py. Instalace HADS je neúplná.");return FALSE;}qarg(cmd,_countof(cmd),py);_snwprintf(cmd+wcslen(cmd),_countof(cmd)-wcslen(cmd),L" -u \"%ls\"",script);launcher_logf(root,L"fáze=spuštění port=%u příkaz=%ls",port,cmd);
    make_path(server_log,_countof(server_log),root,L"data\\hads_server.log");ZeroMemory(&sa,sizeof(sa));sa.nLength=sizeof(sa);sa.bInheritHandle=TRUE;log=CreateFileW(server_log,FILE_APPEND_DATA|GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(log==INVALID_HANDLE_VALUE){launcher_logf(root,L"nelze otevřít hads_server.log, Win32=%lu",GetLastError());return FALSE;}SetFilePointer(log,0,NULL,FILE_END);wsprintfW(port_text,L"%u",port);SetEnvironmentVariableW(L"HADS_SHUTDOWN_TOKEN",token);SetEnvironmentVariableW(L"HADS_PORT",port_text);SetEnvironmentVariableW(L"PYTHONUTF8",L"1");ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdOutput=log;si.hStdError=log;si.hStdInput=GetStdHandle(STD_INPUT_HANDLE);ZeroMemory(&pi,sizeof(pi));BOOL ok=CreateProcessW(py,cmd,NULL,NULL,TRUE,CREATE_NO_WINDOW,NULL,root,&si,&pi);DWORD err=ok?ERROR_SUCCESS:GetLastError();SetEnvironmentVariableW(L"HADS_SHUTDOWN_TOKEN",NULL);CloseHandle(log);if(!ok){launcher_logf(root,L"CreateProcess selhal, Win32=%lu",err);return FALSE;}CloseHandle(pi.hThread);result->process=pi.hProcess;result->pid=pi.dwProcessId;result->port=port;launcher_logf(root,L"fáze=backend_spuštěn pid=%lu port=%u",result->pid,port);return TRUE;
}

/* 1.34.4: native detached parent for the post-exit database helper.
   Python's backend must never be the only parent/supervisor of a process that
   needs to live past its graceful shutdown.  This mode is deliberately small:
   it starts the packaged pythonw with full Unicode paths, captures bootstrap
   stderr, requests job breakaway, and watches for a post-ready unexpected
   exit.  HADS.exe itself is launched with CREATE_BREAKAWAY_FROM_JOB by the
   backend, so this is also robust when a shell/launcher job would otherwise
   kill descendants on backend teardown. */
static BOOL ensure_replace_dirs(const wchar_t *root) {
    wchar_t p[MAX_PATH*4];
    make_path(p,_countof(p),root,L"updates"); if(!CreateDirectoryW(p,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return FALSE;
    make_path(p,_countof(p),root,L"updates\\logs"); if(!CreateDirectoryW(p,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return FALSE;
    make_path(p,_countof(p),root,L"updates\\database_jobs"); if(!CreateDirectoryW(p,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return FALSE;
    make_path(p,_countof(p),root,L"updates\\database_jobs\\ready"); if(!CreateDirectoryW(p,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return FALSE;
    make_path(p,_countof(p),root,L"updates\\database_jobs\\results"); if(!CreateDirectoryW(p,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS)return FALSE;
    make_path(p,_countof(p),root,L"updates\\database_jobs\\supervisor_failed"); return CreateDirectoryW(p,NULL)||GetLastError()==ERROR_ALREADY_EXISTS;
}
static BOOL job_id_from_path(const wchar_t *job,wchar_t *out,size_t cap) {
    const wchar_t *base=wcsrchr(job,L'\\');base=base?base+1:job;size_t n=wcslen(base);
    if(n<25||wcsncmp(base,L"job_",4)!=0||wcscmp(base+n-5,L".json")!=0||n-9>=cap)return FALSE;
    for(size_t i=4;i<n-5;i++)if(!((base[i]>=L'A'&&base[i]<=L'Z')||(base[i]>=L'a'&&base[i]<=L'z')||(base[i]>=L'0'&&base[i]<=L'9')))return FALSE;
    wcsncpy(out,base+4,n-9);out[n-9]=0;return TRUE;
}
static void write_supervisor_failure(const wchar_t *root,const wchar_t *id,DWORD code) {
    wchar_t path[MAX_PATH*4];HANDLE h;char text[512];DWORD written;
    _snwprintf(path,_countof(path),L"%ls\\updates\\database_jobs\\supervisor_failed\\%ls.txt",root,id);
    h=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE)return;
    _snprintf(text,sizeof(text),"native supervisor observed helper exit code %lu after ready; inspect updates/logs/database_update_%ls.log\\n",code,id);
    WriteFile(h,text,(DWORD)strlen(text),&written,NULL);CloseHandle(h);
}
static void restart_after_supervisor_failure(const wchar_t *root) {
    wchar_t exe[MAX_PATH*4],cmd[MAX_PATH*8];STARTUPINFOW si;PROCESS_INFORMATION pi;
    make_path(exe,_countof(exe),root,L"HADS.exe");_snwprintf(cmd,_countof(cmd),L"\"%ls\" --no-browser",exe);
    ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);ZeroMemory(&pi,sizeof(pi));
    if(CreateProcessW(exe,cmd,NULL,NULL,FALSE,CREATE_NO_WINDOW|CREATE_NEW_PROCESS_GROUP|CREATE_BREAKAWAY_FROM_JOB,NULL,root,&si,&pi)){CloseHandle(pi.hThread);CloseHandle(pi.hProcess);}
}
static BOOL wait_backend_lock_release(const wchar_t *root,DWORD timeout) {
    wchar_t lock[MAX_PATH*4];DWORD began=GetTickCount();make_path(lock,_countof(lock),root,L"data\\hads_server.lock");
    while(file_exists(lock)&&GetTickCount()-began<timeout)Sleep(100);
    return !file_exists(lock);
}
static BOOL receipt_reports_restart(const wchar_t *path) {
    HANDLE h=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);char text[2049]={0};DWORD got=0;
    if(h==INVALID_HANDLE_VALUE)return FALSE;BOOL ok=ReadFile(h,text,2048,&got,NULL);CloseHandle(h);if(!ok)return FALSE;text[got]=0;
    return strstr(text,"\"restart_spawned\":true")!=NULL;
}
static int run_replace_supervisor(const wchar_t *root,const wchar_t *job) {
    wchar_t full_job[MAX_PATH*4],expected[MAX_PATH*4],id[96],py[MAX_PATH*4],script[MAX_PATH*4],cmd[MAX_PATH*8],log_path[MAX_PATH*4],ready[MAX_PATH*4],result[MAX_PATH*4];
    STARTUPINFOW si;PROCESS_INFORMATION pi;SECURITY_ATTRIBUTES sa;HANDLE log;DWORD waited,code=1;
    if(!GetFullPathNameW(job,_countof(full_job),full_job,NULL)||!job_id_from_path(full_job,id,_countof(id))||!ensure_replace_dirs(root))return 2;
    _snwprintf(expected,_countof(expected),L"%ls\\updates\\database_jobs\\job_%ls.json",root,id);
    if(_wcsicmp(full_job,expected)!=0||!file_exists(full_job)){launcher_logf(root,L"replace_supervisor_reject job=%ls",full_job);return 2;}
    make_path(py,_countof(py),root,L"runtime\\pythonw.exe");make_path(script,_countof(script),root,L"tools\\hads_database_replacer.py");
    if(!file_exists(py)||!file_exists(script)){launcher_logf(root,L"replace_supervisor_missing_runtime_or_script");return 2;}
    _snwprintf(log_path,_countof(log_path),L"%ls\\updates\\logs\\database_supervisor_%ls.log",root,id);
    ZeroMemory(&sa,sizeof(sa));sa.nLength=sizeof(sa);sa.bInheritHandle=TRUE;
    log=CreateFileW(log_path,FILE_APPEND_DATA|GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(log==INVALID_HANDLE_VALUE){launcher_logf(root,L"replace_supervisor_log_open_failed Win32=%lu",GetLastError());return 2;}
    SetFilePointer(log,0,NULL,FILE_END);_snwprintf(cmd,_countof(cmd),L"\"%ls\" -u \"%ls\" \"%ls\"",py,script,full_job);
    ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdOutput=log;si.hStdError=log;si.hStdInput=GetStdHandle(STD_INPUT_HANDLE);ZeroMemory(&pi,sizeof(pi));
    if(!CreateProcessW(py,cmd,NULL,NULL,TRUE,CREATE_NO_WINDOW|CREATE_NEW_PROCESS_GROUP|DETACHED_PROCESS|CREATE_BREAKAWAY_FROM_JOB,NULL,root,&si,&pi)){DWORD err=GetLastError();CloseHandle(log);launcher_logf(root,L"replace_supervisor_CreateProcess_failed Win32=%lu",err);return 2;}
    CloseHandle(log);CloseHandle(pi.hThread);launcher_logf(root,L"replace_supervisor_started helper_pid=%lu job=%ls",pi.dwProcessId,full_job);
    waited=WaitForSingleObject(pi.hProcess,INFINITE);if(waited==WAIT_OBJECT_0)GetExitCodeProcess(pi.hProcess,&code);CloseHandle(pi.hProcess);
    _snwprintf(ready,_countof(ready),L"%ls\\updates\\database_jobs\\ready\\%ls.json",root,id);_snwprintf(result,_countof(result),L"%ls\\updates\\database_jobs\\results\\%ls.json",root,id);
    launcher_logf(root,L"replace_supervisor_helper_exit code=%lu ready=%d result=%d",code,file_exists(ready),file_exists(result));
    if(file_exists(ready)&&(!file_exists(result)||!receipt_reports_restart(result))){
        write_supervisor_failure(root,id,code);
        if(wait_backend_lock_release(root,20000))restart_after_supervisor_failure(root);
        else launcher_logf(root,L"replace_supervisor_no_restart_backend_still_live job=%ls",full_job);
    }
    return code==0?0:1;
}
int WINAPI wWinMain(HINSTANCE hi,HINSTANCE hp,PWSTR cmd,int show) {
    wchar_t root[MAX_PATH*4],err[420]={0},url[128];int argc=0;LPWSTR *argv=CommandLineToArgvW(GetCommandLineW(),&argc);BOOL only_shortcut=FALSE,no_browser=FALSE;const wchar_t *replace_job=NULL;for(int i=1;i<argc;i++){if(wcscmp(argv[i],L"--create-shortcut")==0)only_shortcut=TRUE;if(wcscmp(argv[i],L"--no-browser")==0)no_browser=TRUE;if(wcscmp(argv[i],L"--replace-database")==0&&i+1<argc)replace_job=argv[++i];}if(!get_root(root,_countof(root))){if(argv)LocalFree(argv);MessageBoxW(NULL,L"Nelze určit instalační složku HADS.",APP,MB_OK|MB_ICONERROR);return 1;}if(replace_job){int rc=run_replace_supervisor(root,replace_job);if(argv)LocalFree(argv);return rc;}if(argv)LocalFree(argv);if(!get_root(root,_countof(root))){MessageBoxW(NULL,L"Nelze určit instalační složku HADS.",APP,MB_OK|MB_ICONERROR);return 1;}if(!ensure_data_dir(root)){fail(root,L"Nelze vytvořit složku data/ pro diagnostiku HADS.");return 1;}log_line(root,L"fáze=launcher_start");if(only_shortcut){if(create_shortcut(root,err,_countof(err))){MessageBoxW(NULL,L"Zástupce HADS byl vytvořen nebo opraven na ploše.",APP,MB_OK|MB_ICONINFORMATION);return 0;}fail(root,err);return 1;}if(!stop_existing(root)){fail(root,L"Nelze bezpečně ukončit předchozí spuštění HADS. Aplikace nebyla spuštěna podruhé; podrobnosti jsou v data\\hads_launcher.log.");return 1;}unsigned short port=0;if(!choose_loopback_port(&port)){fail(root,L"Nelze vybrat lokální port pro HADS. Zkontrolujte síťová omezení Windows.");return 1;}LaunchResult started;if(!launch_server(root,port,&started)){fail(root,L"Backend HADS nelze spustit. Zkontrolujte data\\hads_launcher.log a data\\hads_server.log.");return 1;}DWORD began=GetTickCount();while(GetTickCount()-began<STARTUP_WAIT_MS){if(health_ready(started.port)){launcher_logf(root,L"fáze=health_ok port=%u",started.port);if(!create_shortcut(root,err,_countof(err)))log_line(root,err);if(!no_browser){swprintf(url,_countof(url),L"http://127.0.0.1:%u/",started.port);ShellExecuteW(NULL,L"open",url,NULL,root,SW_SHOWNORMAL);}CloseHandle(started.process);return 0;}if(WaitForSingleObject(started.process,0)==WAIT_OBJECT_0){DWORD code=0;GetExitCodeProcess(started.process,&code);launcher_logf(root,L"fáze=backend_ukončen_pred_health exit_code=%lu",code);log_backend_tail(root);CloseHandle(started.process);swprintf(err,_countof(err),L"Backend HADS se ukončil před spuštěním (kód %lu). Zkontrolujte data\\hads_server.log; poslední bezpečné řádky jsou i v data\\hads_launcher.log.",code);fail(root,err);return 1;}Sleep(250);}log_line(root,L"fáze=health_timeout; ukončuji vlastní backend");TerminateProcess(started.process,1);WaitForSingleObject(started.process,2000);log_backend_tail(root);CloseHandle(started.process);fail(root,L"Backend HADS neodpověděl na health kontrolu v očekávaném čase. Zkontrolujte data\\hads_server.log a data\\hads_launcher.log.");return 1;
}
