#!/usr/bin/env python3
"""Vytvoří podepsané vydání pro sdílenou složku HADS.

Soukromý klíč je vždy povinný explicitní argument. Tento nástroj klíč
nevyhledává, neukládá a nesmí se spouštět nad složkou zákaznických dat.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from shared_updates import PRODUCT, canonical_json, validate_release, version_tuple  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_notes(argument: str) -> dict:
    try:
        value = json.loads(Path(argument).read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SystemExit(f"Nelze načíst JSON poznámek: {exc}") from exc
    if not isinstance(value, dict):
        raise SystemExit("Poznámky musí být JSON objekt s kategoriemi new, improved, fixed, security, important.")
    return value


def sign(data: bytes, private_key: Path) -> bytes:
    if not private_key.is_file() or private_key.is_symlink():
        raise SystemExit("--private-key musí být bezpečný existující soubor.")
    try:
        completed = subprocess.run(
            ["openssl", "dgst", "-sha256", "-sign", str(private_key)], input=data,
            capture_output=True, check=False,
        )
    except OSError as exc:
        raise SystemExit("Pro podpis nebyl dostupný OpenSSL: " + str(exc)) from exc
    if completed.returncode or not completed.stdout:
        raise SystemExit("OpenSSL podpis selhal: " + completed.stderr.decode("utf-8", "replace").strip())
    return completed.stdout


def publish(version: str, package: Path, output_root: Path, private_key: Path, release_date: str, minimum_version: str, mandatory: bool, title: str, summary: str, notes: dict) -> Path:
    version_tuple(version); version_tuple(minimum_version)
    if not package.is_file() or package.is_symlink() or package.suffix.lower() != ".zip":
        raise SystemExit("--package musí být bezpečný aktualizační ZIP.")
    folder = output_root / version
    if folder.exists():
        raise SystemExit(f"Cílová verze již existuje: {folder}")
    folder.mkdir(parents=True)
    target_package = folder / package.name
    shutil.copy2(package, target_package)
    metadata = {
        "product": PRODUCT, "version": version, "release_date": release_date,
        "package_filename": target_package.name, "byte_size": target_package.stat().st_size,
        "sha256": sha256(target_package), "minimum_version": minimum_version,
        "mandatory": mandatory, "title": title, "summary": summary, "release_notes": notes,
    }
    try:
        normalized = validate_release(metadata, version)
    except Exception as exc:
        shutil.rmtree(folder, ignore_errors=True)
        raise SystemExit("Neplatné metadata vydání: " + str(exc)) from exc
    raw = canonical_json(normalized)
    (folder / "release.json").write_bytes(raw + b"\n")
    (folder / "release.json.sig").write_text(base64.b64encode(sign(raw, private_key)).decode("ascii") + "\n", encoding="ascii")
    return folder


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Vytvoří podepsanou složku HADS_aktualizace/X.Y.Z.")
    parser.add_argument("--version", required=True)
    parser.add_argument("--package", required=True)
    parser.add_argument("--output-root", required=True, help="kořen HADS_aktualizace")
    parser.add_argument("--private-key", required=True, help="explicitní cesta k offline soukromému klíči")
    parser.add_argument("--release-date", required=True)
    parser.add_argument("--minimum-version", required=True)
    parser.add_argument("--mandatory", action="store_true")
    parser.add_argument("--title", required=True)
    parser.add_argument("--summary", required=True)
    parser.add_argument("--notes-json", required=True)
    args = parser.parse_args(argv)
    folder = publish(args.version, Path(args.package), Path(args.output_root), Path(args.private_key), args.release_date, args.minimum_version, args.mandatory, args.title, args.summary, load_notes(args.notes_json))
    print(folder)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
