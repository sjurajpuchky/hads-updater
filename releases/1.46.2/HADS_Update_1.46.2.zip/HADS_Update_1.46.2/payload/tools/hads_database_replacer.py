#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""One-shot external replacement of a staged HADS .ndb database.

This program is intentionally launched by the backend and then survives it.
It is the only production component allowed to rename the active .ndb and its
SQLite sidecars.  It has no HTTP server, never reads user configuration and
does not need PowerShell or administrator rights.
"""
from __future__ import annotations

import ctypes
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import time
import traceback
from urllib.parse import quote
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
from process_identity import is_verifiable_identity, process_identity as _shared_process_identity, process_state  # noqa: E402

SIDECARS = ("-wal", "-shm", "-journal")
MAX_DESCRIPTOR_BYTES = 32 * 1024
READY_FORMAT = 2
JOB_FORMAT = 3
HANDSHAKE_TIMEOUT_SECONDS = 8.0


def _bootstrap_log_path(argument: str | None) -> Path:
    """Return a deterministic safe log path before importing application code.

    This is deliberately independent from a descriptor field: a malformed job,
    an import failure or a broken embeddable-runtime path must still leave a
    diagnostic trace under the installation's updates/logs folder.
    """
    name = Path(str(argument or "unknown")).name
    match = re.fullmatch(r"job_([A-Za-z0-9]{20,80})\.json", name)
    suffix = match.group(1) if match else "invalid_" + str(os.getpid())
    return ROOT / "updates" / "logs" / f"database_update_{suffix}.log"


def _open_bootstrap_log(argument: str | None) -> Path:
    path = _bootstrap_log_path(argument)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.parent.is_symlink() or path.is_symlink():
            raise OSError("log path is a symbolic link")
        stream = path.open("a", encoding="utf-8", buffering=1)
        # Do not depend on supervisor stdout/stderr inheritance.  From this
        # first instruction both output streams are independently owned by the
        # helper and remain valid after the backend closes its handles.
        sys.stdout = stream
        sys.stderr = stream
    except Exception:
        # There is no safe alternative path outside the installation.  Native
        # HADS.exe also captures early stderr in its supervisor log.
        pass
    return path


REQUIRED_TABLES = {
    "Tbl_Info", "Tbl_Routes", "Tbl_Severity", "Tbl_Tree", "Tbl_Cell", "Tbl_Cell_Stats",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_ndb(path: Path) -> dict:
    """Self-contained immutable SQLite validation for the embeddable runtime."""
    if not path.is_file() or path.stat().st_size < 100:
        raise HelperError("Soubor je prázdný nebo příliš krátký.")
    with path.open("rb") as fh:
        if fh.read(16) != b"SQLite format 3\x00":
            raise HelperError("Soubor není databáze SQLite ve formátu .ndb.")
    uri = "file:" + quote(str(path.resolve()).replace("\\", "/")) + "?mode=ro&immutable=1"
    try:
        con = sqlite3.connect(uri, uri=True, timeout=2)
        con.execute("PRAGMA query_only=ON")
        try:
            integrity = con.execute("PRAGMA quick_check(1)").fetchone()
            if not integrity or str(integrity[0]).casefold() != "ok":
                raise HelperError("Kontrola integrity SQLite neprošla.")
            tables = {str(row[0]) for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            missing = sorted(REQUIRED_TABLES - tables)
            if missing:
                raise HelperError("Soubor nemá očekávané schéma DDS/HADS (chybí: " + ", ".join(missing) + ").")
            columns = {str(row[1]) for row in con.execute("PRAGMA table_info(Tbl_Tree)")}
            if not {"ID", "Name", "Parent", "Type"}.issubset(columns):
                raise HelperError("Tabulka stromu nemá očekávané schéma DDS/HADS.")
            root = con.execute(
                "SELECT Name FROM Tbl_Tree WHERE (Parent=0 OR Parent IS NULL) ORDER BY SortId, ID LIMIT 1"
            ).fetchone()
            if not root or not str(root[0] or "").strip():
                root = con.execute("SELECT Name FROM Tbl_Tree WHERE Type=1 ORDER BY SortId, ID LIMIT 1").fetchone()
            if not root or not str(root[0] or "").strip():
                root = con.execute("SELECT Name FROM Tbl_Routes LIMIT 1").fetchone()
            return {"identity": str(root[0]).strip() if root and str(root[0] or "").strip() else None}
        finally:
            con.close()
    except HelperError:
        raise
    except sqlite3.Error as exc:
        raise HelperError(f"Soubor nelze bezpečně otevřít jako SQLite databázi: {exc}") from exc


class HelperError(RuntimeError):
    pass


def log(message: str) -> None:
    print(f"{time.strftime('%Y-%m-%d %H:%M:%S')} database-replacer {message}", flush=True)


def canonical(value: str | Path) -> Path:
    return Path(value).resolve(strict=False)


def under(path: Path, root: Path) -> bool:
    try:
        canonical(path).relative_to(canonical(root))
        return True
    except ValueError:
        return False


def regular(path: Path, label: str, required: bool = True) -> None:
    if path.is_symlink():
        raise HelperError(f"{label} nesmí být symbolický odkaz: {path}")
    if not path.is_file() and required:
        raise HelperError(f"Chybí {label}: {path}")


def safe_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.parent.is_symlink() or path.is_symlink():
        raise HelperError(f"Výsledek nelze zapisovat přes odkaz: {path}")
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with tmp.open("x", encoding="utf-8") as fh:
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def process_identity(pid: int) -> str | None:
    """Compatibility facade; all process identity comes from the shared API."""
    return _shared_process_identity(pid)


def process_running(pid: int) -> bool:
    return bool(pid > 0 and process_state(pid)[1])


def handshake_mac(secret: str, purpose: str, *fields: object) -> str:
    transcript = json.dumps(
        [purpose, *fields], ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hmac.new(secret.encode("ascii"), transcript, hashlib.sha256).hexdigest()


def wait_for_exact_parent(pid: int, expected_identity: str, timeout: float) -> None:
    """Wait only while the recorded exact backend process still exists."""
    started = time.monotonic()
    initial = process_identity(pid)
    if initial is not None and initial != expected_identity:
        raise HelperError(
            f"PID {pid} patří jinému procesu (očekáváno {expected_identity}, nalezeno {initial}); výměna odmítnuta."
        )
    if initial is None and process_running(pid):
        raise HelperError(f"Nelze ověřit startovní identitu běžícího backendu PID {pid}; výměna odmítnuta.")
    while process_running(pid):
        actual = process_identity(pid)
        if actual != expected_identity:
            raise HelperError(
                f"PID {pid} byl znovu použit nebo změnil identitu ({actual!r}); výměna odmítnuta."
            )
        if time.monotonic() - started >= timeout:
            # Do not kill the backend. A correct authenticated shutdown should
            # already be in progress; a timeout must preserve all customer data.
            raise HelperError(
                f"Backend PID {pid} se neukončil do {timeout:.0f} s; pomocník jej bezpečně neukončuje."
            )
        time.sleep(0.10)
    log(f"phase=parent_exited pid={pid} identity={expected_identity}")


def is_sharing_error(exc: OSError) -> bool:
    return getattr(exc, "winerror", None) in (32, 33) or getattr(exc, "errno", None) in (13, 16)


def retry_move(source: Path, destination: Path, phase: str, seconds: float) -> None:
    deadline = time.monotonic() + max(0.1, seconds)
    attempt = 0
    while True:
        attempt += 1
        try:
            os.replace(source, destination)
            log(f"phase={phase} attempt={attempt} source={source} destination={destination}")
            return
        except OSError as exc:
            if not is_sharing_error(exc) or time.monotonic() >= deadline:
                win = getattr(exc, "winerror", None)
                raise HelperError(
                    f"Fáze {phase} selhala pro {source} -> {destination}: {exc} (WinError={win})"
                ) from exc
            log(
                f"phase={phase} retry={attempt} path={source} WinError={getattr(exc, 'winerror', None)}"
            )
            time.sleep(min(0.50, 0.05 * attempt))


def retry_remove(path: Path, phase: str, seconds: float) -> None:
    if not path.exists():
        return
    deadline = time.monotonic() + max(0.1, seconds)
    attempt = 0
    while True:
        attempt += 1
        try:
            path.unlink()
            log(f"phase={phase} attempt={attempt} path={path}")
            return
        except OSError as exc:
            if not is_sharing_error(exc) or time.monotonic() >= deadline:
                raise HelperError(
                    f"Fáze {phase} selhala pro {path}: {exc} (WinError={getattr(exc, 'winerror', None)})"
                ) from exc
            log(f"phase={phase} retry={attempt} path={path} WinError={getattr(exc, 'winerror', None)}")
            time.sleep(min(0.50, 0.05 * attempt))


def snapshot(path: Path) -> dict:
    if not path.exists():
        return {"exists": False}
    regular(path, "soubor rollbacku")
    return {"exists": True, "size": path.stat().st_size, "sha256": sha256_file(path)}


def verify_snapshot(path: Path, state: dict) -> bool:
    if not state.get("exists"):
        return not path.exists()
    try:
        return path.is_file() and not path.is_symlink() and path.stat().st_size == state["size"] and sha256_file(path) == state["sha256"]
    except OSError:
        return False


def load_job(arg: str) -> tuple[dict, Path, Path]:
    descriptor = canonical(arg)
    if not descriptor.is_file() or descriptor.is_symlink() or descriptor.stat().st_size > MAX_DESCRIPTOR_BYTES:
        raise HelperError("Descriptor aktualizace není bezpečný soubor.")
    try:
        job = json.loads(descriptor.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise HelperError(f"Descriptor aktualizace nelze načíst: {exc}") from exc
    if not isinstance(job, dict) or job.get("format") != JOB_FORMAT:
        raise HelperError("Descriptor aktualizace má neplatný formát.")
    job_id = job.get("job_id")
    if not isinstance(job_id, str) or not re.fullmatch(r"[A-Za-z0-9]{20,80}", job_id):
        raise HelperError("Descriptor má neplatný jednorázový identifikátor.")
    root = canonical(str(job.get("installation_root", "")))
    jobs = root / "updates" / "database_jobs"
    expected_descriptor = jobs / f"job_{job_id}.json"
    if descriptor != canonical(expected_descriptor) or not under(descriptor, jobs):
        raise HelperError("Descriptor není ve vlastněné složce databázových úloh.")
    if root.is_symlink() or jobs.is_symlink():
        raise HelperError("Instalace nebo složka úloh nesmí být odkaz.")
    expected_fingerprint = hashlib.sha256(str(root).casefold().encode("utf-8")).hexdigest()
    if job.get("installation_fingerprint") != expected_fingerprint:
        raise HelperError("Descriptor nepatří této instalaci HADS.")
    target = canonical(str(job.get("target_path", "")))
    staged = canonical(str(job.get("staged_path", "")))
    restart = canonical(str(job.get("restart_executable", "")))
    result = canonical(str(job.get("result_path", "")))
    ready = canonical(str(job.get("ready_path", "")))
    challenge = canonical(str(job.get("challenge_path", "")))
    response = canonical(str(job.get("response_path", "")))
    cancelled = canonical(str(job.get("cancel_path", "")))
    if target.parent != root / "data" or target.suffix.casefold() != ".ndb" or not under(target, root / "data"):
        raise HelperError("Cíl databáze je mimo povolenou složku data/.")
    if staged.parent != jobs / "staging" or staged.suffix.casefold() != ".ndb":
        raise HelperError("Staging databáze je mimo povolenou složku.")
    if result.parent != jobs / "results" or result.name != f"{job_id}.json":
        raise HelperError("Cesta výsledku je mimo povolenou složku.")
    if ready.parent != jobs / "ready" or ready.name != f"{job_id}.json":
        raise HelperError("Cesta potvrzení pomocníka je mimo povolenou složku.")
    if challenge.parent != jobs / "challenges" or challenge.name != f"{job_id}.json":
        raise HelperError("Cesta challenge pomocníka je mimo povolenou složku.")
    if response.parent != jobs / "responses" or response.name != f"{job_id}.json":
        raise HelperError("Cesta response pomocníka je mimo povolenou složku.")
    if cancelled.parent != jobs / "cancelled" or cancelled.name != f"{job_id}.json":
        raise HelperError("Cesta zrušení pomocníka je mimo povolenou složku.")
    if restart != root / "HADS.exe":
        raise HelperError("Restartovací program není HADS.exe této instalace.")
    for key in ("target_sha256", "source_sha256"):
        if not isinstance(job.get(key), str) or not re.fullmatch(r"[0-9a-f]{64}", job[key], re.I):
            raise HelperError(f"Descriptor má neplatný {key}.")
    if not isinstance(job.get("source_size"), int) or job["source_size"] < 100:
        raise HelperError("Descriptor má neplatnou velikost zdroje.")
    if (
        not isinstance(job.get("backend_pid"), int)
        or not is_verifiable_identity(job.get("backend_process_identity"))
    ):
        raise HelperError("Descriptor nemá bezpečnou identitu backendu.")
    if not isinstance(job.get("helper_nonce"), str) or not re.fullmatch(r"[0-9a-f]{64}", job["helper_nonce"], re.I):
        raise HelperError("Descriptor nemá bezpečný nonce pomocníka.")
    if time.time() > float(job.get("expires_at", 0)):
        raise HelperError("Platnost jednorázové databázové úlohy vypršela.")
    regular(target, "aktivní databáze")
    regular(staged, "staging databáze")
    regular(restart, "HADS.exe pro restart")
    if staged.stat().st_size != job["source_size"] or sha256_file(staged) != job["source_sha256"]:
        raise HelperError("Staging databáze neodpovídá ověřenému SHA-256.")
    return job, descriptor, root


def write_ready(job: dict, root: Path) -> None:
    """Publish an authenticated startup handshake before touching the DB."""
    ready = canonical(job["ready_path"])
    cancelled = canonical(job["cancel_path"])
    if cancelled.exists():
        raise HelperError("Backend zrušil úlohu, protože pomocník nepotvrdil bezpečné spuštění včas.")
    helper_pid = os.getpid()
    identity = process_identity(helper_pid)
    payload = {
        "format": READY_FORMAT,
        "job_id": job["job_id"],
        "helper_nonce": job["helper_nonce"],
        "helper_pid": helper_pid,
        "helper_process_identity": identity,
        "installation_root": str(root),
        "target_path": job["target_path"],
        "staged_path": job["staged_path"],
        "log_path": job["log_path"],
        "created_at": time.time(),
    }
    if not identity:
        raise HelperError("Nelze potvrdit startovní identitu externího pomocníka.")
    payload["ready_proof"] = handshake_mac(
        job["helper_nonce"], "ready-v2", job["job_id"], helper_pid, identity,
        job["installation_root"], job["target_path"], job["staged_path"],
    )
    safe_write_json(ready, payload)
    log(f"phase=helper_ready job={job['job_id']} pid={os.getpid()} ready={ready}")


def wait_for_challenge(job: dict) -> None:
    """Prove liveness after ready using the fresh backend-issued challenge."""
    challenge_path = canonical(job["challenge_path"])
    response_path = canonical(job["response_path"])
    identity = process_identity(os.getpid())
    if not identity:
        raise HelperError("Nelze získat identitu pomocníka pro challenge.")
    deadline = time.monotonic() + HANDSHAKE_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        cancelled = canonical(job["cancel_path"])
        if cancelled.exists():
            raise HelperError("Backend zrušil úlohu před challenge potvrzením.")
        if challenge_path.is_file() and not challenge_path.is_symlink():
            try:
                challenge = json.loads(challenge_path.read_text(encoding="utf-8"))
                token = challenge.get("challenge")
                if (
                    challenge.get("format") != 1
                    or challenge.get("job_id") != job["job_id"]
                    or challenge.get("helper_nonce") != job["helper_nonce"]
                    or not isinstance(token, str)
                    or not re.fullmatch(r"[0-9a-f]{64}", token, re.I)
                ):
                    raise HelperError("Challenge backendu neodpovídá jednorázové úloze.")
                payload = {
                    "format": 2, "job_id": job["job_id"],
                    "helper_nonce": job["helper_nonce"], "helper_pid": os.getpid(),
                    "helper_process_identity": identity,
                    "response_proof": handshake_mac(
                        job["helper_nonce"], "response-v2", job["job_id"], token,
                        os.getpid(), identity,
                    ),
                    "created_at": time.time(),
                }
                safe_write_json(response_path, payload)
                log(f"phase=helper_challenge_responded job={job['job_id']} pid={os.getpid()}")
                return
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                raise HelperError(f"Challenge backendu nelze bezpečně ověřit: {exc}") from exc
        time.sleep(0.05)
    raise HelperError("Backend neposlal challenge v očekávaném čase; výměna odmítnuta.")


def restore(
    target: Path, rollback: Path, old: dict[str, dict], moved: set[str],
    new_main_moved: bool, retry_seconds: float,
) -> bool:
    """Restore original main and sidecars byte-for-byte where a swap began."""
    log("phase=rollback_begin")
    ok = True
    # A new main is installed only after every old main/sidecar was moved.
    # Only in that state can current sidecars be new and must be removed.
    if new_main_moved:
        for suffix in SIDECARS:
            try:
                retry_remove(Path(str(target) + suffix), "rollback_remove_new_sidecar", retry_seconds)
            except HelperError as exc:
                log(f"phase=rollback_remove_sidecar_failed detail={exc}")
                ok = False
    if new_main_moved and target.exists():
        try:
            retry_remove(target, "rollback_remove_new_main", retry_seconds)
        except HelperError as exc:
            log(f"phase=rollback_remove_main_failed detail={exc}")
            ok = False
    for suffix in ("", *SIDECARS):
        state = old[suffix]
        saved = rollback / ("main.ndb" if not suffix else "main.ndb" + suffix)
        destination = target if not suffix else Path(str(target) + suffix)
        if state.get("exists") and suffix in moved:
            try:
                if saved.exists():
                    retry_move(saved, destination, "rollback_restore" + (suffix or "_main"), retry_seconds)
                else:
                    log(f"phase=rollback_missing_backup path={saved}")
                    ok = False
            except HelperError as exc:
                log(f"phase=rollback_restore_failed path={destination} detail={exc}")
                ok = False
    verified = ok and all(
        verify_snapshot(target if not suffix else Path(str(target) + suffix), old[suffix])
        for suffix in ("", *SIDECARS)
    )
    log(f"phase=rollback_verified value={verified}")
    return verified


def perform(job: dict, root: Path) -> dict:
    target = canonical(job["target_path"])
    staged = canonical(job["staged_path"])
    jobs = root / "updates" / "database_jobs"
    rollback = jobs / "rollback" / job["job_id"]
    if rollback.exists() or rollback.is_symlink():
        raise HelperError(f"Rollback složka již existuje nebo není bezpečná: {rollback}")
    rollback.mkdir(parents=True, mode=0o700)
    old = {"": snapshot(target)}
    old.update({suffix: snapshot(Path(str(target) + suffix)) for suffix in SIDECARS})
    if old[""]["size"] != job["target_size"] or old[""]["sha256"] != job["target_sha256"]:
        raise HelperError("Aktivní databáze se od preflightu změnila; výměna odmítnuta.")
    moved: set[str] = set()
    new_main_moved = False
    try:
        # Move every old sidecar away. No checkpoint/open occurs here: after
        # parent exit this preserves rollback bytes exactly and prevents stale
        # WAL replay next to the new main file.
        for suffix in ("", *SIDECARS):
            source = target if not suffix else Path(str(target) + suffix)
            if old[suffix].get("exists"):
                destination = rollback / ("main.ndb" if not suffix else "main.ndb" + suffix)
                retry_move(source, destination, "move_old" + (suffix or "_main"), float(job["lock_retry_seconds"]))
                moved.add(suffix)
        retry_move(staged, target, "move_staged_main", float(job["lock_retry_seconds"]))
        new_main_moved = True
        # There must be no old WAL/SHM/journal alongside the new main database.
        for suffix in SIDECARS:
            if Path(str(target) + suffix).exists():
                raise HelperError(f"Po výměně zůstal pomocný soubor {target}{suffix}; rollback bude proveden.")
        if target.stat().st_size != job["source_size"] or sha256_file(target) != job["source_sha256"]:
            raise HelperError("SHA-256 nové databáze po přesunu neodpovídá staging souboru.")
        meta = validate_ndb(target)
        expected_identity = job.get("expected_company_identity")
        if meta.get("identity") != expected_identity:
            raise HelperError("Identita nové databáze po výměně neodpovídá preflightu.")
        shutil.rmtree(rollback)
        log("phase=success validated=immutable_sqlite")
        return {"success": True, "old_verified_restored": False, "detail": "Databáze byla úspěšně nahrazena."}
    except Exception as exc:
        verified = restore(
            target, rollback, old, moved, new_main_moved, float(job["lock_retry_seconds"])
        ) if moved else all(
            verify_snapshot(target if not suffix else Path(str(target) + suffix), old[suffix])
            for suffix in ("", *SIDECARS)
        )
        return {
            "success": False, "old_verified_restored": verified,
            "detail": str(exc), "rollback_path": str(rollback),
        }


def restart(job: dict, root: Path) -> tuple[bool, str | None]:
    exe = canonical(job["restart_executable"])
    try:
        kwargs = {"cwd": str(root), "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        else:
            kwargs["start_new_session"] = True
        subprocess.Popen([str(exe)], **kwargs)
        log(f"phase=restart_spawned executable={exe}")
        return True, None
    except OSError as exc:
        log(f"phase=restart_failed executable={exe} detail={exc}")
        return False, str(exc)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    argument = argv[-1] if argv else None
    bootstrap_path = _open_bootstrap_log(argument)
    log(
        "phase=helper_started "
        f"pid={os.getpid()} executable={sys.executable} cwd={Path.cwd()} "
        f"script={Path(__file__).resolve()} bootstrap_log={bootstrap_path}"
    )
    if len(argv) == 2 and argv[0] == "--preflight":
        try:
            job, _, root = load_job(argv[1])
            log(f"phase=preflight_ok job={job['job_id']} root={root}")
            return 0
        except Exception as exc:
            log(f"phase=preflight_failed detail={exc}")
            traceback.print_exc()
            return 2
    if len(argv) != 1:
        log("phase=reject reason=expected_one_descriptor_argument")
        return 2
    job = None
    root = None
    try:
        job, _, root = load_job(argv[0])
        log(f"phase=job_validated job={job['job_id']}")
        write_ready(job, root)
        wait_for_challenge(job)
        wait_for_exact_parent(job["backend_pid"], job["backend_process_identity"], float(job["parent_wait_seconds"]))
        if canonical(job["cancel_path"]).exists():
            raise HelperError("Úloha byla zrušena před výměnou databáze.")
        result = perform(job, root)
    except Exception as exc:
        log(f"phase=fatal detail={exc}")
        traceback.print_exc()
        # A malformed/tampered descriptor does not give us a safe receipt
        # location. Once a descriptor passed structural validation, however,
        # write a failure receipt so the next HADS start explains exactly why
        # no replacement occurred. Never restart while the exact parent may
        # still be alive.
        if job is not None and root is not None:
            result = {
                "format": 1, "job_id": job["job_id"], "completed_at": time.time(),
                "success": False, "old_verified_restored": False,
                "detail": str(exc), "source_name": job.get("source_name"),
                "source_last_modified": job.get("source_last_modified"),
                "source_size": job.get("source_size"), "log_path": job.get("log_path"),
                "restart_spawned": False,
            }
            try:
                safe_write_json(canonical(job["result_path"]), result)
                canonical(job["active_lock_path"]).unlink(missing_ok=True)
                # The backend normally exits after a valid ready handshake.
                # If it already has, a post-ready helper failure must still
                # bring HADS back, with the receipt written before launch.
                parent_is_gone = (
                    not process_running(int(job["backend_pid"]))
                    and process_identity(int(job["backend_pid"])) is None
                )
                if parent_is_gone:
                    restarted, restart_error = restart(job, root)
                    result["restart_spawned"] = restarted
                    if restart_error:
                        result["restart_error"] = restart_error
                    safe_write_json(canonical(job["result_path"]), result)
            except Exception as receipt_exc:
                log(f"phase=receipt_failed detail={receipt_exc}")
        return 1
    result.update({
        "format": 1, "job_id": job["job_id"], "completed_at": time.time(),
        "source_name": job.get("source_name"), "source_last_modified": job.get("source_last_modified"),
        "source_size": job.get("source_size"), "log_path": job.get("log_path"),
    })
    # Persist the receipt before starting HADS.  Otherwise a fast new backend
    # can start between Popen() and receipt creation and never surface the
    # one-time result to the user.
    try:
        safe_write_json(canonical(job["result_path"]), result)
        canonical(job["active_lock_path"]).unlink(missing_ok=True)
    except Exception as exc:
        log(f"phase=receipt_failed detail={exc}")
        return 1
    restarted, restart_error = restart(job, root)
    result["restart_spawned"] = restarted
    if restart_error:
        result["restart_error"] = restart_error
    try:
        safe_write_json(canonical(job["result_path"]), result)
    except Exception as exc:
        log(f"phase=receipt_restart_update_failed detail={exc}")
        return 1
    return 0 if result["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
