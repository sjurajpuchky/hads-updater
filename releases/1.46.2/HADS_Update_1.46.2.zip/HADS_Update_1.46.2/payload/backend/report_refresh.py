# -*- coding: utf-8 -*-
"""Aktualizace rozpracovaného NÁVRHU protokolu podle aktuálních limitů karet strojů.

MOTIVACE
--------
Uživatel běžně upraví limity na kartě stroje (nebo normu, ze které se limity
odvozují) až ve chvíli, kdy už má rozpracovaný protokol. Dřív musel vygenerovat
celý nový návrh — a přišel tím o ručně upravené texty (závěry, doporučení,
hlavičku, vybrané grafy). Tento modul umí protokol jen **aktualizovat**:
přepočítá klasifikaci (pásma A–D) každého měřicího bodu z **aktuálně uložených
limitů** a obnoví z toho odvozené souhrny, ale **nesahá na texty**.

BEZPEČNÁ LOGIKA (co se přepíše a co ne)
---------------------------------------
Přepočítá se (jde o data odvozená z měření a limitů, ne o autorský text):

  * `rows` — maximum právě vybraných nezávislých směrů H/V/A a jeho pásmo,
  * `bearings_summary` — maximum právě vybraných H/V/A pro zrychlení,
    obálku a stav ložiska,
  * `points_index` — meze A/B, B/C, C/D pro hladiny v trendech a značky spekter,
  * `worst_band`, `auto_severity` — nejhorší pásmo a automatický stav stroje,
  * `severity` — jen pokud NENÍ ručně přepsaný (viz níže),
  * `card`, `name`, `parent_name`, `speed_hz`, `iso_norm`, `last_measured` —
    identifikační údaje z karty stroje a z databáze,
  * `balance_success_pct` — procentuální úspěšnost vyvážení (verze 3),
  * `graphs` — pouze pokud si stroj drží výběr grafů (`graph_selections`);
    trendy totiž vykreslují hladiny limitů, které se právě změnily,
  * `used_norms` na úrovni dokumentu — příloha „použité normy“.

NIKDY se nepřepíše (ruční vstup uživatele):

  * `problem`, `zaver`, `doporuceni` — závěry a doporučení per stroj,
  * `severity_override` — ruční přepis celkového stavu stroje (zůstává platný
    a má i po aktualizaci přednost před automatikou),
  * `excluded_points` — body vyloučené z hodnocení (respektují se při přepočtu),
  * `graph_selections` — výběr grafů, včetně komentářů, značek a přiblížení,
  * hlavička, `intro`, `appendix_intro`, `scope_label`, obrázek přílohy a
    jakékoli další klíče dokumentu i stroje, které aktualizace nezná.

Změna stavu tedy nikdy sama nepřepíše text závěru — modul jen **vrátí seznam
změn**, aby frontend mohl uživatele upozornit, že závěr může být vhodné
zkontrolovat.

Používá POUZE standardní knihovnu Pythonu.
"""

import copy
import datetime

import report as report_mod

# Klíče stroje, které aktualizace přepočítá z aktuálních dat a limitů.
# Vše ostatní (zejména ruční texty) se z návrhu přenáší beze změny.
_RECOMPUTED_KEYS = (
    "rows",
    "bearings_summary",
    "points_index",
    "last_measured",
    "name",
    "parent_name",
    "speed_hz",
    "iso_norm",
    "card",
    "env_label",
    "protocol_direction",
    "protocol_quantities",
    "measurement_selection",
    "measurement_selection_schema",
    "measurement_selection_audit",
    "measurement_selection_notices",
)

# Lidské popisky sledovaných veličin pro výpis změn.
_QUANTITY_LABELS = {
    "vel_band": "rychlost vibrací",
    "acc_band": "zrychlení",
    "env_band": "obálka zrychlení",
    "bearing_state": "stav ložiska",
}

# Maximální počet vypsaných jednotlivých změn (ochrana velikosti odpovědi).
_MAX_CHANGES = 200


def _band_txt(band):
    """Popisek pásma pro výpis změn ('—' pro chybějící klasifikaci)."""
    return band if band else "—"


def _row_key(row):
    return report_mod.point_row_key(row.get("place"), row.get("direction"))


def _machine_has_any_band(mrep):
    """True, pokud je aspoň jedna hodnota stroje klasifikovaná do pásma.

    False znamená, že pro stroj nejsou k dispozici žádné použitelné limity
    (na kartě stroje ani v databázi), případně je klasifikace vypnutá.
    """
    for r in mrep.get("rows") or []:
        if r.get("vel_band"):
            return True
    for b in mrep.get("bearings_summary") or []:
        if b.get("acc_band") or b.get("env_band") or b.get("bearing_state"):
            return True
    return False


def _collect_band_changes(machine_name, old_m, new_m, out):
    """Porovná pásma bodů a ložisek před/po a doplní rozdíly do `out`.

    Vrací počet nalezených změn (i když se do `out` kvůli limitu nevešly).
    """
    n = 0

    old_rows = {_row_key(r): r for r in (old_m.get("rows") or [])}
    for r in new_m.get("rows") or []:
        key = _row_key(r)
        old_r = old_rows.get(key)
        if old_r is None:
            continue  # nový bod (dřív v návrhu nebyl) – není to změna stavu
        if old_r.get("vel_band") != r.get("vel_band"):
            n += 1
            if len(out) < _MAX_CHANGES:
                out.append({
                    "machine": machine_name,
                    "place": r.get("place") or "",
                    "direction": r.get("direction") or "",
                    "quantity": _QUANTITY_LABELS["vel_band"],
                    "from": _band_txt(old_r.get("vel_band")),
                    "to": _band_txt(r.get("vel_band")),
                })

    old_brgs = {b.get("place"): b for b in (old_m.get("bearings_summary") or [])}
    for b in new_m.get("bearings_summary") or []:
        old_b = old_brgs.get(b.get("place"))
        if old_b is None:
            continue
        for field in ("acc_band", "env_band", "bearing_state"):
            if (old_b.get(field) or "") == (b.get(field) or ""):
                continue
            n += 1
            if len(out) < _MAX_CHANGES:
                out.append({
                    "machine": machine_name,
                    "place": b.get("place") or "",
                    "direction": "",
                    "quantity": _QUANTITY_LABELS[field],
                    "from": _band_txt(old_b.get(field)),
                    "to": _band_txt(b.get(field)),
                })
    return n


def _refresh_balance_pct(mrep):
    """Dopočítá procentuální úspěšnost vyvážení (verze 3) per řádek i na stroj."""
    max_pct = None
    for r in mrep.get("rows") or []:
        pct = report_mod.balance_success_pct(r.get("vel_prev"), r.get("vel_cur"))
        r["balance_success_pct"] = pct
        if pct is not None and (max_pct is None or pct > max_pct):
            max_pct = pct
    mrep["balance_success_pct"] = max_pct


def _preserve_category_overrides(old_m, new_m):
    """Přenese pouze explicitní reportové volby A–D do nového automatu.

    Limity a právě zvolené hodnoty H/V/A se vždy načtou znovu, ale volba diagnostika je
    vlastností konkrétního návrhu, nikoli karty stroje. Prázdné/poškozené
    hodnoty se záměrně nepřenášejí: znamenají režim Automaticky.
    """
    old_rows = {
        _row_key(r): r for r in (old_m.get("rows") or [])
    }
    for row in new_m.get("rows") or []:
        old = old_rows.get(_row_key(row))
        if old:
            row["vel_band_override"] = old.get("vel_band_override") or ""
    old_brgs = {
        b.get("place"): b for b in (old_m.get("bearings_summary") or [])
    }
    for brg in new_m.get("bearings_summary") or []:
        old = old_brgs.get(brg.get("place"))
        if old:
            brg["acc_band_override"] = old.get("acc_band_override") or ""
            brg["env_band_override"] = old.get("env_band_override") or ""
    report_mod.recompute_category_states(new_m)


def refresh_report_draft(db, doc, all_over, qmap=None):
    """Přepočítá rozpracovaný návrh protokolu podle aktuálních limitů.

    * `db` — otevřená databáze .ndb (zdrojová DDS databáze) daného podniku,
    * `doc` — rozpracovaný návrh (dict), typicky i s neuloženými úpravami
      z editoru; nemodifikuje se, pracuje se nad kopií,
    * `all_over` — přepisy karet strojů podniku
      (machine_config.get_db_overrides), odkud pocházejí aktuální limity,
    * `qmap` — volitelná mapa veličin z Nastavení databáze.

    Vrací (new_doc, info), kde `info` popisuje, co se změnilo:
        {"machines_total", "machines_updated", "machines_changed",
         "points_changed", "changes": [...], "severity_changes": [...],
         "skipped": [...], "no_limits": [...], "refreshed_at"}
    """
    if not isinstance(doc, dict):
        raise ValueError("Návrh protokolu má neplatný formát.")

    new_doc = copy.deepcopy(doc)
    machines = new_doc.get("machines")
    if not isinstance(machines, list):
        machines = []
        new_doc["machines"] = machines

    now_iso = datetime.datetime.now().replace(microsecond=0).isoformat()
    info = {
        "machines_total": len(machines),
        "machines_updated": 0,
        "machines_changed": 0,
        "points_changed": 0,
        "changes": [],
        "severity_changes": [],
        "skipped": [],
        "no_limits": [],
        "refreshed_at": now_iso,
        "selection_notices": [],
    }
    if not machines:
        new_doc["limits_refreshed_at"] = now_iso
        return new_doc, info

    stored_scope = doc.get("scope")
    stored_window = (report_mod.scope_time_window(db, stored_scope)
                     if stored_scope else None)

    # Stroje z databáze VČETNĚ aktuálních přepisů karet (limity, normy, ložiska).
    by_id = {}
    for mc in db.machines(overrides=all_over or {}).get("machines", []):
        by_id[mc.get("id")] = mc

    for idx, old_m in enumerate(machines):
        if not isinstance(old_m, dict):
            continue
        mid = old_m.get("machine_id")
        mname = old_m.get("name") or ("stroj %s" % mid)
        mc = by_id.get(mid)
        if mc is None:
            # Stroj už v databázi není (jiná/přejmenovaná .ndb, smazaný uzel).
            # Ponecháme jej v protokolu beze změny – uživatel se rozhodne sám.
            info["skipped"].append(mname)
            continue

        # Nové návrhy od 1.31.3 nesou původní okruh. Starší uložené návrhy
        # jej nemají; ``None`` zachovává jejich tehdejší chování (celá
        # historie), místo aby refresh potají zavedl neznámé omezení.
        fresh = report_mod.build_machine_report(
            db, mc, all_over, qmap=qmap, scope=stored_scope,
            scope_window=stored_window,
            measurement_selection=old_m.get("measurement_selection") or {})

        # Sloučení: vyjdi z PŮVODNÍHO stroje (drží všechny ruční texty i klíče,
        # o kterých aktualizace nemusí vědět) a přepiš jen přepočtená data.
        new_m = dict(old_m)
        for key in _RECOMPUTED_KEYS:
            if key in fresh:
                new_m[key] = fresh[key]
        info["selection_notices"].extend(
            fresh.get("measurement_selection_notices") or [])
        # Výslovné A–D zůstává v návrhu i když změna limitů přepočítá
        # automatická pásma. Prázdné „Automaticky“ se naopak přepočte.
        _preserve_category_overrides(old_m, new_m)
        _refresh_balance_pct(new_m)

        # Stav stroje: automatický z nových pásem, ruční přepis zůstává platný.
        old_auto = old_m.get("auto_severity")
        old_sev = old_m.get("severity")
        report_mod.recompute_machine_state(new_m)
        if (new_m.get("auto_severity") != old_auto
                or new_m.get("severity") != old_sev):
            info["severity_changes"].append({
                "machine": mname,
                "from": report_mod.SEV_LABELS.get(old_sev, "—"),
                "to": new_m.get("severity_label") or "—",
                "auto_from": report_mod.SEV_LABELS.get(old_auto, "—"),
                "auto_to": new_m.get("auto_severity_label") or "—",
                "manual": bool(new_m.get("severity_manual")),
            })

        n_changed = _collect_band_changes(mname, old_m, new_m, info["changes"])
        info["points_changed"] += n_changed
        if n_changed:
            info["machines_changed"] += 1

        # Grafy drží v sobě vykreslené hladiny limitů → překresli je dle
        # zachovaného výběru. Selhání není kritické (grafy se stejně přepočítají
        # před generováním PDF).
        sels = new_m.get("graph_selections") or []
        if sels:
            try:
                new_m["graphs"] = report_mod.collect_machine_graphs(
                    db, new_m, sels)
            except Exception:
                pass

        if not _machine_has_any_band(new_m):
            info["no_limits"].append(mname)

        machines[idx] = new_m
        info["machines_updated"] += 1

    # Příloha „použité normy“ vychází z norem na kartách strojů – obnov ji.
    # Úvodní text (`intro`, `appendix_intro`) je ruční, ten zůstává.
    try:
        new_doc["used_norms"] = report_mod.collect_used_norms(machines)
    except Exception:
        pass
    new_doc["limits_refreshed_at"] = now_iso
    new_doc["measurement_selection_schema"] = report_mod.MEASUREMENT_SELECTION_SCHEMA
    return new_doc, info


def summary_text(info):
    """Sestaví českou jednořádkovou zprávu o výsledku aktualizace pro UI."""
    info = info or {}
    if not info.get("machines_total"):
        return "Návrh protokolu neobsahuje žádné stroje – není co aktualizovat."
    parts = []
    pts = info.get("points_changed") or 0
    if pts:
        parts.append("změněn stav %d bod(ů) na %d stroji(ch)"
                     % (pts, info.get("machines_changed") or 0))
    else:
        parts.append("stavy bodů odpovídají aktuálním limitům (žádná změna)")
    sev = info.get("severity_changes") or []
    if sev:
        parts.append("změněn celkový stav %d stroje(ů)" % len(sev))
    skipped = info.get("skipped") or []
    if skipped:
        parts.append("přeskočeno (stroj není v databázi): " + ", ".join(skipped[:5]))
    nolim = info.get("no_limits") or []
    if nolim:
        parts.append("bez nastavených limitů: " + ", ".join(nolim[:5]))
    return ("Aktualizováno podle limitů karet strojů – " + "; ".join(parts)
            + ". Ručně upravené texty zůstaly zachovány.")
