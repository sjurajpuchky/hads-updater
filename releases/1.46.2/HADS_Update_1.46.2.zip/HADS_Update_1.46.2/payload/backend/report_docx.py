# -*- coding: utf-8 -*-
"""Export protokolu z měření vibrací do PLNĚ EDITOVATELNÉHO DOCX (Word).

Designově zrcadlí `report_pdf.py` (stejná hlavička, dashboard, sekce, tabulky
a barvy), ale místo pevně vysázených stran generuje standardní WordprocessingML
dokument, který lze v Microsoft Word / LibreOffice Writer volně upravovat
(nadpisy, tabulky, text — nic není "zamčené" jako obrázek).

Používá POUZE `docx_writer` (nad standardní knihovnou Pythonu) — žádné
externí balíčky (python-docx apod.).

Do dokumentu se navíc vkládají SKRYTÉ strojové značky (`docx_writer.hidden_tag`)
kolem textu "Závěry" a "Doporučení" každého stroje. Značky nejsou nikdy
viditelné ani tisknutelné a slouží výhradně k tomu, aby modul `docx_import.py`
mohl při zpětném importu bezpečně rozpoznat, KTERÝ text patří ke kterému
stroji — nikdy se z nich nečtou ani nezapisují technické/naměřené hodnoty.
"""

from pathlib import Path

import branding
import docx_writer as dw
import report as report_mod

_ASSET_DIR = Path(__file__).resolve().parent / "assets"

# ---- paleta (shodná s report_pdf.py, převedená do hex pro Word) ----
INK = "1F2126"
MUTED = "666E7A"
FAINT = "9EA6B2"
RULE = "2E333B"
HAIR = "CCD1D8"
ZEBRA = "F6F7F9"
PANEL = "F1F2F5"
WHITE = "FFFFFF"

SEV_HEX = {
    "ok": "29A06B",
    "alarm": "E5B31F",
    "warn": "D7423D",
    "none": "A8ADB5",
}
SEV_TEXT_HEX = {
    "ok": "FFFFFF",
    "alarm": "1F1F1F",
    "warn": "FFFFFF",
    "none": "FFFFFF",
}
SEV_RANK = {"none": 0, "ok": 1, "alarm": 2, "warn": 3}

# Značky pro tagovaný import (viz docx_import.py) — VŽDY jen kolem
# uživatelského textu závěru/doporučení, nikdy kolem technických hodnot.
TAG_OPEN = "[[HADS:%s:%s:START]]"     # (pole, machine_id)
TAG_CLOSE = "[[HADS:%s:%s:END]]"


def _logo_bytes():
    """Logo z Nastavení (vlastní), jinak vestavěné — zrcadlí `report_pdf`."""
    return branding.logo_bytes()


def _footer_values(doc):
    """Patička z aktuální personalizace instalace; uložený návrh je jen záloha."""
    values = dict(doc.get("footer") or {})
    values.update(branding.footer())
    return values


def _fmt_num(v, dec=1):
    if v is None:
        return "—"
    try:
        return ("%.*f" % (dec, float(v))).replace(".", ",")
    except (TypeError, ValueError):
        return "—"


def _counts(machines):
    c = {"ok": 0, "alarm": 0, "warn": 0, "none": 0}
    for m in machines:
        sev = m.get("severity") or "none"
        if sev not in c:
            sev = "none"
        c[sev] += 1
    return c


def _vel_max_by_place(rows):
    """Vrátí řádek rychlosti pro každé ložisko.

    Nové návrhy mají na ložisko jeden kanonický řádek: rychlost je maximum
    právě vybraných nezávislých výskytů H/V/A. Funkce pouze slučuje případné
    duplicitní historické řádky pro bezpečné vykreslení.
    """
    best = {}
    order = []
    for r in rows or []:
        p = r.get("place") or ""
        cur = r.get("vel_cur")
        cur = float("-inf") if cur is None else cur
        if p not in best:
            best[p] = r
            order.append(p)
        else:
            bc = best[p].get("vel_cur")
            bc = float("-inf") if bc is None else bc
            if cur > bc:
                best[p] = r
    return [best[p] for p in order]


def _band_cell_runs(band, manual=False):
    if not band:
        return [dw.Run("—", color=FAINT, size=8.5)]
    sev = report_mod.band_severity(band) or "none"
    return [dw.Run(" %s%s " % (band, " ručně" if manual else ""), bold=True, size=8.5,
                   color=SEV_TEXT_HEX.get(sev, "FFFFFF"))]


def _band_cell_shading(band):
    if not band:
        return None
    sev = report_mod.band_severity(band) or "none"
    return SEV_HEX.get(sev, None)


# =========================== hlavička dokumentu ===========================
def _add_title_header(D, doc):
    """Titulní hlavička: logo HEISTECH VLEVO (pokud je k dispozici), jinak
    textová varianta značky (fallback) — zrcadlí `report_pdf.py`, kde se
    NIKDY nezobrazují obě varianty najednou.
    """
    logo = _logo_bytes()
    placed = False
    if logo:
        try:
            D.add_image_inline(logo, 160, 46, "image/jpeg", align="left")
            placed = True
        except Exception:
            placed = False
    if not placed:
        brand = _footer_values(doc).get("brand", "")
        D.add_paragraph(
            [dw.Run(brand, bold=True, size=16, color=INK)],
            spacing_after=0)
        D.add_paragraph(
            [dw.Run("TECHNICKÁ DIAGNOSTIKA A MONITORING", bold=True,
                   size=8, color=MUTED)],
            spacing_after=6)
    D.add_paragraph(
        [dw.Run("PROTOKOL Z MĚŘENÍ VIBRACÍ", bold=True, size=8.5,
               color=MUTED)],
        align="right", spacing_after=2, border_bottom=RULE)

    D.add_paragraph(
        [dw.Run(doc.get("report_title", "Zpráva z měření vibrací"),
               bold=True, size=17, color=INK)],
        spacing_before=6, spacing_after=10)

    addr = doc.get("company_address") or ""
    place = doc.get("measured_at") or doc.get("measured_place") or ""
    mb1 = (doc.get("measured_by") or "").split("\n")[0].strip()
    mb2 = (doc.get("measured_by2") or "").split("\n")[0].strip()
    measured_by = ", ".join([p for p in (mb1, mb2) if p]) or "—"
    approved_by = (doc.get("approved_by") or "—").split("\n")[0]

    meta_rows = [
        [("ZÁKAZNÍK", doc.get("company_name") or "—", addr),
         ("MÍSTO MĚŘENÍ", place or "—", ""),
         ("ČÍSLO ZAKÁZKY", doc.get("order_number") or "—", ""),
         ("RÁMCOVÁ SMLOUVA", doc.get("contract_number") or "—", "")],
        [("MĚŘENÍ PROVEDL", measured_by, ""),
         ("SCHVÁLIL", approved_by, ""),
         ("TERMÍN MĚŘENÍ", doc.get("date_measured") or "—", ""),
         ("VYHOTOVENO", doc.get("date_created") or "—", "")],
    ]
    tbl = dw.Table(width_pct=100, border_color=WHITE)
    for r in meta_rows:
        cells = []
        for lab, val, sub in r:
            paras = [
                dw.Paragraph([dw.Run(lab, bold=True, size=6.6, color=FAINT)],
                            spacing_after=1),
                dw.Paragraph([dw.Run(str(val), bold=True, size=9.5,
                                    color=INK)], spacing_after=(1 if sub else 0)),
            ]
            if sub:
                paras.append(dw.Paragraph([dw.Run(str(sub), size=7.5,
                                                  color=MUTED)],
                                         spacing_after=0))
            cells.append(dw.Cell(paras, width_pct=25))
        tbl.add_row(dw.Row(cells))
    D.add_table(tbl)
    D.add_paragraph(border_bottom=HAIR, spacing_after=10)


def _section_heading(D, num, title):
    p = D.add_paragraph(spacing_before=14, spacing_after=8, keep_next=True)
    p.add_run(dw.Run(num + "  ", bold=True, size=10.5, color=FAINT))
    p.add_run(dw.Run(title.upper(), bold=True, size=11.5, color=INK))
    return p


def _kpi_table(D, doc):
    machines = doc.get("machines", [])
    counts = _counts(machines)
    total = len(machines)
    measured = counts["ok"] + counts["alarm"] + counts["warn"]

    _section_heading(D, "01", "Stavový přehled")
    tbl = dw.Table(width_pct=100, border_color=HAIR)
    kpis = [("STROJŮ CELKEM", total, None), ("OK", counts["ok"], "ok"),
            ("UPOZORNĚNÍ", counts["alarm"], "alarm"),
            ("VÝSTRAHA", counts["warn"], "warn")]
    cells = []
    for lab, val, sev in kpis:
        shading = SEV_HEX[sev] if sev else PANEL
        text_color = SEV_TEXT_HEX[sev] if sev else INK
        paras = [
            dw.Paragraph([dw.Run(str(val), bold=True, size=20,
                                color=text_color)], spacing_after=1),
            dw.Paragraph([dw.Run(lab, bold=True, size=7,
                                color=(text_color if sev else MUTED))],
                        spacing_after=0),
        ]
        cells.append(dw.Cell(paras, width_pct=25, shading=(shading if sev
                                                            else PANEL)))
    tbl.add_row(dw.Row(cells, height=28))
    D.add_table(tbl)

    if measured > 0:
        D.add_paragraph(
            [dw.Run("Rozložení stavu naměřených strojů (z %d naměřených): "
                   % measured, size=8, color=MUTED)],
            spacing_before=6, spacing_after=2)
        parts = []
        for sev, lab in (("ok", "OK (A/B)"), ("alarm", "Upozornění (C)"),
                         ("warn", "Výstraha (D)")):
            c = counts[sev]
            if c <= 0:
                continue
            parts.append((sev, lab, c))
        p2 = D.add_paragraph(spacing_after=10)
        legend_bits = ["%s: %d" % (lab, c) for sev, lab, c in parts]
        p2.add_run(dw.Run(" · ".join(legend_bits), size=8.5, color=INK))
    else:
        D.add_paragraph([dw.Run("Zatím nejsou k dispozici žádná měření.",
                               size=9, color=MUTED)], spacing_after=10)


def _action_table(D, machines):
    critical = [m for m in machines if m.get("severity") in ("warn", "alarm")]
    critical.sort(key=lambda m: SEV_RANK.get(m.get("severity"), 0),
                 reverse=True)
    _section_heading(D, "02", "Co je potřeba řešit")
    if not critical:
        D.add_paragraph(
            [dw.Run("Žádný stroj nevyžaduje okamžitou pozornost. Všechny "
                   "naměřené stroje jsou v přijatelném stavu.", size=9.5,
                   color=INK)], spacing_after=10, shading=PANEL)
        return
    tbl = dw.Table(width_pct=100, border_color=HAIR)
    header = dw.Row([
        dw.Cell([dw.Paragraph([dw.Run("STAV", bold=True, size=7,
                                     color=MUTED)])], width_pct=12,
               shading=PANEL),
        dw.Cell([dw.Paragraph([dw.Run("STROJ", bold=True, size=7,
                                     color=MUTED)])], width_pct=25,
               shading=PANEL),
        dw.Cell([dw.Paragraph([dw.Run("PÁSMO", bold=True, size=7,
                                     color=MUTED)])], width_pct=10,
               shading=PANEL),
        dw.Cell([dw.Paragraph([dw.Run("MĚŘENO", bold=True, size=7,
                                     color=MUTED)])], width_pct=14,
               shading=PANEL),
        dw.Cell([dw.Paragraph([dw.Run("PROBLÉM / DOPORUČENÍ", bold=True,
                                     size=7, color=MUTED)])], width_pct=39,
               shading=PANEL),
    ], header=True)
    tbl.add_row(header)
    for idx, m in enumerate(critical):
        sev = m.get("severity", "none")
        rec = (m.get("problem") or "").strip()
        dop = (m.get("doporuceni") or "").strip()
        text = " ".join([t for t in (rec, dop) if t]) or "—"
        zebra = ZEBRA if idx % 2 == 1 else WHITE
        tbl.add_row(dw.Row([
            dw.Cell([dw.Paragraph([dw.Run(m.get("severity_label", ""),
                                         bold=True, size=8,
                                         color=SEV_TEXT_HEX.get(sev, INK))])],
                   width_pct=12, shading=SEV_HEX.get(sev, ZEBRA)),
            dw.Cell([dw.Paragraph([dw.Run(m.get("name", ""), bold=True,
                                         size=9, color=INK)])], width_pct=25,
                   shading=zebra),
            dw.Cell([dw.Paragraph([dw.Run(m.get("worst_band") or "—",
                                         bold=True, size=9, color=INK)],
                                 align="center")], width_pct=10,
                   shading=zebra),
            dw.Cell([dw.Paragraph([dw.Run(m.get("last_measured") or "—",
                                         size=8, color=MUTED)])],
                   width_pct=14, shading=zebra),
            dw.Cell([dw.Paragraph([dw.Run(text, size=8.3, color=INK)])],
                   width_pct=39, shading=zebra),
        ]))
    D.add_table(tbl)
    D.add_paragraph(spacing_after=8)


def _methodology(D, doc):
    _section_heading(D, "03", "Metodika měření")
    intro = doc.get("intro", "") or ""
    for para in intro.split("\n\n"):
        if para.strip():
            D.add_paragraph([dw.Run(para.strip(), size=9.5, color=INK)],
                           spacing_after=8, line_spacing=1.15)


def _full_summary_table(D, machines):
    _section_heading(D, "04", "Přehled všech strojů")
    ms = sorted(machines, key=lambda m: (-SEV_RANK.get(m.get("severity"), 0),
                                         m.get("name") or ""))
    tbl = dw.Table(width_pct=100, border_color=HAIR)
    tbl.add_row(dw.Row([
        dw.Cell([dw.Paragraph([dw.Run("STAV", bold=True, size=7,
                                     color=MUTED)])], width_pct=10,
               shading=PANEL),
        dw.Cell([dw.Paragraph([dw.Run("STROJ", bold=True, size=7,
                                     color=MUTED)])], width_pct=28,
               shading=PANEL),
        dw.Cell([dw.Paragraph([dw.Run("MĚŘENO", bold=True, size=7,
                                     color=MUTED)])], width_pct=14,
               shading=PANEL),
        dw.Cell([dw.Paragraph([dw.Run("DOPORUČENÍ / POZNÁMKA", bold=True,
                                     size=7, color=MUTED)])], width_pct=48,
               shading=PANEL),
    ], header=True))
    for idx, m in enumerate(ms):
        sev = m.get("severity", "none")
        rec = (m.get("doporuceni") or "").strip() or (m.get("problem") or "").strip()
        if not rec:
            rec = ("V pořádku — bez nutnosti zásahu." if sev == "ok"
                   else ("Neměřeno." if sev == "none" else "—"))
        zebra = ZEBRA if idx % 2 == 1 else WHITE
        tbl.add_row(dw.Row([
            dw.Cell([dw.Paragraph([dw.Run(m.get("severity_label", ""),
                                         bold=True, size=8,
                                         color=SEV_TEXT_HEX.get(sev, INK))])],
                   width_pct=10, shading=SEV_HEX.get(sev, ZEBRA)),
            dw.Cell([dw.Paragraph([dw.Run(m.get("name", ""), bold=True,
                                         size=9, color=INK)])], width_pct=28,
                   shading=zebra),
            dw.Cell([dw.Paragraph([dw.Run(m.get("last_measured") or "—",
                                         size=8, color=MUTED)])],
                   width_pct=14, shading=zebra),
            dw.Cell([dw.Paragraph([dw.Run(rec, size=8.3, color=INK)])],
                   width_pct=48, shading=zebra),
        ]))
    D.add_table(tbl)
    D.add_paragraph(spacing_after=8)


def _overall_table(D, m, with_prev=False, balance=False):
    rows = m.get("rows", []) or []
    brg = m.get("bearings_summary", []) or []
    vel_max = _vel_max_by_place(rows)
    if not vel_max and not brg:
        return
    vel_by_place = {r.get("place") or "": r for r in vel_max}
    brg_by_place = {b.get("place") or "": b for b in brg}
    places = []
    seen = set()
    for b in brg:
        p = b.get("place") or ""
        if p not in seen:
            seen.add(p)
            places.append(p)
    for r in vel_max:
        p = r.get("place") or ""
        if p not in seen:
            seen.add(p)
            places.append(p)

    if balance:
        cols = [("Ložisko", 14), ("porovnání", 9), ("p.", 6), ("aktuální", 9),
                ("Pásmo", 7), ("úsp. [%]", 9), ("zrychlení H", 13),
                ("obálka H", 13), ("Stav ložiska", 20)]
        title = ("RYCHLOST MAX. H/V/A — POROVNÁNÍ / AKTUÁLNÍ [mm/s], "
                 "LOŽISKA Z H [g]")
    elif with_prev:
        cols = [("Ložisko", 15), ("porovnání max.", 12), ("rychlost max.", 14),
                ("Pásmo", 9), ("zrychlení H", 14), ("obálka H", 14),
                ("Stav ložiska", 22)]
        title = "CELKOVÉ HODNOTY: RYCHLOST MAX. H/V/A, LOŽISKO Z H [mm/s, g]"
    else:
        cols = [("Ložisko", 18), ("rychlost max.", 16), ("Pásmo", 10),
                ("zrychlení H", 16), ("obálka H", 16), ("Stav ložiska", 24)]
        title = "CELKOVÉ HODNOTY: RYCHLOST MAX. H/V/A, LOŽISKO Z H [mm/s, g]"

    D.add_paragraph([dw.Run(title, bold=True, size=7.5, color=MUTED)],
                   spacing_before=6, spacing_after=3)
    D.add_paragraph([dw.Run(
        "Rychlost = max. vybraných H/V/A, (H/V/A) = vítězný směr; zrychlení a obálka pouze z H.",
        size=6.5, color=MUTED)], spacing_after=3)
    tbl = dw.Table(width_pct=100, border_color=HAIR)
    tbl.add_row(dw.Row(
        [dw.Cell([dw.Paragraph([dw.Run(lab, bold=True, size=7, color=MUTED)])],
                width_pct=w, shading=PANEL) for lab, w in cols],
        header=True))
    for idx, p in enumerate(places):
        v = vel_by_place.get(p, {})
        b = brg_by_place.get(p, {})
        zebra = ZEBRA if idx % 2 == 1 else WHITE
        vel_cur = v.get("vel_cur")
        vdir = v.get("direction")
        vel_txt = "—"
        if vel_cur is not None:
            vel_txt = _fmt_num(vel_cur, 2)
            if vdir:
                vel_txt += " (%s)" % vdir
        cells = [dw.Cell([dw.Paragraph([dw.Run(p, bold=True, size=8.5,
                                              color=INK)])], width_pct=cols[0][1],
                        shading=zebra)]
        ci = 1
        if balance:
            vel_prev = v.get("vel_prev")
            prev_txt = _fmt_num(vel_prev, 2) if vel_prev is not None else "—"
            if vel_prev is not None and v.get("vel_prev_dir"):
                prev_txt += " (%s)" % v.get("vel_prev_dir")
            cells.append(dw.Cell([dw.Paragraph([dw.Run(prev_txt, size=8.5,
                                                       color=INK)],
                                              align="right")],
                                width_pct=cols[ci][1], shading=zebra)); ci += 1
            band = v.get("vel_prev_band")
            cells.append(dw.Cell([dw.Paragraph(_band_cell_runs(band),
                                              align="center")],
                                width_pct=cols[ci][1],
                                shading=(_band_cell_shading(band) or zebra))); ci += 1
            cells.append(dw.Cell([dw.Paragraph([dw.Run(vel_txt, size=8.5,
                                                       color=INK)],
                                              align="right")],
                                width_pct=cols[ci][1], shading=zebra)); ci += 1
            band2 = v.get("vel_band")
            cells.append(dw.Cell([dw.Paragraph(_band_cell_runs(
                band2, bool(v.get("vel_band_override"))), align="center")],
                                width_pct=cols[ci][1],
                                shading=(_band_cell_shading(band2) or zebra))); ci += 1
            pct = v.get("balance_success_pct")
            pct_txt = ("%+.0f %%" % pct) if isinstance(pct, (int, float)) else "—"
            cells.append(dw.Cell([dw.Paragraph([dw.Run(pct_txt, size=8.5,
                                                       color=INK)],
                                              align="right")],
                                width_pct=cols[ci][1], shading=zebra)); ci += 1
        else:
            if with_prev:
                vel_prev = v.get("vel_prev")
                prev_txt = _fmt_num(vel_prev, 2) if vel_prev is not None else "—"
                if vel_prev is not None and v.get("vel_prev_dir"):
                    prev_txt += " (%s)" % v.get("vel_prev_dir")
                cells.append(dw.Cell([dw.Paragraph([dw.Run(prev_txt, size=8.5,
                                                           color=INK)],
                                                  align="right")],
                                    width_pct=cols[ci][1], shading=zebra)); ci += 1
            cells.append(dw.Cell([dw.Paragraph([dw.Run(vel_txt, size=8.5,
                                                       color=INK)],
                                              align="right")],
                                width_pct=cols[ci][1], shading=zebra)); ci += 1
            band = v.get("vel_band")
            cells.append(dw.Cell([dw.Paragraph(_band_cell_runs(
                band, bool(v.get("vel_band_override"))), align="center")],
                                width_pct=cols[ci][1],
                                shading=(_band_cell_shading(band) or zebra))); ci += 1
        acc_txt = _fmt_num(b.get("acc_cur"), 2) if b.get("acc_cur") is not None else "—"
        env_txt = _fmt_num(b.get("env_cur"), 2) if b.get("env_cur") is not None else "—"
        if b.get("acc_cur") is not None and b.get("acc_dir"):
            acc_txt += " (%s)" % b.get("acc_dir")
        if b.get("env_cur") is not None and b.get("env_dir"):
            env_txt += " (%s)" % b.get("env_dir")
        cells.append(dw.Cell([dw.Paragraph([dw.Run(acc_txt, size=8.5,
                                                   color=INK)], align="right")],
                            width_pct=cols[ci][1], shading=zebra)); ci += 1
        cells.append(dw.Cell([dw.Paragraph([dw.Run(env_txt, size=8.5,
                                                   color=INK)], align="right")],
                            width_pct=cols[ci][1], shading=zebra)); ci += 1
        bstate = b.get("bearing_state")
        cells.append(dw.Cell([dw.Paragraph(_band_cell_runs(
            bstate, bool(b.get("acc_band_override") or b.get("env_band_override"))),
                                          align="center")],
                            width_pct=cols[ci][1],
                            shading=(_band_cell_shading(bstate) or zebra)))
        tbl.add_row(dw.Row(cells))
    D.add_table(tbl)
    if (any(r.get("vel_band_override") for r in rows)
            or any(b.get("acc_band_override") or b.get("env_band_override") for b in brg)):
        D.add_paragraph([dw.Run("Pásmo s označením „ručně“ bylo pro tento protokol určeno ručně.",
                                size=7.5, color=MUTED)], spacing_before=2, spacing_after=2)


def _machine_conclusion_block(D, m, tag_ok=True):
    """Vysází „Závěry / Doporučení" pro jeden stroj a obalí je SKRYTÝMI
    strojovými značkami pro tagovaný import. Zrcadlí `report_pdf.py`, který
    u žádné verze nevypisuje samostatné pole „Popis problému" — jen
    ZÁVĚR/DOPORUČENÍ.
    """
    mid = m.get("machine_id")
    zaver = (m.get("zaver") or "").strip()
    dop = (m.get("doporuceni") or "").strip()

    p = D.add_paragraph(spacing_before=4, spacing_after=2)
    p.add_run(dw.Run("Závěry", bold=True, size=9.5, color=INK))
    p_body = D.add_paragraph(spacing_after=6, shading=PANEL, line_spacing=1.15)
    if tag_ok and mid is not None:
        p_body.add_run(dw.hidden_tag(TAG_OPEN % ("zaver", mid)))
    p_body.add_run(dw.Run(zaver, size=9.5, color=INK))
    if tag_ok and mid is not None:
        p_body.add_run(dw.hidden_tag(TAG_CLOSE % ("zaver", mid)))
    if not zaver:
        p_body.add_run(dw.Run("(bez textu – doplňte závěr)", italic=True,
                             size=9, color=FAINT))

    p2 = D.add_paragraph(spacing_before=4, spacing_after=2)
    p2.add_run(dw.Run("Doporučení", bold=True, size=9.5, color=INK))
    p2_body = D.add_paragraph(spacing_after=10, shading=PANEL, line_spacing=1.15)
    if tag_ok and mid is not None:
        p2_body.add_run(dw.hidden_tag(TAG_OPEN % ("doporuceni", mid)))
    p2_body.add_run(dw.Run(dop, size=9.5, color=INK))
    if tag_ok and mid is not None:
        p2_body.add_run(dw.hidden_tag(TAG_CLOSE % ("doporuceni", mid)))
    if not dop:
        p2_body.add_run(dw.Run("(bez textu – doplňte doporučení)", italic=True,
                              size=9, color=FAINT))


def _machine_section(D, m, version):
    """Kompletní karta stroje (VERZE 1): barevná hlavička + celková tabulka +
    závěry/doporučení v jednom bloku (žádné oddělené sekce 04/05).
    """
    name = m.get("name") or "Stroj"
    sev = m.get("severity", "none")
    header_p = D.add_paragraph(spacing_before=16, spacing_after=6,
                              shading=SEV_HEX.get(sev, PANEL), keep_next=True)
    header_p.add_run(dw.Run(" %s" % name, bold=True, size=12.5,
                            color=SEV_TEXT_HEX.get(sev, INK)))
    header_p.add_run(dw.Run("   ·   %s" % (m.get("severity_label") or ""),
                            bold=True, size=9.5, color=SEV_TEXT_HEX.get(sev, INK)))
    if m.get("worst_band"):
        header_p.add_run(dw.Run("   ·   pásmo %s" % m.get("worst_band"),
                                size=9.5, color=SEV_TEXT_HEX.get(sev, INK)))
    if m.get("parent_name"):
        D.add_paragraph([dw.Run(m.get("parent_name"), size=8.5, color=MUTED)],
                       spacing_after=6)

    _overall_table(D, m, with_prev=False, balance=False)
    _machine_conclusion_block(D, m, tag_ok=True)


def _conclusion_machine_row(D, m):
    """Jeden řádek v sekci 04 „Závěry a doporučení" (VERZE 2/3): barevný
    stavový puntík + název stroje + pásmo v hlavičce, následované PLNÝM
    textem závěru a doporučení (SE skrytými značkami pro tagovaný import).
    Zrcadlí `report_pdf._conclusions_section` (bez sloupce s datem měření,
    bez tabulky naměřených hodnot – ty jsou v sekci 05).
    """
    sev = m.get("severity", "none")
    name = m.get("name") or "Stroj"
    header_p = D.add_paragraph(spacing_before=14, spacing_after=4,
                              keep_next=True)
    header_p.add_run(dw.Run("●  ", bold=True, size=10.5,
                            color=SEV_HEX.get(sev, FAINT)))
    header_p.add_run(dw.Run(name, bold=True, size=10.5, color=INK))
    if m.get("worst_band"):
        header_p.add_run(dw.Run("    %s" % m.get("worst_band"), bold=True,
                                size=9, color=SEV_HEX.get(sev, MUTED)))
    D.add_paragraph(border_bottom=HAIR, spacing_after=6)
    _machine_conclusion_block(D, m, tag_ok=True)


def _conclusions_section(D, machines):
    """Sekce „04 Závěry a doporučení" (VERZE 2/3) — zrcadlí
    `report_pdf._conclusions_section`: kompaktní přehled stav|stroj|pásmo
    s PLNÝM textem závěru/doporučení pro každý stroj, řazeno dle závažnosti.
    """
    _section_heading(D, "04", "Závěry a doporučení")
    intro = ("Následující přehled uvádí pro každý stroj v okruhu jeho "
             "aktuální stav, nejhorší pásmo a stručný závěr s doporučením "
             "dalšího postupu.")
    D.add_paragraph([dw.Run(intro, size=9, color=INK)],
                   spacing_after=10, line_spacing=1.15)
    ms = sorted(machines, key=lambda m: (-SEV_RANK.get(m.get("severity"), 0),
                                         m.get("name") or ""))
    for m in ms:
        _conclusion_machine_row(D, m)


def _assessment_machine_block(D, m, balance=False, show_previous=True):
    """Kompaktní blok jednoho stroje pro sekci 05 „Hodnocení technického
    stavu" / „Zhodnocení vyvažování" (VERZE 2/3): název stroje + otáčky/norma/
    datum měření na jednom řádku + tabulka celkových hodnot. BEZ závěru/
    doporučení a BEZ skrytých značek (technické hodnoty se nikdy neimportují).
    """
    name = m.get("name") or "Stroj"
    sev = m.get("severity", "none")
    p = D.add_paragraph(spacing_before=14, spacing_after=2, keep_next=True)
    p.add_run(dw.Run("▍ ", bold=True, size=11, color=SEV_HEX.get(sev, FAINT)))
    p.add_run(dw.Run(name, bold=True, size=11, color=INK))
    bits = []
    rpm = (m.get("card") or {}).get("rpm")
    if rpm:
        bits.append("%s min⁻¹" % rpm)
    if not balance:
        norm_lbl = report_mod.norm_label(m.get("iso_norm"), name_only=True)
        if norm_lbl:
            bits.append(norm_lbl)
    if m.get("last_measured"):
        bits.append("měřeno %s" % m.get("last_measured"))
    if bits:
        p.add_run(dw.Run("     " + " · ".join(bits), size=8, color=MUTED))
    _overall_table(D, m, with_prev=(show_previous and not balance),
                   balance=(balance and show_previous))


def _technical_assessment_section(D, machines, balance=False, show_previous=True):
    """Sekce „05 Hodnocení technického stavu" (VERZE 2) / „05 Zhodnocení
    vyvažování" (VERZE 3) — zrcadlí `report_pdf._technical_assessment_section`:
    všechny stroje, kompaktní tabulky naměřených hodnot, plynule za sebou.
    """
    if balance:
        title = "Zhodnocení vyvažování"
        intro = ("Následující tabulky uvádějí pro každý vyvažovaný stroj "
                 "naměřené hodnoty rychlosti vibrací H PŘED a PO vyvážení "
                 "spolu s příslušnými pásmy A–D, procentuální úspěšností "
                 "vyvážení a stavem valivých ložisek.")
    else:
        title = "Hodnocení technického stavu"
        intro = ("Následující tabulky uvádějí pro každý stroj naměřenou "
                 "rychlost vibrací H (RMS) v jednotlivých měřicích "
                 "místech spolu s předchozí hodnotou H pro porovnání vývoje "
                 "a stavem valivých ložisek.")
    _section_heading(D, "05", title)
    D.add_paragraph([dw.Run(intro, size=9, color=INK)],
                   spacing_after=10, line_spacing=1.15)
    for m in machines:
        _assessment_machine_block(D, m, balance=balance,
                                  show_previous=show_previous)


def _fmt_mm(v):
    """Naformátuje mez v mm/s (česká des. čárka), nebo „–“ když chybí."""
    if v is None:
        return "–"
    try:
        f = float(v)
    except (TypeError, ValueError):
        return "–"
    s = ("%.2f" % f).rstrip("0").rstrip(".")
    return s.replace(".", ",")


def _used_norms_block(D, doc):
    """Vypíše SKUTEČNĚ použité normy (``doc['used_norms']``) včetně jejich
    mezních hodnot rychlosti vibrací [mm/s RMS]: A/B, B/C (výstraha),
    C/D (alarm). Když není známá žádná norma, vypíše obecný popis
    ČSN ISO 20816 (zpětně kompatibilní fallback) — zrcadlí
    `report_pdf._used_norms_block`.
    """
    used = doc.get("used_norms") or []
    if not used:
        try:
            used = report_mod.collect_used_norms(doc.get("machines") or [])
        except Exception:
            used = []

    if used:
        D.add_paragraph([dw.Run("Použité normy a jejich mezní hodnoty",
                               bold=True, size=9.5, color=INK)],
                       spacing_before=4, spacing_after=4)
        intro = ("Níže jsou uvedeny normy, dle kterých byly stroje v tomto "
                 "protokolu skutečně klasifikovány, včetně mezních "
                 "efektivních hodnot rychlosti vibrací (RMS) [mm/s] "
                 "oddělujících pásma stavu A/B, B/C a C/D.")
        D.add_paragraph([dw.Run(intro, size=9, color=INK)],
                       spacing_after=8, line_spacing=1.15)

        tbl = dw.Table(width_pct=100, border_color=HAIR)
        tbl.add_row(dw.Row([
            dw.Cell([dw.Paragraph([dw.Run("NORMA / TŘÍDA", bold=True, size=7,
                                         color=MUTED)])],
                   width_pct=46, shading=PANEL),
            dw.Cell([dw.Paragraph([dw.Run("A/B", bold=True, size=7,
                                         color=MUTED)], align="right")],
                   width_pct=18, shading=PANEL),
            dw.Cell([dw.Paragraph([dw.Run("B/C (VÝSTRAHA)", bold=True,
                                         size=7, color=MUTED)],
                                 align="right")],
                   width_pct=18, shading=PANEL),
            dw.Cell([dw.Paragraph([dw.Run("C/D (ALARM)", bold=True, size=7,
                                         color=MUTED)], align="right")],
                   width_pct=18, shading=PANEL),
        ], header=True))
        for idx, rec in enumerate(used):
            zebra = ZEBRA if idx % 2 == 1 else WHITE
            std = (rec.get("standard") or "–").strip() or "–"
            mc = (rec.get("machine_class") or "").strip()
            label = std if not mc else ("%s – %s" % (std, mc))
            extra = ""
            brgs = rec.get("bearings") or []
            machs = rec.get("machines") or []
            if brgs:
                extra = "ložiska: " + ", ".join(brgs)
            elif machs:
                extra = "stroje: " + ", ".join(machs)
            name_paras = [dw.Paragraph([dw.Run(label, size=8.5, color=INK)])]
            if extra:
                name_paras.append(dw.Paragraph([dw.Run(extra, size=7,
                                                       color=MUTED)],
                                              spacing_after=0))
            tbl.add_row(dw.Row([
                dw.Cell(name_paras, width_pct=46, shading=zebra),
                dw.Cell([dw.Paragraph([dw.Run(_fmt_mm(rec.get("ab")),
                                            size=8.5, color=INK)],
                                     align="right")],
                       width_pct=18, shading=zebra),
                dw.Cell([dw.Paragraph([dw.Run(_fmt_mm(rec.get("warning")),
                                            size=8.5, color=INK)],
                                     align="right")],
                       width_pct=18, shading=zebra),
                dw.Cell([dw.Paragraph([dw.Run(_fmt_mm(rec.get("alarm")),
                                            size=8.5, color=INK)],
                                     align="right")],
                       width_pct=18, shading=zebra),
            ]))
        D.add_table(tbl)
        pozn = ("Pozn.: Mezní hodnoty odpovídají třídě stroje nastavené na "
                "kartě (Nastavení → Normy). Hodnota „–“ znamená, že norma "
                "danou mez neuvádí.")
        D.add_paragraph([dw.Run(pozn, size=7.5, color=MUTED)],
                       spacing_before=6, spacing_after=10, line_spacing=1.1)
        return

    # --- fallback: žádné známé normy → obecný popis ČSN ISO 20816 ---
    D.add_paragraph([dw.Run("ČSN ISO 20816 — Mechanické vibrace", bold=True,
                           size=9.5, color=INK)],
                   spacing_before=4, spacing_after=4)
    p1 = ("ČSN ISO 20816 (dříve ČSN ISO 10816) stanovuje pravidla pro "
          "hodnocení mechanických vibrací strojů měřením na nerotujících "
          "částech (skříních ložisek). Základním hodnotícím parametrem je "
          "efektivní hodnota (RMS) rychlosti vibrací [mm/s] v pásmu "
          "10–1000 Hz. Stroje se dělí do skupin podle výkonu a způsobu "
          "uložení (tuhé / poddajné základy), pro které platí odlišné "
          "mezní hodnoty.")
    D.add_paragraph([dw.Run(p1, size=9, color=INK)],
                   spacing_after=10, line_spacing=1.15)


def _bands_table(D):
    """Tabulka pásem stavu A–D — zrcadlí `report_pdf._norms_appendix_page`."""
    D.add_paragraph([dw.Run("PÁSMA STAVU (A–D)", bold=True, size=7.5,
                           color=MUTED)],
                   spacing_before=2, spacing_after=4)
    bands = [
        ("A", "ok", "Vibrace nově uvedených strojů do provozu — stroj v "
                    "bezvadném stavu."),
        ("B", "ok", "Stroj vhodný pro dlouhodobý nepřetržitý provoz bez "
                    "omezení."),
        ("C", "alarm", "Stav nevyhovující pro dlouhodobý trvalý provoz; "
                       "stroj lze provozovat omezenou dobu — naplánujte "
                       "nápravné opatření."),
        ("D", "warn", "Vibrace nebezpečné — mohou způsobit poškození "
                      "stroje; nutný okamžitý zásah."),
    ]
    tbl = dw.Table(width_pct=100, border_color=HAIR)
    for band, sev, desc in bands:
        tbl.add_row(dw.Row([
            dw.Cell([dw.Paragraph([dw.Run(band, bold=True, size=10.5,
                                         color=SEV_TEXT_HEX.get(sev, "FFFFFF"))],
                                 align="center")],
                   width_pct=8, shading=SEV_HEX.get(sev, FAINT)),
            dw.Cell([dw.Paragraph([dw.Run(desc, size=9, color=INK)])],
                   width_pct=92, shading=WHITE),
        ]))
    D.add_table(tbl)
    pozn = ("Pozn.: Meze A/B, B/C a C/D rychlosti vibrací vycházejí z použité "
            "normy (Nastavení → Normy). Není-li hranice A/B v normě "
            "uvedena, odhadne se jako polovina meze výstrahy (B/C). "
            "U zrychlení a obálky se pásmo A/B neodhaduje — pracuje se "
            "pouze se skutečně zadanými mezemi výstrahy a alarmu.")
    D.add_paragraph([dw.Run(pozn, size=7.5, color=MUTED)],
                   spacing_before=6, spacing_after=10, line_spacing=1.1)


def _used_norms_appendix(D, doc):
    """Závěrečná příloha s informacemi o použitých normách a metodice
    hodnocení — zrcadlí `report_pdf._norms_appendix_page` (normy + limity,
    tabulka pásem A–D, metoda obálky zrychlení, FFT).
    """
    D.add_page_break()
    _section_heading(D, "", "Příloha — použité normy a hodnocení")
    appendix_intro = (doc.get("appendix_intro") or "").strip() or (
        "Hodnocení stavu strojů v tomto protokolu vychází z níže uvedených "
        "norem a metod. Měření i vyhodnocení bylo provedeno měřicí a "
        "softwarovou technologií HADS.")
    D.add_paragraph([dw.Run(appendix_intro, size=9, color=INK)],
                   spacing_after=10, line_spacing=1.15)

    _used_norms_block(D, doc)
    _bands_table(D)

    D.add_paragraph([dw.Run("Analýza valivých ložisek — metoda obálky "
                           "zrychlení", bold=True, size=9.5, color=INK)],
                   spacing_before=2, spacing_after=4)
    p2 = ("Stav valivých ložisek se hodnotí metodou obálky signálu "
          "zrychlení (ACC ENV), která zvýrazňuje rázové děje vznikající "
          "při poškození valivých elementů a drah. Doplňkově se sleduje "
          "celkové zrychlení vibrací (ACC RMS) a ukazatel stavu ložisek "
          "(BEARING). Hodnoty jsou uvedeny v jednotkách g (1 g ≈ "
          "9,81 m/s²).")
    D.add_paragraph([dw.Run(p2, size=9, color=INK)],
                   spacing_after=10, line_spacing=1.15)

    D.add_paragraph([dw.Run("Frekvenční analýza (FFT)", bold=True, size=9.5,
                           color=INK)],
                   spacing_before=2, spacing_after=4)
    p3 = ("Rychlá Fourierova transformace (FFT) rozkládá měřený časový "
          "signál na frekvenční složky. Z polohy a amplitudy výrazných "
          "složek ve spektru lze identifikovat příčinu zvýšených vibrací "
          "(nevyváženost, nesouosost, mechanické uvolnění, závady ložisek "
          "či ozubení apod.).")
    D.add_paragraph([dw.Run(p3, size=9, color=INK)],
                   spacing_after=4, line_spacing=1.15)


def _footer_paragraphs(doc):
    f = _footer_values(doc)
    p = dw.Paragraph(align="center", spacing_after=0)
    p.add_run(dw.Run(
        "%s · %s · %s" % (f.get("company", ""), f.get("address", ""),
                          f.get("web", "")),
        size=7, color=MUTED))
    return [p]


def _header_paragraphs(doc):
    p = dw.Paragraph(align="right", spacing_after=0)
    p.add_run(dw.Run(doc.get("header_left") or "Vibrační diagnostika",
                     size=7.5, color=MUTED))
    return [p]


def render(doc):
    """Vygeneruje DOCX (bytes) z návrhu protokolu `doc` — mirror report_pdf.render.

    VŽDY zapisuje pouze text/tabulky (žádné makro, žádné živé pole ani
    externí odkaz) — výsledný soubor je bezpečný standardní dokument Wordu.
    """
    doc = dict(doc or {})
    if not isinstance(doc.get("footer"), dict):
        doc["footer"] = branding.footer()
    version = report_mod.norm_report_version(doc.get("report_version"))
    machines_all = doc.get("machines", [])

    D = dw.DocxDocument(title=doc.get("report_title") or "Protokol",
                        subject="HADS – protokol z měření vibrací")
    D.set_header_footer(_header_paragraphs(doc), _footer_paragraphs(doc))

    _add_title_header(D, doc)
    _kpi_table(D, doc)
    _action_table(D, machines_all)
    D.add_page_break()
    _methodology(D, doc)

    if version in (2, 3):
        _conclusions_section(D, machines_all)
        D.add_page_break()
        _technical_assessment_section(
            D, machines_all, balance=(version == 3),
            show_previous=bool(doc.get("show_previous", version == 2)))
    else:
        _full_summary_table(D, machines_all)
        detail = [m for m in machines_all if m.get("severity") in ("warn", "alarm")]
        detail.sort(key=lambda m: (-SEV_RANK.get(m.get("severity"), 0),
                                   m.get("name") or ""))
        for m in detail:
            D.add_page_break()
            _machine_section(D, m, version)

    _used_norms_appendix(D, doc)

    return D.save_bytes()
