"""Perzistence údajů o podniku (firmě) vázaných na databázi (.ndb).

Každá databáze (.ndb) představuje jeden podnik. Pro každou databázi se ukládá:
    {
      "name": <název podniku>,
      "address": <adresa>,
      "contact": <kontaktní osoba>
    }

Data jsou uložena per-podnik v data/podniky/<slug>/company.json se strukturou:
    {"name": ..., "address": ..., "contact": ...}
(dříve jeden sdílený data/company.json klíčovaný jménem/klíčem podniku).

Používá POUZE standardní knihovnu Pythonu.
"""

import data_store

_KIND = data_store.KIND_COMPANY


def _empty():
    return {"name": "", "address": "", "contact": ""}


def migrate_key(old_key, new_key):
    """Jednorázově přesune data podniku ze staré složky (starý klíč) do nové
    (nový klíč). Deleguje na data_store.rename_podnik (přesune VŠECHNY per-podnik
    soubory, ne jen údaje o podniku). Ponechán kvůli zpětné kompatibilitě API.
    """
    if not old_key or not new_key or old_key == new_key:
        return False
    return data_store.rename_podnik(old_key, new_key)


def get_company(db_filename):
    """Vrátí údaje o podniku pro danou databázi (nebo prázdnou strukturu)."""
    rec = data_store.load(_KIND, db_filename) or {}
    out = _empty()
    out["name"] = str(rec.get("name", "") or "").strip()
    out["address"] = str(rec.get("address", "") or "").strip()
    out["contact"] = str(rec.get("contact", "") or "").strip()
    return out


def save_company(db_filename, company):
    """Uloží údaje o podniku pro danou databázi. Vrátí očištěnou strukturu.

    Pokud jsou všechna pole prázdná, záznam se z úložiště odstraní.
    """
    company = company or {}
    clean = {
        "name": str(company.get("name", "") or "").strip(),
        "address": str(company.get("address", "") or "").strip(),
        "contact": str(company.get("contact", "") or "").strip(),
    }
    if clean["name"] or clean["address"] or clean["contact"]:
        data_store.save(_KIND, db_filename, clean)
    else:
        data_store.delete(_KIND, db_filename)
    return clean
