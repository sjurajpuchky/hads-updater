# -*- coding: utf-8 -*-
"""Verzované, bezpečné a uživatelsky editovatelné šablony AI protokolů.

Do ``data/ai_prompts.json`` se ukládají pouze odchylky od verzovaných
vestavěných výchozích hodnot.  Neměnný kontrakt výstupu se do šablony vkládá
výhradně přes povinný placeholder ``{report_contract}``; uživatel jej tedy
nemůže odstranit ani změnit.  Datový kontext, klasifikace, JSON schema a
faktické ukotvení zůstávají v ``ai_eval.py`` v kódu aplikace.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any


DATA_DIR = Path(__file__).resolve().parent.parent / "data"
FILE_NAME = "ai_prompts.json"
FORMAT = 1
DEFAULTS_REVISION = "1.46.0"
MAX_TEMPLATE_CHARS = 20000
_LOCK = threading.RLock()


# Texty jsou záměrně rozdělené přesně před dosavadní neměnnou částí. Bez
# uživatelského přepisu render vrací stejný system prompt jako HADS 1.37.0.
# Neměnný obal odpovědi. Šablona verze protokolu popisuje, CO a JAK se má
# hodnotit; tento kontrakt určuje pouze strojově čitelný formát, aby šel
# výsledek spolehlivě rozparsovat do editoru protokolu. Je proto u všech
# verzí stejný a úprava šablony ho nemůže rozbít — což je celý smysl toho,
# že je oddělený od upravitelné části.
_RESPONSE_CONTRACT = (
    "FORMÁT ODPOVĚDI (neměnný): Odpověz POUZE platným JSON objektem se třemi "
    "textovými klíči: 'problem' (stručný popis problému, max 4 slova, např. "
    "'Provozní stav' nebo 'Mírná nevývaha rotoru'), 'zaver' (text závěru "
    "přesně podle pokynů výše) a 'doporuceni' (doporučení podle pokynů výše, "
    "např. 'Provádět pravidelné kontrolní měření.' nebo 'Bez doporučení'). "
    "Víceřádkový text odděluj znakem nového řádku (\\n). Žádný text mimo "
    "JSON. Nevymýšlej si hodnoty, které nejsou v datech."
)

_CONTRACTS = {
    "report_brief_v1": _RESPONSE_CONTRACT,
    "report_brief_v2": _RESPONSE_CONTRACT,
    "report_brief_v3": _RESPONSE_CONTRACT,
}

METHODOLOGY_ID = "report_methodology"

# Jediná metodologie sdílená všemi verzemi protokolu i poradcem u měřicího
# bodu. Popisuje POSTUP ÚVAHY; formát odpovědi řídí výhradně kód přes
# {report_contract} a strukturu závěru verzní šablona.
_METHODOLOGY_DEFAULT = (
    "Jsi senior vibrační diagnostik s mnohaletou praxí v prediktivní údržbě "
    "rotačních strojů. Při hodnocení se držíš výhradně této metodologie.\n"
    "\n"
    "1) ZDROJ ČÍSEL. Všechny naměřené hodnoty, pásma A–D, řády otáčkové "
    "frekvence (× ot) i poruchové frekvence ložisek už spočítala aplikace z "
    "naměřených dat a máš je v zadání. Nikdy je nepřepočítávej, needituj ani "
    "nedoplňuj. O tom, co v zadání není, netvrdíš nic.\n"
    "\n"
    "2) CELKOVÉ HODNOTY A MEZE. Každou veličinu porovnávej VÝHRADNĚ s mezemi "
    "uvedenými u ní jako „platné meze“. Je-li jejich zdrojem norma, má "
    "přednost před mezemi z databáze přístroje — ty jsou v zadání jen pro "
    "informaci a nikdy podle nich nehodnoť. Pásmo A–D uvedené u hodnoty je "
    "závazné; nepřeřazuj hodnotu vlastní úvahou. Rychlost vibrací [mm/s RMS] "
    "vypovídá o celkovém stavu stroje (nevývaha, nesouosost, uvolnění, "
    "rezonance); zrychlení [g] a obálka zrychlení [gE] o stavu valivých "
    "ložisek a ozubení.\n"
    "\n"
    "3) ČÍM HODNOTU UKOTVIT. „Vysoká“ hodnota má smysl jen ve srovnání, a to "
    "v tomto pořadí spolehlivosti: (a) trend téhož měřicího bodu — sleduj "
    "RYCHLOST změny, ne jen absolutní hodnotu; (b) baseline ze známého dobrého "
    "stavu; (c) shodný (sesterský) stroj za srovnatelných podmínek; (d) norma. "
    "Norma je hrubé vodítko pro stroj BEZ historie, ne rozhodčí. Zadání uvádí, "
    "které opory jsou k dispozici — použij tu nejsilnější a napiš, o kterou se "
    "závěr opírá. Je-li k dispozici jen norma, uveď to a doporuč založit "
    "baseline. Roste-li hodnota soustavně, zmiň to i v pásmu A/B.\n"
    "\n"
    "4) KTERÉ SPEKTRUM K ČEMU SLOUŽÍ. Každá veličina zvýrazňuje jiné pásmo, "
    "a proto se z ní vyvozuje jiný druh závady. Toto rozdělení je závazné:\n"
    "   • spektrum RYCHLOSTI [mm/s] — a jedině ono — slouží k nízkofrekvenční "
    "dynamice v řádech otáčkové frekvence: NEVÝVAHA, NESOUOSOST, MECHANICKÉ "
    "UVOLNĚNÍ, OHNUTÁ HŘÍDEL, NAKŘIVO NASAZENÉ LOŽISKO, ŘEMENOVÝ PŘEVOD, "
    "REZONANCE. Řády 1×–nX, poměr 2×/1× a subharmonické posuzuj výhradně zde;\n"
    "   • spektrum ZRYCHLENÍ [g] a OBÁLKY zrychlení [gE] slouží k "
    "vysokofrekvenčnímu poškození: VALIVÁ LOŽISKA, OZUBENÍ, PŘIDÍRÁNÍ, "
    "KAVITACE. Poruchové frekvence ložisek a záběr zubů posuzuj výhradně zde.\n"
    "   Každé spektrum má v zadání uvedenou roli v hranatých závorkách. "
    "Neodvozuj poškození ložiska ze spektra rychlosti ani nevývahu ze spektra "
    "obálky, i kdyby tam odpovídající frekvence náhodou vyšla.\n"
    "\n"
    "5) FFT SPEKTRA — VÝKLAD NÁLEZŮ. Pracuj pouze s uvedenými nálezy (vrcholy, "
    "otáčková a její harmonické, poruchové frekvence ložiska, postranní pásma, "
    "vzorec spektra). Závadu přiřazuj podle toho, kde leží dominantní energie:\n"
    "   • dominantní 1× ot radiálně, bez harmonických nad 15 % z 1× → "
    "NEVÝVAHA;\n"
    "   • 1× i 2× ot se zvýšenou axiální složkou → NESOUOSOST. Rozhoduj podle "
    "uvedeného poměru 2×/1×: pod 50 % obvykle přijatelné, 50–150 % "
    "pravděpodobné poškození spojky, nad 150 % vážná nesouosost;\n"
    "   • tři a více harmonických v rozsahu 2×–10× nad 20 % z 1×, "
    "subharmonické 0,5× / 1,5× / 2,5× a ZVÝŠENÝ práh šumu → MECHANICKÉ "
    "UVOLNĚNÍ. Nesouosost dává harmonické také, ale práh šumu nezvyšuje a "
    "subharmonické nemá — to je rozhodující rozdíl;\n"
    "   • zlomkové řády 1/3, 1/4, 1/5 spolu s harmonickými → PŘIDÍRÁNÍ "
    "ROTORU, nikoli uvolnění;\n"
    "   • shoda s BPFO / BPFI / BSF / FTF ve spektru zrychlení nebo obálky → "
    "POŠKOZENÍ VALIVÉHO LOŽISKA; násobky téže frekvence nález potvrzují. "
    "Osamocená složka bez násobků a bez postranních pásem je SLABÁ indikace — "
    "hledej i jiné vysvětlení;\n"
    "   • postranní pásma identifikují modulující prvek: odstup 1× ot → "
    "vnitřní kroužek, odstup FTF → valivý element, žádná modulace → vnější "
    "kroužek. U ozubení a motorů odstup ukazuje na konkrétní hřídel či na "
    "elektrický původ;\n"
    "   • zvýšená obálka zrychlení bez zvýšené rychlosti → počínající "
    "poškození ložiska nebo nedostatečné mazání;\n"
    "   • zvýšení bez vazby na řád či poruchovou frekvenci → možná rezonance; "
    "označ ji jako MOŽNOU, nikoli prokázanou.\n"
    "\n"
    "6) CHYBĚJÍCÍ KINEMATIKA. Je-li uveden silný celočíselný řád s odhadem "
    "počtu lopatek nebo zubů, ber jej jako KANDIDÁTA, ne jako fakt: napiš, že "
    "složka odpovídá průchodu lopatek či záběru zubů při daném počtu, a vyzvi "
    "k ověření na stroji. Řada harmonických POD otáčkovou frekvencí odpovídá "
    "řemenovému převodu. Nikdy neuváděj počet lopatek ani zubů jako zjištěný "
    "údaj.\n"
    "\n"
    "7) SMĚROVOST. Je-li uveden rozbor H/V/A, použij jej: radiální ≫ axiální "
    "s dominantní 1× svědčí pro nevývahu, axiální ≥ radiální pro nesouosost, "
    "V ≥ H s harmonickými pro uvolnění. Fázi HADS k dispozici nemá, takže "
    "nevývahu od nesouososti nelze prokázat s VYSOKOU jistotou — u takového "
    "závěru vždy doporuč doplňkové fázové odečty.\n"
    "\n"
    "8) KDYŽ NENÍ CO HLÁSIT. Nejsou-li u spekter uvedeny žádné nálezy nebo "
    "žádný z nich nevybočuje, napiš to přímo a stručně. Nikdy si nevymýšlej "
    "frekvenci, násobek, postranní pásmo ani závadu, která není v zadání "
    "doložena. Nejsou-li známy otáčky, neurčuj řády ani poruchové frekvence.\n"
    "\n"
    "9) PRIMÁRNÍ PŘÍČINA. Nález symptomu není nálezem příčiny. Poškozené "
    "ložisko bývá NÁSLEDKEM nesouososti, nevývahy, uvolnění, špatného mazání "
    "nebo průchodu proudu. U každého ložiskového nálezu se vyjádři i k tomu, "
    "co jej pravděpodobně způsobilo.\n"
    "\n"
    "10) MÍRA JISTOTY. Důsledně odlišuj prokázané od možného. Uvádí-li zadání "
    "upozornění k rozsahu měření, ke zvoleným otáčkám nebo k chybějícím "
    "vstupům, promítni je do závěru a jistotu odpovídajícím způsobem sniž. "
    "Nestačí-li data k jednoznačnému závěru, napiš to a navrhni konkrétní "
    "doplňující měření.\n"
    "\n"
    "11) JAZYK. Odborně, věcně a v ČEŠTINĚ, bez vycpávkových frází."
)

_DEFINITIONS = {
    METHODOLOGY_ID: {
        "label": "Metodologie diagnostiky (společná)",
        "purpose": ("Odborný postup hodnocení vibrací a FFT spekter. Vkládá se "
                    "do všech verzí protokolu i do poradce u měřicího bodu."),
        "template": _METHODOLOGY_DEFAULT,
    },
    "report_brief_v1": {
        "label": "Stručný protokol",
        "purpose": ("Závěr a doporučení pro každý stroj ve stručném protokolu. "
                    "Rozsah i strukturu závěru určuje výhradně tato šablona."),
        "template": (
            "{methodology}\n\n"
            "ÚKOL: Na základě naměřených dat napiš "
            "VELMI STRUČNÝ závěr a doporučení do protokolu z měření vibrací.\n"
            "STRUKTURA ZÁVĚRU: 2-3 krátké věty souvislého textu.\n"
            "DOPORUČENÍ: 1-2 krátké věty.\n"
            "{report_contract}"
        ),
    },
    "report_brief_v2": {
        "label": "Detailní protokol",
        "purpose": ("Strukturovaný závěr a doporučení pro každý stroj "
                    "v detailním protokolu. Počet i pořadí bodů závěru určuje "
                    "výhradně tato šablona."),
        "template": (
            "{methodology}\n\n"
            "ÚKOL: Na základě naměřených dat napiš "
            "JASNÝ a STRUČNÝ, ale STRUKTUROVANÝ závěr a doporučení do detailního "
            "protokolu z měření vibrací.\n"
            "STRUKTURA ZÁVĚRU: PŘESNĚ 4 ČÍSLOVANÉ BODY, "
            "KAŽDÝ BOD NA NOVÉM ŘÁDKU, V TOMTO PEVNÉM POŘADÍ:\n"
            "1. Zhodnocení rychlosti vibrací dle platné normy (ČSN ISO 10816/20816) "
            "s vyjádřením nejhoršího zjištěného stavu (které pásmo/směr/místo je "
            "nejhorší).\n"
            "2. Zhodnocení FFT spektra rychlosti vibrací a možná příčina zjištěného "
            "stavu. Pokud FFT analýza rychlosti NEODHALILA žádnou zvýšenou/"
            "nápadnou hodnotu, napiš do tohoto bodu prostě větu: "
            "'FFT spektra rychlosti vibrací bez detekce nedostatků.'\n"
            "3. Zhodnocení dle zrychlení a obálky zrychlení (pokud jsou tato data "
            "k dispozici; jinak stručně uveď, že nejsou k dispozici).\n"
            "4. Zhodnocení FFT zrychlení a obálky zrychlení (pokud jsou tato data "
            "k dispozici, včetně možné příčiny; jinak stručně uveď, že nejsou "
            "k dispozici).\n"
            "Každý bod piš jako 1-2 stručné, jasné věty — žádné zbytečné fráze.\n"
            "DOPORUČENÍ: 1-2 krátké věty.\n"
            "{report_contract}"
        ),
    },
    "report_brief_v3": {
        "label": "Protokol z vyvažování",
        "purpose": ("Závěr před/po vyvážení pro každý stroj. Počet i pořadí "
                    "bodů závěru určuje výhradně tato šablona."),
        "template": (
            "{methodology}\n\n"
            "ÚKOL: Jde o VYVAŽOVÁNÍ rotoru (zpravidla ventilátoru). "
            "Na základě naměřených dat PŘED a PO "
            "vyvážení napiš STRUKTUROVANÝ závěr do protokolu z vyvažování.\n"
            "STRUKTURA ZÁVĚRU: PŘESNĚ 3 ČÍSLOVANÉ BODY, "
            "KAŽDÝ BOD NA NOVÉM ŘÁDKU, V TOMTO PEVNÉM POŘADÍ:\n"
            "1. Zhodnocení POKLESU celkových hodnot rychlosti vibrací dle "
            "pásem A–D příslušné normy (např. 'Po vyčištění oběžného kola "
            "klesly celkové hodnoty z pásma D do pásma A'). Uveď z jakého "
            "pásma do jakého se hodnoty posunuly.\n"
            "2. Zhodnocení FFT spektra rychlosti vibrací PO vyvážení. Pokud "
            "FFT analýza rychlosti NEODHALILA žádnou zvýšenou/nápadnou "
            "hodnotu, napiš prostě: 'Spektra FFT rychlosti po vyvážení bez "
            "detekce poškození.'\n"
            "3. Zhodnocení zrychlení a obálky zrychlení se zaměřením na stav "
            "LOŽISEK (motor L1/L2, ventilátor L3/L4). Uveď případný mírný "
            "nárůst na konkrétním ložisku a možnou příčinu (např. nedokonalé "
            "mazání). Ukonči větou o provozním stavu.\n"
            "Každý bod piš jako 1-2 stručné, jasné věty.\n"
            "DOPORUČENÍ: 1-2 krátké věty, např. 'Provádět pravidelné kontrolní "
            "měření.' nebo 'Doplnit mazivo na ložisku L1.'\n"
            "{report_contract}"
        ),
    },
}

# POVINNÉ placeholdery. Metodologie sama žádný nemá — vkládá se DO ostatních
# šablon, takže by odkaz na sebe samu vytvořil rekurzi.
_REQUIRED_PLACEHOLDERS = {
    METHODOLOGY_ID: frozenset(),
    "report_brief_v1": frozenset({"report_contract"}),
    "report_brief_v2": frozenset({"report_contract"}),
    "report_brief_v3": frozenset({"report_contract"}),
}

# POVOLENÉ placeholdery. `{methodology}` je záměrně volitelný: řídí pouze to,
# KAM se metodologie vloží. Metodologie se uplatní vždy — chybí-li placeholder
# (typicky u šablony upravené ve starší verzi HADS), vloží se na začátek.
# Kdyby byl povinný, každý existující uživatelský přepis by se po aktualizaci
# stal neplatným a tiše by se zahodil ve prospěch výchozí šablony.
_ALLOWED_PLACEHOLDERS = {
    METHODOLOGY_ID: frozenset(),
    "report_brief_v1": frozenset({"report_contract", "methodology"}),
    "report_brief_v2": frozenset({"report_contract", "methodology"}),
    "report_brief_v3": frozenset({"report_contract", "methodology"}),
}

_PLACEHOLDER_HELP = {
    "report_contract": "Neměnný formát JSON a pravidla faktického ukotvení.",
    "methodology": ("Společná metodologie diagnostiky (samostatná šablona). "
                    "Volitelný — určuje jen místo vložení; bez něj se "
                    "metodologie vloží na začátek."),
}

_ALLOWED = frozenset({"report_contract", "methodology"})


class PromptValidationError(ValueError):
    """Chyba šablony vhodná pro bezpečné zobrazení v uživatelském rozhraní."""


class PromptConflictError(RuntimeError):
    """Jiná otevřená karta mezitím změnila globální konfiguraci."""

    def __init__(self, current_revision: int):
        super().__init__("Nastavení AI promptů mezitím změnila jiná otevřená karta.")
        self.current_revision = current_revision


@dataclass(frozen=True)
class PromptSnapshot:
    identifier: str
    text: str
    revision: int
    digest: str
    modified: bool
    # Text společné metodologie zachycený ve stejném okamžiku jako šablona.
    # Bez něj by úprava metodologie v jiné kartě mohla změnit prompt mezi
    # dvěma stroji téhož návrhu a audit by pak neodpovídal skutečnému běhu.
    methodology: str = ""
    methodology_modified: bool = False


def _path() -> Path:
    return DATA_DIR / FILE_NAME


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _parse_placeholders(text: str, allowed: frozenset[str] = _ALLOWED) -> list[tuple[str, int, int]]:
    """Vrátí placeholdery a přitom zkontroluje jednoduchou bezpečnou syntaxi."""
    if not isinstance(text, str):
        raise PromptValidationError("Prompt musí být text.")
    if not text.strip():
        raise PromptValidationError("Prompt nesmí být prázdný.")
    if len(text) > MAX_TEMPLATE_CHARS:
        raise PromptValidationError(
            "Prompt je příliš dlouhý (maximálně %d znaků)." % MAX_TEMPLATE_CHARS)
    found: list[tuple[str, int, int]] = []
    i = 0
    while i < len(text):
        char = text[i]
        if char == "{":
            if i + 1 < len(text) and text[i + 1] == "{":
                i += 2
                continue
            end = text.find("}", i + 1)
            if end < 0:
                raise PromptValidationError(
                    "Neuzavřená složená závorka. Doslovnou závorku zapište jako '{{'.")
            token = text[i + 1:end]
            if not token:
                raise PromptValidationError("Prázdný placeholder '{}' není povolen.")
            if (not token.replace("_", "a").isalpha() or not token.isascii()
                    or token != token.lower()):
                raise PromptValidationError(
                    "Neplatný placeholder '{%s}'. Povoleny jsou pouze malá písmena a podtržítko." % token)
            if token not in allowed:
                permitted = (", ".join("{%s}" % name for name in sorted(allowed))
                             if allowed else "v této šabloně žádný")
                raise PromptValidationError(
                    "Neznámý placeholder '{%s}'. Povoleno je: %s." % (token, permitted))
            found.append((token, i, end + 1))
            i = end + 1
            continue
        if char == "}":
            if i + 1 < len(text) and text[i + 1] == "}":
                i += 2
                continue
            raise PromptValidationError(
                "Neuzavřená složená závorka. Doslovnou závorku zapište jako '}}'.")
        i += 1
    return found


def validate_template(identifier: str, text: str) -> list[str]:
    """Ověří šablonu a vrátí seznam skutečně použitých placeholderů."""
    if identifier not in _DEFINITIONS:
        raise PromptValidationError("Neznámý typ promptu.")
    found = _parse_placeholders(text, _ALLOWED_PLACEHOLDERS[identifier])
    names = [item[0] for item in found]
    for name in sorted(_REQUIRED_PLACEHOLDERS[identifier]):
        count = names.count(name)
        if count == 0:
            raise PromptValidationError(
                "Chybí povinný placeholder {%s}; zajišťuje neměnný formát odpovědi." % name)
        if count != 1:
            raise PromptValidationError(
                "Placeholder {%s} musí být použit právě jednou." % name)
    if names.count("methodology") > 1:
        raise PromptValidationError(
            "Placeholder {methodology} smí být použit nejvýše jednou.")
    return names


def render_template(identifier: str, text: str, methodology: str | None = None) -> str:
    """Bezpečně vyrenderuje allowlist placeholderů, nepoužívá ``str.format``.

    `methodology` je text společné metodologie platný pro tento běh. None
    znamená „použij aktuálně uloženou“ — pro jeden návrh protokolu se ale
    předává explicitně ze snapshotu, aby editace v jiné kartě nezměnila
    prompt mezi stroji téhož návrhu.

    Metodologie se uplatní VŽDY. Neobsahuje-li šablona `{methodology}`
    (například proto, že ji uživatel upravil ve starší verzi HADS), vloží se
    na začátek — jinak by starší přepis tiše obešel společný odborný postup.
    """
    names = validate_template(identifier, text)
    supports = "methodology" in _ALLOWED_PLACEHOLDERS[identifier]
    if methodology is None and supports:
        methodology = _text_from(_load()[0], METHODOLOGY_ID)
    values = {
        "report_contract": _CONTRACTS.get(identifier, ""),
        "methodology": methodology or "",
    }
    if supports and "methodology" not in names and values["methodology"]:
        text = "{methodology}\n\n" + text
    out: list[str] = []
    i = 0
    while i < len(text):
        if text.startswith("{{", i):
            out.append("{")
            i += 2
        elif text.startswith("}}", i):
            out.append("}")
            i += 2
        elif text[i] == "{":
            end = text.index("}", i + 1)
            out.append(values[text[i + 1:end]])
            i = end + 1
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def _empty() -> dict[str, Any]:
    return {
        "format": FORMAT,
        "defaults_revision": DEFAULTS_REVISION,
        "revision": 0,
        "updated_at": None,
        "overrides": {},
    }


def _decode(raw: Any) -> tuple[dict[str, Any], list[str]]:
    """Načte podporovaný formát a invalidní override bezpečně ignoruje."""
    warnings: list[str] = []
    state = _empty()
    if raw is None:
        return state, warnings
    if not isinstance(raw, dict):
        return state, ["Soubor AI promptů není platný JSON objekt; používají se výchozí prompty."]
    # Migrace prvního experimentálního formátu bez explicitního čísla.
    if raw.get("format") not in (None, FORMAT):
        return state, ["Soubor AI promptů má nepodporovaný formát; používají se výchozí prompty."]
    try:
        revision = int(raw.get("revision", 0))
        if revision < 0:
            raise ValueError
    except (TypeError, ValueError):
        revision = 0
        warnings.append("Revize AI promptů je neplatná; byla použita bezpečná výchozí revize.")
    state["revision"] = revision
    state["updated_at"] = raw.get("updated_at") if isinstance(raw.get("updated_at"), str) else None
    overrides = raw.get("overrides")
    if overrides is None and isinstance(raw.get("prompts"), dict):
        overrides = raw["prompts"]
        warnings.append("Nalezen starší formát AI promptů; při příštím uložení bude převeden.")
    if not isinstance(overrides, dict):
        if overrides is not None:
            warnings.append("Přepisy AI promptů nejsou platné; používají se výchozí prompty.")
        return state, warnings
    for identifier, record in overrides.items():
        if identifier not in _DEFINITIONS:
            warnings.append("Neznámý uložený AI prompt byl ignorován.")
            continue
        text = record.get("text") if isinstance(record, dict) else record
        try:
            validate_template(identifier, text)
        except PromptValidationError:
            warnings.append(
                "Uložený prompt „%s“ není platný; používá se výchozí verze." %
                _DEFINITIONS[identifier]["label"])
            continue
        state["overrides"][identifier] = {
            "text": text,
            "updated_at": record.get("updated_at") if isinstance(record, dict) else None,
        }
    return state, warnings


def _load() -> tuple[dict[str, Any], list[str]]:
    path = _path()
    try:
        raw = json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return _empty(), ["Soubor AI promptů nelze načíst; používají se výchozí prompty."]
    return _decode(raw)


def _atomic_write(state: dict[str, Any]) -> None:
    path = _path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as stream:
            try:
                os.chmod(temporary, 0o600)
            except OSError:
                pass
            stream.write(payload)
            stream.flush()
            try:
                os.fsync(stream.fileno())
            except OSError:
                pass
        os.replace(temporary, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        try:
            temporary.unlink()
        except OSError:
            pass


def _text_from(state: dict[str, Any], identifier: str) -> str:
    record = state["overrides"].get(identifier) or {}
    return str(record.get("text") or _DEFINITIONS[identifier]["template"])


def _snapshot_from(state: dict[str, Any], identifier: str) -> PromptSnapshot:
    text = _text_from(state, identifier)
    methodology = _text_from(state, METHODOLOGY_ID)
    return PromptSnapshot(
        identifier=identifier,
        text=text,
        revision=int(state["revision"]),
        digest=_sha256(render_template(identifier, text, methodology)),
        modified=identifier in state["overrides"],
        methodology=methodology,
        methodology_modified=METHODOLOGY_ID in state["overrides"],
    )


def get_snapshot(identifier: str) -> PromptSnapshot:
    with _LOCK:
        state, _warnings = _load()
        if identifier not in _DEFINITIONS:
            raise PromptValidationError("Neznámý typ promptu.")
        return _snapshot_from(state, identifier)


def prompt_id_for_report_version(report_version: int | None) -> str:
    return "report_brief_v%d" % (3 if report_version == 3 else 2 if report_version == 2 else 1)


def report_snapshot(report_version: int | None) -> PromptSnapshot:
    return get_snapshot(prompt_id_for_report_version(report_version))


def render_snapshot(snapshot: PromptSnapshot) -> str:
    return render_template(snapshot.identifier, snapshot.text,
                           snapshot.methodology or None)


def audit_metadata(snapshot: PromptSnapshot) -> dict[str, Any]:
    templates = [{
        "id": snapshot.identifier,
        "sha256": snapshot.digest,
        "modified": snapshot.modified,
        "defaults_revision": DEFAULTS_REVISION,
    }]
    if snapshot.methodology:
        # Metodologie se do auditu zapisuje jen otiskem, nikdy celým textem.
        templates.append({
            "id": METHODOLOGY_ID,
            "sha256": _sha256(snapshot.methodology),
            "modified": snapshot.methodology_modified,
            "defaults_revision": DEFAULTS_REVISION,
        })
    return {
        "format": 1,
        "configuration_revision": snapshot.revision,
        "templates": templates,
    }


def public_config() -> dict[str, Any]:
    with _LOCK:
        state, warnings = _load()
        templates = []
        methodology = _text_from(state, METHODOLOGY_ID)
        for identifier, definition in _DEFINITIONS.items():
            snapshot = _snapshot_from(state, identifier)
            override = state["overrides"].get(identifier) or {}
            templates.append({
                "id": identifier,
                "label": definition["label"],
                "purpose": definition["purpose"],
                "text": snapshot.text,
                "is_modified": snapshot.modified,
                "saved_at": override.get("updated_at") if snapshot.modified else None,
                "default_hash": _sha256(render_template(
                    identifier, definition["template"], methodology)),
                "effective_hash": snapshot.digest,
                "placeholders": [{
                    "name": name,
                    "required": name in _REQUIRED_PLACEHOLDERS[identifier],
                    "description": _PLACEHOLDER_HELP.get(name, ""),
                } for name in sorted(_ALLOWED_PLACEHOLDERS[identifier])],
            })
        return {
            "format": FORMAT,
            "scope": "global",
            "revision": state["revision"],
            "defaults_revision": DEFAULTS_REVISION,
            "warnings": warnings,
            "templates": templates,
        }


def save_override(identifier: str, text: str, expected_revision: Any) -> dict[str, Any]:
    validate_template(identifier, text)
    with _LOCK:
        state, _warnings = _load()
        try:
            expected = int(expected_revision)
        except (TypeError, ValueError):
            raise PromptValidationError("Chybí platná revize nastavení. Načtěte prompty znovu.")
        if expected != state["revision"]:
            raise PromptConflictError(state["revision"])
        state["overrides"][identifier] = {"text": text, "updated_at": _now_iso()}
        state["revision"] += 1
        state["updated_at"] = _now_iso()
        state["defaults_revision"] = DEFAULTS_REVISION
        _atomic_write(state)
        return public_config()


def reset_override(identifier: str, expected_revision: Any) -> dict[str, Any]:
    if identifier not in _DEFINITIONS:
        raise PromptValidationError("Neznámý typ promptu.")
    with _LOCK:
        state, _warnings = _load()
        try:
            expected = int(expected_revision)
        except (TypeError, ValueError):
            raise PromptValidationError("Chybí platná revize nastavení. Načtěte prompty znovu.")
        if expected != state["revision"]:
            raise PromptConflictError(state["revision"])
        state["overrides"].pop(identifier, None)
        state["revision"] += 1
        state["updated_at"] = _now_iso()
        state["defaults_revision"] = DEFAULTS_REVISION
        _atomic_write(state)
        return public_config()


def preview(identifier: str, text: str) -> dict[str, str]:
    """Lokální náhled – nevolá poskytovatele AI ani nepoužívá data zákazníka."""
    rendered = render_template(identifier, text)
    return {
        "system_prompt": rendered,
        "sample_context": (
            "STROJ: Ukázkový pohon [anonymizováno]\n"
            "NAMĚŘENÁ DATA: rychlost vibrací 3,20 mm/s; limit varování 4,50 mm/s.\n"
            "Poznámka: jde o lokální anonymizovaný vzorek, AI nebyla volána."
        ),
    }
