"""Kontrola neměnnosti uživatelských dat během aktualizace HADS.

Tento modul není úložištěm aplikace.  Pracuje výhradně s účtenkami v
``updates/data-protection``; samotný aktualizátor proto nikdy nevytváří,
nepřejmenovává ani nemaže nic v ``data/`` ani v ``runtime/``.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import uuid
from typing import Any


MAX_FULL_HASH_BYTES = 32 * 1024 * 1024
SAMPLE_BYTES = 128 * 1024
DATA_VOLATILE = {
    "hads_server.lock", "hads_server.log", "hads_launcher.log",
}
_CREDENTIAL_PAIR = ("data/ai_credentials.bin", "data/ai_credentials.machinekey")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _sample_sha256(path: Path) -> str:
    size = path.stat().st_size
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        digest.update(stream.read(SAMPLE_BYTES))
        if size > SAMPLE_BYTES:
            stream.seek(max(0, size - SAMPLE_BYTES))
            digest.update(stream.read(SAMPLE_BYTES))
    return digest.hexdigest()


def _is_ndb_or_sidecar(rel: Path) -> bool:
    name = rel.name.casefold()
    return name.endswith(".ndb") or ".ndb-" in name or name.endswith(".ndb-journal")


def _is_volatile_data(rel: Path) -> bool:
    return len(rel.parts) == 1 and rel.name.casefold() in DATA_VOLATILE


def inventory(installation: Path) -> dict[str, Any]:
    """Return a deterministic, secret-free inventory of protected files.

    Small data and runtime files have a full SHA-256.  Large NDB files and
    sidecars are never copied by the updater; their size plus first/last sample
    hash makes an accidental replacement visible without reading multi-GB files.
    """
    installation = Path(installation).resolve()
    files: dict[str, dict[str, Any]] = {}
    for top in ("data", "runtime"):
        root = installation / top
        if not root.is_dir() or root.is_symlink():
            continue
        for item in sorted(root.rglob("*")):
            if not item.is_file() or item.is_symlink():
                continue
            rel = item.relative_to(installation)
            if top == "data" and _is_volatile_data(rel.relative_to("data")):
                continue
            size = item.stat().st_size
            rec: dict[str, Any] = {"size": size}
            if _is_ndb_or_sidecar(rel) or size > MAX_FULL_HASH_BYTES:
                rec.update({"kind": "ndb" if _is_ndb_or_sidecar(rel) else "large",
                            "sample_sha256": _sample_sha256(item)})
            else:
                rec.update({"kind": "file", "sha256": _sha256(item)})
            files[rel.as_posix()] = rec
    return {"format": 1, "files": files}


def compare(expected: dict[str, Any], actual: dict[str, Any]) -> dict[str, list[str]]:
    before = expected.get("files", {}) if isinstance(expected, dict) else {}
    after = actual.get("files", {}) if isinstance(actual, dict) else {}
    if not isinstance(before, dict) or not isinstance(after, dict):
        return {"missing": ["<neplatný inventář>"], "changed": [], "added": []}
    return {
        "missing": sorted(set(before) - set(after)),
        "changed": sorted(name for name in set(before) & set(after) if before[name] != after[name]),
        "added": sorted(set(after) - set(before)),
    }


def protected_summary(snapshot: dict[str, Any]) -> dict[str, int]:
    files = snapshot.get("files", {}) if isinstance(snapshot, dict) else {}
    total = sum(int(rec.get("size", 0)) for rec in files.values() if isinstance(rec, dict))
    ndb = sum(1 for name in files if name.casefold().startswith("data/") and _is_ndb_or_sidecar(Path(name)))
    return {"files": len(files), "bytes": total, "ndb_files": ndb}


def receipt_root(installation: Path) -> Path:
    return Path(installation) / "updates" / "data-protection"


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def write_receipt(installation: Path, backup_name: str, before: dict[str, Any],
                  after: dict[str, Any], backup_path: Path) -> Path:
    diff = compare(before, after)
    path = receipt_root(installation) / (backup_name + ".json")
    _atomic_json(path, {
        "format": 1, "created_at": time.time(), "status": "pending_startup_validation",
        "backup": str(backup_path), "before": before, "after_updater": after,
        "updater_difference": diff, "summary": protected_summary(before),
    })
    return path


def latest_pending_receipt(installation: Path) -> Path | None:
    root = receipt_root(installation)
    if not root.is_dir() or root.is_symlink():
        return None
    choices: list[Path] = []
    for item in root.glob("*.json"):
        if item.is_file() and not item.is_symlink():
            try:
                value = json.loads(item.read_text(encoding="utf-8"))
            except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                continue
            if value.get("status") == "pending_startup_validation":
                choices.append(item)
    return max(choices, key=lambda item: item.name) if choices else None


def _restore_missing_from_backup(installation: Path, backup: Path, missing: list[str],
                                 expected: dict[str, Any]) -> list[str]:
    """Restore only absent files from a verified small-file backup.

    Existing divergent files are deliberately never overwritten: they can be
    newer user work.  NDBs are intentionally absent from this backup format.
    """
    restored: list[str] = []
    root = backup / "data_files"
    # Credential blob + fallback key are one unit.  A lone restored half cannot
    # decrypt and must not be manufactured at application startup.  Existing
    # partial files are intentionally left untouched for explicit recovery.
    # Windows DPAPI LocalMachine has no machinekey companion.  Treat the pair
    # atomically only when this *specific backup inventory* contains both
    # fallback files; a DPAPI blob remains a verified standalone record.
    pair_is_applicable = all(name in expected.get("files", {}) for name in _CREDENTIAL_PAIR) if isinstance(expected, dict) else False
    pair_missing = [name for name in _CREDENTIAL_PAIR if name in missing] if pair_is_applicable else []
    pair_present = [name for name in _CREDENTIAL_PAIR if (Path(installation) / name).exists()]
    if pair_missing:
        # Never fall through to the ordinary per-file loop for this pair.
        missing = [name for name in missing if name not in _CREDENTIAL_PAIR]
        if pair_present or set(pair_missing) != set(_CREDENTIAL_PAIR):
            pass
        else:
            staged: list[tuple[Path, Path]] = []
            try:
                for name in _CREDENTIAL_PAIR:
                    record = expected.get("files", {}).get(name, {}) if isinstance(expected, dict) else {}
                    rel = Path(name).relative_to("data")
                    source, target = root / rel, Path(installation) / name
                    if (not source.is_file() or source.is_symlink()
                            or not isinstance(record, dict) or record.get("kind") != "file"
                            or source.stat().st_size != record.get("size")
                            or _sha256(source) != record.get("sha256")):
                        staged = []
                        break
                    target.parent.mkdir(parents=True, exist_ok=True)
                    temporary = target.with_name(target.name + ".restore-" + uuid.uuid4().hex)
                    shutil.copy2(source, temporary)
                    staged.append((temporary, target))
                if len(staged) == len(_CREDENTIAL_PAIR):
                    for temporary, target in staged:
                        os.replace(temporary, target)
                        restored.append(target.relative_to(installation).as_posix())
            finally:
                for temporary, _target in staged:
                    try:
                        temporary.unlink()
                    except OSError:
                        pass
    for name in missing:
        if not name.startswith("data/"):
            continue
        rel = Path(name).relative_to("data")
        source, target = root / rel, Path(installation) / name
        if not source.is_file() or source.is_symlink() or target.exists():
            continue
        record = expected.get("files", {}).get(name, {}) if isinstance(expected, dict) else {}
        if (not isinstance(record, dict) or record.get("kind") != "file"
                or source.stat().st_size != record.get("size")
                or _sha256(source) != record.get("sha256")):
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        restored.append(name)
    return restored


def validate_pending_startup(installation: Path) -> dict[str, Any] | None:
    """Validate the one outstanding update receipt before application migration.

    On damage, the function only restores files that are *missing* and are
    present in the independently created pre-update backup.  It reports the
    condition to the launcher/server; the caller must abort normal startup.
    """
    receipt_path = latest_pending_receipt(installation)
    if receipt_path is None:
        return None
    try:
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        expected = receipt["before"]
        backup = Path(str(receipt["backup"]))
    except (OSError, KeyError, TypeError, json.JSONDecodeError):
        return {"ok": False, "error": "Účtenka ochrany dat je nečitelná.", "receipt": str(receipt_path)}
    diff = compare(expected, inventory(installation))
    if not diff["missing"] and not diff["changed"]:
        receipt["status"] = "validated"
        receipt["validated_at"] = time.time()
        _atomic_json(receipt_path, receipt)
        return {"ok": True, "receipt": str(receipt_path), "summary": receipt.get("summary", {})}
    restored = _restore_missing_from_backup(installation, backup, diff["missing"], expected)
    final_diff = compare(expected, inventory(installation))
    receipt.update({
        "status": "damage_detected",
        "validated_at": time.time(),
        "detected_difference": diff,
        "restored_missing": restored,
        "difference_after_missing_restore": final_diff,
    })
    _atomic_json(receipt_path, receipt)
    return {
        "ok": False, "receipt": str(receipt_path), "backup": str(backup),
        "difference": final_diff, "restored_missing": restored,
        "error": ("Ochrana dat zjistila změnu po aktualizaci. HADS nebyl spuštěn; "
                  "program bude vrácen na předchozí verzi. Podrobnosti jsou v " + str(receipt_path)),
    }
