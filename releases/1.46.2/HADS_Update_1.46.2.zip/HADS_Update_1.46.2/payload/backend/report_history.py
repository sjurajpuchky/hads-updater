# -*- coding: utf-8 -*-
"""Perzistence HISTORIE finalizovaných protokolů (per podnik).

Na rozdíl od ``report_store.py`` (který drží pouze POSLEDNÍ rozpracovaný
návrh a přepisuje ho) tato historie protokoly **archivuje** – každé uložení
přidá novou položku do seznamu, nic se nepřepisuje. Uchovává se KOMPLETNÍ
dokument protokolu (``doc``), takže je vše zpětně vyvolatelné a editovatelné:
úvody, doplňující pokyny pro AI (``ai_context``), okruh strojů (``scope`` /
``scope_label`` / seznam ``machines``), závěry a doporučení (per stroj),
verze protokolu, hlavička, patička i příloha.

Data se ukládají per-podnik do ``data/podniky/<slug>/report_history.json``
ve tvaru SEZNAMU (dříve jeden sdílený ``data/report_history.json`` klíčovaný
``podnik:<název>``)::

    [ <záznam>, <záznam>, ... ]

kde nejnovější záznam je na začátku seznamu. Každý záznam::

    {
      "id": "<uuid>",              # stabilní identifikátor položky
      "created_at": "<ISO 8601>",  # kdy byl uložen do historie
      "updated_at": "<ISO 8601>",  # poslední editace položky v historii
      "label": "<lidský popis>",   # název protokolu + datum měření
      "report_title": "...",
      "report_version": 1,
      "date_measured": "...",
      "scope_label": "...",
      "machine_count": 3,
      "pdf_filename": "...",
      "ai_prompt_audit": { ... hash/revize promptu použitá při generování ... },
      "doc": { ... celý dokument protokolu ... }
    }

Používá POUZE standardní knihovnu Pythonu.
"""

import uuid
import datetime

import data_store

_KIND = data_store.KIND_REPORT_HISTORY


def _now_iso():
    # milisekundové rozlišení – aby se rychlá editace v rámci jedné sekundy
    # spolehlivě odlišila od času vytvoření (updated_at != created_at)
    now = datetime.datetime.now()
    return now.replace(microsecond=(now.microsecond // 1000) * 1000).isoformat()


def _load_items(db_key):
    """Vrátí seznam položek historie daného podniku (nebo prázdný seznam)."""
    items = data_store.load(_KIND, db_key, default=[])
    return items if isinstance(items, list) else []


def _save_items(db_key, items):
    data_store.save(_KIND, db_key, items)


def _machine_count(doc):
    try:
        return len(doc.get("machines") or [])
    except Exception:
        return 0


def _derive_label(doc):
    """Sestaví lidský popisek položky historie z dokumentu protokolu."""
    d = doc if isinstance(doc, dict) else {}
    title = str(d.get("report_title") or "Protokol").strip() or "Protokol"
    dm = str(d.get("date_measured") or "").strip()
    dc = str(d.get("date_created") or "").strip()
    date_part = dm or dc
    if date_part:
        return "%s (%s)" % (title, date_part)
    return title


def _summarize(rec):
    """Vrátí položku bez těžkého ``doc`` – pro výpis seznamu ve frontendu."""
    return {
        "id": rec.get("id"),
        "created_at": rec.get("created_at"),
        "updated_at": rec.get("updated_at"),
        "label": rec.get("label"),
        "report_title": rec.get("report_title"),
        "report_version": rec.get("report_version"),
        "date_measured": rec.get("date_measured"),
        "date_created": rec.get("date_created"),
        "scope_label": rec.get("scope_label"),
        "machine_count": rec.get("machine_count"),
        "pdf_filename": rec.get("pdf_filename"),
        "company_name": rec.get("company_name"),
        "ai_prompt_audit": rec.get("ai_prompt_audit"),
    }


def list_history(db_key):
    """Vrátí seznam položek historie (nejnovější první) BEZ ``doc``."""
    if not db_key:
        return []
    return [_summarize(r) for r in _load_items(db_key)]


def get_entry(db_key, entry_id):
    """Vrátí kompletní záznam historie (včetně ``doc``), nebo None."""
    if not db_key or not entry_id:
        return None
    for r in _load_items(db_key):
        if r.get("id") == entry_id:
            return r
    return None


def add_entry(db_key, doc, pdf_filename=None):
    """Přidá NOVÝ protokol do historie (archivace, nepřepisuje).

    Uloží kompletní ``doc`` + odvozená metadata. Vrací shrnutí nové položky.
    """
    if not db_key or not isinstance(doc, dict):
        return None
    items = _load_items(db_key)
    now = _now_iso()
    rec = {
        "id": uuid.uuid4().hex,
        "created_at": now,
        "updated_at": now,
        "label": _derive_label(doc),
        "report_title": doc.get("report_title") or "",
        "report_version": doc.get("report_version") or 1,
        "date_measured": doc.get("date_measured") or "",
        "date_created": doc.get("date_created") or "",
        "scope_label": doc.get("scope_label") or "",
        "machine_count": _machine_count(doc),
        "pdf_filename": pdf_filename or doc.get("pdf_filename") or "",
        "company_name": doc.get("company_name") or "",
        "ai_prompt_audit": doc.get("ai_prompt_audit"),
        "doc": doc,
    }
    items.insert(0, rec)          # nejnovější první
    _save_items(db_key, items)
    return _summarize(rec)


def update_entry(db_key, entry_id, doc, pdf_filename=None):
    """Přepíše EXISTUJÍCÍ položku historie novým obsahem (editace).

    Zachová ``id`` a ``created_at``, aktualizuje ``updated_at`` a metadata.
    Vrací shrnutí, nebo None když položka neexistuje.
    """
    if not db_key or not entry_id or not isinstance(doc, dict):
        return None
    items = _load_items(db_key)
    for i, r in enumerate(items):
        if r.get("id") == entry_id:
            r["doc"] = doc
            r["updated_at"] = _now_iso()
            r["label"] = _derive_label(doc)
            r["report_title"] = doc.get("report_title") or ""
            r["report_version"] = doc.get("report_version") or 1
            r["date_measured"] = doc.get("date_measured") or ""
            r["date_created"] = doc.get("date_created") or ""
            r["scope_label"] = doc.get("scope_label") or ""
            r["machine_count"] = _machine_count(doc)
            r["pdf_filename"] = (pdf_filename or doc.get("pdf_filename")
                                 or r.get("pdf_filename") or "")
            r["company_name"] = doc.get("company_name") or ""
            r["ai_prompt_audit"] = doc.get("ai_prompt_audit")
            items[i] = r
            _save_items(db_key, items)
            return _summarize(r)
    return None


def delete_entry(db_key, entry_id):
    """Smaže položku historie. Vrací True při úspěchu."""
    if not db_key or not entry_id:
        return False
    items = _load_items(db_key)
    new_items = [r for r in items if r.get("id") != entry_id]
    if len(new_items) == len(items):
        return False
    _save_items(db_key, new_items)
    return True


def migrate_key(old_key, new_key):
    """Přesune data podniku ze staré složky do nové (deleguje na
    data_store.rename_podnik). Ponecháno kvůli zpětné kompatibilitě API.
    """
    if not old_key or not new_key or old_key == new_key:
        return
    data_store.rename_podnik(old_key, new_key)
