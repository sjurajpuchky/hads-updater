# -*- coding: utf-8 -*-
"""Minimalistický generátor DOCX (OOXML) — POUZE standardní knihovna Pythonu.

Nepoužívá python-docx ani žádný jiný externí balíček — pouze `zipfile` a
ruční sestavení XML částí balíčku .docx (Office Open XML / WordprocessingML).
Výsledný soubor je STANDARDNÍ, plně editovatelný dokument aplikace Microsoft
Word / LibreOffice Writer (žádná makra, žádné externí odkazy, žádné pole
generovaná serverem za běhu — dokument je čistě statický obsah).

Podporuje:
  * odstavce s běžnými styly (nadpisy, běžný text, poznámky),
  * běhy textu (run) s tučným/kurzívou/barvou/velikostí,
  * jednoduché i složité tabulky (sloučené záhlaví, stínování buněk, šířky
    sloupců v procentech obsahové šířky),
  * barevné "chipy" stavu pomocí stínování buňky (shading) + tučný text,
  * vložené rastrové obrázky (JPEG/PNG) přes vztahy (relationships),
  * podporu skrytých strukturovaných značek (content controls / prostý
    text s neviditelnou barvou) pro následné strojové rozpoznání sekcí při
    importu — VŽDY jen jako komentářový text v dokumentu, nikdy jako
    skutečná pole/makra.

Cílem je, aby výsledný .docx vypadal designově obdobně jako PDF generované
`report_pdf.py`, ale byl 100% editovatelný ve Wordu (žádný vložený obrázek
celé stránky, žádné needitovatelné rámečky).
"""

import io
import re
import zipfile
from xml.sax.saxutils import escape as _xml_escape

EMU_PER_PX = 9525  # 1 px (96 DPI) = 9525 EMU
TWIPS_PER_PT = 20  # 1 bod = 20 twips (jednotky WordprocessingML)
DXA = TWIPS_PER_PT  # alias


def _esc(s):
    if s is None:
        s = ""
    return _xml_escape(str(s), {'"': "&quot;"})


def pt(v):
    """Body -> twips (celé číslo)."""
    return int(round(float(v) * TWIPS_PER_PT))


def half_pt(v):
    """Body -> half-points (velikost fontu ve WordprocessingML je v 1/2 bodu)."""
    return int(round(float(v) * 2))


def rgb_hex(rgb):
    """(r,g,b) v rozsahu 0..1 nebo 0..255 -> "RRGGBB"."""
    if rgb is None:
        return None
    r, g, b = rgb
    if max(r, g, b) <= 1.0:
        r, g, b = r * 255, g * 255, b * 255
    return "%02X%02X%02X" % (int(round(r)), int(round(g)), int(round(b)))


# =====================================================================
#                              RUN / ODSTAVEC
# =====================================================================
class Run:
    """Jeden textový běh (run) v odstavci."""

    def __init__(self, text="", bold=False, italic=False, size=None,
                 color=None, font=None, hidden=False, underline=False,
                 highlight=None, vanish_tag=None):
        self.text = text
        self.bold = bold
        self.italic = italic
        self.size = size          # v bodech
        self.color = color        # (r,g,b) 0..1 nebo hex řetězec "RRGGBB"
        self.font = font
        self.hidden = hidden      # skrytý text (w:vanish) — pro strojové značky
        self.underline = underline
        self.highlight = highlight  # word highlight name, e.g. "yellow"
        self.vanish_tag = vanish_tag  # nepoužito zde, rezerva

    def _color_hex(self):
        if self.color is None:
            return None
        if isinstance(self.color, str):
            return self.color.lstrip("#").upper()
        return rgb_hex(self.color)

    def to_xml(self):
        props = []
        if self.font:
            props.append(
                '<w:rFonts w:ascii="%s" w:hAnsi="%s" w:cs="%s"/>'
                % (_esc(self.font), _esc(self.font), _esc(self.font)))
        if self.bold:
            props.append("<w:b/>")
        if self.italic:
            props.append("<w:i/>")
        if self.underline:
            props.append('<w:u w:val="single"/>')
        col = self._color_hex()
        if col:
            props.append('<w:color w:val="%s"/>' % col)
        if self.highlight:
            props.append('<w:highlight w:val="%s"/>' % _esc(self.highlight))
        if self.size:
            sz = half_pt(self.size)
            props.append('<w:sz w:val="%d"/>' % sz)
            props.append('<w:szCs w:val="%d"/>' % sz)
        if self.hidden:
            props.append("<w:vanish/>")
        rpr = ("<w:rPr>" + "".join(props) + "</w:rPr>") if props else ""
        # zachovej mezery na začátku/konci a zalomení řádků
        lines = (self.text or "").split("\n")
        parts = []
        for i, ln in enumerate(lines):
            if i > 0:
                parts.append("<w:br/>")
            if ln != "":
                parts.append(
                    '<w:t xml:space="preserve">%s</w:t>' % _esc(ln))
        body = "".join(parts) if parts else '<w:t xml:space="preserve"></w:t>'
        return "<w:r>" + rpr + body + "</w:r>"


class Paragraph:
    """Odstavec — sekvence run(ů) + volitelné vlastnosti odstavce."""

    def __init__(self, runs=None, align=None, spacing_before=0,
                 spacing_after=6, style=None, shading=None,
                 border_bottom=None, keep_next=False, indent_left=0,
                 line_spacing=None):
        if runs is None:
            runs = []
        elif isinstance(runs, Run):
            runs = [runs]
        elif isinstance(runs, str):
            runs = [Run(runs)]
        self.runs = runs
        self.align = align  # left/center/right/both
        self.spacing_before = spacing_before
        self.spacing_after = spacing_after
        self.style = style  # style id, e.g. "Heading1"
        self.shading = shading  # hex barva pozadí odstavce
        self.border_bottom = border_bottom  # hex barva spodní linky nebo None
        self.keep_next = keep_next
        self.indent_left = indent_left  # v bodech
        self.line_spacing = line_spacing

    def add_run(self, run):
        self.runs.append(run)
        return self

    def to_xml(self):
        pprops = []
        if self.style:
            pprops.append('<w:pStyle w:val="%s"/>' % _esc(self.style))
        if self.keep_next:
            pprops.append("<w:keepNext/>")
        spacing_attrs = 'w:before="%d" w:after="%d"' % (
            pt(self.spacing_before), pt(self.spacing_after))
        if self.line_spacing:
            spacing_attrs += ' w:line="%d" w:lineRule="auto"' % int(
                self.line_spacing * 240)
        pprops.append("<w:spacing %s/>" % spacing_attrs)
        if self.indent_left:
            pprops.append('<w:ind w:left="%d"/>' % pt(self.indent_left))
        if self.align:
            pprops.append('<w:jc w:val="%s"/>' % self.align)
        if self.shading:
            pprops.append(
                '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>'
                % self.shading)
        if self.border_bottom:
            pprops.append(
                '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" '
                'w:color="%s"/></w:pBdr>' % self.border_bottom)
        ppr = ("<w:pPr>" + "".join(pprops) + "</w:pPr>") if pprops else ""
        runs_xml = "".join(r.to_xml() for r in self.runs)
        return "<w:p>" + ppr + runs_xml + "</w:p>"


def hidden_tag(tag_text):
    """Vytvoří skrytý run se strojovou značkou (pro tagovaný import).

    Značky mají tvar `[[HADS:...]]` a jsou vysázeny BÍLÝM, velmi malým a
    skrytým (w:vanish) textem, aby se nikdy nezobrazily ani netiskly, ale
    zůstaly čitelné jako obyčejný text při parsování XML dokumentu (tedy i
    když je uživatel při úpravách omylem "odskryje", nejde o pole ani o
    makro – jde o prostý text).
    """
    return Run(tag_text, size=1, color="FFFFFF", hidden=True)


# =====================================================================
#                                TABULKA
# =====================================================================
class Cell:
    def __init__(self, paragraphs=None, shading=None, width_pct=None,
                 valign="center", colspan=1, borders=True):
        if paragraphs is None:
            paragraphs = [Paragraph()]
        elif isinstance(paragraphs, Paragraph):
            paragraphs = [paragraphs]
        self.paragraphs = paragraphs
        self.shading = shading
        self.width_pct = width_pct  # % z celkové šířky tabulky (0..100)
        self.valign = valign
        self.colspan = colspan
        self.borders = borders

    def to_xml(self, total_width_twips):
        w = int(total_width_twips * (self.width_pct or 0) / 100.0)
        props = ['<w:tcW w:w="%d" w:type="dxa"/>' % w]
        if self.colspan > 1:
            props.append('<w:gridSpan w:val="%d"/>' % self.colspan)
        if self.shading:
            props.append(
                '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>'
                % self.shading)
        props.append('<w:vAlign w:val="%s"/>' % self.valign)
        margins = ('<w:tcMar><w:top w:w="40" w:type="dxa"/>'
                   '<w:left w:w="80" w:type="dxa"/>'
                   '<w:bottom w:w="40" w:type="dxa"/>'
                   '<w:right w:w="80" w:type="dxa"/></w:tcMar>')
        tcpr = "<w:tcPr>" + "".join(props) + margins + "</w:tcPr>"
        body = "".join(p.to_xml() for p in self.paragraphs)
        return "<w:tc>" + tcpr + body + "</w:tc>"


class Row:
    def __init__(self, cells=None, header=False, height=None):
        self.cells = cells or []
        self.header = header
        self.height = height  # v bodech (minimální výška)

    def to_xml(self, total_width_twips):
        props = []
        if self.header:
            props.append("<w:tblHeader/>")
        if self.height:
            props.append('<w:trHeight w:val="%d" w:hRule="atLeast"/>'
                        % pt(self.height))
        trpr = ("<w:trPr>" + "".join(props) + "</w:trPr>") if props else ""
        cells_xml = "".join(c.to_xml(total_width_twips) for c in self.cells)
        return "<w:tr>" + trpr + cells_xml + "</w:tr>"


class Table:
    """Tabulka s viditelnými vlasovými linkami (jako v PDF designu)."""

    def __init__(self, rows=None, width_pct=100, border_color="CCCCCC"):
        self.rows = rows or []
        self.width_pct = width_pct
        self.border_color = border_color

    def add_row(self, row):
        self.rows.append(row)
        return self

    def to_xml(self, page_content_width_twips):
        total_w = int(page_content_width_twips * self.width_pct / 100.0)
        bc = self.border_color
        borders = (
            "<w:tblBorders>"
            '<w:top w:val="single" w:sz="4" w:space="0" w:color="%s"/>'
            '<w:left w:val="single" w:sz="4" w:space="0" w:color="%s"/>'
            '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="%s"/>'
            '<w:right w:val="single" w:sz="4" w:space="0" w:color="%s"/>'
            '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="%s"/>'
            '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="%s"/>'
            "</w:tblBorders>" % (bc, bc, bc, bc, bc, bc)
        )
        tblpr = (
            "<w:tblPr>"
            '<w:tblW w:w="%d" w:type="dxa"/>' % total_w
            + borders +
            '<w:tblLayout w:type="fixed"/>'
            "</w:tblPr>"
        )
        grid = "<w:tblGrid>"
        if self.rows:
            first = self.rows[0]
            for c in first.cells:
                cw = int(total_w * (c.width_pct or 0) / 100.0)
                for _ in range(c.colspan):
                    grid += '<w:gridCol w:w="%d"/>' % (cw // max(1, c.colspan))
        grid += "</w:tblGrid>"
        rows_xml = "".join(r.to_xml(total_w) for r in self.rows)
        return "<w:tbl>" + tblpr + grid + rows_xml + "</w:tbl>"


class PageBreak(object):
    def to_xml(self):
        return "<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>"


class Image(object):
    """Vložený obrázek (JPEG/PNG) jako plovoucí prvek v odstavci (inline)."""

    _COUNTER = [0]

    def __init__(self, data, width_px, height_px, content_type="image/jpeg",
                 align="left"):
        self.data = data
        self.width_px = width_px
        self.height_px = height_px
        self.content_type = content_type
        self.align = align
        Image._COUNTER[0] += 1
        self._id = Image._COUNTER[0]

    def ext(self):
        return "png" if "png" in self.content_type else "jpeg"


# =====================================================================
#                               DOCUMENT
# =====================================================================
class DocxDocument:
    """Sestaví kompletní .docx (Wordprocessing) dokument z odstavců/tabulek.

    Rozvržení stránky: A4 na výšku, okraje shodné s PDF (viz report_pdf.py:
    56 bodů vlevo/vpravo -> ~2 cm), s podporou záhlaví/zápatí a číslování
    stránek.
    """

    PAGE_W_TWIPS = 11906   # A4 210mm
    PAGE_H_TWIPS = 16838   # A4 297mm
    MARGIN_TWIPS = 1134    # ~2cm (shodné přibližně s 56pt okrajem PDF)

    def __init__(self, title="Protokol", subject="", creator="HADS"):
        self.body = []  # seznam Paragraph / Table / PageBreak
        self.title = title
        self.subject = subject
        self.creator = creator
        self._images = []  # list of Image objects actually inserted
        self._header_paragraphs = None
        self._footer_paragraphs = None

    @property
    def content_width_twips(self):
        return self.PAGE_W_TWIPS - 2 * self.MARGIN_TWIPS

    def add(self, item):
        self.body.append(item)
        return item

    def add_paragraph(self, *args, **kwargs):
        p = Paragraph(*args, **kwargs)
        self.body.append(p)
        return p

    def add_heading(self, text, level=1, color=None, size=None,
                     spacing_before=14, spacing_after=8):
        default_sizes = {1: 18, 2: 13, 3: 11}
        sz = size or default_sizes.get(level, 11)
        p = Paragraph(
            Run(text, bold=True, size=sz, color=color),
            spacing_before=spacing_before, spacing_after=spacing_after,
            keep_next=True)
        self.body.append(p)
        return p

    def add_page_break(self):
        self.body.append(PageBreak())

    def add_table(self, table):
        self.body.append(table)
        # tabulky ve WordprocessingML potřebují mít za sebou odstavec,
        # jinak se mohou spojit s následující tabulkou
        return table

    def set_header_footer(self, header_paragraphs, footer_paragraphs):
        self._header_paragraphs = header_paragraphs
        self._footer_paragraphs = footer_paragraphs

    def add_image_inline(self, data, width_px, height_px,
                          content_type="image/jpeg", max_width_pt=None,
                          align="left"):
        """Přidá obrázek jako samostatný odstavec (inline, ne page-anchored)."""
        img = Image(data, width_px, height_px, content_type, align)
        self._images.append(img)
        p = Paragraph(align=align, spacing_after=8)
        p._image = img  # speciální marker zpracovaný v _paragraph_or_image_xml
        self.body.append(p)
        return img

    # -------------------- interní: sestavení XML částí --------------------
    def _body_xml(self):
        out = []
        for item in self.body:
            if isinstance(item, PageBreak):
                out.append(item.to_xml())
            elif isinstance(item, Table):
                out.append(item.to_xml(self.content_width_twips))
                # prázdný odstavec po tabulce (dobrá praxe v OOXML)
                out.append('<w:p><w:pPr><w:spacing w:before="0" w:after="0"/>'
                           '</w:pPr></w:p>')
            elif isinstance(item, Paragraph):
                if getattr(item, "_image", None) is not None:
                    out.append(self._image_paragraph_xml(item))
                else:
                    out.append(item.to_xml())
            else:
                out.append(str(item))
        return "".join(out)

    def _image_paragraph_xml(self, para):
        img = para._image
        cx = img.width_px * EMU_PER_PX
        cy = img.height_px * EMU_PER_PX
        rid = "rIdImg%d" % img._id
        img._rid = rid
        align = para.align or "left"
        jc = '<w:jc w:val="%s"/>' % align if align else ""
        drawing = (
            '<w:drawing>'
            '<wp:inline distT="0" distB="0" distL="0" distR="0">'
            '<wp:extent cx="%d" cy="%d"/>' % (cx, cy) +
            '<wp:effectExtent l="0" t="0" r="0" b="0"/>'
            '<wp:docPr id="%d" name="Obrazek%d"/>' % (img._id, img._id) +
            '<wp:cNvGraphicFramePr>'
            '<a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/'
            'drawingml/2006/main" noChangeAspect="1"/>'
            '</wp:cNvGraphicFramePr>'
            '<a:graphic xmlns:a="http://schemas.openxmlformats.org/'
            'drawingml/2006/main">'
            '<a:graphicData uri="http://schemas.openxmlformats.org/'
            'drawingml/2006/picture">'
            '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/'
            'drawingml/2006/picture">'
            '<pic:nvPicPr><pic:cNvPr id="%d" name="Obrazek%d"/>'
            % (img._id, img._id) +
            '<pic:cNvPicPr/></pic:nvPicPr>'
            '<pic:blipFill><a:blip r:embed="%s"/>' % rid +
            '<a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
            '<pic:spPr><a:xfrm><a:off x="0" y="0"/>'
            '<a:ext cx="%d" cy="%d"/></a:xfrm>' % (cx, cy) +
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
            '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing>'
        )
        return "<w:p><w:pPr>%s</w:pPr><w:r>%s</w:r></w:p>" % (jc, drawing)

    def _section_props_xml(self, has_header, has_footer):
        refs = ""
        if has_header:
            refs += '<w:headerReference w:type="default" r:id="rIdHeader"/>'
        if has_footer:
            refs += '<w:footerReference w:type="default" r:id="rIdFooter"/>'
        return (
            "<w:sectPr>" + refs +
            '<w:pgSz w:w="%d" w:h="%d"/>' % (self.PAGE_W_TWIPS, self.PAGE_H_TWIPS) +
            '<w:pgMar w:top="%d" w:right="%d" w:bottom="%d" w:left="%d" '
            'w:header="480" w:footer="480" w:gutter="0"/>'
            % (self.MARGIN_TWIPS, self.MARGIN_TWIPS, self.MARGIN_TWIPS,
               self.MARGIN_TWIPS) +
            "</w:sectPr>"
        )

    def _document_xml(self):
        body = self._body_xml()
        sect = self._section_props_xml(
            self._header_paragraphs is not None,
            self._footer_paragraphs is not None)
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:document '
            'xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" '
            'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
            'xmlns:o="urn:schemas-microsoft-com:office:office" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
            'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
            'xmlns:v="urn:schemas-microsoft-com:vml" '
            'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
            'xmlns:w10="urn:schemas-microsoft-com:office:word" '
            'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
            'xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" '
            'xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" '
            'xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" '
            'xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" '
            'mc:Ignorable="w14 wp14">'
            "<w:body>" + body + sect + "</w:body>"
            "</w:document>"
        )

    def _styles_xml(self):
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:styles xmlns:w="http://schemas.openxmlformats.org/'
            'wordprocessingml/2006/main">'
            '<w:docDefaults>'
            '<w:rPrDefault><w:rPr>'
            '<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>'
            '<w:sz w:val="20"/><w:lang w:val="cs-CZ"/>'
            '</w:rPr></w:rPrDefault>'
            "</w:docDefaults>"
            '<w:style w:type="paragraph" w:default="1" w:styleId="Normal">'
            '<w:name w:val="Normal"/><w:qFormat/>'
            "</w:style>"
            '<w:style w:type="paragraph" w:styleId="Heading1">'
            '<w:name w:val="heading 1"/><w:basedOn w:val="Normal"/>'
            '<w:qFormat/><w:pPr><w:spacing w:before="240" w:after="120"/>'
            "</w:pPr>"
            '<w:rPr><w:b/><w:sz w:val="32"/></w:rPr>'
            "</w:style>"
            "</w:styles>"
        )

    def _header_footer_xml(self, paragraphs, tag):
        body = "".join(p.to_xml() for p in paragraphs)
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            "<w:%s "
            'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            "%s</w:%s>" % (tag, body, tag)
        )

    def _content_types_xml(self):
        overrides = [
            '<Override PartName="/word/document.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.'
            'wordprocessingml.document.main+xml"/>',
            '<Override PartName="/word/styles.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.'
            'wordprocessingml.styles+xml"/>',
            '<Override PartName="/docProps/core.xml" '
            'ContentType="application/vnd.openxmlformats-package.'
            'core-properties+xml"/>',
            '<Override PartName="/docProps/app.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.'
            'extended-properties+xml"/>',
        ]
        defaults = [
            '<Default Extension="rels" '
            'ContentType="application/vnd.openxmlformats-package.'
            'relationships+xml"/>',
            '<Default Extension="xml" ContentType="application/xml"/>',
            '<Default Extension="jpeg" ContentType="image/jpeg"/>',
            '<Default Extension="png" ContentType="image/png"/>',
        ]
        if self._header_paragraphs is not None:
            overrides.append(
                '<Override PartName="/word/header1.xml" '
                'ContentType="application/vnd.openxmlformats-officedocument.'
                'wordprocessingml.header+xml"/>')
        if self._footer_paragraphs is not None:
            overrides.append(
                '<Override PartName="/word/footer1.xml" '
                'ContentType="application/vnd.openxmlformats-officedocument.'
                'wordprocessingml.footer+xml"/>')
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/'
            'content-types">' + "".join(defaults) + "".join(overrides) +
            "</Types>"
        )

    def _rels_root_xml(self):
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Relationships xmlns="http://schemas.openxmlformats.org/'
            'package/2006/relationships">'
            '<Relationship Id="rId1" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/'
            'relationships/officeDocument" Target="word/document.xml"/>'
            '<Relationship Id="rId2" '
            'Type="http://schemas.openxmlformats.org/package/2006/'
            'relationships/metadata/core-properties" '
            'Target="docProps/core.xml"/>'
            '<Relationship Id="rId3" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/'
            'relationships/extended-properties" Target="docProps/app.xml"/>'
            "</Relationships>"
        )

    def _document_rels_xml(self):
        rels = [
            '<Relationship Id="rIdStyles" '
            'Type="http://schemas.openxmlformats.org/officeDocument/2006/'
            'relationships/styles" Target="styles.xml"/>',
        ]
        if self._header_paragraphs is not None:
            rels.append(
                '<Relationship Id="rIdHeader" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                'relationships/header" Target="header1.xml"/>')
        if self._footer_paragraphs is not None:
            rels.append(
                '<Relationship Id="rIdFooter" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                'relationships/footer" Target="footer1.xml"/>')
        for img in self._images:
            rels.append(
                '<Relationship Id="%s" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                'relationships/image" Target="media/image%d.%s"/>'
                % (img._rid, img._id, img.ext()))
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Relationships xmlns="http://schemas.openxmlformats.org/'
            'package/2006/relationships">' + "".join(rels) +
            "</Relationships>"
        )

    def _core_xml(self):
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<cp:coreProperties '
            'xmlns:cp="http://schemas.openxmlformats.org/package/2006/'
            'metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" '
            'xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            "<dc:title>%s</dc:title>"
            "<dc:subject>%s</dc:subject>"
            "<dc:creator>%s</dc:creator>"
            "</cp:coreProperties>"
            % (_esc(self.title), _esc(self.subject), _esc(self.creator))
        )

    def _app_xml(self):
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Properties xmlns="http://schemas.openxmlformats.org/'
            'officeDocument/2006/extended-properties">'
            "<Application>HADS</Application>"
            "</Properties>"
        )

    def save_bytes(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", self._content_types_xml())
            z.writestr("_rels/.rels", self._rels_root_xml())
            z.writestr("docProps/core.xml", self._core_xml())
            z.writestr("docProps/app.xml", self._app_xml())
            z.writestr("word/document.xml", self._document_xml())
            z.writestr("word/styles.xml", self._styles_xml())
            z.writestr("word/_rels/document.xml.rels",
                       self._document_rels_xml())
            if self._header_paragraphs is not None:
                z.writestr("word/header1.xml",
                           self._header_footer_xml(self._header_paragraphs,
                                                   "hdr"))
            if self._footer_paragraphs is not None:
                z.writestr("word/footer1.xml",
                           self._header_footer_xml(self._footer_paragraphs,
                                                   "ftr"))
            for img in self._images:
                z.writestr("word/media/image%d.%s" % (img._id, img.ext()),
                           img.data)
        return buf.getvalue()
