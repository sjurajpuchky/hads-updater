"""Lokální úložiště API klíčů HADS.

Windows používá DPAPI ``CRYPTPROTECT_LOCAL_MACHINE``.  To odpovídá volbě
"tento počítač": data mohou používat lokální uživatelé stejné instalace, ale
blob nejde dešifrovat na jiném počítači.  Volitelná entropie obsahuje stabilní
identifikátor instalace uložený pouze jako metadata v šifrovaném blobu.

Na jiných systémech stdlib Python nemá přístup k OS keychainu.  Proto se
klíče ukládají šifrované proudem odvozeným z lokálního klíče 0600 v samostatném
souboru a ověřené HMAC.  Není to náhrada systémového trezoru: uživatel nebo
proces, který umí číst oba soubory, může klíče obnovit.  Pro přísnější model
se mají použít proměnné prostředí OPENAI_API_KEY/ANTHROPIC_API_KEY.
"""
from __future__ import annotations

import base64
import binascii
import ctypes
from ctypes import wintypes
import hashlib
import hmac
import json
import os
from pathlib import Path
import platform
import secrets
import stat
import tempfile
from typing import Callable


CREDENTIALS_FILENAME = "ai_credentials.bin"
LOCAL_KEY_FILENAME = "ai_credentials.machinekey"
FORMAT = 1
WINDOWS_BACKEND = "windows-dpapi-local-machine"
FALLBACK_BACKEND = "local-0600-machine-key-v1"
_CONTEXT = b"HADS AI credentials\x00v1\x00"


class SecretStorageError(RuntimeError):
    """Chyba trezoru bez obsahu tajemství."""


def _atomic_write(path: Path, raw: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, name = tempfile.mkstemp(prefix=path.name + ".tmp-", dir=str(path.parent))
    temp = Path(name)
    try:
        try:
            os.fchmod(handle, mode)
        except (AttributeError, OSError):
            pass
        with os.fdopen(handle, "wb") as out:
            out.write(raw)
            out.flush()
            try:
                os.fsync(out.fileno())
            except OSError:
                pass
        _restrict_permissions(temp)
        os.replace(temp, path)
        _restrict_permissions(path)
    finally:
        try:
            temp.unlink()
        except OSError:
            pass


def _restrict_permissions(path: Path) -> None:
    """Best-effort restrictive permissions. DPAPI remains the Windows boundary."""
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    if os.name == "nt":
        # icacls is deliberately best effort: a domain policy can provide a
        # stronger ACL and a failure must not turn a successful DPAPI write into
        # an accidental plaintext fallback.
        try:
            import subprocess
            subprocess.run(
                ["icacls", str(path), "/inheritance:r",
                 "/grant:r", "*S-1-5-32-544:(F)", "*S-1-5-18:(F)",
                 "*S-1-5-32-545:(M)"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                check=False, timeout=5,
            )
        except (OSError, ValueError):
            pass


def _json_record(raw: bytes) -> dict:
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SecretStorageError("Uložené přístupové údaje nelze bezpečně přečíst.") from exc
    if not isinstance(value, dict) or value.get("format") != FORMAT:
        raise SecretStorageError("Uložené přístupové údaje mají neplatný formát.")
    return value


def _entropy(install_id: str) -> bytes:
    return hashlib.sha256(_CONTEXT + install_id.encode("ascii")).digest()


def _fallback_machine_binding() -> bytes:
    """Derive a non-secret local-machine binding for the stdlib fallback.

    Python's standard library cannot call a Linux/macOS keychain.  A separate
    0600 random file is still required, but deriving the actual cipher/HMAC
    material with a machine identity prevents copying those two files to an
    arbitrary other host.  The identity itself is never stored; only a hash of
    the resulting binding is recorded for tamper/wrong-host detection.
    """
    identity = ""
    for name in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            identity = Path(name).read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if identity:
            break
    if not identity:
        identity = "\x00".join((
            platform.system(), platform.machine(), platform.node(),
        ))
    if not identity:
        raise SecretStorageError(
            "Nelze bezpečně určit lokální počítač pro úložiště přístupových údajů."
        )
    return hashlib.sha256(_CONTEXT + b"fallback-machine\x00" +
                          identity.encode("utf-8", "surrogatepass")).digest()


def _fallback_material(local_key: bytes) -> tuple[bytes, bytes]:
    binding = _fallback_machine_binding()
    material = hmac.new(local_key, b"local-file-key\x00" + binding,
                        hashlib.sha256).digest()
    return material, binding


def _record_payload(values: dict[str, str]) -> bytes:
    allowed = {
        provider: str(value).strip()
        for provider, value in values.items()
        if provider in ("openai", "anthropic") and str(value).strip()
    }
    return json.dumps({"providers": allowed}, ensure_ascii=False,
                      separators=(",", ":")).encode("utf-8")


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def _blob(raw: bytes) -> tuple[_DataBlob, ctypes.Array[ctypes.c_ubyte]]:
    array = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    return _DataBlob(len(raw), array), array


def _dpapi(protect: bool, raw: bytes, entropy: bytes) -> bytes:
    if os.name != "nt":
        raise SecretStorageError("Windows DPAPI není v tomto systému dostupné.")
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    fn.argtypes = [
        ctypes.POINTER(_DataBlob), wintypes.LPCWSTR, ctypes.POINTER(_DataBlob),
        ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DataBlob),
    ]
    fn.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    source, source_keepalive = _blob(raw)
    extra, extra_keepalive = _blob(entropy)
    output = _DataBlob()
    # CRYPTPROTECT_LOCAL_MACHINE is a CryptProtectData-only flag.  Passing it
    # to CryptUnprotectData is not part of that API's contract and can fail on
    # Windows; the scope is carried by the protected blob itself.
    flags = 0x1 | (0x4 if protect else 0)  # UI_FORBIDDEN | LOCAL_MACHINE (protect only)
    if not fn(ctypes.byref(source), "HADS AI credentials" if protect else None,
              ctypes.byref(extra), None, None, flags, ctypes.byref(output)):
        error = ctypes.get_last_error()
        raise SecretStorageError("Windows DPAPI nemohlo bezpečně zpracovat přístupové údaje "
                                 f"(kód {error}).")
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        if output.pbData:
            kernel32.LocalFree(ctypes.cast(output.pbData, ctypes.c_void_p))


def _keystream(key: bytes, nonce: bytes, size: int) -> bytes:
    output = bytearray()
    counter = 0
    while len(output) < size:
        output.extend(hmac.new(key, b"stream\x00" + nonce + counter.to_bytes(8, "big"),
                               hashlib.sha256).digest())
        counter += 1
    return bytes(output[:size])


def _xor(left: bytes, right: bytes) -> bytes:
    return bytes(a ^ b for a, b in zip(left, right))


class LocalSecretStore:
    """Čte a zapisuje pouze šifrovaný blob a nevrací jej do API vrstev."""

    def __init__(self, data_dir: Path, *, system_name: str | None = None,
                 dpapi: Callable[[bool, bytes, bytes], bytes] | None = None):
        self.data_dir = Path(data_dir)
        self.credentials_path = self.data_dir / CREDENTIALS_FILENAME
        self.local_key_path = self.data_dir / LOCAL_KEY_FILENAME
        self.system_name = system_name or platform.system()
        self._dpapi = dpapi or _dpapi

    @property
    def is_windows(self) -> bool:
        return self.system_name.casefold() == "windows"

    def _fallback_key(self, *, create: bool = False) -> bytes:
        if self.local_key_path.exists():
            try:
                key = self.local_key_path.read_bytes()
            except OSError as exc:
                raise SecretStorageError("Lokální klíč přístupových údajů nelze přečíst.") from exc
            if len(key) != 32:
                raise SecretStorageError("Lokální klíč přístupových údajů má neplatný formát.")
            return key
        if not create:
            # Čtení stavu nikdy nesmí vytvořit nový klíč.  Jinak by pouhé
            # otevření Nastavení změnilo neúplnou dvojici blob+machinekey a
            # zničilo možnost bezpečně obnovit původní pár ze zálohy.
            raise SecretStorageError(
                "Chybí párový lokální klíč k uloženým přístupovým údajům."
            )
        key = secrets.token_bytes(32)
        _atomic_write(self.local_key_path, key)
        return key

    def _new_install_id(self) -> str:
        return secrets.token_hex(24)

    def _read_record(self) -> dict | None:
        if not self.credentials_path.exists():
            return None
        try:
            return _json_record(self.credentials_path.read_bytes())
        except OSError as exc:
            raise SecretStorageError("Uložené přístupové údaje nelze přečíst.") from exc

    def diagnostic_state(self) -> dict[str, bool | str]:
        """Vrátí jen bezpečný stav souborů, nikdy jejich obsah ani metadata.

        Slouží pro UI, které musí odlišit chybějící klíč od klíče uloženého,
        ale nečitelného na tomto počítači.  Neprovádí dešifrování ani zápis.
        """
        blob_exists = self.credentials_path.is_file() and not self.credentials_path.is_symlink()
        machinekey_exists = self.local_key_path.is_file() and not self.local_key_path.is_symlink()
        if not blob_exists:
            return {
                "stored": False,
                "pair_complete": not machinekey_exists,
                "backend": "none",
            }
        backend = "unknown"
        try:
            record = self._read_record() or {}
            value = record.get("backend")
            if value == WINDOWS_BACKEND:
                backend = "windows"
            elif value == FALLBACK_BACKEND:
                backend = "fallback"
        except SecretStorageError:
            backend = "unreadable"
        return {
            "stored": True,
            "pair_complete": True if backend == "windows" else machinekey_exists,
            "backend": backend,
        }

    def load(self) -> dict[str, str]:
        record = self._read_record()
        if record is None:
            return {}
        backend = record.get("backend")
        install_id = record.get("install_id")
        ciphertext = record.get("ciphertext_b64")
        if not isinstance(install_id, str) or not isinstance(ciphertext, str):
            raise SecretStorageError("Uložené přístupové údaje mají neplatná metadata.")
        try:
            encrypted = base64.b64decode(ciphertext.encode("ascii"), validate=True)
        except (UnicodeEncodeError, ValueError, binascii.Error) as exc:
            raise SecretStorageError("Uložené přístupové údaje jsou poškozené.") from exc
        if self.is_windows:
            if backend != WINDOWS_BACKEND:
                raise SecretStorageError("Přístupové údaje byly vytvořeny pro jiný systém úložiště.")
            raw = self._dpapi(False, encrypted, _entropy(install_id))
        else:
            if backend != FALLBACK_BACKEND:
                raise SecretStorageError("Přístupové údaje byly vytvořeny pro jiný systém úložiště.")
            nonce_b64, tag_b64 = record.get("nonce_b64"), record.get("tag_b64")
            binding_hash = record.get("machine_binding_sha256")
            if (not isinstance(nonce_b64, str) or not isinstance(tag_b64, str)
                    or not isinstance(binding_hash, str)):
                raise SecretStorageError("Uložené přístupové údaje mají neplatná metadata.")
            try:
                nonce = base64.b64decode(nonce_b64.encode("ascii"), validate=True)
                tag = base64.b64decode(tag_b64.encode("ascii"), validate=True)
            except (UnicodeEncodeError, ValueError, binascii.Error) as exc:
                raise SecretStorageError("Uložené přístupové údaje jsou poškozené.") from exc
            key, binding = _fallback_material(self._fallback_key(create=False))
            if not hmac.compare_digest(binding_hash, hashlib.sha256(binding).hexdigest()):
                raise SecretStorageError("Přístupové údaje byly vytvořeny pro jiný počítač.")
            expected = hmac.new(key, b"auth\x00" + install_id.encode("ascii") + nonce + encrypted,
                                hashlib.sha256).digest()
            if not hmac.compare_digest(tag, expected):
                raise SecretStorageError("Ověření uložených přístupových údajů selhalo.")
            raw = _xor(encrypted, _keystream(key, nonce, len(encrypted)))
        try:
            payload = json.loads(raw.decode("utf-8"))
            providers = payload.get("providers", {})
        except (UnicodeDecodeError, json.JSONDecodeError, AttributeError) as exc:
            raise SecretStorageError("Uložené přístupové údaje mají neplatný obsah.") from exc
        if not isinstance(providers, dict):
            raise SecretStorageError("Uložené přístupové údaje mají neplatný obsah.")
        return {p: str(v).strip() for p, v in providers.items()
                if p in ("openai", "anthropic") and isinstance(v, str) and v.strip()}

    def save(self, values: dict[str, str]) -> None:
        values = {p: str(v).strip() for p, v in values.items()
                  if p in ("openai", "anthropic") and str(v).strip()}
        if not values:
            self.delete_all()
            return
        old = self._read_record()
        install_id = old.get("install_id") if isinstance(old, dict) else None
        if not isinstance(install_id, str) or len(install_id) < 16:
            install_id = self._new_install_id()
        raw = _record_payload(values)
        if self.is_windows:
            record = {
                "format": FORMAT, "backend": WINDOWS_BACKEND, "scope": "local-machine",
                "install_id": install_id, "entropy_sha256": hashlib.sha256(_entropy(install_id)).hexdigest(),
                "ciphertext_b64": base64.b64encode(self._dpapi(True, raw, _entropy(install_id))).decode("ascii"),
            }
        else:
            key, binding = _fallback_material(self._fallback_key(create=True))
            nonce = secrets.token_bytes(24)
            ciphertext = _xor(raw, _keystream(key, nonce, len(raw)))
            record = {
                "format": FORMAT, "backend": FALLBACK_BACKEND, "scope": "local-file-0600",
                "install_id": install_id, "nonce_b64": base64.b64encode(nonce).decode("ascii"),
                "ciphertext_b64": base64.b64encode(ciphertext).decode("ascii"),
                "machine_binding_sha256": hashlib.sha256(binding).hexdigest(),
                "tag_b64": base64.b64encode(hmac.new(
                    key, b"auth\x00" + install_id.encode("ascii") + nonce + ciphertext,
                    hashlib.sha256).digest()).decode("ascii"),
            }
        _atomic_write(self.credentials_path,
                      (json.dumps(record, ensure_ascii=True, separators=(",", ":")) + "\n").encode("utf-8"))

    def delete_all(self) -> None:
        for path in (self.credentials_path, self.local_key_path):
            try:
                path.unlink()
            except FileNotFoundError:
                pass
            except OSError as exc:
                raise SecretStorageError("Přístupové údaje nelze bezpečně odstranit.") from exc

    def exportable_windows_blob(self) -> Path:
        record = self._read_record()
        if not self.is_windows or not record or record.get("backend") != WINDOWS_BACKEND:
            raise SecretStorageError("Export je možný jen pro existující Windows DPAPI credential blob.")
        return self.credentials_path
