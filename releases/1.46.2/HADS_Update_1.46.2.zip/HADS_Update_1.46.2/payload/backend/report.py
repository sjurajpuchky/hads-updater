# -*- coding: utf-8 -*-
"""Sestavení dat pro protokol z měření vibrací (zdrojová DDS databáze).

Tento modul:
  * určí OKRUH strojů podle data měření (poslední N dní / týden / konkrétní
    datum / vše),
  * pro každý stroj sestaví tabulku hodnot (rychlost, zrychlení, obálka
    zrychlení) pro aktuální a minulé měření a klasifikuje je do PÁSEM A/B/C/D
    podle limitů (norma / DB),
  * určí celkovou závažnost stroje (Provoz / Alarm / Výstraha / Neměřeno),
  * vrátí strukturu vhodnou k uložení jako editovatelný NÁVRH protokolu a
    pro následné vykreslení PDF.

Používá POUZE standardní knihovnu Pythonu.
"""

import datetime
import math

import ai_eval
import branding
from ndb_parser import bearing_key

# veličiny zařazené do tabulky protokolu (pořadí sloupců skupin) — VÝCHOZÍ
# názvy. Lze je globálně přepsat per databáze v Nastavení databáze; přepis se
# do stavby protokolu předává přes parametr `qmap` (viz resolve_quantities).
VELOCITY_Q = "ISO RMS"                 # rychlost vibrací [mm/s]
ACCEL_Q = "ACC RMS 10 - 6400 Hz"       # zrychlení [g]
ENV_Q = "ACC ENV RMS 500 Hz"           # obálka zrychlení [g]
BEARING_Q = "BEARING RMS"              # ukazatel stavu ložisek [g]


def resolve_quantities(qmap=None):
    """Vrátí názvy veličin (velocity, accel, env) pro stavbu protokolu.

    `qmap` je volitelná mapa z Nastavení databáze:
        {"velocity": <název>, "accel": <název>, "env": <název>}.
    Nevyplněné (prázdné) položky se nahradí VÝCHOZÍMI konstantami, takže
    zůstává zachována zpětná kompatibilita s databázemi bez nastavení.
    """
    qmap = qmap or {}
    vel = (qmap.get("velocity") or "").strip() or VELOCITY_Q
    acc = (qmap.get("accel") or "").strip() or ACCEL_Q
    # Prázdné nastavení znamená přesně výchozí veličinu. Nesmí zde vzniknout
    # automatický výběr jiné obálky podle dostupnosti na směru H, protože by
    # tabulka a její stav mohly vycházet z rozdílných datových základů.
    env = (qmap.get("env") or "").strip() or ENV_Q
    return {"velocity": vel, "accel": acc, "env": env}

# pořadí směrů pro řazení řádků tabulky
_DIR_ORDER = {"H": 0, "V": 1, "A": 2, "": 3, None: 3}


def _report_h_point(bearing, points):
    """Vybere jediný jednoznačný H bod stejného ložiska.

    Stabilní ``bearing_key`` a ``direction`` dodává parser. U starších
    struktur bez nich se použije tentýž striktní parser jména; neexistuje
    fallback na V/A ani na podobný název. Dva různé H body jsou explicitní
    nejednoznačnost, nikoli důvod tiše použít první záznam.
    """
    expected = str(bearing.get("bearing_key") or bearing.get("label") or "").upper()
    unique = {}
    for point in points or []:
        parsed_key, _label, parsed_direction = bearing_key(point.get("name") or "")
        stable_key = str(point.get("bearing_key") or parsed_key or "").upper()
        explicit_direction = str(point.get("direction") or "").strip().upper()
        if explicit_direction and parsed_direction and explicit_direction != parsed_direction:
            continue
        direction = explicit_direction or parsed_direction
        if stable_key != expected or direction != "H":
            continue
        pid = point.get("id")
        unique[("id", pid) if pid is not None else ("object", id(point))] = point
    if len(unique) == 1:
        return next(iter(unique.values())), ""
    return None, ("ambiguous_h" if len(unique) > 1 else "missing_h")

# barvy závažnosti (hex) — sladěno s frontendem
SEV_COLORS = {
    "ok": "19a974",       # Provoz (zelená)
    "alarm": "e6c019",    # Alarm (žlutá)
    "warn": "e23b3b",     # Výstraha (červená)
    "none": "c8ced6",     # Neměřeno (šedá)
}
SEV_LABELS = {
    "ok": "OK",           # pásmo A a B
    "alarm": "Upozornění", # pásmo C
    "warn": "Výstraha",   # pásmo D
    "none": "Neměřeno",
}

# Povolené hodnoty ručního přepisu stavu stroje (viz build_machine_report).
MANUAL_SEV_VALUES = ("ok", "alarm", "warn", "none")


# ----------------------------- pomocné -----------------------------
def _parse_iso(ts):
    """Bezpečně převede ISO čas (z trendu) na datetime, nebo None."""
    if not ts:
        return None
    s = str(ts)
    try:
        # trend ukládá '2026-05-19T11:57:28.423000'
        return datetime.datetime.fromisoformat(s)
    except ValueError:
        # zkus bez mikrosekund
        try:
            return datetime.datetime.strptime(s[:19], "%Y-%m-%dT%H:%M:%S")
        except ValueError:
            return None


def _fmt_date(dt):
    if not dt:
        return ""
    return dt.strftime("%d.%m.%Y")


def scope_time_window(db, scope):
    """Vrátí časové meze aktuálního okruhu protokolu.

    Výsledek je dvojice ``(od, do)`` typu ``datetime`` včetně obou mezí.
    ``(None, None)`` znamená celý dostupný trend. Okno je záměrně
    odvozené stejnou konvencí jako :func:`select_machines_by_scope`, aby
    seznam strojů a hodnoty v jejich tabulkách nepoužívaly rozdílné období.

    Ruční ``machine_ids`` omezuje *které* stroje jsou v protokolu, nikdy
    však neruší datumové omezení jejich hodnot.
    """
    scope = scope or {}
    mode = scope.get("mode", "all")
    if mode == "all":
        return None, None
    if mode == "date":
        try:
            day = datetime.datetime.strptime(
                str(scope.get("date")), "%Y-%m-%d").date()
        except (TypeError, ValueError):
            # Stejný fallback jako select_machines_by_scope: poslední den
            # dostupných měření; bez měření nelze vytvořit smysluplné okno.
            mach_last = machines_with_measurements(db)
            if not mach_last:
                return None, None
            day = max(mach_last.values()).date()
        start = datetime.datetime.combine(day, datetime.time.min)
        end = datetime.datetime.combine(day, datetime.time.max)
        return start, end

    # last_days / week – aplikace historicky používá relativní okno vůči
    # nejnovějšímu měření v načtené databázi, nikoli vůči hodinám PC.
    mach_last = machines_with_measurements(db)
    if not mach_last:
        return None, None
    newest = max(mach_last.values())
    try:
        days = 7 if mode == "week" else int(scope.get("days", 3) or 3)
    except (TypeError, ValueError):
        days = 3
    return newest - datetime.timedelta(days=days), newest


def classify_band(value, warning, alarm, ab=None, estimate_ab=True):
    """Zařadí hodnotu do pásma A/B/C/D podle mezí normy.

    ČSN ISO 20816 definuje 4 pásma A–D oddělená třemi mezemi:
      * ab      = hranice A/B,
      * warning = hranice B/C (mez výstrahy),
      * alarm   = hranice C/D (mez alarmu).
    Nově lze zadat všechny tři meze (viz Nastavení → Normy). Pokud není
    hranice A/B zadána (starší norma či ruční limit se dvěma mezemi), odvodí
    se jako warning/2 (rozumný odhad „nového stroje") – zachována zpětná
    kompatibilita. Pokud limity chybí, vrátí None.

    `estimate_ab=False` ten odhad vypne. Používá se u veličin, které mají
    jen dvě meze z databáze přístroje (zrychlení, obálka): tam pásmo A/B
    nikdo nedefinoval a odhad by hodnotu hluboko pod mezí varování označil
    jako pásmo B. Bez odhadu platí prosté „pod varováním = A“.

    Klasifikace: A a B → dobrý stav (zelená), C → výstraha (žlutá),
    D → alarm (červená) – viz band_severity().

    Vrací 'A' | 'B' | 'C' | 'D' | None.
    """
    if value is None:
        return None
    # Potřebujeme aspoň jednu z mezí B/C (warning) nebo C/D (alarm).
    if warning is None and alarm is None:
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    w = None
    a = None
    try:
        if warning is not None:
            w = float(warning)
    except (TypeError, ValueError):
        w = None
    try:
        if alarm is not None:
            a = float(alarm)
    except (TypeError, ValueError):
        a = None
    # Chybí-li mez B/C, odvodíme ji z meze C/D (a rozumný odhad), aby
    # klasifikace fungovala i při zadání jen jedné meze.
    if w is None:
        w = a
    # hranice A/B: explicitní z normy, jinak volitelný odhad warning/2
    ab_val = None
    if ab is not None:
        try:
            ab_val = float(ab)
        except (TypeError, ValueError):
            ab_val = None
    if ab_val is None or ab_val <= 0 or ab_val >= w:
        # Odhad má smysl jen tam, kde pásma A–D definuje norma (rychlost
        # vibrací dle ČSN ISO 20816). U veličin, které mají pouze dvě meze
        # z databáze přístroje, žádná hranice A/B neexistuje a odhad by ji
        # vymyslel: hodnota hluboko pod mezí varování by se pak v protokolu
        # ukázala jako pásmo B, ačkoli na kartě stroje je bod v pořádku.
        ab_val = (w / 2.0) if estimate_ab else None
    if ab_val is None:
        return "A" if v < w else ("C" if a is None or v < a else "D")
    if v < ab_val:
        return "A"
    if v < w:
        return "B"
    # Chybí-li mez C/D (alarm=None, např. ISO 14694 BV-1/BV-2), nejvyšší
    # dosažitelné pásmo je C (mez odstavení norma neuvádí).
    if a is None:
        return "C"
    if v < a:
        return "C"
    return "D"


def band_severity(band):
    """Mapuje pásmo na závažnost: A,B -> ok (OK); C -> alarm (Upozornění);
    D -> warn (Výstraha).

    Sjednocená terminologie napříč aplikací:
      * pásmo A a B -> "ok"    = OK (zelená),
      * pásmo C     -> "alarm" = Upozornění (žlutá),
      * pásmo D     -> "warn"  = Výstraha (červená).
    """
    if band in ("A", "B"):
        return "ok"
    if band == "C":
        return "alarm"
    if band == "D":
        return "warn"
    return None


def _worst_severity(sev_list):
    """Vrátí nejhorší závažnost ze seznamu ('warn' > 'alarm' > 'ok' > 'none')."""
    rank = {"none": 0, "ok": 1, "alarm": 2, "warn": 3}
    best = None
    best_r = -1
    for s in sev_list:
        if s is None:
            continue
        r = rank.get(s, 0)
        if r > best_r:
            best_r = r
            best = s
    return best


# ---------------------- výběr aktuálního/minulého měření ----------------------
def _current_previous(db, cell_ids, scope=None, time_window=None):
    """Z trendů zadaných buněk (směrů jednoho ložiska/veličiny) vybere
    AKTUÁLNÍ (poslední) a MINULÉ (předposlední) měření.

    Volání protokolu předává vždy JEDNU přesně určenou buňku vybraného směru
    a veličiny. Parametr zůstává seznamem kvůli zpětné kompatibilitě.

    Platný kandidát má skutečný parsovatelný čas, konečnou číselnou hodnotu
    (ne ``NULL``, text, ``NaN`` ani ``Inf``) a leží ve zvoleném okně
    protokolu. Primární řazení je vždy podle času měření, nikdy podle rowid,
    pořadí vložení ani pořadí seznamu. Jen při shodném timestampu se použije
    stabilní pořadí parseru (u NDB řádek statistik, pak pořadí v BLOBu).

    Vrací (current, previous, current_time)."""
    start, end = (time_window if time_window is not None else
                  (scope_time_window(db, scope) if scope else (None, None)))
    samples = []
    for cell_pos, cid in enumerate(cell_ids):
        if cid is None:
            continue
        try:
            points = db.trend(cid) or []
        except Exception:
            points = []
        for point_pos, p in enumerate(points):
            if not isinstance(p, dict):
                continue
            dt = _parse_iso(p.get("t"))
            if dt is None or (start is not None and dt < start) or (
                    end is not None and dt > end):
                continue
            try:
                value = float(p.get("value"))
            except (TypeError, ValueError):
                continue
            if not math.isfinite(value):
                continue
            tie = p.get("_order", point_pos)
            tie_parts = tie if isinstance(tie, (tuple, list)) else (tie,)
            # Jednotný, vždy porovnatelný klíč – externí adaptér může vrátit
            # číslo, text i n-tici; žádná z těchto variant nesmí rozbít výběr.
            tie_key = []
            for part in tie_parts:
                if isinstance(part, (int, float)) and math.isfinite(part):
                    tie_key.append((0, float(part)))
                else:
                    tie_key.append((1, str(part)))
            samples.append((dt, cell_pos, tuple(tie_key), point_pos, value))
    if not samples:
        return None, None, None
    # `cell_pos` je po timestampu jen obrana pro starší volání s více
    # buňkami; protokol předává jedinou přesně určenou H buňku.
    samples.sort(key=lambda x: (x[0], x[1], x[2], x[3]))
    current = samples[-1]
    previous = samples[-2] if len(samples) >= 2 else None
    return (current[4] if current else None,
            previous[4] if previous else None,
            current[0].isoformat() if current else None)


def _quantity_limits(bearing, qname):
    """Vrátí (warning, alarm) pro veličinu z ložiska (platné limity).

    Pokud má veličina (nebo celé ložisko) vypnutou klasifikaci dle limitů
    (`classify` = False), vrátí (None, None) — stav se pak nezařazuje do
    pásem A–D a nepřispívá k celkové závažnosti.
    """
    if bearing.get("classify") is False:
        return None, None
    for q in bearing.get("quantities", []):
        if q.get("name") == qname:
            if q.get("classify") is False:
                return None, None
            return q.get("warning"), q.get("alarm")
    return None, None


def _quantity_from_norm(bearing, qname):
    """Pochází platná mez veličiny z normy? Řídí odhad hranice A/B.

    Odhad „A/B = polovina meze výstrahy" je konvence normy. U mezí
    z databáze přístroje ani u ručně zadaných prahů žádnou oporu nemá —
    tam jsou meze jen dvě a pásmo B by se vyrobilo z ničeho.
    """
    if bearing.get("classify") is False:
        return False
    for q in bearing.get("quantities", []):
        if q.get("name") == qname:
            if q.get("classify") is False:
                return False
            return bool(q.get("from_norm"))
    return False


def _quantity_ab(bearing, qname):
    """Vrátí hranici A/B pro veličinu z ložiska, nebo None.

    Hranice A/B (`ab`) pochází z norem se třemi mezemi (Nastavení → Normy).
    Pokud není uložena, vrátí None a klasifikace ji odvodí jako warning/2
    (zpětná kompatibilita). Respektuje vypnutí klasifikace stejně jako
    _quantity_limits().
    """
    if bearing.get("classify") is False:
        return None
    for q in bearing.get("quantities", []):
        if q.get("name") == qname:
            if q.get("classify") is False:
                return None
            return q.get("ab")
    return None


def _configured_env_quantity_name(preferred=""):
    """Vrátí přesně zvolený (nebo výchozí) název obálky pro PROTOKOL.

    Protokol nesmí při chybějící veličině automaticky přepnout na jinou
    obálku. Takový fallback patří případně do širší diagnostiky dashboardu,
    nikoli do společného datového základu tabulky a jejího stavu.
    """
    return (preferred or "").strip() or ENV_Q


# ------------------------- okruh strojů dle data -------------------------
def machine_last_measured(db, machine_id):
    """Vrátí datetime posledního měření stroje (max přes jeho body), nebo None."""
    ov = db.status_overview()
    best = None
    for p in ov.get("points", []):
        if p.get("parent") != machine_id:
            continue
        dt = _parse_iso(p.get("last_measured"))
        if dt and (best is None or dt > best):
            best = dt
    return best


def machines_with_measurements(db):
    """Vrátí {machine_id: poslední_datum_měření} pro všechny stroje,
    které mají alespoň jedno měření (bez ohledu na okruh dle data).
    """
    ov = db.status_overview()
    mach_last = {}
    for p in ov.get("points", []):
        dt = _parse_iso(p.get("last_measured"))
        if not dt:
            continue
        mid = p.get("parent")
        if mid not in mach_last or dt > mach_last[mid]:
            mach_last[mid] = dt
    return mach_last


def select_machines_by_scope(db, scope):
    """Vybere ID strojů podle okruhu (scope).

    scope = {"mode": "last_days"|"week"|"date"|"all",
             "days": <int>, "date": "YYYY-MM-DD",
             "machine_ids": [<int>, …] (volitelné, ruční výběr)}.

    Vrací (machine_ids set, scope_label str, measurement_dates list).
    Stroj se zařadí, má-li alespoň jedno měření v daném časovém okně.

    Je-li v `scope` uveden neprázdný seznam `machine_ids`, jde o ruční
    vyklikání konkrétních strojů z frontendu (checkbox seznam, seedovaný
    okruhem dle data, ale uživatelem volně upravitelný). Tento seznam je
    pak závazný — nahrazuje výsledek automatického výběru dle data, aby
    šlo do reportu zařadit/vyřadit libovolný stroj bez ohledu na to, kdy
    byl naposledy měřen.
    """
    mode = (scope or {}).get("mode", "all")
    mach_last = machines_with_measurements(db)

    if not mach_last:
        return set(), "Žádná měření", []

    newest = max(mach_last.values())
    selected = set()
    label = ""

    if mode == "all":
        selected = set(mach_last.keys())
        label = "Všechna měření"
    elif mode == "date":
        target = None
        try:
            target = datetime.datetime.strptime(
                str(scope.get("date")), "%Y-%m-%d").date()
        except (TypeError, ValueError):
            target = newest.date()
        for mid, dt in mach_last.items():
            if dt.date() == target:
                selected.add(mid)
        label = "Datum měření: " + _fmt_date(
            datetime.datetime.combine(target, datetime.time()))
    else:
        # last_days / week — okno od (newest - N dní) do newest včetně
        days = 7 if mode == "week" else int((scope or {}).get("days", 3) or 3)
        cutoff = newest - datetime.timedelta(days=days)
        for mid, dt in mach_last.items():
            if dt >= cutoff:
                selected.add(mid)
        if mode == "week":
            label = "Poslední týden"
        else:
            label = "Posledních %d dní" % days

    # ruční výběr strojů (checkboxy) je závazný, pokud je zadán
    manual_ids = (scope or {}).get("machine_ids")
    if manual_ids:
        try:
            manual_set = {int(x) for x in manual_ids}
        except (TypeError, ValueError):
            manual_set = set(manual_ids)
        # omezíme na stroje, které vůbec mají nějaké měření
        manual_set = {mid for mid in manual_set if mid in mach_last}
        if manual_set:
            selected = manual_set
            label = label + " (ruční výběr strojů)" if label else "Ruční výběr strojů"

    dates = sorted({mach_last[mid] for mid in selected})
    return selected, label, dates


# --------------------------- sestavení dat stroje ---------------------------
def _stable_tie(value):
    """Normalizuje parserový tie-breaker na textový, serializovatelný klíč."""
    if isinstance(value, (tuple, list)):
        return "|".join(_stable_tie(v) for v in value)
    return str(value if value is not None else "")


def _valid_cell_samples(db, cell_id, scope_window=None):
    """Vrátí platné vzorky jedné buňky, seřazené dle času a DDS pořadí.

    DDS/NDB nemá samostatnou tabulku relace měřicího běhu. ``TimeFrom`` je
    proto pouze čas vzorku konkrétní buňky, nikoli důkaz společné relace mezi
    H/V/A. Nikdy nespojujeme blízké časy fuzzy oknem ani přes stejný čas mezi
    směry. Uvnitř jednoho směru se duplicitní timestamp rozliší stabilním
    pořadím, aby se neztratil žádný samostatně volitelný výskyt.
    """
    start, end = scope_window or (None, None)
    out = []
    if cell_id is None:
        return out
    try:
        points = db.trend(cell_id) or []
    except Exception:
        return out
    for pos, p in enumerate(points):
        if not isinstance(p, dict):
            continue
        dt = _parse_iso(p.get("t"))
        if dt is None or (start is not None and dt < start) or (
                end is not None and dt > end):
            continue
        try:
            value = float(p.get("value"))
        except (TypeError, ValueError):
            continue
        if not math.isfinite(value):
            continue
        out.append((dt, _stable_tie(p.get("_order", pos)), pos, value))
    out.sort(key=lambda s: (s[0], s[1], s[2]))
    return out


# Schéma 2 zavádí stabilní výskyt pro každý fyzický směr H/V/A.  Číslo je
# součástí uloženého návrhu, historie i auditních metadat exportu.
MEASUREMENT_SELECTION_SCHEMA = 2
_DIRECTIONS = ("H", "V", "A")


def _direction_occurrences(db, bearing, qnames, scope_window=None):
    """Vrátí nezávislé přesné výskyty pro každý fyzický směr.

    DDS nenese důvěryhodné ID akviziční relace napříč body H/V/A. Proto zde
    záměrně *neexistuje* žádné seskupování mezi směry, ani když mají stejný
    ``TimeFrom``. Výskyt patří právě jednomu směru a jeho ID je stabilní
    ``H|<ISO čas>#<pořadí>``. Pořadí řeší vícenásobné identické timestampy
    uvnitř téhož směru; je dáno parserovým stabilním pořadím vzorku.

    Veličiny jednoho směru se čtou jen z téhož přesného času a ordinalu.
    Chybějící veličina zůstává chybějící — nikdy se nedoplní z jiného času.
    """
    points = list(bearing.get("points", []) or [])
    by_point = {p.get("id"): p for p in points}
    cells = {}
    # Více bodů stejného fyzického směru není bezpečně slučitelných.
    point_for_direction = {}
    ambiguous_direction = set()
    for p in points:
        parsed = bearing_key(p.get("name") or "")[2]
        direction = str(p.get("direction") or parsed or "").upper()
        if direction not in _DIRECTIONS:
            continue
        if direction in point_for_direction and point_for_direction[direction] != p.get("id"):
            ambiguous_direction.add(direction)
        else:
            point_for_direction[direction] = p.get("id")
    for q in bearing.get("quantities", []) or []:
        qname = q.get("name")
        if qname not in qnames:
            continue
        for cell in q.get("cells") or []:
            point = by_point.get(cell.get("point_id")) or {}
            parsed = bearing_key(point.get("name") or "")[2]
            direction = str(point.get("direction") or cell.get("direction") or parsed or "").upper()
            if direction in _DIRECTIONS and direction not in ambiguous_direction:
                # Exact point prevents unrelated similarly named points from
                # silently becoming an additional source for a direction.
                if point_for_direction.get(direction) == cell.get("point_id"):
                    cells[(qname, direction)] = cell.get("cell_id")

    out = {direction: [] for direction in _DIRECTIONS}
    for direction in _DIRECTIONS:
        if direction in ambiguous_direction:
            continue
        samples_by_q = {}
        all_times = set()
        for qname in qnames:
            cid = cells.get((qname, direction))
            by_time = {}
            if cid is not None:
                for dt, tie, pos, value in _valid_cell_samples(db, cid, scope_window):
                    by_time.setdefault(dt, []).append((tie, pos, value))
                for samples in by_time.values():
                    samples.sort(key=lambda rec: (rec[0], rec[1]))
            samples_by_q[qname] = by_time
            all_times.update(by_time)
        for dt in sorted(all_times):
            max_ordinal = max((len(samples_by_q[qname].get(dt, []))
                               for qname in qnames), default=0)
            for ordinal in range(1, max_ordinal + 1):
                values = {}
                for qname in qnames:
                    samples = samples_by_q[qname].get(dt, [])
                    if len(samples) >= ordinal:
                        values[qname] = samples[ordinal - 1][2]
                if not values:
                    continue
                out[direction].append({
                    "id": "%s|%s#%d" % (direction, dt.isoformat(), ordinal),
                    "time": dt.isoformat(), "ordinal": ordinal,
                    "direction": direction, "values": values, "usable": True,
                })
    return out


def _legacy_id_for_direction(old_id, direction, occurrences):
    """Převede prokazatelný 1.37/1.38 shared ID na ID konkrétního směru."""
    if not old_id or old_id == "__none__":
        return old_id
    text = str(old_id)
    if text.startswith(direction + "|"):
        return text
    if "#" not in text or text.endswith("#ambiguous"):
        return None
    time, ordinal = text.rsplit("#", 1)
    if not ordinal.isdigit():
        return None
    candidate = "%s|%s#%s" % (direction, time, ordinal)
    return candidate if any(o.get("id") == candidate for o in occurrences) else None


def _normalise_direction_selection(raw, occurrences_by_direction):
    """Normalizuje staré i nové schéma do per-direction map.

    Vrací ``(selection, migrated)``. Při starém shared ID se zachová pouze
    přesně dokazatelná shoda času/ordinalu v daném směru. Ostatní směry se
    bezpečně vrátí na vlastní poslední platnou hodnotu.
    """
    raw = raw if isinstance(raw, dict) else {}
    schema = raw.get("schema")
    current_raw = raw.get("current") if isinstance(raw.get("current"), dict) else {}
    previous_raw = raw.get("previous") if isinstance(raw.get("previous"), dict) else {}
    migrated = (schema != MEASUREMENT_SELECTION_SCHEMA and bool(raw))
    if not current_raw and raw.get("current_ids") and isinstance(raw.get("current_ids"), dict):
        current_raw = raw.get("current_ids")
        migrated = True
    if not previous_raw and raw.get("previous_ids") and isinstance(raw.get("previous_ids"), dict):
        previous_raw = raw.get("previous_ids")
        migrated = True
    result = {"schema": MEASUREMENT_SELECTION_SCHEMA, "current": {}, "previous": {}}
    for direction in _DIRECTIONS:
        occurrences = occurrences_by_direction.get(direction) or []
        cur = current_raw.get(direction)
        prev = previous_raw.get(direction)
        if schema != MEASUREMENT_SELECTION_SCHEMA:
            cur = _legacy_id_for_direction(raw.get("current_id"), direction, occurrences)
            old_previous = raw.get("previous_id")
            prev = "__none__" if old_previous == "__none__" else _legacy_id_for_direction(
                old_previous, direction, occurrences)
        if cur:
            result["current"][direction] = str(cur)
        if prev:
            result["previous"][direction] = str(prev)
    return result, migrated


def _select_direction_occurrence(occurrences, requested_id=None, before=None):
    """Vybere vyžádaný nebo poslední platný výskyt jednoho směru."""
    usable = [o for o in occurrences if o.get("usable")]
    def is_before(candidate):
        return (before is None or
                (candidate.get("time"), candidate.get("ordinal")) <
                (before.get("time"), before.get("ordinal")))
    if requested_id:
        found = next((o for o in usable if o.get("id") == requested_id), None)
        # Porovnávací hodnota smí být pouze skutečně před aktuálně zvoleným
        # výskytem téhož směru.  Neplatná ruční volba bezpečně spadne na
        # nejbližší předcházející výskyt, nikdy na budoucí měření.
        if found and is_before(found):
            return found, False
    candidates = [o for o in usable if is_before(o)]
    return (candidates[-1] if candidates else None), bool(requested_id)


# Zrychlení a obálka zrychlení se v protokolu hodnotí VÝHRADNĚ z
# horizontálního směru. Stav valivého ložiska je ukazatel jednoho měřicího
# místa; maximum přes H/V/A míchalo tři různá místa do jedné buňky a mohlo
# stav ložiska zhoršit složkou, která s ním nesouvisí.
_HORIZONTAL_ONLY = ("H",)


def _winner_from_direction_occurrences(selected, qname, directions=_DIRECTIONS):
    """Maximum přes zadané směry, vždy jen z explicitně vybraného výskytu."""
    candidates = []
    for direction in directions:
        occurrence = selected.get(direction)
        value = (occurrence or {}).get("values", {}).get(qname)
        if value is not None:
            candidates.append((float(value), direction))
    return (max(candidates, key=lambda x: (x[0], -_DIR_ORDER[x[1]]))
            if candidates else (None, ""))


def _selection_option(occurrence, qnames):
    dt = _parse_iso(occurrence.get("time"))
    label = ("%d. %d. %d %s" % (dt.day, dt.month, dt.year,
             dt.strftime("%H:%M:%S"))) if dt else occurrence.get("time", "")
    labels = (("R", qnames[0], "mm/s"), ("Z", qnames[1], "g"), ("O", qnames[2], "g"))
    values = occurrence.get("values") or {}
    details = []
    for short, qname, unit in labels:
        value = values.get(qname)
        if value is not None:
            formatted = ("%.2f" % float(value)).replace(".", ",")
            details.append("%s %s %s" % (short, formatted, unit))
    suffix = " • " + " • ".join(details) if details else ""
    ordinal = occurrence.get("ordinal") or 1
    if ordinal > 1:
        suffix += " • #%d" % ordinal
    return {
        "id": occurrence.get("id"), "label": label + suffix,
        "time": occurrence.get("time"), "ordinal": ordinal,
        "direction": occurrence.get("direction"), "values": dict(values),
        "usable": bool(occurrence.get("usable")),
    }


def _direction_selection_result(db, bearing, qnames, raw_selection, scope_window=None):
    """Kanonický výsledek výběru pro jedno ložisko.

    Tato jediná funkce určuje hodnoty tabulky, klasifikace, refresh i audit
    exportů. Nikde mimo ni se nesmí dopočítávat „poslední“ H/V/A.
    """
    occurrences = _direction_occurrences(db, bearing, qnames, scope_window)
    requested, migrated = _normalise_direction_selection(raw_selection, occurrences)
    selected_current, selected_previous = {}, {}
    normalized = {"schema": MEASUREMENT_SELECTION_SCHEMA, "current": {}, "previous": {}}
    fallback_directions = []
    for direction in _DIRECTIONS:
        items = occurrences.get(direction) or []
        if not items:
            continue
        requested_current = requested["current"].get(direction)
        current, current_fallback = _select_direction_occurrence(items, requested_current)
        if current:
            selected_current[direction] = current
            normalized["current"][direction] = current["id"]
        if current_fallback and requested_current:
            fallback_directions.append(direction)
        requested_previous = requested["previous"].get(direction)
        if requested_previous == "__none__":
            normalized["previous"][direction] = "__none__"
            continue
        if requested_previous:
            previous, previous_fallback = _select_direction_occurrence(
                items, requested_previous, before=current)
        else:
            previous, previous_fallback = _select_direction_occurrence(items, before=current)
        if previous:
            selected_previous[direction] = previous
            normalized["previous"][direction] = previous["id"]
            if previous_fallback and requested_previous:
                fallback_directions.append(direction)
        elif requested_previous:
            # Explicit value vanished / became invalid; do not pretend it is
            # still selected. The UI will show the immediately preceding value.
            fallback_directions.append(direction)
    current_values = {
        # Rychlost vibrací popisuje chování celého stroje, proto se u ní bere
        # nejhorší z vybraných směrů. Zrychlení a obálka popisují stav ložiska
        # v jednom místě — ty se berou jen z H.
        "velocity": _winner_from_direction_occurrences(selected_current, qnames[0]),
        "accel": _winner_from_direction_occurrences(selected_current, qnames[1],
                                                    _HORIZONTAL_ONLY),
        "env": _winner_from_direction_occurrences(selected_current, qnames[2],
                                                  _HORIZONTAL_ONLY),
    }
    previous_values = {
        "velocity": _winner_from_direction_occurrences(selected_previous, qnames[0]),
    }
    per_direction = {}
    for direction in _DIRECTIONS:
        current = selected_current.get(direction)
        previous = selected_previous.get(direction)
        per_direction[direction] = {
            "direction": direction,
            "options": [_selection_option(o, qnames)
                        for o in reversed(occurrences.get(direction) or [])],
            # Porovnání neukazuje ani nepřijme aktuální či budoucí výskyt.
            # Nejde o druhý algoritmus: je to jen podmnožina stejných
            # per-direction occurrence records jako u aktuální volby.
            "previous_options": [
                _selection_option(o, qnames)
                for o in reversed(occurrences.get(direction) or [])
                if current is not None and
                (o.get("time"), o.get("ordinal")) <
                (current.get("time"), current.get("ordinal"))
            ],
            "current_id": current.get("id") if current else "",
            "previous_id": ("__none__" if normalized["previous"].get(direction) == "__none__"
                            else (previous.get("id") if previous else "")),
            "current_preview": dict((current or {}).get("values") or {}),
            "previous_preview": dict((previous or {}).get("values") or {}),
            "current_time": (current or {}).get("time"),
            "previous_time": (previous or {}).get("time"),
        }
    audit = {
        "schema": MEASUREMENT_SELECTION_SCHEMA,
        "current": {d: {"id": o["id"], "time": o["time"]}
                    for d, o in selected_current.items()},
        "previous": {d: {"id": o["id"], "time": o["time"]}
                     for d, o in selected_previous.items()},
    }
    return {
        "selection": normalized, "directions": per_direction,
        "current": current_values, "previous": previous_values,
        "migration_notice": migrated,
        "fallback_directions": sorted(set(fallback_directions)),
        "audit": audit,
    }


def build_machine_report(db, machine, all_over, qmap=None, scope=None,
                         scope_window=None, measurement_selection=None):
    """Sestaví report pro JEDEN stroj (z výstupu machines() + přepisů).

    Vrací slovník s kartou, tabulkou řádků (per směr) a celkovou závažností.

    `qmap` je volitelná mapa vybraných veličin (rychlost / zrychlení / obálka)
    z Nastavení databáze — viz resolve_quantities. Nevyplněné položky se
    nahradí výchozími názvy veličin.
    """
    qres = resolve_quantities(qmap)
    velocity_q = qres["velocity"]
    accel_q = qres["accel"]
    env_pref = qres["env"]
    mid = machine["id"]
    card = machine.get("card") or {}
    # Zamez opakovanému výpočtu okna (status_overview může být drahý) pro
    # každou ze tří veličin každého ložiska.
    if scope_window is None and scope:
        scope_window = scope_time_window(db, scope)

    rows = []
    # Každé ložisko má v protokolu právě jeden řádek. Hodnota jednotlivé
    # veličiny je maximum nezávisle vybraných výskytů H/V/A.
    bearings_summary = []
    points_index = []       # měřicí body pro výběr grafů (trend / FFT)
    sev_overall = []
    selection_notices = []
    last_meas_dt = None

    machine_speed_hz = machine.get("speed_hz")
    for b in machine.get("bearings", []):
        blabel = b.get("label") or b.get("bearing_key") or ""
        bkey = b.get("bearing_key") or blabel
        # defektní frekvence ložiska (násobky otáčkové frekvence hřídele) –
        # použijí se pro značky ve FFT spektru
        b_bearing = b.get("bearing") or {}
        # limity veličin na ložisku (warning=B/C, alarm=C/D, ab=A/B volitelně)
        vel_w, vel_a = _quantity_limits(b, velocity_q)
        acc_w, acc_a = _quantity_limits(b, accel_q)
        env_name = _configured_env_quantity_name(env_pref)
        env_w, env_a = _quantity_limits(b, env_name)
        # hranice A/B (z norem se třemi mezemi; None = odvodí se warning/2)
        vel_ab = _quantity_ab(b, velocity_q)
        acc_ab = _quantity_ab(b, accel_q)
        env_ab = _quantity_ab(b, env_name)
        # Odhad A/B smí proběhnout jen tam, kde ho zavádí norma.
        vel_norm = _quantity_from_norm(b, velocity_q)
        acc_norm = _quantity_from_norm(b, accel_q)
        env_norm = _quantity_from_norm(b, env_name)

        # body (směry) ložiska
        points = sorted(
            b.get("points", []),
            key=lambda p: _DIR_ORDER.get(p.get("direction"), 3))

        # Buňky se vyhledávají podle přesného point_id pro grafy; volba
        # reportu níže naopak vědomě posuzuje všechny H/V/A směry.
        def _cell_for_point(qname, point):
            if not point:
                return None
            for q in b.get("quantities", []):
                if q.get("name") == qname:
                    for cell in q.get("cells") or []:
                        if cell.get("point_id") == point.get("id"):
                            return cell.get("cell_id")
            return None

        # Výběr je kanonicky per fyzický směr. DDS nemá důvěryhodný session ID
        # mezi H/V/A, proto žádný společný výskyt ložiska nevymýšlíme.
        bsel = ((measurement_selection or {}).get(str(bkey))
                or (measurement_selection or {}).get(str(blabel), {}))
        selection_result = _direction_selection_result(
            db, b, (velocity_q, accel_q, env_name), bsel, scope_window)
        if selection_result["migration_notice"]:
            selection_notices.append(
                "%s: starý společný výběr byl převeden jen tam, kde přesně "
                "identifikoval výskyt směru; ostatní směry používají poslední hodnotu."
                % blabel)
        if selection_result["fallback_directions"]:
            selection_notices.append(
                "%s: zvolený výskyt již není v databázi; pro směr %s byla použita "
                "poslední dostupná hodnota." % (
                    blabel, "/".join(selection_result["fallback_directions"])))
        vel_cur, vel_dir = selection_result["current"]["velocity"]
        vel_prev, vel_prev_dir = selection_result["previous"]["velocity"]
        acc_cur, acc_dir = selection_result["current"]["accel"]
        env_cur, env_dir = selection_result["current"]["env"]
        vel_t = (selection_result["directions"].get(vel_dir) or {}).get("current_time")
        acc_t = (selection_result["directions"].get(acc_dir) or {}).get("current_time")
        env_t = (selection_result["directions"].get(env_dir) or {}).get("current_time")

        for ts in (vel_t, acc_t, env_t):
            dt = _parse_iso(ts)
            if dt and (last_meas_dt is None or dt > last_meas_dt):
                last_meas_dt = dt

        # Automatická pásma jsou neměnný auditní podklad. `*_band` níže je
        # efektivní (automatické nebo ručně zadané) pásmo, které se skutečně
        # zobrazuje, exportuje a vstupuje do celkového stavu.
        # Hranice A/B se dopočítává jen u mezí z normy. Zrychlení a obálka
        # mají zpravidla jen dvě meze z databáze přístroje, takže tam pásmo B
        # vzniknout nesmí; totéž platí pro ručně přepsané meze rychlosti.
        vel_auto_band = classify_band(vel_cur, vel_w, vel_a, vel_ab,
                                      estimate_ab=vel_norm)
        vel_band_prev = classify_band(vel_prev, vel_w, vel_a, vel_ab,
                                      estimate_ab=vel_norm)
        acc_auto_band = classify_band(acc_cur, acc_w, acc_a, acc_ab,
                                      estimate_ab=acc_norm)
        env_auto_band = classify_band(env_cur, env_w, env_a, env_ab,
                                      estimate_ab=env_norm)
        vel_band = vel_auto_band
        acc_band = acc_auto_band
        env_band = env_auto_band

        # Pásmo rychlosti je samostatná informace. Stav ložiska patří pouze
        # zrychlení a obálce ve stejném zobrazeném H bodě; rychlost se do
        # pravého sloupce „Stav ložiska“ nikdy nepřenáší.
        # BEARING RMS ani jakákoli jiná/nezvolená veličina do něj nesmí
        # přispět.
        bearing_state = _worst_band(acc_band, env_band)
        sev_overall.append(_worst_severity([
            band_severity(vel_band), band_severity(bearing_state),
        ]))

        h_point, h_mapping = _report_h_point(b, points)
        rows.append({
            "place": blabel,
            "direction": vel_dir,
            "point_id": h_point.get("id") if h_point else None,
            "point_mapping": h_mapping,
            "vel_prev": vel_prev, "vel_prev_dir": vel_prev_dir,
            "vel_prev_band": vel_band_prev,
            "vel_cur": vel_cur, "vel_auto_band": vel_auto_band,
            "vel_band_override": "", "vel_band": vel_band,
            "current_occurrence_id": selection_result["selection"].get("current", {}),
            "previous_occurrence_id": selection_result["selection"].get("previous", {}),
        })

        # Rejstřík bodů pro výběr grafů (trendy + FFT spektra) může zachovat
        # všechny směry; není součástí vyhodnocení ani stavu protokolu.
        for p in points:
            # — pro rychlost, zrychlení i obálku; vč. limitů pásem pro trendy
            # otáčky bodu: prioritně z bodu, jinak ze stroje
            pt_speed = p.get("speed_hz")
            if pt_speed is None:
                pt_speed = machine_speed_hz
            points_index.append({
                "point_id": p.get("id"),
                "point_name": p.get("name") or (blabel + (p.get("direction") or "")),
                "bearing": blabel,
                "direction": p.get("direction") or "",
                "vel_cell_id": _cell_for_point(velocity_q, p),
                "acc_cell_id": _cell_for_point(accel_q, p),
                "env_cell_id": _cell_for_point(env_name, p),
                # ID spektrálních měření (pro interaktivní náhled FFT ve frontendu)
                "vel_spec_cell_id": _find_spectrum_cell(db, p.get("id"), VELOCITY_SPEC),
                "acc_spec_cell_id": _find_spectrum_cell(db, p.get("id"), ACCEL_SPEC),
                "env_spec_cell_id": _find_spectrum_cell(db, p.get("id"), ENV_SPEC),
                # limity (mez výstrahy = B/C, mez alarmu = C/D, ab = A/B) pro hladiny v trendu
                "vel_warning": vel_w, "vel_alarm": vel_a, "vel_ab": vel_ab,
                "acc_warning": acc_w, "acc_alarm": acc_a, "acc_ab": acc_ab,
                "env_warning": env_w, "env_alarm": env_a, "env_ab": env_ab,
                "env_quantity": env_name,
                # otáčky + defektní frekvence ložiska (pro značky ve spektru)
                "speed_hz": pt_speed,
                "bearing_designation": b_bearing.get("designation") or "",
                "bearing_ftf": b_bearing.get("FTF"),
                "bearing_bsf": b_bearing.get("BSF"),
                "bearing_bpfo": b_bearing.get("BPFO"),
                "bearing_bpfi": b_bearing.get("BPFI"),
            })

        bearings_summary.append({
            "place": blabel,
            "point_id": h_point.get("id") if h_point else None,
            "point_mapping": h_mapping,
            "acc_cur": acc_cur, "acc_auto_band": acc_auto_band,
            "acc_band_override": "", "acc_band": acc_band,
            "acc_dir": acc_dir,
            "env_cur": env_cur, "env_auto_band": env_auto_band,
            "env_band_override": "", "env_band": env_band,
            "env_dir": env_dir,
            "bearing_auto_state": bearing_state or "",
            "bearing_state": bearing_state or "",
            "measurement_directions": selection_result["directions"],
            "measurement_selection": selection_result["selection"],
            "measurement_selection_audit": selection_result["audit"],
            "measurement_migration_notice": bool(selection_result["migration_notice"]),
            "measurement_fallback_directions": selection_result["fallback_directions"],
        })

    # „Neměřeno“ pouze tehdy, když není dostupná ani jedna z viditelných
    # veličin nezávisle vybraných pro protokol.
    has_data = any(r.get("vel_cur") is not None for r in rows) or any(
        b.get("acc_cur") is not None or b.get("env_cur") is not None
        for b in bearings_summary)

    # Nejhorší pásmo (A–D) POUZE z informací, které jsou skutečně zobrazeny:
    # z pásma rychlosti max. H/V/A a ze samostatného stavu ložiska
    # (ACC/ENV max. H/V/A).
    # Nic jiného do stavu stroje nevstupuje.
    all_bands = [r.get("vel_band") for r in rows]
    for b in bearings_summary:
        all_bands.append(b.get("bearing_state"))
    worst_band = _worst_band(*all_bands) if has_data else None

    # Celkový stav stroje = závažnost odvozená PŘÍMO z nejhoršího zobrazeného
    # pásma. Tím je zaručeno, že stavový štítek (barva) vždy odpovídá tomu, co
    # uživatel vidí v tabulce — pásmo A/B => OK, C => Upozornění, D => Výstraha.
    if not has_data:
        severity = "none"
    else:
        severity = band_severity(worst_band) or "ok"
    auto_severity = severity  # automaticky spočtený stav (z pásem v tabulce)
    # Ruční přepis stavu je vlastností NÁVRHU protokolu (ne karty stroje):
    # nastavuje se v editoru a persistuje se přímo v draftu (doc.machines[].
    # severity_override). Při prvním sestavení návrhu je stav vždy automatický.
    manual_applied = False

    return {
        "machine_id": mid,
        "name": machine.get("name"),
        "parent_name": machine.get("parent_name"),
        "speed_hz": machine.get("speed_hz"),
        "iso_norm": machine.get("iso_norm"),
        "card": {
            "drive_no": card.get("drive_no", ""),
            "tech_location": card.get("tech_location", ""),
            "power_kw": card.get("power_kw", ""),
            "rpm": card.get("rpm", ""),
            "impeller_diameter": card.get("impeller_diameter", ""),
            "description": card.get("description", ""),
            "image": card.get("image", ""),
        },
        "rows": rows,
        "bearings_summary": bearings_summary,
        "points_index": points_index,
        "severity": severity,
        "severity_label": SEV_LABELS.get(severity, ""),
        "auto_severity": auto_severity,
        "auto_severity_label": SEV_LABELS.get(auto_severity, ""),
        "severity_manual": manual_applied,
        "severity_override": "",
        "worst_band": worst_band,
        "last_measured": _fmt_date(last_meas_dt),
        "env_label": "obálka zrychlení",
        "protocol_direction": "max_hva",
        "measurement_selection_schema": MEASUREMENT_SELECTION_SCHEMA,
        "measurement_selection": {
            str(b.get("place") or ""): dict(b.get("measurement_selection") or {})
            for b in bearings_summary
        },
        "measurement_selection_audit": {
            str(b.get("place") or ""): dict(b.get("measurement_selection_audit") or {})
            for b in bearings_summary
        },
        "measurement_selection_notices": selection_notices,
        "protocol_quantities": {
            "velocity": velocity_q, "accel": accel_q, "env": env_name,
        },
    }


# --------------------------- data grafů (trend / FFT) ---------------------------
def _downsample(xs, ys, max_pts):
    """Zjednoduše zmenší počet bodů křivky na max_pts (po krokách)."""
    n = len(ys)
    if n <= max_pts:
        return list(xs), list(ys)
    step = n / float(max_pts)
    ox, oy = [], []
    i = 0.0
    while int(i) < n:
        k = int(i)
        ox.append(xs[k]); oy.append(ys[k])
        i += step
    # zajisti poslední bod (špička konce osy)
    if oy and oy[-1] != ys[-1]:
        ox.append(xs[-1]); oy.append(ys[-1])
    return ox, oy


def _downsample_peaks(xs, ys, max_pts):
    """Redukce počtu bodů spektra se **zachováním špiček**.

    Prosté kročejí pod-vzorkování (_downsample) u FFT spektra vynechává
    lokální maxima – vykreslené spektrum pak vypadá jinak než v náhledu.
    Zde dělíme rozsah do 'bucketů' a z každého bereme bod s **nejvyšší
    amplitudou** (plus první a poslední bod), takže tvar spektra i špičky
    zůstanou zachovány. Pro typická spektra (<= max_pts) nemění nic.
    """
    n = len(ys)
    if n <= max_pts or max_pts < 3:
        return list(xs), list(ys)
    # rezervuj místo pro první a poslední bod
    buckets = max_pts - 2
    step = n / float(buckets)
    ox, oy = [xs[0]], [ys[0]]
    for b in range(buckets):
        lo = int(b * step)
        hi = int((b + 1) * step)
        if hi <= lo:
            hi = lo + 1
        if lo >= n:
            break
        hi = min(hi, n)
        # najdi index maxima v tomto bucketu
        kmax = lo
        vmax = ys[lo]
        for k in range(lo, hi):
            if ys[k] > vmax:
                vmax = ys[k]; kmax = k
        # nezdvojuj úplně první bod
        if kmax != 0:
            ox.append(xs[kmax]); oy.append(ys[kmax])
    # zajisti poslední bod
    if ox[-1] != xs[-1]:
        ox.append(xs[-1]); oy.append(ys[-1])
    return ox, oy


def build_trend_graph(db, cell_id, max_pts=60, warning=None, alarm=None,
                      x_range=None, ab=None):
    """Sestaví data trendu (čas × hodnota) pro jednu buňku k vykreslení do PDF.

    Volitelně přidá hladiny limitů pásem (`warning` = mez B/C, `alarm` = mez
    C/D), které se v grafu vykreslí jako vodorovné čáry.

    `max_pts` = "all" (nebo None) použije všechny body bez pod-vzorkování.
    `x_range` = [i_min, i_max] omezí trend na podrozsah indexovaných bodů
    (zoom přenesený z interaktivního náhledu).
    """
    if not cell_id:
        return None
    pts = db.trend(cell_id)
    if not pts or len(pts) < 2:
        return None
    # popisky časové osy: první a poslední datum
    def _d(p):
        dt = _parse_iso(p.get("t"))
        return _fmt_date(dt) if dt else ""
    # otočení rozsahu (zoom) na podmnožinu bodů dle indexu na ose X
    i0, i1 = 0, len(pts) - 1
    if x_range and len(x_range) == 2:
        try:
            a = int(round(float(x_range[0])))
            b = int(round(float(x_range[1])))
            i0 = max(0, min(a, b))
            i1 = min(len(pts) - 1, max(a, b))
            if i1 - i0 < 1:
                i0, i1 = 0, len(pts) - 1
        except (TypeError, ValueError):
            i0, i1 = 0, len(pts) - 1
    sub = pts[i0:i1 + 1]
    if len(sub) < 2:
        sub = pts
        i0, i1 = 0, len(pts) - 1
    xs = list(range(len(sub)))
    ys = [p.get("value") for p in sub]
    # "all"/None = bez pod-vzorkování
    if max_pts in (None, "all"):
        ox, oy = xs, ys
    else:
        ox, oy = _downsample(xs, ys, max_pts)
    g = {
        "type": "trend",
        "y": oy,
        "x_first": _d(sub[0]),
        "x_last": _d(sub[-1]),
        "n": len(sub),
        "i0": i0,          # index prvního bodu v původním trendu (kvůli značkám)
        "i1": i1,          # index posledního bodu
    }
    # hladiny limitů pásem (pro vykreslení do trendu)
    limits = []
    try:
        if warning is not None:
            w = float(warning)
            # hranice A/B: explicitní z normy, jinak odhad warning/2
            ab_line = None
            if ab is not None:
                try:
                    ab_line = float(ab)
                except (TypeError, ValueError):
                    ab_line = None
            if ab_line is None or ab_line <= 0 or ab_line >= w:
                ab_line = w / 2.0
            limits.append({"value": ab_line, "band": "A/B"})
            limits.append({"value": w, "band": "B/C"})
        if alarm is not None:
            limits.append({"value": float(alarm), "band": "C/D"})
    except (TypeError, ValueError):
        limits = []
    if limits:
        g["limits"] = limits
    return g


# spektrální měření (názvy cell) odpovídající veličinám trendů
VELOCITY_SPEC = ("ISO SPECTRUM",)
ACCEL_SPEC = ("ACC Spectrum", "ACC SPECTRUM")
ENV_SPEC = ("ACC ENV SPEC 500 Hz", "ACC ENV SPEC 1 kHz")


def _find_spectrum_cell(db, point_id, name_options):
    """Najde ID spektrálního měření bodu podle názvu veličiny (case-insensitive)."""
    if not point_id:
        return None
    try:
        cells = db._con.execute(
            "SELECT ID, Name, DataType FROM Tbl_Cell WHERE Parent=? ORDER BY ID",
            (point_id,),
        ).fetchall()
    except Exception:
        return None
    wanted = [n.lower() for n in name_options]
    spec = [c for c in cells if c["DataType"] in (7, 8)]
    for w in wanted:
        for c in spec:
            if (c["Name"] or "").lower() == w:
                return c["ID"]
    # fallback: částečná shoda
    for w in wanted:
        for c in spec:
            if w in (c["Name"] or "").lower():
                return c["ID"]
    return None


def build_spectrum_graph(db, point_id, max_pts=1600, spec_cell_id=None,
                         x_range=None):
    """Sestaví poslední FFT spektrum bodu (frekvence × amplituda) k vykreslení.

    `spec_cell_id` volitelně určuje konkrétní spektrální měření (veličinu) bodu;
    pokud chybí, vybere se spektrum s nejvíce pořízeními (zpětná kompatibilita).

    `x_range` = [f_min, f_max] omezí spektrum na frekvenční okno (zoom
    přenesený z interaktivního náhledu).

    Redukce počtu bodů se provádí **se zachováním špiček** (_downsample_peaks)
    a s vysokým limitem, aby vykreslené spektrum v PDF odpovídalo náhledu
    i bez použití zoomu (typická spektra do ~1600 linek se nemění vůbec).
    """
    if not point_id:
        return None
    try:
        wf = db.waterfall(point_id, limit=1, cell_id=spec_cell_id)
    except Exception:
        return None
    spectra = wf.get("spectra") or []
    freqs = wf.get("frequencies") or []
    if not spectra or not freqs:
        return None
    last = spectra[-1]
    ys = last.get("values") or []
    if not ys:
        return None
    n = min(len(freqs), len(ys))
    xs = freqs[:n]
    ys = ys[:n]
    # frekvenční okno (zoom): ořež na [f_min, f_max]
    fmin_win = xs[0] if xs else 0
    if x_range and len(x_range) == 2:
        try:
            lo = float(min(x_range))
            hi = float(max(x_range))
            fxs, fys = [], []
            for xv, yv in zip(xs, ys):
                if xv >= lo and xv <= hi:
                    fxs.append(xv); fys.append(yv)
            if len(fxs) >= 2:
                xs, ys = fxs, fys
                fmin_win = lo
        except (TypeError, ValueError):
            pass
    ox, oy = _downsample_peaks(xs, ys, max_pts)
    fmax = xs[-1] if xs else 0
    fmin = xs[0] if xs else 0
    return {
        "type": "spectrum",
        "x": ox,
        "y": oy,
        "x_max": fmax,
        "x_min": fmin,
        "x_unit": wf.get("x_unit", "Hz"),
        "cell_name": wf.get("cell_name", ""),
        "time": last.get("time", ""),
    }


# definice druhů grafů: kind -> (typ, popis veličiny, jednotka, klíč cell, veličina)
# `kind` je volitelně ve formátu "<typ>_<veličina>" (např. "trend_acc");
# staré hodnoty "trend"/"spectrum" = rychlost (zpětná kompatibilita).
_GRAPH_KINDS = {
    # trendy
    "trend":      ("trend", "rychlosti vibrací", "mm/s", "vel_cell_id", "vel"),
    "trend_vel":  ("trend", "rychlosti vibrací", "mm/s", "vel_cell_id", "vel"),
    "trend_acc":  ("trend", "zrychlení", "g", "acc_cell_id", "acc"),
    "trend_env":  ("trend", "obálky zrychlení", "g", "env_cell_id", "env"),
    # spektra
    "spectrum":     ("spectrum", "rychlosti (ISO)", "mm/s", None, "vel"),
    "spectrum_vel": ("spectrum", "rychlosti (ISO)", "mm/s", None, "vel"),
    "spectrum_acc": ("spectrum", "zrychlení", "g", None, "acc"),
    "spectrum_env": ("spectrum", "obálky zrychlení", "g", None, "env"),
}

_SPEC_NAMES = {"vel": VELOCITY_SPEC, "acc": ACCEL_SPEC, "env": ENV_SPEC}


def collect_machine_graphs(db, rep, selections):
    """Pro stroj sestaví vybrané grafy.

    selections = seznam položek:
      {"point_id": int, "kind": str, "point_name": str, "note": str (volitelně)}
    kde `kind` je např. "trend", "trend_acc", "trend_env", "spectrum",
    "spectrum_acc", "spectrum_env" ("trend"/"spectrum" = rychlost).
    Vrací list grafů (s daty) připravených k vykreslení.
    """
    out = []
    idx = {pi.get("point_id"): pi for pi in rep.get("points_index", [])}
    for sel in (selections or []):
        pid = sel.get("point_id")
        kind = sel.get("kind") or "trend"
        pi = idx.get(pid, {})
        title = sel.get("point_name") or pi.get("point_name") or ""
        note = (sel.get("note") or "").strip()
        spec = _GRAPH_KINDS.get(kind)
        if not spec:
            continue
        gtype, qlabel, unit, cell_key, qkey = spec
        # rozsah os (zoom) a uživatelské značky přenesené z náhledu
        x_range = sel.get("x_range")
        if not (isinstance(x_range, (list, tuple)) and len(x_range) == 2):
            x_range = None
        user_markers = sel.get("user_markers") or []
        g = None
        if gtype == "trend":
            cell_id = pi.get(cell_key)
            warn = pi.get(qkey + "_warning")
            alarm = pi.get(qkey + "_alarm")
            ab = pi.get(qkey + "_ab")
            # trend vždy používá všechny body (bez pod-vzorkování)
            g = build_trend_graph(db, cell_id, max_pts="all",
                                  warning=warn, alarm=alarm, x_range=x_range,
                                  ab=ab)
            if g:
                g["title"] = "Trend " + qlabel + " – " + title
                g["y_unit"] = unit
                # uživatelské značky trendu (svislé čáry na indexu bodu);
                # harmonické/pásma se u trendu neuplatňují
                um = _user_markers_norm(user_markers, expand=False)
                if um:
                    g["user_markers"] = um
        else:  # spectrum
            spec_cell = _find_spectrum_cell(db, pid, _SPEC_NAMES.get(qkey, ()))
            g = build_spectrum_graph(db, pid, spec_cell_id=spec_cell,
                                     x_range=x_range)
            if g:
                g["title"] = "FFT spektrum " + qlabel + " – " + title
                g["y_unit"] = unit
                # automatické značky (otáčková, harmonické, ložiskové) – dle výběru
                markers = _spectrum_markers(sel.get("markers") or [], pi,
                                            g.get("x_max") or 0)
                # přidej uživatelské značky (ručně přidané v náhledu) včetně
                # harmonických a postranních pásem, oříznuté na rozsah spektra
                um = _user_markers_norm(user_markers, expand=True,
                                        x_max=g.get("x_max") or 0,
                                        x_min=g.get("x_min") or 0)
                if um:
                    markers = (markers or []) + um
                if markers:
                    g["markers"] = markers
        if g:
            if note:
                g["note"] = note
            out.append(g)
    return out


def _user_markers_norm(user_markers, expand=False, x_max=0, x_min=0):
    """Normalizuje uživatelské značky z náhledu na formát {freq, label, kind}.

    Vstup je seznam {x|freq, label, harmonics?, sidebands?, sb_spacing?}.
    `kind="user"` je odlišuje od automaticky vypočtených značek.

    Pokud expand=True (spektrum), rozgeneruje pro každou značku i její
    harmonické (x×k pro k=1..harmonics) a postranní pásma
    (x×k ± s·sb_spacing pro s=1..sidebands), oříznuté na rozsah
    [x_min, x_max]. Pokud expand=False (trend), použije jen základní
    pozici (harmonické/pásma se u trendu neuplatňují).
    """
    try:
        xmax = float(x_max) if x_max else 0.0
    except (TypeError, ValueError):
        xmax = 0.0
    try:
        xmin = float(x_min) if x_min else 0.0
    except (TypeError, ValueError):
        xmin = 0.0

    def _in_range(f):
        if f is None or f <= 0:
            return False
        if xmax and f > xmax:
            return False
        if xmin and f < xmin:
            return False
        return True

    out = []
    for m in (user_markers or []):
        if not isinstance(m, dict):
            continue
        x = m.get("freq", m.get("x"))
        try:
            xv = float(x)
        except (TypeError, ValueError):
            continue
        if xv <= 0:
            continue
        lbl = str(m.get("label") or "").strip() or ("%.1f" % xv)

        if not expand:
            # trend – jen základní pozice (svislá čára na indexu/hodnotě)
            out.append({"freq": round(xv, 3), "label": lbl, "kind": "user"})
            continue

        # spektrum – rozgeneruj harmonické a postranní pásma
        try:
            n_h = int(m.get("harmonics") or 1)
        except (TypeError, ValueError):
            n_h = 1
        if n_h < 1:
            n_h = 1
        try:
            n_sb = int(m.get("sidebands") or 0)
        except (TypeError, ValueError):
            n_sb = 0
        if n_sb < 0:
            n_sb = 0
        try:
            sb_sp = float(m.get("sb_spacing") or 0.0)
        except (TypeError, ValueError):
            sb_sp = 0.0
        if sb_sp < 0:
            sb_sp = 0.0

        for k in range(1, n_h + 1):
            fx = xv * k
            if not _in_range(fx):
                continue
            if k == 1:
                klbl = lbl
            else:
                klbl = "%s %d×" % (lbl, k)
            out.append({"freq": round(fx, 3), "label": klbl,
                        "kind": "user", "line": "harm" if k > 1 else "base"})
            # postranní pásma kolem této harmonické
            if n_sb and sb_sp > 0:
                for s in range(1, n_sb + 1):
                    for sign in (-1, 1):
                        fsb = fx + sign * s * sb_sp
                        if not _in_range(fsb):
                            continue
                        out.append({"freq": round(fsb, 3), "label": "",
                                    "kind": "user", "line": "sb"})
    return out


def _spectrum_markers(marker_kinds, pi, x_max):
    """Vypočítá frekvenční značky pro FFT spektrum.

    marker_kinds – seznam z {"speed", "harmonics", "bearing"}.
    pi – záznam bodu z points_index (obsahuje speed_hz a násobky ložiska).
    Vrací list {freq, label, kind} pro frekvence v rozsahu [0, x_max].
    """
    kinds = set(marker_kinds or [])
    if not kinds:
        return []
    try:
        speed = float(pi.get("speed_hz")) if pi.get("speed_hz") is not None else None
    except (TypeError, ValueError):
        speed = None
    if not speed or speed <= 0:
        return []
    try:
        xmax = float(x_max) if x_max else 0.0
    except (TypeError, ValueError):
        xmax = 0.0

    out = []

    def _add(freq, label, kind):
        if freq is None or freq <= 0:
            return
        if xmax and freq > xmax:
            return
        out.append({"freq": round(freq, 2), "label": label, "kind": kind})

    # otáčková (1× RPM)
    if "speed" in kinds:
        _add(speed, "1×", "speed")
    # harmonické otáček (2×–6×)
    if "harmonics" in kinds:
        for k in range(2, 7):
            _add(speed * k, "%d×" % k, "harmonics")
    # ložiskové defektní frekvence (násobek × otáčky)
    if "bearing" in kinds:
        for key, lbl in (("bearing_bpfo", "BPFO"), ("bearing_bpfi", "BPFI"),
                         ("bearing_bsf", "BSF"), ("bearing_ftf", "FTF")):
            coef = pi.get(key)
            try:
                coef = float(coef) if coef is not None else None
            except (TypeError, ValueError):
                coef = None
            if coef and coef > 0:
                _add(speed * coef, lbl, "bearing")
    return out


def _worst_band(*bands):
    """Vrátí nejhorší pásmo (D > C > B > A)."""
    rank = {"A": 0, "B": 1, "C": 2, "D": 3}
    best = None
    best_r = -1
    for b in bands:
        if b is None:
            continue
        r = rank.get(b, -1)
        if r > best_r:
            best_r = r
            best = b
    return best


def point_row_key(place, direction):
    """Jednoznačný klíč měřicího bodu = místo (ložisko) + směr (např. 'L1|H').

    Používá se pro vyloučení konkrétních bodů z tabulky celkových hodnot.
    """
    return "%s|%s" % (str(place or ""), str(direction or ""))


MANUAL_BAND_VALUES = ("A", "B", "C", "D")


def _effective_band(auto_band, override):
    """Vrátí ruční pásmo A–D, je-li platné, jinak aktuální automatiku."""
    return override if override in MANUAL_BAND_VALUES else auto_band


def recompute_category_states(m):
    """Znovu sestaví efektivní stavy tří kategorií a stav každého ložiska.

    Schéma návrhu je záměrně ploché kvůli zpětné kompatibilitě:
    ``*_auto_band`` je výsledek z přesně zobrazené H hodnoty a jejích limitů,
    ``*_band_override`` je prázdné/``A``–``D`` reportové ruční rozhodnutí a
    ``*_band`` je efektivní hodnota. Starší návrhy bez ``*_auto_band`` se
    považují za automatické a bezpečně se migrují při prvním přepočtu.
    """
    for r in m.get("rows") or []:
        if "vel_auto_band" not in r:
            r["vel_auto_band"] = r.get("vel_band")
        r["vel_band"] = _effective_band(
            r.get("vel_auto_band"), r.get("vel_band_override"))
    for b in m.get("bearings_summary") or []:
        if "acc_auto_band" not in b:
            b["acc_auto_band"] = b.get("acc_band")
        if "env_auto_band" not in b:
            b["env_auto_band"] = b.get("env_band")
        b["acc_band"] = _effective_band(
            b.get("acc_auto_band"), b.get("acc_band_override"))
        b["env_band"] = _effective_band(
            b.get("env_auto_band"), b.get("env_band_override"))
        # Pravý stav ložiska je záměrně nezávislý na pásmu rychlosti. Řádek
        # rychlosti je vlastní samostatná veličina a vstupuje až do stavu
        # stroje, nikoli do stavu ložiska.
        auto_bearing = _worst_band(
            b.get("acc_auto_band"), b.get("env_auto_band"))
        b["bearing_auto_state"] = auto_bearing or ""
        effective = _worst_band(b.get("acc_band"), b.get("env_band"))
        b["bearing_state"] = effective or ""


def report_state_context(m):
    """Krátký AI kontext výhradně z kanonického výsledku výběru."""
    parts = []
    rows = {r.get("place"): r for r in (m.get("rows") or [])}
    for b in m.get("bearings_summary") or []:
        place = b.get("place") or "?"
        r = rows.get(place, {})
        cats = (
            ("pásmo rychlosti", r.get("vel_band"), r.get("vel_band_override")),
            ("zrychlení", b.get("acc_band"), b.get("acc_band_override")),
            ("obálka", b.get("env_band"), b.get("env_band_override")),
        )
        text = ", ".join(
            "%s %s%s" % (label, band or "—",
                          " (ručně)" if manual in MANUAL_BAND_VALUES else "")
            for label, band, manual in cats)
        values = "R %s (%s), Z %s (%s), O %s (%s)" % (
            r.get("vel_cur") if r.get("vel_cur") is not None else "—",
            r.get("direction") or "—",
            b.get("acc_cur") if b.get("acc_cur") is not None else "—",
            b.get("acc_dir") or "—",
            b.get("env_cur") if b.get("env_cur") is not None else "—",
            b.get("env_dir") or "—")
        parts.append("%s: %s; %s; stav ložiska (zrychlení/obálka) %s" % (
            place, values, text, b.get("bearing_state") or "—"))
    return " | ".join(parts)


def report_measurement_context(m):
    """Serializace hodnot stejného kanonického výsledku pro AI.

    Vzniká až po ``_direction_selection_result`` a používá hodnoty uložené do
    řádků/souhrnů. AI proto nemá druhou cestu, která by mohla z historie vybrat
    jiné „nejnovější“ měření než tabulka a export.
    """
    rows = {r.get("place"): r for r in (m.get("rows") or [])}
    chunks = []
    for b in m.get("bearings_summary") or []:
        place = b.get("place") or "?"
        row = rows.get(place, {})
        chunks.append(
            "%s: rychlost %s mm/s (%s); zrychlení %s g (%s); obálka %s g (%s)"
            % (place,
               row.get("vel_cur") if row.get("vel_cur") is not None else "—",
               row.get("direction") or "—",
               b.get("acc_cur") if b.get("acc_cur") is not None else "—",
               b.get("acc_dir") or "—",
               b.get("env_cur") if b.get("env_cur") is not None else "—",
               b.get("env_dir") or "—"))
    return "\n".join(chunks)


def recompute_machine_state(m):
    """Přepočítá stav JEDNOHO stroje z jeho aktuálních řádků a souhrnů.

    Nastaví (in-place) `worst_band`, `auto_severity`, `auto_severity_label`,
    `severity`, `severity_label` a `severity_manual`.

    Do hodnocení vstupují POUZE informace zobrazené v tabulce celkových hodnot
    (pásmo rychlosti H a stav ložiska z ACC/ENV H) a POUZE body,
    které uživatel v editoru nevyloučil (`excluded_points`). Ruční přepis stavu
    (`severity_override`) má přednost před automatikou – automatický stav se
    přitom vždy dopočítá, aby uživatel viděl, co by automatika určila.

    Vrací (auto_severity, severity).
    """
    recompute_category_states(m)
    excluded = set(m.get("excluded_points") or [])
    rows = m.get("rows") or []
    brgs = m.get("bearings_summary") or []
    if excluded:
        rows = [r for r in rows
                if point_row_key(r.get("place"), r.get("direction")) not in excluded]
        kept_places = {r.get("place") for r in rows}
        brgs = [b for b in brgs if b.get("place") in kept_places]

    has_data = any(r.get("vel_cur") is not None for r in rows) or any(
        b.get("acc_cur") is not None or b.get("env_cur") is not None
        for b in brgs)
    all_bands = [r.get("vel_band") for r in rows]
    for b in brgs:
        all_bands.append(b.get("bearing_state"))
    worst_band = _worst_band(*all_bands) if has_data else None
    m["worst_band"] = worst_band

    auto_sev = "none" if not has_data else (band_severity(worst_band) or "ok")
    m["auto_severity"] = auto_sev
    m["auto_severity_label"] = SEV_LABELS.get(auto_sev, "")

    manual_sev = m.get("severity_override")
    if manual_sev in MANUAL_SEV_VALUES:
        m["severity"] = manual_sev
        m["severity_manual"] = True
    else:
        m["severity"] = auto_sev
        m["severity_manual"] = False
    m["severity_label"] = SEV_LABELS.get(m["severity"], "")
    return auto_sev, m["severity"]


def apply_excluded_points(doc):
    """Odstraní z každého stroje měřicí body, které uživatel v editoru
    odškrtl (`machine['excluded_points']`), a přepočítá závažnost stroje
    i nejhorší pásmo POUZE ze zbylých bodů.

    Vyloučené body se pak nezobrazí v tabulce celkových hodnot v PDF ani
    nepřispívají k hodnocení (klasifikace do pásem A–D, celkový stav).

    Pracuje nad KOPIÍ relevantních částí – vrací NOVÝ doc vhodný k vykreslení;
    uložený návrh (s kompletními řádky a zaškrtávátky) zůstává nedotčený.

    Klíč bodu = place|direction (viz point_row_key).
    """
    import copy
    if not isinstance(doc, dict):
        return doc
    machines = doc.get("machines") or []
    if not any((m or {}).get("excluded_points") for m in machines):
        return doc  # nic vyloučeného – vrať původní doc beze změny

    new_doc = copy.deepcopy(doc)
    for m in new_doc.get("machines", []):
        excluded = set(m.get("excluded_points") or [])
        if not excluded:
            continue
        rows = m.get("rows") or []
        kept_rows = [r for r in rows
                     if point_row_key(r.get("place"), r.get("direction"))
                     not in excluded]
        m["rows"] = kept_rows

        # místa (ložiska), která mají ještě aspoň jeden zbylý směr
        kept_places = {r.get("place") for r in kept_rows}
        # bearings_summary: ponech pouze ložiska, kde zůstal aspoň jeden bod
        brg = m.get("bearings_summary") or []
        m["bearings_summary"] = [b for b in brg if b.get("place") in kept_places]
        # points_index (pro grafy) – filtruj stejně dle klíče bodu
        pidx = m.get("points_index") or []
        m["points_index"] = [
            p for p in pidx
            if point_row_key(p.get("bearing"), p.get("direction")) not in excluded]

        # přepočet nejhoršího pásma a stavu jen ze zbylých dat (POUZE z hodnot
        # zobrazených v tabulce: rychlost, zrychlení, obálka, stav ložiska);
        # ruční přepis stavu má přednost před automatikou
        recompute_machine_state(m)
    return new_doc


# {norm} = placeholder nahrazený skutečně použitou normou (viz
# _intro_with_norms / collect_used_norms). Pokud norma není známa, dosadí se
# neutrální "platné normy pro hodnocení stavu průmyslových strojů".
DEFAULT_INTRO = (
    "Měření vibrací bylo provedeno na vybraných strojích a pohonech z důvodu "
    "zjištění objektivního stavu ložisek a celého strojního zařízení. Celkové "
    "efektivní hodnoty rychlosti vibrací jsou klasifikovány dle {norm}.\n\n"
    "Pro analýzu stavu valivých ložisek je použita metoda obálky signálu "
    "zrychlení. Dále je provedena frekvenční analýza aplikací rychlé Fourierovy "
    "transformace (FFT) na měřené vibrační signály s cílem zjistit dané "
    "frekvenční složky obsažené v signálu vibrací, jež jsou obrazem případných "
    "mechanických, elektrických či jiných nedostatků.\n\n"
    "K měření byla použita měřicí a softwarová technologie od firmy HADS."
)

# Vestavěné výchozí hodnoty vydavatele. Skutečně použitá patička a schvalovatel
# se berou z Nastavení → Firma a logo (modul `branding`); tyto konstanty
# zůstávají jako záloha a jako výchozí obsah personalizace.
DEFAULT_FOOTER = {
    "brand": "HEISTECH",
    "company": "Heistech, s.r.o.",
    "address": "Dobrkovice 111, 763 07 Dobrkovice",
    "web": "www.heistech.cz",
}

DEFAULT_APPROVED_BY = "Ing. Lukáš Heisig, Ph.D. CTD"


def issuer_footer():
    """Patička nového návrhu podle personalizace instalace."""
    try:
        return branding.footer()
    except Exception:
        return dict(DEFAULT_FOOTER)


def issuer_approved_by():
    """Výchozí „Schválil“ nového návrhu podle personalizace instalace."""
    try:
        return branding.approved_by()
    except Exception:
        return DEFAULT_APPROVED_BY


REPORT_VERSIONS = (1, 2, 3)
DEFAULT_REPORT_VERSION = 1

# Popisky verzí protokolu (pro UI a AI prompt)
REPORT_VERSION_LABELS = {
    1: "Stručná",
    2: "Detailní",
    3: "Vyvažování",
}


def norm_report_version(v):
    """Ověří/normalizuje verzi šablony protokolu (1, 2 nebo 3, výchozí 1)."""
    try:
        v = int(v)
    except (TypeError, ValueError):
        return DEFAULT_REPORT_VERSION
    return v if v in REPORT_VERSIONS else DEFAULT_REPORT_VERSION


# ---- vyvažování ----------------------------------------------------------
DEFAULT_INTRO_BALANCE = (
    "Provozní vyvažování ventilátoru bylo provedeno na místě u zákazníka "
    "z důvodu zvýšených hodnot vibrací před zahájením prací. Cílem bylo "
    "snížit celkové efektivní hodnoty rychlosti vibrací (ISO RMS) na úroveň "
    "přijatelnou dle platné normy (typicky do pásma A/B) a ověřit celkový "
    "stav valivých ložisek.\n\n"
    "Postup: nejprve bylo změřeno počáteční (výchozí) stav vibrací, následně "
    "bylo provedeno vyvážení oběžného kola ventilátoru (dle potřeby včetně "
    "vyčištění a odstranění nánosů). Po vyvážení bylo měření zopakováno pro "
    "ověření dosažené úrovně vibrací. V tomto protokolu jsou uvedeny obě "
    "hodnoty (před / po) s klasifikací do pásem A–D a přepočtem procentuální "
    "úspěšnosti vyvážení.\n\n"
    "K měření a vyvažování byla použita měřicí a softwarová technologie od "
    "firmy HADS."
)

DEFAULT_CONCLUSION_BALANCE = (
    "Po vyčištění oběžného kola ventilátoru klesly celkové hodnoty z pásma D "
    "do pásma A dle příslušné normy. Spektra FFT rychlosti po vyvážení bez "
    "detekce poškození. Spektra zrychlení (obálky zrychlení) detekují mírný "
    "nárůst na ložisku motoru L1 vlivem nedokonalého mazání. Provozní stav."
)


def balance_success_pct(vel_prev, vel_cur):
    """Vrátí procentuální úspěšnost vyvážení pro dvojici hodnot rychlosti.

    Definice: (vel_prev - vel_cur) / vel_prev * 100 %. Kladná hodnota znamená
    zlepšení (snížení vibrací), záporná zhoršení. Vrací None, pokud některá
    z hodnot chybí nebo je vel_prev nulový/záporný.
    """
    try:
        p = float(vel_prev)
        c = float(vel_cur)
    except (TypeError, ValueError):
        return None
    if p <= 0:
        return None
    return (p - c) / p * 100.0


def build_report_draft(db, all_over, company, scope, ai_fn=None, model=None,
                       graph_selections=None, report_version=None, qmap=None):
    """Sestaví editovatelný NÁVRH protokolu (slovník `doc`).

    * vybere okruh strojů dle `scope`,
    * pro každý stroj sestaví tabulku a klasifikaci,
    * volitelně zavolá `ai_fn(machine_report)` -> {problem, zaver, doporuceni}
      pro stručný závěr a doporučení (per stroj),
    * doplní výchozí hlavičku, úvod a podpisy (editovatelné ve frontendu).

    `ai_fn` je callable přebírající (machine_dict, machine_report_dict) a vracející
    {"problem", "zaver", "doporuceni"} nebo None.

    `graph_selections` = {"<machine_id>": [{"point_id", "kind", "point_name"}, …]}
    — volitelné grafy (trend / FFT) k vykreslení na straně stroje.

    `report_version` volí šablonu výsledného PDF (viz report_pdf.render):
      1 = stručná (výchozí) — detailní strana jen pro stroje Alarm/Výstraha,
          tabulka s hodnotami výhradně v horizontálním směru H.
      2 = detailní — detailní strana pro VŠECHNY stroje, tabulka H rychlosti
          včetně předchozí hodnoty pro porovnání.
      3 = vyvažování — většinou pro jeden ventilátor: tabulka s před/po
          hodnotami rychlosti (včetně pásem A–D obou hodnot) a procentuální
          úspěšností vyvážení, stav ložisek, příloha se spektry/trendy a
          externím vektorovým grafem (data URL obrázku v `doc["appendix_image"]`).
    """
    graph_selections = graph_selections or {}
    report_version = norm_report_version(report_version)

    selected, scope_label, dates = select_machines_by_scope(db, scope)
    selected_window = scope_time_window(db, scope) if scope else None
    machines_all = db.machines(overrides=all_over).get("machines", [])
    machine_reports = []
    ai_errors = []   # diagnostika neuspešných AI závěrů (per stroj)
    ai_ok = 0        # počet strojů, u nichž AI vrátila závěr
    for mc in machines_all:
        if mc["id"] not in selected:
            continue
        rep = build_machine_report(
            db, mc, all_over, qmap=qmap, scope=scope,
            scope_window=selected_window)
        # AI stručný závěr + doporučení
        problem = zaver = doporuceni = ""
        if ai_fn is not None:
            mname = mc.get("name") or ("stroj %s" % mc.get("id"))
            res = None
            try:
                res = ai_fn(mc, rep)
                if res is not None:
                    if not isinstance(res, dict) or any(
                            not isinstance(res.get(field), str)
                            for field in ("problem", "zaver", "doporuceni")):
                        raise ai_eval.AIResponseFormatError()
            except ai_eval.AIResponseFormatError:
                ai_errors.append(
                    "%s: %s" % (mname, ai_eval.public_response_format_message()))
                res = None
            except Exception:
                # Odpověď poskytovatele není důvěryhodná: může obsahovat
                # echo hlaviček nebo jiná tajemství. Zachováme diagnostiku
                # stroje, nikdy však nepředáváme původní text chyby.
                ai_errors.append(
                    "%s: AI služba požadavek nedokončila; zkontrolujte "
                    "nastavení AI, model a připojení." % mname)
                res = None
            else:
                if res is None:
                    ai_errors.append(
                        "%s: pro stroj nejsou k dispozici data měření pro "
                        "AI vyhodnocení." % mname)
            if res:
                problem = res.get("problem", "")
                zaver = res.get("zaver", "")
                doporuceni = res.get("doporuceni", "")
                if (zaver or "").strip() or (doporuceni or "").strip():
                    ai_ok += 1
                else:
                    ai_errors.append(
                        "%s: AI vrátila prázdný závěr — zkuste generování "
                        "zopakovat, případně změnit model." % mname)
        # u verze 3 (vyvažování) předvyplníme témaťovou textaci závěru,
        # když AI nedodala vlastní — aby uživatel měl vždy startovní šablonu
        # (čistota oběžného kola, pokles pásma, stav ložisek).
        if report_version == 3 and not zaver:
            zaver = DEFAULT_CONCLUSION_BALANCE
        rep["problem"] = problem
        rep["zaver"] = zaver
        rep["doporuceni"] = doporuceni
        # volitelné grafy dle výběru
        sels = graph_selections.get(str(mc["id"])) or graph_selections.get(mc["id"]) or []
        rep["graphs"] = collect_machine_graphs(db, rep, sels)
        rep["graph_selections"] = sels
        # předpočet procentuální úspěšnosti vyvážení (per řádek + agregace na stroj)
        # nechceme volat při renderingu; uložíme rovnou do dat, ať se to zobrazuje
        # jak v editoru (frontend), tak v PDF konzistentně.
        max_pct = None
        for r in rep.get("rows", []):
            pct = balance_success_pct(r.get("vel_prev"), r.get("vel_cur"))
            r["balance_success_pct"] = pct
            if pct is not None and (max_pct is None or pct > max_pct):
                max_pct = pct
        rep["balance_success_pct"] = max_pct
        machine_reports.append(rep)

    # termín měření (z dat) — rozsah dat
    date_measured = ""
    if dates:
        d0 = _fmt_date(dates[0])
        d1 = _fmt_date(dates[-1])
        date_measured = d0 if d0 == d1 else (d0 + " – " + d1)

    today = datetime.datetime.now()
    company = company or {}
    # výchozí hlavička/intro dle verze protokolu (u vyvažování je jiný název
    # i úvod, aby uživatel po vytvoření návrhu nemusel přepisovat textace)
    if report_version == 3:
        report_title = "Protokol z vyvažování ventilátoru"
        header_left = "Vyvažování — vibrační diagnostika"
        intro_text = DEFAULT_INTRO_BALANCE
    else:
        report_title = "Zpráva z měření vibrací"
        header_left = "Vibrační diagnostika"
        intro_text = DEFAULT_INTRO
    # SKUTEČNĚ použité normy (dle přiřazení na kartách strojů) + jejich limity.
    # Slouží pro dynamický úvod a přílohu, aby neuváděly natvrdo jednu normu.
    used_norms = collect_used_norms(machine_reports)
    # Do šablony úvodu dosadí skutečnou normu na místo placeholderu {norm}.
    intro_text = _intro_with_norms(intro_text, used_norms)
    doc = {
        "header_left": header_left,
        "company_name": company.get("name", ""),
        "company_address": company.get("address", ""),
        "measured_at": "",
        "report_title": report_title,
        "order_number": "",
        "contract_number": "-",
        "date_created": _fmt_date(today),
        "date_measured": date_measured,
        "created_by": "",
        "measured_by": "",
        "measured_by2": "",
        "approved_by": issuer_approved_by(),
        "intro": intro_text,
        # editovatelný úvodní text přílohy „použité normy“ (prázdné = výchozí
        # text vysázený v report_pdf._used_norms_block)
        "appendix_intro": "",
        "scope_label": scope_label,
        # Uložený scope je závazný i pro tlačítko Aktualizovat. Bez něj by
        # refresh mohl nahradit historickou hodnotu novější hodnotou mimo
        # období, z něhož byl návrh vytvořen.
        "scope": dict(scope or {}),
        "footer": issuer_footer(),
        "report_version": report_version,
        # Kompatibilní výchozí: v detailní šabloně v2 byl sloupec „Minulá“
        # součástí tabulky, ve v1/v3 ne. Frontend/server jej mohou přepsat.
        "show_previous": report_version == 2,
        # Auditovatelné schéma per-direction výběru; jednotlivé ID/časy jsou
        # u strojů v ``measurement_selection[_audit]`` a putují i do historie.
        "measurement_selection_schema": MEASUREMENT_SELECTION_SCHEMA,
        "machines": machine_reports,
        # externí obrázek do přílohy (typicky vektorový diagram z vyvažování)
        # uložený jako data URL (base64). Využívá se pouze u verze 3.
        "appendix_image": "",
        "appendix_image_caption": "",
        # skutečně použité normy + limity (pro přílohu "použité normy")
        "used_norms": used_norms,
    }
    # diagnostika AI závěrů (kolik strojů dostalo závěr, příp. proč ne)
    if ai_fn is not None:
        doc["ai_ok"] = ai_ok
        doc["ai_errors"] = ai_errors
    return doc


def norm_label(iso_norm, name_only=False):
    """Lidský popisek SKUTEČNĚ zadané normy.

    Bere normu z karty stroje (``iso_norm.standard`` – např. "ČSN 20 0065"),
    nikdy ji nenatvrdo nenahrazuje za "ISO 20816".

    - ``name_only=True``  → vrátí jen samotný název normy (např. "ČSN 20 0065")
      bez třídy stroje či dalšího komentáře. Používá se v tabulkách sekce
      "Hodnocení technického stavu".
    - ``name_only=False`` → vrátí název normy doplněný o třídu stroje
      (a případný vlastní text). Používá se v kartě stroje.
    """
    iso_norm = iso_norm or {}
    custom = (iso_norm.get("custom") or "").strip()

    # --- režim VÍCE NOREM dle ložisek (mode=multi) ---
    if iso_norm.get("mode") == "multi":
        assigns = iso_norm.get("assignments") or []
        if name_only:
            seen = []
            for a in assigns:
                s = (a.get("standard") or "").strip()
                if s and s not in seen:
                    seen.append(s)
            return ", ".join(seen) if seen else "—"
        parts = []
        for a in assigns:
            s = (a.get("standard") or "").strip()
            mc = (a.get("machine_class") or "").strip()
            brgs = [str(b).strip().upper() for b in (a.get("bearings") or []) if str(b).strip()]
            if not s or not mc:
                continue
            lbl = "%s - %s" % (s, mc)
            if brgs:
                lbl += " (%s)" % ", ".join(brgs)
            parts.append(lbl)
        if custom:
            parts.append(custom)
        return "; ".join(parts) if parts else "—"

    # --- režim JEDNA NORMA (výchozí / zpětně kompatibilní) ---
    standard = (iso_norm.get("standard") or "").strip()
    # Fallback, pokud u stroje není norma vůbec zadaná.
    if not standard:
        standard = "—"
    if name_only:
        return standard
    parts = [standard]
    mc = (iso_norm.get("machine_class") or "").strip()
    if mc:
        parts.append(mc)
    if custom:
        parts.append(custom)
    return " - ".join(parts) if len(parts) > 1 else parts[0]


def collect_used_norms(machines):
    """Ze seznamu machine-reportů posbírá SKUTEČNĚ použité normy + jejich limity.

    Prochází ``iso_norm`` každého stroje (single i multi režim) a vytvoří
    seznam unikátních dvojic (standard, třída) s limity v mm/s RMS:
        [{"standard", "machine_class", "ab", "warning", "alarm",
          "machines": [...], "bearings": [...]}]
    Limity se čtou z katalogu norem přes ``ai_eval.iso_limits_for_class``.
    Slouží pro úvod a přílohu protokolu, aby odpovídaly tomu, dle čeho byly
    stroje opravdu klasifikovány.
    """
    try:
        import ai_eval
    except Exception:
        ai_eval = None

    order = []
    by_key = {}

    def _add(standard, machine_class, mname, bearings):
        standard = (standard or "").strip()
        machine_class = (machine_class or "").strip()
        if not standard and not machine_class:
            return
        key = (standard, machine_class)
        rec = by_key.get(key)
        if rec is None:
            lim = None
            if ai_eval is not None and machine_class:
                try:
                    lim = ai_eval.iso_limits_for_class(machine_class, standard=standard)
                except Exception:
                    lim = None
            lim = lim or {}
            rec = {
                "standard": standard,
                "machine_class": machine_class,
                "ab": lim.get("ab"),
                "warning": lim.get("warning"),
                "alarm": lim.get("alarm"),
                "machines": [],
                "bearings": [],
            }
            by_key[key] = rec
            order.append(key)
        if mname and mname not in rec["machines"]:
            rec["machines"].append(mname)
        for b in (bearings or []):
            b = str(b).strip().upper()
            if b and b not in rec["bearings"]:
                rec["bearings"].append(b)

    for m in (machines or []):
        iso = m.get("iso_norm") or {}
        mname = m.get("name") or ""
        if iso.get("mode") == "multi":
            for a in (iso.get("assignments") or []):
                _add(a.get("standard"), a.get("machine_class"), mname,
                     a.get("bearings"))
        else:
            _add(iso.get("standard"), iso.get("machine_class"), mname, None)

    return [by_key[k] for k in order]


def _norms_phrase(used_norms):
    """Sestaví textovou zmínku o skutečně použitých normách pro úvod protokolu.

    Vrací např.:
    - jedna norma:  "normy ČSN 20 0065 pro hodnocení stavu průmyslových strojů"
    - více norem:   "norem ČSN 20 0065 a ČSN ISO 20816 pro hodnocení ..."
    - žádná známá:  "platné normy pro hodnocení stavu průmyslových strojů"
    """
    tail = " pro hodnocení stavu průmyslových strojů"
    names = []
    for rec in (used_norms or []):
        s = (rec.get("standard") or "").strip()
        if s and s not in names:
            names.append(s)
    if not names:
        return "platné normy" + tail
    if len(names) == 1:
        return "normy " + names[0] + tail
    joined = ", ".join(names[:-1]) + " a " + names[-1]
    return "norem " + joined + tail


def _intro_with_norms(intro_text, used_norms):
    """Do šablony úvodu dosadí skutečně použité normy na místo ``{norm}``.

    Je-li šablona bez placeholderu (např. uživatel si úvod přepsal ručně),
    vrátí se beze změny – nikdy nepřepisujeme uživatelský text.
    """
    if not intro_text or "{norm}" not in intro_text:
        return intro_text
    return intro_text.replace("{norm}", _norms_phrase(used_norms))
