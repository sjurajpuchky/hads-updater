"""Jednotná, PID-reuse-odolná identita procesu pro HADS.

Windows creation time is intentionally read through ``OpenProcess`` even for
the current process.  Calling GetProcessTimes with the untyped pseudo-handle
returned by GetCurrentProcess can truncate that HANDLE in ctypes on 64bit
Windows.  The resulting false failure used to make the backend persist
``unknown`` while the external helper correctly read ``win-create:<FILETIME>``.
"""
from __future__ import annotations

import ctypes
import os
from pathlib import Path
import re

WINDOWS_IDENTITY_RE = re.compile(r"win-create:[0-9]+\Z")
POSIX_IDENTITY_RE = re.compile(r"proc-start:[0-9]+\Z")

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
SYNCHRONIZE = 0x00100000
WAIT_TIMEOUT = 0x102


def _windows_kernel32():
    """Return kernel32 with every process API explicitly typed."""
    from ctypes import wintypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    # HANDLE is pointer-sized on both x86 and x64.  Do not let ctypes default
    # it to c_int: a 64-bit handle would then be truncated before CloseHandle.
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = (
        wintypes.HANDLE,
        ctypes.POINTER(wintypes.FILETIME),
        ctypes.POINTER(wintypes.FILETIME),
        ctypes.POINTER(wintypes.FILETIME),
        ctypes.POINTER(wintypes.FILETIME),
    )
    kernel.GetProcessTimes.restype = wintypes.BOOL
    kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel.CloseHandle.restype = wintypes.BOOL
    return kernel


def _format_windows_creation_time(created: object) -> str:
    """Return the sole canonical Windows identity representation."""
    value = (int(created.dwHighDateTime) << 32) | int(created.dwLowDateTime)
    return f"win-create:{value}"


def windows_process_state(pid: int) -> tuple[str | None, bool]:
    """Return ``(win-create:<FILETIME>, live)`` for a Windows PID.

    Query failure is deliberately indistinguishable from an unverifiable
    process: callers must reject the dangerous operation rather than invent an
    ``unknown`` identity.
    """
    if pid <= 0:
        return None, False
    from ctypes import wintypes

    kernel = _windows_kernel32()
    handle = kernel.OpenProcess(
        PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, int(pid)
    )
    if not handle:
        return None, False
    try:
        created = wintypes.FILETIME()
        exited = wintypes.FILETIME()
        kernel_time = wintypes.FILETIME()
        user_time = wintypes.FILETIME()
        if not kernel.GetProcessTimes(
            handle,
            ctypes.byref(created),
            ctypes.byref(exited),
            ctypes.byref(kernel_time),
            ctypes.byref(user_time),
        ):
            return None, False
        return _format_windows_creation_time(created), (
            kernel.WaitForSingleObject(handle, 0) == WAIT_TIMEOUT
        )
    finally:
        kernel.CloseHandle(handle)


def process_state(pid: int) -> tuple[str | None, bool]:
    """Return a canonical creation identity and whether that exact PID is live."""
    try:
        if os.name == "nt":
            return windows_process_state(pid)
        fields = Path(f"/proc/{int(pid)}/stat").read_text(encoding="utf-8").split()
        if len(fields) <= 21:
            return None, False
        return f"proc-start:{fields[21]}", fields[2] != "Z"
    except (AttributeError, OSError, ValueError, IndexError):
        return None, False


def process_identity(pid: int) -> str | None:
    """Return a canonical, queryable process identity or ``None`` on failure."""
    return process_state(pid)[0]


def current_process_identity() -> str | None:
    """Query the current process through the same typed path as the helper."""
    return process_identity(os.getpid())


def is_verifiable_identity(identity: object, *, windows: bool | None = None) -> bool:
    """Reject ``unknown`` and any noncanonical identity before sensitive work."""
    if not isinstance(identity, str):
        return False
    is_windows = os.name == "nt" if windows is None else windows
    return bool(
        WINDOWS_IDENTITY_RE.fullmatch(identity)
        if is_windows
        else POSIX_IDENTITY_RE.fullmatch(identity)
    )
