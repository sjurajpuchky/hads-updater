"""Perzistence konfigurace strojů (karty strojů).

Limity i ložiska se vážou na LOŽISKO (ne na jednotlivý směr), aby platily
sdíleně přes všechny směry téhož ložiska (L1H, L1V, L1A → ložisko "L1").

Pro každou databázi (.ndb) a každý stroj (uzel Tbl_Tree Type=2) ukládá POUZE
uživatelské PŘEPISY (override) nad výchozími hodnotami z databáze:

  - limity per ložisko a per veličina (přepis výchozích limitů z DB):
        {"warning": <float|null>, "alarm": <float|null>}
  - přiřazené ložisko per ložisko (skupinu směrů):
        {"designation", "manufacturer", "type", "FTF", "BSF", "BPFO", "BPFI", "rpm_hz"}

Data jsou uložena per-podnik v data/podniky/<slug>/machine_config.json
(dříve jeden sdílený data/machine_config.json klíčovaný <db_filename>).
Soubor obsahuje PŘÍMO strukturu jednoho podniku:
    {
      "<machine_id>": {
        "bearings": {
          "<bearing_key>": {
            "limits": { "<quantity>": {"warning": x, "alarm": y}, ... },
            "bearing": { ... } | null
          }
        }
      },
      "points": { "<point_id>": { ... } }
    }

`bearing_key` je normalizovaný identifikátor ložiska odvozený z názvů měřicích
míst (např. "L1", "L2"). Backend ho počítá v ndb_parser.bearing_key().

Používá POUZE standardní knihovnu Pythonu.
"""

from datetime import datetime, timezone
import re

import data_store

_KIND = data_store.KIND_MACHINE_CONFIG

# Maximální počet uchovávaných záznamů historie detekce otáček (na stroj).
_SPEED_HISTORY_MAX = 5
# Maximální počet uchovávaných záznamů historie AI vyhodnocení (na stroj).
_AI_HISTORY_MAX = 30
# Název veličiny rychlosti vibrací, do které se propisují limity z ISO normy.
ISO_RMS_QUANTITY = "ISO RMS"


def _load_db(db_filename):
    """Načte per-podnik strukturu (slovník machine_id -> {...} + "points")."""
    d = data_store.load(_KIND, db_filename, default={})
    return d if isinstance(d, dict) else {}


def _save_db(db_filename, dbdata):
    """Uloží per-podnik strukturu. Prázdnou strukturu uloží jako {}."""
    data_store.save(_KIND, db_filename, dbdata or {})


def migrate_key(old_key, new_key):
    """Přesune data podniku ze staré složky do nové (deleguje na
    data_store.rename_podnik). Ponecháno kvůli zpětné kompatibilitě API.
    """
    if not old_key or not new_key or old_key == new_key:
        return False
    return data_store.rename_podnik(old_key, new_key)


def get_db_overrides(db_filename):
    """Vrátí všechny přepisy pro danou databázi (slovník machine_id -> {...}).

    Vyloučí služební klíč "points" (ten drží přepisy měřicích bodů).
    """
    db = _load_db(db_filename)
    return {k: v for k, v in db.items() if k != "points"}


def get_machine_overrides(db_filename, machine_id):
    """Vrátí uložené přepisy stroje (nebo prázdnou strukturu).

    Vrací {"bearings": {<bearing_key>: {"limits": {...}, "bearing": {...}|None}},
           "speed_hz": <float|None>,
           "speed_history": [{"time": <ISO>, "value": <float>}, ...],
           "iso_norm": {"standard": <str>, "machine_class": <str>,
                        "custom": <str>} | None,
           "ai_eval": {"text": <str>, "time": <ISO>, "speed_hz": <float>,
                       "norm": <str>, "model": <str>, "edited": <bool>} | None}.
    """
    db = _load_db(db_filename)
    mc = db.get(str(machine_id))
    if not mc:
        return {"bearings": {}, "speed_hz": None, "speed_history": [],
                "iso_norm": None, "ai_eval": None, "ai_eval_history": [],
                "card": None, "ewma": None, "kinematics": None,
                "baseline": None, "sister_machine_id": None}
    if "bearings" not in mc:
        mc["bearings"] = {}
    if "speed_hz" not in mc:
        mc["speed_hz"] = None
    if "speed_history" not in mc:
        mc["speed_history"] = []
    if "iso_norm" not in mc:
        mc["iso_norm"] = None
    if "ai_eval" not in mc:
        mc["ai_eval"] = None
    if "ai_eval_history" not in mc:
        mc["ai_eval_history"] = []
    if "card" not in mc:
        mc["card"] = None
    if "ewma" not in mc:
        mc["ewma"] = None
    if "kinematics" not in mc:
        mc["kinematics"] = None
    if "baseline" not in mc:
        mc["baseline"] = None
    if "sister_machine_id" not in mc:
        mc["sister_machine_id"] = None
    return mc


def _sanitize_speed_history(raw):
    """Očistí seznam historie detekcí na [{"time": <ISO str>, "value": <float>}].

    Zachová max. _SPEED_HISTORY_MAX nejnovějších záznamů (nejnovější první).
    """
    out = []
    for rec in (raw or []):
        rec = rec or {}
        val = _to_float_or_none(rec.get("value"))
        if val is None or val <= 0:
            continue
        t = rec.get("time")
        t = str(t) if t else ""
        out.append({"time": t, "value": val})
    return out[:_SPEED_HISTORY_MAX]


def append_speed_detection(db_filename, machine_id, value, when=None):
    """Přidá záznam detekce otáček do historie stroje a uloží jej.

    Historie je seznam {"time": <ISO>, "value": <float>} (nejnovější první),
    omezený na _SPEED_HISTORY_MAX záznamů. Nemění aktuálně nastavené otáčky
    (speed_hz) ani ostatní přepisy. Vrací aktualizovaný seznam historie.
    """
    val = _to_float_or_none(value)
    if val is None or val <= 0:
        return get_machine_overrides(db_filename, machine_id).get("speed_history", [])
    if when is None:
        when = datetime.now(timezone.utc).astimezone().replace(microsecond=0).isoformat()

    db = _load_db(db_filename)
    mck = str(machine_id)
    mc = db.get(mck) or {"bearings": {}, "speed_hz": None}
    history = _sanitize_speed_history(mc.get("speed_history"))
    history.insert(0, {"time": when, "value": val})
    mc["speed_history"] = history[:_SPEED_HISTORY_MAX]
    if "bearings" not in mc:
        mc["bearings"] = {}
    db[mck] = mc
    _save_db(db_filename, db)
    return mc["speed_history"]


def save_machine_overrides(db_filename, machine_id, config):
    """Uloží přepisy stroje. Vrátí uloženou (očištěnou) strukturu.

    Historie detekcí otáček (speed_history) a výsledek AI vyhodnocení (ai_eval)
    se zachovávají – frontend je při ukládání karty neposílá, vedou se nezávisle.
    Norma (iso_norm) se ukládá spolu s konfigurací karty.
    """
    db = _load_db(db_filename)
    mck = str(machine_id)
    # zachovej existující historii detekcí a AI vyhodnocení (nejsou součástí
    # odeslané konfigurace karty)
    prev = db.get(mck) or {}
    history = _sanitize_speed_history(prev.get("speed_history"))
    prev_ai = prev.get("ai_eval")
    prev_ai_hist = _sanitize_ai_history(prev.get("ai_eval_history"))
    cleaned = _sanitize_config(config)
    if history:
        cleaned["speed_history"] = history
    if prev_ai:
        cleaned["ai_eval"] = prev_ai
    if prev_ai_hist:
        cleaned["ai_eval_history"] = prev_ai_hist
    # automaticky a vždy: pokud je nastavena norma s třídou stroje, propíšou se
    # limity rychlosti vibrací do veličiny ISO RMS u každého ložiska
    cleaned = _apply_iso_limits(cleaned)
    has_norm = cleaned.get("iso_norm") is not None
    has_card = cleaned.get("card") is not None
    has_ewma = cleaned.get("ewma") is not None
    has_kinematics = cleaned.get("kinematics") is not None
    has_reference = (cleaned.get("baseline") is not None
                     or cleaned.get("sister_machine_id") is not None)
    if (cleaned["bearings"] or cleaned.get("speed_hz") is not None
            or history or has_norm or has_card or has_ewma or has_kinematics
            or has_reference or prev_ai or prev_ai_hist):
        db[mck] = cleaned
    else:
        # nic k uložení → odstraň prázdný záznam
        db.pop(mck, None)
    _save_db(db_filename, db)
    return cleaned


def save_ai_eval(db_filename, machine_id, eval_obj):
    """Uloží výsledek AI vyhodnocení stroje (ai_eval) a vrátí jej.

    `eval_obj` = {"text": <str>, "time": <ISO>, "speed_hz": <float|None>,
                  "norm": <str>, "model": <str>, "edited": <bool>}.
    Nemění ostatní přepisy (limity, ložiska, otáčky, historie, norma).
    """
    db = _load_db(db_filename)
    mck = str(machine_id)
    mc = db.get(mck) or {"bearings": {}, "speed_hz": None}
    if "bearings" not in mc:
        mc["bearings"] = {}
    clean = _sanitize_ai_eval(eval_obj)
    mc["ai_eval"] = clean
    # automatické ukládání do historie (nejnovější první), perzistentní
    hist = _sanitize_ai_history(mc.get("ai_eval_history"))
    hist.insert(0, clean)
    mc["ai_eval_history"] = hist[:_AI_HISTORY_MAX]
    db[mck] = mc
    _save_db(db_filename, db)
    return clean


def _sanitize_ai_eval(raw):
    """Očistí objekt AI vyhodnocení na očekávanou strukturu."""
    raw = raw or {}
    text = str(raw.get("text", "") or "").strip()
    when = raw.get("time")
    if not when:
        when = datetime.now(timezone.utc).astimezone().replace(
            microsecond=0).isoformat()
    return {
        "text": text,
        "time": str(when),
        "speed_hz": _to_float_or_none(raw.get("speed_hz")),
        "norm": str(raw.get("norm", "") or "").strip(),
        "model": str(raw.get("model", "") or "").strip(),
        "edited": bool(raw.get("edited", False)),
    }


def _sanitize_ai_history(raw):
    """Očistí seznam historie AI vyhodnocení (nejnovější první, max _AI_HISTORY_MAX)."""
    out = []
    for rec in (raw or []):
        if not rec:
            continue
        clean = _sanitize_ai_eval(rec)
        if clean.get("text"):
            out.append(clean)
    return out[:_AI_HISTORY_MAX]


def set_active_ai_eval(db_filename, machine_id, index):
    """Nastaví aktuální (zobrazené) AI vyhodnocení podle indexu v historii.

    Slouží ke zpětnému vyvolání staršího vyhodnocení. Vrací zvolený záznam,
    nebo None, pokud index neexistuje.
    """
    db = _load_db(db_filename)
    mck = str(machine_id)
    mc = db.get(mck)
    if not mc:
        return None
    hist = _sanitize_ai_history(mc.get("ai_eval_history"))
    try:
        idx = int(index)
    except (TypeError, ValueError):
        return None
    if idx < 0 or idx >= len(hist):
        return None
    chosen = hist[idx]
    mc["ai_eval"] = chosen
    mc["ai_eval_history"] = hist
    db[mck] = mc
    _save_db(db_filename, db)
    return chosen


def _apply_iso_limits(cleaned):
    """Propíše limity z ISO normy do veličiny ISO RMS u každého ložiska.

    Mapování (dle ai_eval.iso_limits_for_class): B/C -> warning, C/D -> alarm.
    Provádí se automaticky vždy, když je nastavena třída stroje. Přepíše
    případné ruční limity pro ISO RMS, ostatní veličiny ponechá beze změny.
    """
    iso_norm = cleaned.get("iso_norm")
    if not iso_norm:
        return cleaned
    try:
        import ai_eval
    except Exception:
        return cleaned
    bearings = cleaned.setdefault("bearings", {})
    # Ložiska uvedená v přiřazeních norem musí ve konfiguraci existovat, i když
    # na nich uživatel nemá žádný ruční limit – jinak by se propis limitů normy
    # do ISO RMS vůbec neuložil (stroj bez ručních limitů = prázdný `bearings`).
    for a in (iso_norm.get("assignments") or []):
        if not isinstance(a, dict):
            continue
        for b in (a.get("bearings") or []):
            bk = str(b or "").strip().upper()
            if bk and bk not in bearings:
                bearings[bk] = {"limits": {}, "bearing": None}
    # Propíšeme limity ISO RMS do každého ložiska. V režimu více norem se
    # limity vybírají podle konkrétního ložiska (bkey); ložisko, které nespadá
    # pod žádné přiřazení, dostane limit ISO RMS odebrán (klasifikuje se z DB).
    for bkey, bcfg in list(bearings.items()):
        bcfg = bcfg or {}
        try:
            lim = ai_eval.iso_limits_from_norm(iso_norm, bearing_key=bkey)
        except Exception:
            lim = None
        limits = bcfg.setdefault("limits", {})
        if lim:
            limits[ISO_RMS_QUANTITY] = {
                "warning": lim["warning"],
                "alarm": lim["alarm"],
                "ab": lim.get("ab"),
            }
        else:
            # bez přiřazení normy pro toto ložisko odstraníme dříve propísaný
            # limit ISO RMS, aby nezůstal viset starý (z jiného režimu/normy)
            limits.pop(ISO_RMS_QUANTITY, None)
        bcfg.setdefault("bearing", bcfg.get("bearing"))
        if not limits and not bcfg.get("bearing") and "classify" not in bcfg:
            bearings.pop(bkey, None)   # nezůstane prázdný záznam ložiska
        else:
            bearings[bkey] = bcfg
    return cleaned


def _sanitize_assignments(raw):
    """Očistí seznam přiřazení norem ložiskům (režim více norem).

    Každé přiřazení: {"standard": <str>, "machine_class": <str>,
    "bearings": [<klíč ložiska>, ...]}. Zahodí přiřazení bez třídy nebo
    bez ložisek. Klíče ložisek se normalizují na velká písmena a deduplikují.

    Skupiny ložisek jsou vždy DISJUNKTNÍ: pokud uživatel zaškrtne totéž
    ložisko ve dvou přiřazeních, zůstane jen v prvním. Uložený model je tak
    jednoznačný a výsledná pásma nezávisí na pořadí přiřazení.
    """
    out = []
    used = set()
    for a in (raw or []):
        if not isinstance(a, dict):
            continue
        std = str(a.get("standard", "") or "").strip()
        cls = str(a.get("machine_class", "") or "").strip()
        bearings = []
        seen = set()
        for b in (a.get("bearings") or []):
            bk = str(b or "").strip().upper()
            if bk and bk not in seen and bk not in used:
                seen.add(bk)
                bearings.append(bk)
        if not cls or not bearings:
            continue
        used.update(bearings)
        out.append({"standard": std, "machine_class": cls, "bearings": bearings})
    return out


def _sanitize_iso_norm(raw):
    """Očistí nastavení normy stroje, nebo vrátí None, pokud není zadána.

    Struktura (jedna norma pro celý stroj):
        {"standard": <str>, "machine_class": <str>, "custom": <str>,
         "mode": "single"}
    Struktura (více norem dle ložisek):
        {"mode": "multi", "custom": <str>,
         "assignments": [{"standard", "machine_class", "bearings": [...]}, ...]}

    Zpětně kompatibilní: chybějící `mode` = "single".
    """
    raw = raw or {}
    mode = str(raw.get("mode", "") or "").strip().lower()
    custom = str(raw.get("custom", "") or "").strip()
    if mode == "multi":
        assignments = _sanitize_assignments(raw.get("assignments"))
        if not assignments and not custom:
            return None
        return {
            "mode": "multi",
            "assignments": assignments,
            "custom": custom,
        }
    standard = str(raw.get("standard", "") or "").strip()
    machine_class = str(raw.get("machine_class", "") or "").strip()
    if not (standard or machine_class or custom):
        return None
    return {
        "mode": "single",
        "standard": standard,
        "machine_class": machine_class,
        "custom": custom,
    }


def _to_float_or_none(v):
    if v is None or v == "":
        return None
    try:
        f = float(v)
        if f != f:  # NaN
            return None
        return f
    except (TypeError, ValueError):
        return None


def _sanitize_card(raw):
    """Očistí rozšířená pole karty stroje pro protokol (nebo None, je-li vše prázdné).

    Struktura: {"drive_no", "tech_location", "power_kw", "rpm",
    "impeller_diameter", "description", "image"}.
    `image` je datová URL (data:image/...;base64,...) nebo prázdné.
    """
    raw = raw or {}
    drive_no = str(raw.get("drive_no", "") or "").strip()[:120]
    tech_location = str(raw.get("tech_location", "") or "").strip()[:200]
    power_kw = str(raw.get("power_kw", "") or "").strip()[:60]
    rpm = str(raw.get("rpm", "") or "").strip()[:60]
    impeller_diameter = str(raw.get("impeller_diameter", "") or "").strip()[:60]
    description = str(raw.get("description", "") or "").strip()[:2000]
    image = str(raw.get("image", "") or "").strip()
    # bezpečnostní strop velikosti obrázku (~3 MB datové URL)
    if image and not image.startswith("data:image/"):
        image = ""
    if len(image) > 4_200_000:
        image = ""
    card = {
        "drive_no": drive_no,
        "tech_location": tech_location,
        "power_kw": power_kw,
        "rpm": rpm,
        "impeller_diameter": impeller_diameter,
        "description": description,
        "image": image,
    }
    if any(v for v in card.values()):
        return card
    return None


def _to_int_in_range(value, low, high):
    """Celé číslo v rozsahu, jinak None. Prázdné pole = neznámý údaj."""
    if value is None or value == "":
        return None
    try:
        number = int(round(float(str(value).replace(",", "."))))
    except (TypeError, ValueError):
        return None
    return number if low <= number <= high else None


def _to_float_in_range(value, low, high):
    number = _to_float_or_none(str(value).replace(",", ".") if value not in (None, "") else None)
    if number is None:
        return None
    return number if low <= number <= high else None


# Rozsahy jsou volné, ale odmítnou zjevný překlep (např. 5000 lopatek).
KINEMATICS_LIMITS = {
    "blade_count": (2, 60),        # lopatky ventilátoru / čerpadla
    "pole_count": (2, 24),         # počet pólů asynchronního motoru
    "gear_teeth_driver": (5, 400),
    "gear_teeth_driven": (5, 400),
}
DRIVE_TYPES = ("", "spojka", "řemen", "ozubení", "přímé")


def _sanitize_kinematics(raw):
    """Očistí kinematické údaje stroje (nebo None, není-li vyplněno nic).

    Tato pole odemykají výpočet kinematických frekvencí, které z pouhého
    spektra odhadnout nelze: BPF z počtu lopatek, GMF z počtu zubů,
    F_L / 2F_L / F_P z počtu pólů a řemenové frekvence z rozměrů převodu.
    Vše je VOLITELNÉ — bez těchto údajů zůstane HADS u odhadu ze spektra.
    """
    raw = raw or {}
    out = {}
    for key, (low, high) in KINEMATICS_LIMITS.items():
        value = _to_int_in_range(raw.get(key), low, high)
        if value is not None:
            out[key] = value
    # Síťová frekvence: v ČR 50 Hz, ale export do zahraničí připouští 60 Hz.
    line_freq = _to_float_in_range(raw.get("line_freq_hz"), 40.0, 70.0)
    if line_freq is not None:
        out["line_freq_hz"] = line_freq
    for key in ("belt_length_mm", "pulley_driver_mm", "pulley_driven_mm"):
        value = _to_float_in_range(raw.get(key), 1.0, 100000.0)
        if value is not None:
            out[key] = value
    drive = str(raw.get("drive_type", "") or "").strip().lower()
    if drive in DRIVE_TYPES and drive:
        out["drive_type"] = drive
    return out or None


def _sanitize_baseline(raw):
    """Očistí referenční (baseline) měření stroje.

    Ukládá se pouze ČAS známého dobrého stavu, nikoli opsané hodnoty: samotná
    data zůstávají v `.ndb`, takže se baseline nikdy nerozejde se skutečným
    měřením a nezabírá místo. Metodologie staví porovnání proti baseline nad
    hodnocení podle normy.
    """
    raw = raw or {}
    time = str(raw.get("time", "") or "").strip()[:40]
    # Očekává se ISO datum (YYYY-MM-DD) nebo plné ISO datum a čas.
    if not re.match(r"^\d{4}-\d{2}-\d{2}([T ].*)?$", time):
        return None
    note = str(raw.get("note", "") or "").strip()[:200]
    return {"time": time, "note": note}


def _sanitize_sister(raw):
    """ID sesterského stroje pro porovnání za srovnatelných podmínek."""
    if raw is None or raw == "":
        return None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def _sanitize_config(config):
    """Očistí příchozí konfiguraci na očekávanou strukturu (override-only).

    Ukládají se pouze limity, které se LIŠÍ od ničeho (tj. jsou vyplněné);
    frontend posílá jen skutečné přepisy. Prázdné se ignorují.
    """
    out = {"bearings": {}, "speed_hz": None, "iso_norm": None, "card": None,
           "ewma": None, "kinematics": None, "baseline": None,
           "sister_machine_id": None}
    # otáčky stroje (na celý stroj, sdíleně pro všechna měřicí místa)
    speed = _to_float_or_none((config or {}).get("speed_hz"))
    if speed is not None and speed > 0:
        out["speed_hz"] = speed
    # norma pro hodnocení rychlosti vibrací (na celý stroj)
    out["iso_norm"] = _sanitize_iso_norm((config or {}).get("iso_norm"))
    # parametry adaptivních limitů EWMA (na celý stroj)
    out["ewma"] = _sanitize_ewma((config or {}).get("ewma"))
    # rozšířená pole karty stroje (pro protokol)
    out["card"] = _sanitize_card((config or {}).get("card"))
    # kinematické údaje pro výpočet BPF, GMF, F_P a řemenových frekvencí
    out["kinematics"] = _sanitize_kinematics((config or {}).get("kinematics"))
    # opory hodnocení, které metodologie staví nad normu (E.1)
    out["baseline"] = _sanitize_baseline((config or {}).get("baseline"))
    out["sister_machine_id"] = _sanitize_sister(
        (config or {}).get("sister_machine_id"))
    bearings = (config or {}).get("bearings", {}) or {}
    for bkey, bcfg in bearings.items():
        bcfg = bcfg or {}
        clean = {"limits": {}, "bearing": None}

        # příznak "klasifikovat stav dle limitů" pro celé ložisko (výchozí True).
        # Ukládá se pouze tehdy, je-li vypnut (False) — True je výchozí stav.
        b_classify = bcfg.get("classify")
        if b_classify is False:
            clean["classify"] = False

        limits = bcfg.get("limits", {}) or {}
        for quantity, lim in limits.items():
            lim = lim or {}
            warning = _to_float_or_none(lim.get("warning"))
            alarm = _to_float_or_none(lim.get("alarm"))
            # hranice A/B (volitelná, z norem se třemi mezemi) – zachováme ji
            ab = _to_float_or_none(lim.get("ab"))
            # per-veličina příznak klasifikace (výchozí True); ukládá se,
            # je-li vypnut, i když veličina nemá vlastní limity.
            q_classify = lim.get("classify")
            q_off = (q_classify is False)
            if warning is None and alarm is None and not q_off:
                continue
            entry = {
                "warning": warning,
                "alarm": alarm,
            }
            if ab is not None:
                entry["ab"] = ab
            if q_off:
                entry["classify"] = False
            clean["limits"][str(quantity)] = entry

        bearing = bcfg.get("bearing")
        if bearing:
            b = {
                "designation": str(bearing.get("designation", "")).strip(),
                "manufacturer": str(bearing.get("manufacturer", "") or "").strip(),
                "type": str(bearing.get("type", "") or "").strip(),
                "FTF": _to_float_or_none(bearing.get("FTF")),
                "BSF": _to_float_or_none(bearing.get("BSF")),
                "BPFO": _to_float_or_none(bearing.get("BPFO")),
                "BPFI": _to_float_or_none(bearing.get("BPFI")),
                "rpm_hz": _to_float_or_none(bearing.get("rpm_hz")),
            }
            if (
                b["designation"]
                or b["FTF"] is not None
                or b["BSF"] is not None
                or b["BPFO"] is not None
                or b["BPFI"] is not None
            ):
                clean["bearing"] = b

        if clean["limits"] or clean["bearing"] or ("classify" in clean):
            out["bearings"][str(bkey)] = clean
    return out


def _sanitize_ewma(raw):
    """Očistí parametry adaptivních limitů EWMA na celý stroj.

    Vrací {"enabled": bool, "lambda": float, "l_warn": float,
           "l_alarm": float, "min_n": int} nebo None, pokud nic nepřišlo.
    """
    if not isinstance(raw, dict):
        return None
    out = {}
    if "enabled" in raw and raw.get("enabled") is not None:
        out["enabled"] = bool(raw.get("enabled"))
    lam = _to_float_or_none(raw.get("lambda"))
    if lam is not None and 0.0 < lam <= 1.0:
        out["lambda"] = lam
    lw = _to_float_or_none(raw.get("l_warn"))
    if lw is not None and lw > 0:
        out["l_warn"] = lw
    la = _to_float_or_none(raw.get("l_alarm"))
    if la is not None and la > 0:
        out["l_alarm"] = la
    mn = _to_float_or_none(raw.get("min_n"))
    if mn is not None and mn >= 2:
        out["min_n"] = int(mn)
    return out or None


# ============================================================================
# AI vyhodnocení a otáčky na úrovni MĚŘICÍHO BODU
# ----------------------------------------------------------------------------
# Ukládá se odděleně od karet strojů, pod vyhrazený klíč "points" v rámci
# záznamu databáze:
#   <per-podnik db>["points"][<point_id>] = {
#       "speed_hz": <float|None>,
#       "speed_history": [{"time": <ISO>, "value": <float>}, ...],
#       "ai_eval": {...} | None,
#       "ai_eval_history": [ {...}, ... ],
#   }
# ============================================================================

def get_point_overrides(db_filename, point_id):
    """Vrátí uložené přepisy měřicího bodu (nebo prázdnou strukturu).

    Vrací {"speed_hz": <float|None>,
           "speed_history": [{"time": <ISO>, "value": <float>}, ...],
           "ai_eval": {...} | None,
           "ai_eval_history": [ {...}, ... ]}.
    """
    db = _load_db(db_filename)
    points = db.get("points", {}) or {}
    pc = points.get(str(point_id))
    if not pc:
        return {"speed_hz": None, "speed_history": [],
                "ai_eval": None, "ai_eval_history": []}
    return {
        "speed_hz": _to_float_or_none(pc.get("speed_hz")),
        "speed_history": _sanitize_speed_history(pc.get("speed_history")),
        "ai_eval": _sanitize_ai_eval(pc["ai_eval"]) if pc.get("ai_eval") else None,
        "ai_eval_history": _sanitize_ai_history(pc.get("ai_eval_history")),
    }


def _get_point_record(db, point_id):
    """Vrátí (a v případě potřeby založí) záznam bodu uvnitř per-podnik `db`."""
    pid = str(point_id)
    if "points" not in db or not isinstance(db["points"], dict):
        db["points"] = {}
    pc = db["points"].get(pid)
    if not pc:
        pc = {"speed_hz": None, "speed_history": [],
              "ai_eval": None, "ai_eval_history": []}
        db["points"][pid] = pc
    return pc


def append_point_speed_detection(db_filename, point_id, value, when=None):
    """Přidá záznam detekce otáček do historie bodu a uloží jej.

    Historie je seznam {"time": <ISO>, "value": <float>} (nejnovější první),
    omezený na _SPEED_HISTORY_MAX záznamů. Vrací aktualizovaný seznam historie.
    """
    val = _to_float_or_none(value)
    if val is None or val <= 0:
        return get_point_overrides(db_filename, point_id).get("speed_history", [])
    if when is None:
        when = datetime.now(timezone.utc).astimezone().replace(microsecond=0).isoformat()

    db = _load_db(db_filename)
    pc = _get_point_record(db, point_id)
    history = _sanitize_speed_history(pc.get("speed_history"))
    history.insert(0, {"time": when, "value": val})
    pc["speed_history"] = history[:_SPEED_HISTORY_MAX]
    _save_db(db_filename, db)
    return pc["speed_history"]


def save_point_ai_eval(db_filename, point_id, eval_obj):
    """Uloží výsledek AI vyhodnocení bodu (ai_eval) a vrátí jej.

    `eval_obj` = {"text", "time", "speed_hz", "norm", "model", "edited"}.
    Automaticky vkládá do historie (nejnovější první, max _AI_HISTORY_MAX).
    """
    db = _load_db(db_filename)
    pc = _get_point_record(db, point_id)
    clean = _sanitize_ai_eval(eval_obj)
    pc["ai_eval"] = clean
    hist = _sanitize_ai_history(pc.get("ai_eval_history"))
    hist.insert(0, clean)
    pc["ai_eval_history"] = hist[:_AI_HISTORY_MAX]
    _save_db(db_filename, db)
    return clean


def set_active_point_ai_eval(db_filename, point_id, index):
    """Nastaví aktuální (zobrazené) AI vyhodnocení bodu podle indexu v historii.

    Vrací zvolený záznam, nebo None, pokud index neexistuje.
    """
    db = _load_db(db_filename)
    pid = str(point_id)
    pc = (db.get("points") or {}).get(pid)
    if not pc:
        return None
    hist = _sanitize_ai_history(pc.get("ai_eval_history"))
    try:
        idx = int(index)
    except (TypeError, ValueError):
        return None
    if idx < 0 or idx >= len(hist):
        return None
    chosen = hist[idx]
    pc["ai_eval"] = chosen
    pc["ai_eval_history"] = hist
    db["points"][pid] = pc
    _save_db(db_filename, db)
    return chosen
