"""
Parser pro databázové soubory měřicí přístroj (.ndb).

Soubor .ndb je SQLite databáze (UTF-16 schema) s těmito klíčovými tabulkami:
  - Tbl_Tree         : hierarchie závod / stroj / měřicí bod (Parent, Type 1/2/3)
  - Tbl_Cell         : definice měření (DataType určuje typ)
  - Tbl_Cell_Stats   : statická data (trendy skalárních hodnot, RMS apod.)
  - Tbl_Cell_Dyns    : dynamická data (FFT spektra, časové signály)
  - Tbl_Severity     : úrovně závažnosti (Ok / Varování / Výstraha / Ohrožení)

Formáty BLOBů (rozluštěno reverzní analýzou):
  - Vše je zlib-komprimováno; zlib hlavička (0x78 0x01) začíná po krátké
    nekomprimované hlavičce uvnitř BLOBu.
  - Statický záznam: po dekompresi pole 64-bajtových záznamů:
        offset 0  : int64  čas (.NET ticks, 100 ns od roku 1)
        offset 16 : double hodnota
  - Dynamický záznam: po dekompresi pole 9-bajtových záznamů:
        offset 0  : float32 amplituda
        offset 4  : 5 bajtů (rezerva / příznaky, obvykle nuly)
    Počet bodů = DataLength, krok osy = DataStep — u spektra v Hz, u časového
    signálu v MILISEKUNDÁCH (viz převod v `dynamic()`; typicky 0,0153 ms, tedy
    vzorkování 65 536 Hz na 65 536 bodů = 1 s záznamu).

DataType v Tbl_Cell:
  1, 2 -> statická skalární hodnota (trend)  -> Tbl_Cell_Stats
  7, 8 -> spektrum (FFT)                       -> Tbl_Cell_Dyns
  9    -> časový signál                        -> Tbl_Cell_Dyns
"""

import sqlite3
import struct
import zlib
import datetime
import math
import re
import unicodedata
import hashlib
import json
from typing import Optional

import fft_analysis

# Epocha metadat (sloupce Time/LastMeasured): milisekundy od 1.1.2000
_EPOCH_2000 = datetime.datetime(2000, 1, 1)

# DataType -> kategorie
STATIC_DATATYPES = {1, 2}
SPECTRUM_DATATYPES = {7, 8}
TIME_DATATYPES = {9}


def _quantity_unit(name: Optional[str]) -> Optional[str]:
    """Odhadne jednotku statické veličiny podle jejího názvu (pro AI prompt).

    HADS/ISO veličiny: rychlost vibrací (ISO/VEL RMS) = mm/s, zrychlení
    (ACC RMS/peak) = g, obálka (ENV/BEARING) = gE, výchylka (DISP) = µm.
    """
    if not name:
        return None
    u = name.upper()
    if "ENV" in u or "BEARING" in u or "ENVELOPE" in u:
        return "gE"
    if "ACC" in u or "ZRYCHL" in u:
        return "g"
    if "DISP" in u or "VÚCHYL" in u or "VYCHYL" in u:
        return "µm"
    if "ISO" in u or "VEL" in u or "RYCHL" in u or "RMS" in u:
        return "mm/s"
    return None


# výchozí parametry adaptivních limitů EWMA (společné pro stroj)
EWMA_DEFAULTS = {
    "enabled": True,
    "lambda": 0.2,      # rychlost adaptace (0–1); nižší = pomalejší
    "l_warn": 3.0,      # násobitel směrodatné odchylky pro Varování
    "l_alarm": 4.0,     # násobitel směrodatné odchylky pro Alarm
    "min_n": 8,         # min. počet měření pro výpočet
}


def is_velocity_quantity(name: Optional[str]) -> bool:
    """Rozpozná, zda jde o rychlost vibrací (mm/s) – ta se z EWMA vylučuje,
    protože její limity řeší norma ČSN ISO 20816 („ISO RMS“ / „VEL“ apod.).
    """
    if not name:
        return False
    u = name.upper()
    return ("ISO" in u) or ("VEL" in u) or ("RYCHL" in u)


def ewma_limits(values, lam=0.2, l_warn=3.0, l_alarm=4.0, min_n=8):
    """Spočítá adaptivní limity z časové řady metodou EWMA.

    Používá exponenciálně vážený klouzavý průměr S_t a exponenciálně váženou
    odhad rozptylu (směrodatná odchylka sigma_t). Limit = S_t + L * sigma_t.

    Vrací slovník:
      {"n": počet platných hodnot, "mean": S_t, "sigma": sigma_t,
       "warning": S_t + l_warn*sigma_t, "alarm": S_t + l_alarm*sigma_t}
    nebo None, pokud není dost dat (< min_n).
    """
    if not values:
        return None
    # ponech jen konečná nezáporná čísla
    xs = []
    for v in values:
        if v is None:
            continue
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isfinite(f):
            xs.append(f)
    n = len(xs)
    if n < max(2, int(min_n or 0)):
        return None
    try:
        lam = float(lam)
    except (TypeError, ValueError):
        lam = 0.2
    if not (0.0 < lam <= 1.0):
        lam = 0.2

    s = xs[0]            # vyhlazená střední hodnota
    var = 0.0            # vyhlazený rozptyl
    for x in xs[1:]:
        diff = x - s
        s = s + lam * diff
        # EWMA rozptylu (de Haan / incremental): v_t = (1-lam)*(v_{t-1}+lam*diff^2)
        var = (1.0 - lam) * (var + lam * diff * diff)
    sigma = math.sqrt(var) if var > 0 else 0.0

    try:
        lw = float(l_warn)
    except (TypeError, ValueError):
        lw = 3.0
    try:
        la = float(l_alarm)
    except (TypeError, ValueError):
        la = 4.0

    return {
        "n": n,
        "mean": s,
        "sigma": sigma,
        "warning": s + lw * sigma,
        "alarm": s + la * sigma,
    }


def ms2000_to_dt(ms: Optional[int]) -> Optional[datetime.datetime]:
    """Převede metadatový timestamp (ms od 2000) na datetime."""
    if ms is None:
        return None
    try:
        return _EPOCH_2000 + datetime.timedelta(milliseconds=ms)
    except (OverflowError, OSError, ValueError):
        return None


def ms2000_to_iso(ms: Optional[int]) -> Optional[str]:
    dt = ms2000_to_dt(ms)
    return dt.isoformat() if dt else None


def _dx_hex_to_double(h: Optional[str]) -> Optional[float]:
    """Převede HADS hex zápis double (např. 'DX0000000000001240') na float.

    HADS ukládá čísla v limitním XML jako little-endian hex 64bit double
    s prefixem 'DX'.
    """
    if not h:
        return None
    h = h.strip()
    if h.startswith("DX"):
        h = h[2:]
    if len(h) != 16:
        return None
    try:
        val = struct.unpack("<d", bytes.fromhex(h))[0]
        if not math.isfinite(val):
            return None
        return val
    except Exception:
        return None


def parse_cell_limits(limits_xml: Optional[str]):
    """Dekóduje limity ze sloupce Tbl_Cell.Limits (XML).

    Vrací slovník:
        {
          "warning": <float|None>,   # práh Varování (severity 2) = hranice C
          "alert":   <float|None>,   # práh Výstraha (severity 3)
          "danger":  <float|None>,   # práh Ohrožení (severity 4) = hranice D
          "levels":  [(threshold, severity_id), ...],  # surová data
        }
    nebo None, pokud limity nejsou definovány.

    Formát HADS: blok <limits> obsahuje seznam <SDS_DOUBLE><dVal> prahů a
    blok <alarmId> seznam <SDS_INT><iVal> id závažnosti. Pole alarmId bývá
    o jeden delší (první prvek je výchozí stav pod prvním prahem, obvykle 1=Ok),
    proto prahy párujeme se závažností následující za daným prahem.

    Záložní heuristika (chybí/nesedí-li alarmId), platná pro DDS statické
    objekty (BEARING RMS, ACC RMS, ENV RMS apod.): pásma C a D vždy určují
    DVĚ NEJVYŠŠÍ PLATNÉ limitní hodnoty (mez C/D = nejvyšší, mez B/C = druhá
    nejvyšší), bez ohledu na to, kolik platných prahů veličina celkem má a
    v jakém pořadí/kolikrát se opakují v XML. Duplicitní a neplatné
    (None/NaN/Inf) hodnoty se před výběrem odstraní. Např. u BEARING RMS se
    3 prahy [0.4, 0.8, 1.2] je C=0.8 (2. nejvyšší) a D=1.2 (nejvyšší); nižší
    hodnoty (odhad hranice A/B) se do dvoumezního schématu (Varování/Alarm)
    nepromítají. Při přesně 2 platných prazích je mapování stejné jako dřív:
    C = nižší z obou, D = vyšší z obou. Norma ISO 20816 (přiřazená na kartě
    stroje) tuto heuristiku nikdy nepoužívá – její meze (ab/warning/alarm) se
    čtou přímo z katalogu norem v ai_eval.py a mají vždy přednost.
    """
    if not limits_xml:
        return None
    # Vyhledáme hlavní blok <limits>...</limits> (prahy) a <alarmId>...</alarmId>
    lim_block = re.search(r"<limits>(.*?)</limits>", limits_xml, re.S)
    alarm_block = re.search(r"<alarmId>(.*?)</alarmId>", limits_xml, re.S)
    if not lim_block:
        return None
    dvals = re.findall(r"<dVal>(.*?)</dVal>", lim_block.group(1), re.S)
    thresholds = [_dx_hex_to_double(d) for d in dvals]
    thresholds = [t for t in thresholds if t is not None]
    if not thresholds:
        return None
    sev_ids = []
    if alarm_block:
        ivals = re.findall(r"<iVal>(.*?)</iVal>", alarm_block.group(1), re.S)
        for v in ivals:
            try:
                sev_ids.append(int(v.strip()))
            except (TypeError, ValueError):
                pass

    # Spárování prahu se závažností NAD tímto prahem.
    # alarmId má obvykle len(thresholds)+1 prvků: [stav_pod_1, sev_po_prahu1, ...]
    levels = []
    for i, th in enumerate(thresholds):
        sev = None
        # severita platná nad i-tým prahem = sev_ids[i+1]
        if i + 1 < len(sev_ids):
            sev = sev_ids[i + 1]
        levels.append((th, sev))

    def _by_sev(target):
        cands = [th for th, sev in levels if sev == target]
        return min(cands) if cands else None

    warning = _by_sev(2)
    alert = _by_sev(3)
    danger = _by_sev(4)

    # Záložní heuristika, když alarmId chybí nebo nesedí s žádnou závažností
    # 2/3/4: pásma C/D určíme jen z platných hodnot prahů, bez ohledu na
    # pořadí/duplicity v XML - vezmeme DVĚ NEJVYŠŠÍ ODLIŠNÉ hodnoty.
    if warning is None and alert is None and danger is None:
        # odstraň neplatné (None/NaN/Inf) a duplicitní hodnoty, seřaď vzestupně
        valid_unique = sorted({
            t for t in thresholds
            if t is not None and math.isfinite(t)
        })
        if len(valid_unique) == 1:
            # jediná platná mez -> nelze určit pásmo B/C i C/D zvlášť,
            # použije se jako Alarm (mez C/D); Varování zůstává neurčené
            danger = valid_unique[0]
        elif len(valid_unique) >= 2:
            # dvě nejvyšší odlišné hodnoty = hranice C (nižší z dvojice)
            # a D (nejvyšší) - platí shodně pro přesně 2 i pro 3+ platných mezí
            danger = valid_unique[-1]
            warning = valid_unique[-2]

    if warning is None and alert is None and danger is None:
        return None
    return {
        "warning": warning,
        "alert": alert,
        "danger": danger,
        "levels": levels,
    }


def bearing_key(point_name: Optional[str]):
    """Odvodí identifikátor LOŽISKA z názvu měřicího místa.

    Měřicí místa bývají označena např. L1H, L1V, L1A (směry téhož ložiska
    L1), případně s příponou ("L1H-motor"). Ložisko je část před písmenem
    směru: L1H/L1V/L1A -> "L1". Pokud vzor nesedí, vrací se celý název
    (očištěný), aby se místo nikdy neztratilo.

    Vrací (key, label, direction):
      key       – normalizovaný klíč ložiska pro perzistenci (např. "L1")
      label     – čitelný popis ložiska pro UI (např. "L1")
      direction – směr H/V/A nebo None
    """
    # NFKC vyrovná pouze typografické zápisy oddělovačů/mezery. Neprovádí
    # nebezpečné přibližné párování názvů ložisek.
    raw = unicodedata.normalize("NFKC", str(point_name or "")).strip()
    if not raw:
        return ("?", "?", None)
    # Část před prvním oddělovačem je vlastní přesný kód bodu. Popis za ním
    # může mít diakritiku a libovolný text („L2H-motor“, „L2H_motor“,
    # „L2H – motor“), ale nikdy nemění směr ani ložisko.
    code = re.split(r"[\s_/\-\u2010\u2011\u2012\u2013\u2014\u2015]", raw, maxsplit=1)[0]
    # vzor: L<číslo><směr H|V|A>  (case-insensitive)
    m = re.match(r"^([A-Za-z]+\d+)([HVAhva])$", code)
    if m:
        base = m.group(1).upper()
        direction = m.group(2).upper()
        return (base, base, direction)
    # vzor bez směru: L<číslo>
    m2 = re.match(r"^([A-Za-z]+\d+)$", code)
    if m2:
        base = m2.group(1).upper()
        return (base, base, None)
    # fallback – celý kód jako vlastní ložisko
    key = code.upper() if code else raw.upper()
    return (key, code or raw, None)


def _find_zlib(blob: bytes) -> int:
    """Najde začátek zlib streamu v BLOBu."""
    for marker in (b"\x78\x01", b"\x78\x9c", b"\x78\xda"):
        idx = blob.find(marker)
        if idx >= 0:
            return idx
    return -1


def _decompress(blob: bytes) -> Optional[bytes]:
    if not blob:
        return None
    idx = _find_zlib(blob)
    if idx < 0:
        return None
    try:
        return zlib.decompress(blob[idx:])
    except zlib.error:
        # zkus s ořezem koncových bajtů (některé záznamy mají padding)
        try:
            d = zlib.decompressobj()
            return d.decompress(blob[idx:]) + d.flush()
        except zlib.error:
            return None


def parse_static_blob(blob: bytes):
    """Vrátí seznam (timestamp_ms2000, value) ze statického BLOBu.

    Záznamy jsou 64 bajtů: int64 .NET ticks + double hodnota na offsetu 16.
    Vrácený čas převedeme z .NET ticks na ms od 2000 kvůli jednotné ose.
    """
    dec = _decompress(blob)
    out = []
    if not dec:
        return out
    rec = 64
    # .NET ticks roku 2000 (100ns od 0001-01-01 do 2000-01-01):
    net_ticks_2000 = 125911584000000000
    for i in range(0, len(dec) - rec + 1, rec):
        r = dec[i:i + rec]
        try:
            ticks = struct.unpack("<q", r[0:8])[0]
            val = struct.unpack("<d", r[16:24])[0]
        except struct.error:
            continue
        if not math.isfinite(val):
            continue
        # převod .NET ticks -> ms od 2000
        ms = (ticks - net_ticks_2000) // 10000
        out.append((ms, val))
    return out


def parse_dynamic_blob(blob: bytes, data_length: int):
    """Vrátí seznam float amplitud z dynamického BLOBu.

    Krok mezi vzorky (stride) se liší podle typu měření:
      - spektrum (FFT):    9 bajtů/bod  (float32 + 5 rezervních)
      - časový signál:      5 bajtů/bod  (float32 + 1 rezervní)
    Stride se proto odvodí z poměru délky dekomprimovaných dat a počtu bodů,
    aby parser fungoval pro všechny typy automaticky.
    """
    dec = _decompress(blob)
    if not dec:
        return []
    if not data_length or data_length <= 0:
        # neznámý počet – zkus 9 (nejčastější u spekter)
        data_length = len(dec) // 9
    stride = len(dec) // data_length if data_length else 9
    if stride < 4:
        stride = 4
    vals = []
    for k in range(data_length):
        off = k * stride
        if off + 4 > len(dec):
            break
        v = struct.unpack("<f", dec[off:off + 4])[0]
        vals.append(v if math.isfinite(v) else 0.0)
    return vals


# Hornopásmový filtr: čáry s frekvencí pod touto hranicí se ze spektra odříznou
# (odstranění stejnosměrné – DC – složky a velmi nízkých kmitočtů).
HP_CUTOFF_HZ = 1.0


def apply_highpass(values, step, cutoff=HP_CUTOFF_HZ):
    """Vrátí kopii spektra s vynulovanými čárami pod hranicí ``cutoff`` [Hz].

    Frekvence i-té čáry je ``i * step``. Všechny čáry s frekvencí menší než
    ``cutoff`` (typicky DC složka na 0 Hz a velmi nízké kmitočty) se nastaví
    na nulu, čímž se odstraní stejnosměrný offset signálu.
    """
    if not values:
        return []
    if not step or step <= 0:
        step = 1.0
    # počet čar k vynulování: i * step < cutoff  =>  i < cutoff/step
    n_cut = int(math.ceil(cutoff / step - 1e-9))
    if n_cut <= 0:
        return list(values)
    out = list(values)
    for i in range(min(n_cut, len(out))):
        out[i] = 0.0
    return out


def _tolerances():
    """Uživatelské tolerance shody frekvencí; při chybě vestavěné výchozí.

    Import je odložený: `fft_settings` čte z disku a nemá se natahovat při
    každém importu parseru.
    """
    try:
        import fft_settings
        return fft_settings.tolerances()
    except Exception:
        return {
            "order_tolerance_pct": fft_analysis.ORDER_TOLERANCE_PCT,
            "bearing_tolerance_pct": fft_analysis.BEARING_TOLERANCE_PCT,
        }


def _positive_or_none(value):
    """Vrátí kladné konečné číslo, jinak None (otáčky, meze)."""
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(out) or out <= 0 or out > 1e30:
        return None
    return out


def _limit_source(eff):
    """Odkud pochází PLATNÝ limit veličiny: norma / vlastní / databáze.

    Slouží výhradně k tomu, aby AI (a tím i text protokolu) porovnávala
    hodnotu proti správné mezi a věděla, že mez z normy má přednost před
    mezí uloženou v .ndb.
    """
    if not isinstance(eff, dict):
        return "none"
    if eff.get("from_norm"):
        return "norm"
    if eff.get("overridden"):
        return "manual"
    if eff.get("warning") is not None or eff.get("alarm") is not None:
        return "db"
    return "none"


def _band_for(value, eff):
    """Pásmo A–D hodnoty podle platných mezí; None, nelze-li určit.

    Import `report` je odložený: `report` importuje `ndb_parser`, takže
    modulový import by vytvořil cyklus (stejný postup jako u `ai_eval`
    v `cell_effective_limits`).
    """
    if value is None or not isinstance(eff, dict):
        return None
    try:
        import report as _report
    except Exception:
        return None
    try:
        # Odhad hranice A/B jako poloviny meze výstrahy zavádí norma, a platí
        # tedy jen pro limit z normy. U mezí z databáze přístroje nebo ručně
        # zadaných existují pouze dva prahy a dopočítané „B" by bylo smyšlené.
        # Stejné pravidlo používá tabulka protokolu (`report.build_machine_report`),
        # jinak by prompt tvrdil jiné pásmo, než jaké vidí diagnostik.
        return _report.classify_band(value, eff.get("warning"), eff.get("alarm"),
                                     eff.get("ab"),
                                     estimate_ab=bool(eff.get("from_norm")))
    except Exception:
        return None


def _parse_iso(value):
    """Bezpečně převede ISO timestamp z trendu na datetime; jinak None."""
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.datetime.fromisoformat(text)
    except ValueError:
        # Datum bez času (baseline zadaný uživatelem jako YYYY-MM-DD).
        try:
            return datetime.datetime.fromisoformat(text[:10])
        except ValueError:
            return None


def _trend_rate(trend):
    """Rychlost změny trendu v % za 30 dní (metodologie E.1)."""
    samples = []
    origin = None
    for item in trend or []:
        moment = _parse_iso(item.get("t") if isinstance(item, dict) else None)
        value = _positive_or_none(item.get("value")) if isinstance(item, dict) else None
        if moment is None or value is None:
            continue
        if origin is None:
            origin = moment
        samples.append(((moment - origin).total_seconds() / 86400.0, value))
    return fft_analysis.trend_rate(samples)


def _value_at(trend, when):
    """Hodnota trendu nejbližší zadanému času (baseline).

    Baseline se ukládá jen jako ČAS; hodnoty se čtou přímo z `.ndb`, takže se
    reference nikdy nerozejde se skutečným měřením.
    """
    target = _parse_iso(when)
    if target is None:
        return None
    best = None
    for item in trend or []:
        if not isinstance(item, dict):
            continue
        moment = _parse_iso(item.get("t"))
        value = item.get("value")
        if moment is None or value is None:
            continue
        distance = abs((moment - target).total_seconds())
        if best is None or distance < best[0]:
            best = (distance, {"value": value, "time": item.get("t"),
                               "days_off": distance / 86400.0})
    return best[1] if best else None


def _baseline_entry(trend, baseline_time, current):
    """Referenční hodnota ze známého dobrého stavu a odchylka od ní."""
    if not baseline_time:
        return None
    found = _value_at(trend, baseline_time)
    if not found:
        return None
    found["compare"] = fft_analysis.compare_to_reference(current, found["value"])
    return found


def _velocity_value(point):
    """Poslední rychlost vibrací bodu — referenční veličina pro směrovost."""
    for quantity in point.get("quantities") or []:
        if is_velocity_quantity(quantity.get("name")):
            return quantity.get("last_value")
    return None


def _direction_profiles(points):
    """Porovná směry H/V/A na každém ložisku stroje (metodologie krok C.5)."""
    by_bearing = {}
    for point in points or []:
        bkey = point.get("bearing_key")
        direction = point.get("direction")
        if not bkey or direction not in ("H", "V", "A"):
            continue
        value = _velocity_value(point)
        if value is None:
            continue
        by_bearing.setdefault(bkey, {})[direction] = value
    out = []
    for bkey in sorted(by_bearing):
        profile = fft_analysis.direction_profile(by_bearing[bkey])
        if profile:
            out.append({"bearing_key": bkey, **profile})
    return out


_RISING_MIN_POINTS = 4
_RISING_FACTOR = 1.25


def _is_rising(trend):
    """Skutečný růst trendu, ne jediný výkyv (metodologie E.1).

    Porovnávají se PRŮMĚRY dvou polovin řady, ne první a poslední hodnota:
    posloupnost 0,07 → 0,14 → 0,12 je jednorázový výkyv s poklesem, a přesto
    by u prostého porovnání krajních hodnot prošla jako rostoucí. Metodologie
    přitom na rostoucí trend váže zvýšení priority, takže falešný růst má
    přímý dopad na doporučení.
    """
    values = []
    for item in trend or []:
        if not isinstance(item, dict):
            continue
        try:
            value = float(item.get("value"))
        except (TypeError, ValueError):
            continue
        if math.isfinite(value):
            values.append(value)
    if len(values) < _RISING_MIN_POINTS:
        return False
    half = len(values) // 2
    older = values[:half]
    newer = values[-half:]
    older_mean = sum(older) / len(older)
    newer_mean = sum(newer) / len(newer)
    return older_mean > 0 and newer_mean > older_mean * _RISING_FACTOR


def _band_of(point, matcher):
    for quantity in point.get("quantities") or []:
        if matcher(quantity.get("name")):
            return quantity.get("band")
    return None


def _is_envelope_quantity(name):
    text = (name or "").upper()
    return "ENV" in text or "BEARING" in text


def _is_accel_quantity(name):
    text = (name or "").upper()
    return ("ACC" in text or "ZRYCHL" in text) and "ENV" not in text


def _bearing_stages(points):
    """Etapa poškození pro každé ložisko stroje (metodologie D.9.3).

    Znaky se sbírají POUZE ze spekter zrychlení a obálky — poškození valivých
    ložisek je vysokofrekvenční jev a spektrum rychlosti o něm nevypovídá.
    """
    by_bearing = {}
    for point in points or []:
        bkey = point.get("bearing_key")
        if not bkey:
            continue
        record = by_bearing.setdefault(bkey, {
            "defect_matches": 0, "defect_harmonics": 0, "sidebands": 0,
            "noise_floor_ratio": 0.0, "envelope_rising": False,
        })
        for spectrum in point.get("spectra") or []:
            if not fft_analysis.role_covers_defects(spectrum.get("role")):
                continue
            analysis = spectrum.get("analysis") or {}
            defects = analysis.get("defects") or []
            record["defect_matches"] += len(defects)
            record["defect_harmonics"] += sum(
                1 for row in defects if str(row.get("key", "")).startswith(("2×", "3×")))
            record["sidebands"] += len(analysis.get("sidebands") or [])
            ratio = (analysis.get("pattern") or {}).get("noise_floor_ratio") or 0.0
            record["noise_floor_ratio"] = max(record["noise_floor_ratio"], ratio)
        for quantity in point.get("quantities") or []:
            if _is_envelope_quantity(quantity.get("name")) and _is_rising(
                    quantity.get("recent_trend")):
                record["envelope_rising"] = True
        for key, matcher in (("velocity_band", is_velocity_quantity),
                             ("accel_band", _is_accel_quantity),
                             ("envelope_band", _is_envelope_quantity)):
            band = _band_of(point, matcher)
            if band and _BAND_RANK.get(band, 0) > _BAND_RANK.get(record.get(key) or "A", 0):
                record[key] = band

    out = []
    for bkey in sorted(by_bearing):
        stage = fft_analysis.bearing_stage(by_bearing[bkey])
        if stage:
            out.append({"bearing_key": bkey, **stage})
    return out


_BAND_RANK = {"A": 0, "B": 1, "C": 2, "D": 3}


def _worst_band(points):
    """Nejhorší pásmo napříč všemi veličinami stroje; None bez klasifikace."""
    worst = None
    for point in points or []:
        for quantity in point.get("quantities") or []:
            band = quantity.get("band")
            if band not in _BAND_RANK:
                continue
            if worst is None or _BAND_RANK[band] > _BAND_RANK[worst]:
                worst = band
    return worst


def spectrum_overall(values, step, cutoff=HP_CUTOFF_HZ):
    """Celková hodnota (overall) spočítaná ze spektra jako RMS přes čáry.

    Overall = odmocnina ze součtu čtverců amplitud čar od ``cutoff`` [Hz] výše
    (Parsevalova věta pro RMS amplitudové spektrum). Stejnosměrná složka a čáry
    pod hranicí hornopásmového filtru se do výpočtu nezahrnují.
    """
    if not values:
        return 0.0
    if not step or step <= 0:
        step = 1.0
    n_cut = int(math.ceil(cutoff / step - 1e-9))
    acc = 0.0
    for i in range(max(n_cut, 0), len(values)):
        v = values[i]
        acc += v * v
    return math.sqrt(acc)


class NdbDatabase:
    """Otevře .ndb soubor a poskytuje přístup ke strukturovaným datům."""

    def __init__(self, path: str):
        self.path = path
        self._con = sqlite3.connect(path, check_same_thread=False)
        self._con.row_factory = sqlite3.Row
        # --- výkonové ladění připojení (WAL + cache) ---
        # Výrazně zrychlí opakované čtení u velkých databází. Vše je bezpečné
        # pro čtení; při chybě (např. jen pro čtení) se tiše přeskočí.
        self._tune_connection()
        # --- zajištění indexů na filtrovacích sloupcích ---
        # Bez těchto indexů běží dotazy WHERE Parent=? / WHERE CellId=? jako
        # plný sken tabulky, což u velkých databází způsobuje načítání desítek
        # sekund. Indexy jsou aditivní (nemění data).
        self._ensure_perf_indexes()

    def _tune_connection(self):
        for pragma in (
            "PRAGMA journal_mode=WAL",
            "PRAGMA synchronous=NORMAL",
            "PRAGMA temp_store=MEMORY",
            "PRAGMA cache_size=-65536",   # ~64 MB stránkové cache
            "PRAGMA mmap_size=268435456", # 256 MB mmap pro čtení
        ):
            try:
                self._con.execute(pragma)
            except Exception:
                pass

    def _ensure_perf_indexes(self):
        """Vytvoří chybějící indexy potřebné pro rychlé načítání.

        Databáze .ndb od výrobce indexuje tabulky převážně jen podle sloupce
        ID, ale aplikace filtruje podle Parent (strom, buňky) a CellId
        (trendová data). Doplníme proto cílené indexy. Používá se
        IF NOT EXISTS, takže opakované volání je bezpečné a rychlé.
        """
        stmts = (
            "CREATE INDEX IF NOT EXISTS ix_tree_parent "
            "ON Tbl_Tree(Parent)",
            "CREATE INDEX IF NOT EXISTS ix_cell_parent "
            "ON Tbl_Cell(Parent)",
            "CREATE INDEX IF NOT EXISTS ix_cellstats_cellid "
            "ON Tbl_Cell_Stats(CellId, TimeFrom)",
            "CREATE INDEX IF NOT EXISTS ix_celldyns_cellid "
            "ON Tbl_Cell_Dyns(CellId)",
        )
        for s in stmts:
            try:
                self._con.execute(s)
            except Exception:
                # tabulka nemusí v některé variantě databáze existovat
                pass
        try:
            self._con.commit()
        except Exception:
            pass

    def close(self):
        try:
            self._con.close()
        except Exception:
            pass

    # ---------- číselníky ----------
    def severities(self):
        rows = self._con.execute(
            "SELECT ID, Name, Color, Severity FROM Tbl_Severity ORDER BY Severity"
        ).fetchall()
        out = []
        for r in rows:
            out.append({
                "id": r["ID"],
                "name": r["Name"],
                "severity": r["Severity"],
                "color": self._color_to_hex(r["Color"]),
            })
        return out

    @staticmethod
    def _color_to_hex(color: Optional[int]) -> Optional[str]:
        """HADS ukládá barvu jako 0x00BBGGRR (BGR). Převedeme na #RRGGBB."""
        if color is None:
            return None
        b = (color >> 16) & 0xFF
        g = (color >> 8) & 0xFF
        r = color & 0xFF
        return "#%02X%02X%02X" % (r, g, b)

    def info(self):
        r = self._con.execute(
            "SELECT Version, DDS_Version, Route_Format FROM Tbl_Info LIMIT 1"
        ).fetchone()
        route = self._con.execute("SELECT Name FROM Tbl_Routes LIMIT 1").fetchone()
        return {
            "version": r["Version"] if r else None,
            "dds_version": r["DDS_Version"] if r else None,
            "route_name": route["Name"] if route else None,
        }

    # ---------- identita databáze (podnik) ----------
    def root_enterprise_name(self):
        """Vrátí název podniku = první kořenový uzel stromu (Type=1, Parent=0).

        Toto je název uvedený jako první ve stromovém adresáři databáze
        (např. „MND“). Slouží jako stabilní identifikátor podniku, který
        zůstává stejný i při opětovném načtení / přejmenování souboru .ndb.
        Pokud kořenový uzel chybí, použije se název trasy (route) z Tbl_Routes.
        """
        try:
            # 1) první kořenový uzel (Parent=0 nebo NULL), v pořadí stromu
            row = self._con.execute(
                "SELECT Name FROM Tbl_Tree "
                "WHERE (Parent=0 OR Parent IS NULL) "
                "ORDER BY SortId, ID LIMIT 1"
            ).fetchone()
            if row and row["Name"] and str(row["Name"]).strip():
                return str(row["Name"]).strip()
            # 2) jakýkoli uzel typu 1 (závod/skupina) jako záloha
            row = self._con.execute(
                "SELECT Name FROM Tbl_Tree WHERE Type=1 "
                "ORDER BY SortId, ID LIMIT 1"
            ).fetchone()
            if row and row["Name"] and str(row["Name"]).strip():
                return str(row["Name"]).strip()
        except Exception:
            pass
        # 3) název trasy jako poslední záloha
        try:
            rt = self._con.execute(
                "SELECT Name FROM Tbl_Routes LIMIT 1"
            ).fetchone()
            if rt and rt["Name"] and str(rt["Name"]).strip():
                return str(rt["Name"]).strip()
        except Exception:
            pass
        return None

    def persistence_identity(self):
        """Return a path-independent, privacy-safe identity for HADS context.

        NDB does not expose a documented immutable UUID.  The least volatile
        intrinsic evidence available in every shipped layout is the root tree
        record (including its database ID) plus the database format metadata.
        It remains stable across installation paths, archive extraction and
        filename changes.  It deliberately excludes measurements, so ordinary
        data acquisition does not change the context identity.

        Callers receive only the SHA-256 fingerprint and the display enterprise;
        raw table metadata never leaves this parser.
        """
        roots = []
        try:
            rows = self._con.execute(
                "SELECT ID, Name, Parent, Type, SortId FROM Tbl_Tree "
                "WHERE Type=1 ORDER BY ID"
            ).fetchall()
            roots = [[str(row["ID"]), str(row["Name"] or ""), str(row["Parent"] or ""),
                      str(row["Type"] or ""), str(row["SortId"] or "")]
                     for row in rows]
        except Exception:
            roots = []
        info = []
        try:
            row = self._con.execute(
                "SELECT Version, DDS_Version, Route_Format FROM Tbl_Info LIMIT 1"
            ).fetchone()
            if row:
                info = [str(row["Version"] or ""), str(row["DDS_Version"] or ""),
                        str(row["Route_Format"] or "")]
        except Exception:
            pass
        route_guid = ""
        try:
            row = self._con.execute("SELECT Guid FROM Tbl_Routes LIMIT 1").fetchone()
            route_guid = str(row["Guid"] or "").strip() if row else ""
        except Exception:
            pass
        enterprise = self.root_enterprise_name() or ""
        # A root ID plus its parent/type is positive intrinsic evidence.  Do
        # not manufacture an identity from a display name alone.
        if not roots:
            return {"fingerprint": None, "enterprise": enterprise}
        payload = json.dumps({"route_guid": route_guid, "roots": roots, "info": info}, ensure_ascii=False,
                             separators=(",", ":"), sort_keys=True)
        return {
            "fingerprint": hashlib.sha256(payload.encode("utf-8")).hexdigest(),
            "enterprise": enterprise,
            "strength": "route_guid" if route_guid else "structural",
        }

    def distinct_quantities(self):
        """Vrátí seřazený seznam názvů všech STATICKÝCH (skalárních) měřených
        veličin nalezených v databázi (napříč všemi měřicími body).

        Slouží k naplnění výběru veličin v Nastavení databáze (které veličiny
        se v protokolu berou jako rychlost / zrychlení / obálka zrychlení).
        Zahrnuje pouze veličiny s trendovými daty (DataType 1/2).
        """
        names = set()
        try:
            rows = self._con.execute(
                "SELECT DISTINCT Name, DataType FROM Tbl_Cell"
            ).fetchall()
            for r in rows:
                if r["DataType"] in STATIC_DATATYPES and r["Name"]:
                    nm = str(r["Name"]).strip()
                    if nm:
                        names.add(nm)
        except Exception:
            pass
        return sorted(names, key=lambda s: s.lower())

    # ---------- strom ----------
    def tree(self):
        """Vrátí seznam uzlů stromu (závod/stroj/bod) s metadaty."""
        rows = self._con.execute(
            "SELECT ID, Name, Parent, SortId, Type, Speed_Hz FROM Tbl_Tree ORDER BY SortId, ID"
        ).fetchall()
        nodes = []
        for r in rows:
            speed = r["Speed_Hz"]
            if speed is not None and (not math.isfinite(speed) or speed > 1e30):
                speed = None
            nodes.append({
                "id": r["ID"],
                "name": r["Name"],
                "parent": r["Parent"],
                "type": r["Type"],  # 1=závod/skupina, 2=stroj, 3=měřicí bod
                "speed_hz": speed,
            })
        return nodes

    def point_max_severity(self):
        """Mapuje id měřicího bodu (Tree.ID) -> max severity z jeho cell."""
        rows = self._con.execute(
            "SELECT Parent, MAX(MaxSeverityId) AS sev FROM Tbl_Cell GROUP BY Parent"
        ).fetchall()
        return {r["Parent"]: r["sev"] for r in rows}

    # ---------- měření v bodu ----------
    def cells_for_point(self, tree_id: int):
        """Vrátí definice měření (cell) pro daný měřicí bod."""
        rows = self._con.execute(
            "SELECT ID, Name, DataType, LastMeasured, MaxSeverityId, LastValSeverityId "
            "FROM Tbl_Cell WHERE Parent=? ORDER BY ID",
            (tree_id,),
        ).fetchall()
        out = []
        for r in rows:
            dt = r["DataType"]
            if dt in STATIC_DATATYPES:
                kind = "trend"
            elif dt in SPECTRUM_DATATYPES:
                kind = "spectrum"
            elif dt in TIME_DATATYPES:
                kind = "time"
            else:
                kind = "other"
            out.append({
                "id": r["ID"],
                "name": r["Name"],
                "data_type": dt,
                "kind": kind,
                "last_measured": ms2000_to_iso(r["LastMeasured"]),
                "max_severity_id": r["MaxSeverityId"],
                "last_severity_id": r["LastValSeverityId"],
            })
        return out

    def cell(self, cell_id: int):
        r = self._con.execute(
            "SELECT ID, Name, Parent, DataType, Limits FROM Tbl_Cell WHERE ID=?",
            (cell_id,),
        ).fetchone()
        if not r:
            return None
        return {
            "id": r["ID"],
            "name": r["Name"],
            "parent": r["Parent"],
            "data_type": r["DataType"],
            "limits": r["Limits"],
        }

    def cell_effective_limits(self, cell_id, overrides=None):
        """Vrátí platné limity buňky (warning/alarm) pro vykreslení v trendu.

        Sloučí výchozí limity z DB s přepisem na úrovni LOŽISKA. `overrides`
        je struktura ze server.py (machine_config.get_db_overrides()):
        {"<machine_id>": {"bearings": {"<bkey>": {"limits": {...}}}}}.

        Vrací slovník:
          {"warning": x|None, "alarm": y|None,
           "db_warning": x|None, "db_alarm": y|None,
           "overridden": bool, "quantity": <název veličiny>,
           "bearing_key": <klíč ložiska>}
        """
        r = self._con.execute(
            "SELECT ID, Name, Parent, DataType, Limits FROM Tbl_Cell WHERE ID=?",
            (cell_id,),
        ).fetchone()
        if not r:
            return None
        db_w, db_a = self._db_limit_pair(parse_cell_limits(r["Limits"]))
        quantity = r["Name"]

        # zjisti název měřicího bodu (Parent) a stroje (Parent bodu)
        point = self._con.execute(
            "SELECT ID, Name, Parent FROM Tbl_Tree WHERE ID=?", (r["Parent"],)
        ).fetchone()
        bkey = None
        machine_id = None
        if point:
            bkey, _label, _dir = bearing_key(point["Name"])
            machine_id = point["Parent"]

        eff_w, eff_a = db_w, db_a
        overridden = False
        from_norm = False
        if overrides and machine_id is not None and bkey is not None:
            mover = overrides.get(str(machine_id), {}).get("bearings", {}) or {}
            ov = (mover.get(bkey, {}) or {}).get("limits", {}) or {}
            qov = ov.get(quantity) or {}
            ov_w = qov.get("warning")
            ov_a = qov.get("alarm")
            if ov_w is not None:
                eff_w = ov_w
                overridden = True
            if ov_a is not None:
                eff_a = ov_a
                overridden = True

        # automaticky a vždy: limity ISO RMS se odvozují z nastavené ISO normy.
        # V režimu více norem (mode="multi") se norma vybírá podle ložiska (bkey).
        eff_ab = None
        if overrides and machine_id is not None and quantity == "ISO RMS":
            iso_norm = (overrides.get(str(machine_id), {}) or {}).get("iso_norm")
            if iso_norm:
                try:
                    import ai_eval as _aie
                    lim = _aie.iso_limits_from_norm(iso_norm, bearing_key=bkey)
                except Exception:
                    lim = None
                if lim:
                    eff_w = lim.get("warning")
                    eff_a = lim.get("alarm")
                    eff_ab = lim.get("ab")
                    overridden = True
                    from_norm = True

        return {
            "warning": eff_w,
            "alarm": eff_a,
            "ab": eff_ab,
            "db_warning": db_w,
            "db_alarm": db_a,
            "overridden": overridden,
            "from_norm": from_norm,
            "quantity": quantity,
            "bearing_key": bkey,
        }

    @staticmethod
    def _classify_value(value, warning, alarm):
        """Zařadí hodnotu podle 2 platných prahů do závažnosti 1/3/4.

        1 = Ok (pod hranicí Varování), 3 = Výstraha (mezi Varování a Alarm),
        4 = Ohrožení (nad hranicí Alarm). Efektivní limity mají jen 2 prahy
        (Varování/Alarm), takže úroveň 2 (Varování) se v tomto zjednodušeném
        schématu nepoužívá — konzistentní s tím, jak limity edituje uživatel
        (karta stroje má jen 2 pole: Varování a Alarm).

        Vrací None, pokud hodnota nebo alespoň jeden limit chybí.
        """
        if value is None or warning is None or alarm is None:
            return None
        try:
            v = float(value)
            w = float(warning)
            a = float(alarm)
        except (TypeError, ValueError):
            return None
        if not (math.isfinite(v) and math.isfinite(w) and math.isfinite(a)):
            return None
        if v < w:
            return 1
        if v < a:
            return 3
        return 4

    def effective_point_severity(self, overrides=None, machine_id=None):
        """Spočítá závažnost KAŽDÉHO měřicího bodu z POSLEDNÍ hodnoty vs.
        aktuálně platné limity (norma ISO 20816 > ruční přepis ložiska > DB).

        Na rozdíl od `point_max_severity()` (což je syrové pole HADS
        `MaxSeverityId` — nezávislé na naší normě/ručních přepisech) tato
        metoda vždy vychází z toho, co uživatel skutečně vidí a nastavuje
        na kartě stroje. Adaptivní limity EWMA se NEPOUŽÍVAJÍ (jsou čistě
        informativní, dokud je uživatel tlačítkem „Převzít“ nezmění na
        ruční přepis — stejná konvence jako v panelu ložiska).

        Volitelný `machine_id` omezí výpočet jen na body daného stroje
        (rychlejší pro kartu jednoho stroje u velkých databází).

        Vrací {point_id: severity_id (1/3/4) | None}. `None`, pokud bod
        nemá žádnou veličinu s definovanými limity a hodnotou.
        """
        all_over = overrides or {}
        if machine_id is not None:
            rows = self._con.execute(
                "SELECT t.ID AS point_id, t.Name AS point_name, t.Parent AS machine_id, "
                "c.ID AS cell_id, c.Name AS cell_name, c.DataType, c.Limits "
                "FROM Tbl_Tree t JOIN Tbl_Cell c ON c.Parent = t.ID "
                "WHERE t.Type = 3 AND t.Parent = ?",
                (machine_id,),
            ).fetchall()
        else:
            rows = self._con.execute(
                "SELECT t.ID AS point_id, t.Name AS point_name, t.Parent AS machine_id, "
                "c.ID AS cell_id, c.Name AS cell_name, c.DataType, c.Limits "
                "FROM Tbl_Tree t JOIN Tbl_Cell c ON c.Parent = t.ID "
                "WHERE t.Type = 3"
            ).fetchall()

        # seskup buňky podle bodu, jen statické (trendové) veličiny mají limity
        by_point = {}
        static_cell_ids = []
        for r in rows:
            if r["DataType"] not in STATIC_DATATYPES:
                continue
            by_point.setdefault(
                (r["point_id"], r["machine_id"]), []
            ).append(r)
            static_cell_ids.append(r["cell_id"])

        # hromadné načtení poslední hodnoty každé buňky (bez N+1 dotazů)
        trends_by_cell = self.trend_batch(static_cell_ids)

        # cache limitů normy podle (stroj, ložisko) – v režimu více norem se
        # limity liší podle ložiska, proto je součástí klíče i bkey
        norm_cache = {}

        def _iso_limits(machine_id, bkey):
            ck = (machine_id, bkey)
            if ck in norm_cache:
                return norm_cache[ck]
            iso_norm = (all_over.get(str(machine_id), {}) or {}).get("iso_norm")
            lim = None
            if iso_norm:
                try:
                    import ai_eval as _aie
                    lim = _aie.iso_limits_from_norm(iso_norm, bearing_key=bkey)
                except Exception:
                    lim = None
            norm_cache[ck] = lim
            return lim

        result = {}
        for (point_id, machine_id), cells in by_point.items():
            point_name = cells[0]["point_name"] if cells else None
            bkey, _label, _direction = bearing_key(point_name)
            mover = (all_over.get(str(machine_id), {}) or {}).get("bearings", {}) or {}
            over_limits = (mover.get(bkey, {}) or {}).get("limits", {}) or {}
            bearing_classify = (mover.get(bkey, {}) or {}).get("classify")
            bearing_classify = (bearing_classify is not False)
            iso_limits = _iso_limits(machine_id, bkey)

            worst = None
            for c in cells:
                qname = c["cell_name"]
                ov = over_limits.get(qname) or {}
                q_classify = ov.get("classify")
                q_classify = (q_classify is not False) and bearing_classify
                if not q_classify:
                    continue
                ov_w = ov.get("warning")
                ov_a = ov.get("alarm")
                if iso_limits and qname == "ISO RMS":
                    ov_w = iso_limits.get("warning")
                    ov_a = iso_limits.get("alarm")
                if ov_w is None or ov_a is None:
                    db_w, db_a = self._db_limit_pair(parse_cell_limits(c["Limits"]))
                    if ov_w is None:
                        ov_w = db_w
                    if ov_a is None:
                        ov_a = db_a
                trend_pts = trends_by_cell.get(c["cell_id"]) or []
                last_v = trend_pts[-1]["value"] if trend_pts else None
                sev = self._classify_value(last_v, ov_w, ov_a)
                if sev is not None and (worst is None or sev > worst):
                    worst = sev
            result[point_id] = worst
        return result

    # ---------- statický trend ----------
    def trend(self, cell_id: int):
        """Vrátí seřazený trend (čas, hodnota) pro skalární měření."""
        rows = self._con.execute(
            "SELECT rowid AS _rowid, Data FROM Tbl_Cell_Stats "
            "WHERE CellId=? ORDER BY TimeFrom, rowid",
            (cell_id,),
        ).fetchall()
        points = []
        for r in rows:
            # Pořadí v BLOBu je stabilní tie-breaker pro shodný čas. Není
            # primárním klíčem: konečné řazení je vždy nejdřív podle času.
            for pos, (ms, val) in enumerate(parse_static_blob(r["Data"])):
                points.append({"t": ms2000_to_iso(ms), "value": val,
                               "_order": (r["_rowid"], pos)})
        points.sort(key=lambda p: (p["t"] or "", p.get("_order", ())))
        return points

    def trend_batch(self, cell_ids):
        """Vrátí trendy pro více buněk najednou (jeden dotaz místo N).

        Řeší problém N+1 dotazů: místo volání trend() ve smyčce (jeden
        SQL dotaz na každou buňku) načte data všech zadaných buněk jediným
        dotazem `WHERE CellId IN (...)` a rozdělí je podle CellId.

        Vrací slovník {cell_id: [{"t":..., "value":...}, ...]} seřazený
        podle času. Buňky bez dat mají prázdný seznam.
        """
        result = {cid: [] for cid in cell_ids}
        ids = [cid for cid in cell_ids if cid is not None]
        if not ids:
            return result
        # SQLite má limit ~999 parametrů na dotaz – dělíme po dávkách.
        CHUNK = 800
        for i in range(0, len(ids), CHUNK):
            chunk = ids[i:i + CHUNK]
            ph = ",".join("?" for _ in chunk)
            rows = self._con.execute(
                f"SELECT rowid AS _rowid, CellId, Data FROM Tbl_Cell_Stats "
                f"WHERE CellId IN ({ph}) ORDER BY CellId, TimeFrom, rowid",
                tuple(chunk),
            ).fetchall()
            for r in rows:
                cid = r["CellId"]
                lst = result.get(cid)
                if lst is None:
                    lst = result[cid] = []
                for pos, (ms, val) in enumerate(parse_static_blob(r["Data"])):
                    lst.append({"t": ms2000_to_iso(ms), "value": val,
                                "_order": (r["_rowid"], pos)})
        for lst in result.values():
            lst.sort(key=lambda p: (p["t"] or "", p.get("_order", ())))
        return result

    # ---------- porovnání trendů více bodů ----------
    def compare_trends(self, point_ids):
        """Vrátí trendy statických hodnot pro několik měřicích bodů najednou.

        Pro každý zadaný měřicí bod (Tree.ID, Type=3) najde jeho trendová
        (skalární) měření a vrátí jejich časové řady. Frontend pak nabídne
        výběr veličiny (např. \"ISO RMS\") a vykreslí ji pro všechny body
        do jedné časové osy.
        """
        if not point_ids:
            return {"points": [], "quantities": []}
        # nazvy mericich bodu (a jejich rodicu = stroju) pro popisky
        placeholders = ",".join("?" for _ in point_ids)
        name_rows = self._con.execute(
            f"SELECT ID, Name, Parent FROM Tbl_Tree WHERE ID IN ({placeholders})",
            tuple(point_ids),
        ).fetchall()
        node_name = {r["ID"]: r["Name"] for r in name_rows}
        node_parent = {r["ID"]: r["Parent"] for r in name_rows}
        # nazvy stroju (rodicu)
        parent_ids = [p for p in node_parent.values() if p is not None]
        machine_name = {}
        if parent_ids:
            ph2 = ",".join("?" for _ in parent_ids)
            for r in self._con.execute(
                f"SELECT ID, Name FROM Tbl_Tree WHERE ID IN ({ph2})", tuple(parent_ids)
            ).fetchall():
                machine_name[r["ID"]] = r["Name"]

        out_points = []
        quantities = set()
        for pid in point_ids:
            # trendova mereni daneho bodu
            cells = self._con.execute(
                "SELECT ID, Name, DataType FROM Tbl_Cell WHERE Parent=? ORDER BY ID",
                (pid,),
            ).fetchall()
            series = []
            for c in cells:
                if c["DataType"] not in STATIC_DATATYPES:
                    continue
                pts = self.trend(c["ID"])
                if not pts:
                    continue
                quantities.add(c["Name"])
                series.append({
                    "cell_id": c["ID"],
                    "quantity": c["Name"],
                    "points": pts,
                })
            mid = node_parent.get(pid)
            out_points.append({
                "point_id": pid,
                "point_name": node_name.get(pid, str(pid)),
                "machine_name": machine_name.get(mid),
                "series": series,
            })
        return {
            "points": out_points,
            "quantities": sorted(quantities, key=lambda s: s.lower()),
        }

    # ---------- dynamika: seznam pořízených měření ----------
    def dynamic_records(self, cell_id: int):
        """Seznam jednotlivých dynamických pořízení (časy) pro výběr."""
        rows = self._con.execute(
            "SELECT ID, Time, DataLength, DataStep, Speed_Hz, Type "
            "FROM Tbl_Cell_Dyns WHERE CellId=? ORDER BY Time",
            (cell_id,),
        ).fetchall()
        out = []
        for r in rows:
            speed = r["Speed_Hz"]
            if speed is not None and (not math.isfinite(speed) or speed > 1e30):
                speed = None
            out.append({
                "id": r["ID"],
                "time": ms2000_to_iso(r["Time"]),
                "data_length": r["DataLength"],
                "data_step": r["DataStep"],
                "speed_hz": speed,
            })
        return out

    def dynamic_data(self, dyn_id: int):
        """Vrátí osu X a amplitudy pro jedno dynamické pořízení."""
        r = self._con.execute(
            "SELECT d.ID, d.CellId, d.Time, d.Data, d.DataLength, d.DataStep, "
            "d.Speed_Hz, c.Name, c.DataType "
            "FROM Tbl_Cell_Dyns d JOIN Tbl_Cell c ON c.ID=d.CellId WHERE d.ID=?",
            (dyn_id,),
        ).fetchone()
        if not r:
            return None
        vals = parse_dynamic_blob(r["Data"], r["DataLength"])
        step = r["DataStep"] or 1.0
        dt = r["DataType"]
        if dt in TIME_DATATYPES:
            # u časového signálu je DataStep v milisekundách -> převod na sekundy
            step_s = step / 1000.0
            x = [round(i * step_s, 8) for i in range(len(vals))]
            x_label, x_unit, kind = "Čas", "s", "time"
            step_out = step_s
        else:
            # spektrum: DataStep je frekvenční krok v Hz
            x = [round(i * step, 6) for i in range(len(vals))]
            x_label, x_unit, kind = "Frekvence", "Hz", "spectrum"
            step_out = step
        speed = r["Speed_Hz"]
        if speed is not None and (not math.isfinite(speed) or speed > 1e30 or speed <= 0):
            speed = None
        overall = None
        hp_cutoff = None
        if kind == "spectrum":
            # hornopásmový filtr 1 Hz – odřízni DC složku i v zobrazeném spektru
            vals = apply_highpass(vals, step, HP_CUTOFF_HZ)
            overall = spectrum_overall(vals, step, HP_CUTOFF_HZ)
            hp_cutoff = HP_CUTOFF_HZ
        return {
            "id": r["ID"],
            "name": r["Name"],
            "time": ms2000_to_iso(r["Time"]),
            "kind": kind,
            "x": x,
            "y": vals,
            "x_label": x_label,
            "x_unit": x_unit,
            "step": step_out,
            "speed_hz": speed,
            "overall": overall,
            "hp_cutoff": hp_cutoff,
        }


    # ---------- vodopádový graf: FFT spektra bodu v čase ----------
    def waterfall(self, point_id: int, limit: int = 30, cell_id: int = None):
        """Vrátí sadu FFT spekter jednoho měřicího bodu v čase pro vodopád.

        Pro zadaný měřicí bod (Tree.ID, Type=3) najde jeho spektrální měření
        (cell s DataType ve SPECTRUM_DATATYPES). Pokud má bod více spektrálních
        měření, vybere se to s nejvíce pořízeními (nebo zadané ``cell_id``).
        Vrátí posledních ``limit`` spekter (seřazeno od nejstaršího k nejnovějšímu)
        zarovnaných na společnou frekvenční osu, vhodných pro 3D plochu i 2D
        skládaný vodopád.
        """
        # 1) najdi spektrální měření daného bodu
        cells = self._con.execute(
            "SELECT ID, Name, DataType FROM Tbl_Cell WHERE Parent=? ORDER BY ID",
            (point_id,),
        ).fetchall()
        spec_cells = [c for c in cells if c["DataType"] in SPECTRUM_DATATYPES]
        if not spec_cells:
            return {"point_id": point_id, "cells": [], "frequencies": [],
                    "spectra": [], "x_unit": "Hz", "speed_hz": None}

        # seznam dostupných spektrálních měření (pro přepínač v UI)
        cell_list = []
        for c in spec_cells:
            cnt = self._con.execute(
                "SELECT COUNT(*) AS n FROM Tbl_Cell_Dyns WHERE CellId=?",
                (c["ID"],),
            ).fetchone()["n"]
            cell_list.append({"cell_id": c["ID"], "name": c["Name"], "count": cnt})

        # 2) vyber konkrétní měření
        chosen = None
        if cell_id is not None:
            chosen = next((c for c in spec_cells if c["ID"] == cell_id), None)
        if chosen is None:
            # to s nejvíce pořízeními
            chosen = max(spec_cells, key=lambda c: next(
                (cl["count"] for cl in cell_list if cl["cell_id"] == c["ID"]), 0))
        chosen_id = chosen["ID"]

        # 3) načti posledních N pořízení (podle času)
        if limit is None or limit <= 0:
            limit = 30
        rows = self._con.execute(
            "SELECT ID, Time, DataLength, DataStep, Speed_Hz "
            "FROM Tbl_Cell_Dyns WHERE CellId=? ORDER BY Time DESC LIMIT ?",
            (chosen_id, limit),
        ).fetchall()
        rows = list(reversed(rows))  # od nejstaršího k nejnovějšímu

        spectra = []
        max_len = 0
        step_ref = None
        speed_ref = None
        for r in rows:
            # Data načítáme cíleně pro každý záznam (úspora paměti u velkých BLOBů)
            blob = self._con.execute(
                "SELECT Data FROM Tbl_Cell_Dyns WHERE ID=?", (r["ID"],)
            ).fetchone()["Data"]
            vals = parse_dynamic_blob(blob, r["DataLength"])
            if not vals:
                continue
            step = r["DataStep"] or 1.0
            if step_ref is None:
                step_ref = step
            sp = r["Speed_Hz"]
            if sp is not None and (not math.isfinite(sp) or sp > 1e30 or sp <= 0):
                sp = None
            if sp is not None and speed_ref is None:
                speed_ref = sp
            spectra.append({
                "dyn_id": r["ID"],
                "time": ms2000_to_iso(r["Time"]),
                "step": step,
                "values": vals,
            })
            if len(vals) > max_len:
                max_len = len(vals)

        if not spectra:
            return {"point_id": point_id, "cells": cell_list, "frequencies": [],
                    "spectra": [], "x_unit": "Hz", "speed_hz": speed_ref,
                    "cell_id": chosen_id, "cell_name": chosen["Name"]}

        # 4) společná frekvenční osa (podle nejdelšího spektra a referenčního kroku)
        step = step_ref or 1.0
        frequencies = [round(i * step, 6) for i in range(max_len)]

        # 5) zarovnej všechna spektra na stejnou délku (doplň nulami),
        #    aplikuj hornopásmový filtr 1 Hz a spočítej celkovou hodnotu (overall)
        out_spectra = []
        for s in spectra:
            y = s["values"]
            if len(y) < max_len:
                y = y + [0.0] * (max_len - len(y))
            elif len(y) > max_len:
                y = y[:max_len]
            # HP filtr 1 Hz – odřízni DC složku ve všech spektrech
            y = apply_highpass(y, step, HP_CUTOFF_HZ)
            overall = spectrum_overall(y, step, HP_CUTOFF_HZ)
            out_spectra.append({
                "dyn_id": s["dyn_id"],
                "time": s["time"],
                "values": y,
                "overall": overall,
            })

        return {
            "point_id": point_id,
            "cell_id": chosen_id,
            "cell_name": chosen["Name"],
            "cells": cell_list,
            "frequencies": frequencies,
            "x_unit": "Hz",
            "step": step,
            "speed_hz": speed_ref,
            "hp_cutoff": HP_CUTOFF_HZ,
            "spectra": out_spectra,
        }

    # ---------- limity z databáze ----------
    def cell_limits(self, cell_id):
        """Vrátí dekódované limity dané buňky z DB (nebo None)."""
        r = self._con.execute(
            "SELECT Limits FROM Tbl_Cell WHERE ID=?", (cell_id,)
        ).fetchone()
        if not r:
            return None
        return parse_cell_limits(r["Limits"])

    @staticmethod
    def _db_limit_pair(parsed):
        """Z dekódovaných DB limitů udělá dvojici (warning, alarm) pro UI.

        Mapování: Varování = první práh nad stavem Ok (Varování 2, jinak
        Výstraha 3); Alarm = nejvyšší práh (Ohrožení 4, jinak Výstraha 3).
        """
        if not parsed:
            return (None, None)
        warning = parsed.get("warning")
        alert = parsed.get("alert")
        danger = parsed.get("danger")
        w = warning if warning is not None else alert
        a = danger if danger is not None else alert
        # když Varování i Alarm vyjdou stejně, ale máme i Výstrahu a Ohrožení,
        # rozliš je (Varování = Výstraha, Alarm = Ohrožení)
        if (w is not None and a is not None and w == a
                and alert is not None and danger is not None):
            w = alert
            a = danger
        return (w, a)

    # ---------- stroje (karty strojů) ----------
    def machine(self, machine_id, overrides=None):
        """Vrátí data jednoho stroje (rychlé načtení karty stroje).

        Je to tenký obal nad machines() s filtrem na jediný stroj – spočítá
        trendy a adaptivní limity EWMA jen pro tento stroj, ne pro celou
        databázi. Vrací {"machine": {...}, "severities": [...]} nebo
        {"machine": None} pokud stroj neexistuje.
        """
        res = self.machines(overrides=overrides, machine_id=machine_id)
        ms = res.get("machines", [])
        return {
            "machine": ms[0] if ms else None,
            "severities": res.get("severities", []),
        }

    def machines(self, overrides=None, machine_id=None):
        """Vrátí seznam strojů (uzly Type=2, které mají měřicí body Type=3).

        Pokud je zadáno `machine_id`, zpracuje se pouze tento jeden stroj
        (významně rychlejší pro otevření karty stroje u velkých databází).

        Měřicí místa jsou seskupena podle LOŽISKA (L1, L2…); směry H/V/A
        téhož ložiska tvoří jednu skupinu. Limity i ložiska se vedou na
        úrovni ložiska (sdíleně přes směry).

        Pro každou veličinu ložiska vrací výchozí limity z databáze
        (db_warning/db_alarm) i aktuálně platné limity (warning/alarm =
        přepis, jinak DB) a příznak overridden.

        `overrides` = struktura {"<machine_id>": {"bearings": {<key>: {...}}}}
        z machine_config.get_machine_overrides(); slévání řeší tato metoda.
        """
        tree_rows = self._con.execute(
            "SELECT ID, Name, Parent, SortId, Type, Speed_Hz FROM Tbl_Tree "
            "ORDER BY SortId, ID"
        ).fetchall()
        by_id = {r["ID"]: r for r in tree_rows}
        children = {}
        for r in tree_rows:
            children.setdefault(r["Parent"], []).append(r)

        sev_map = {s["id"]: s for s in self.severities()}
        pt_sev = self.effective_point_severity(overrides=overrides, machine_id=machine_id)
        all_over = overrides or {}

        machines = []
        for r in tree_rows:
            if r["Type"] != 2:
                continue
            if machine_id is not None and r["ID"] != machine_id:
                continue  # zpracováváme jen požadovaný stroj
            kids = children.get(r["ID"], [])
            points = [k for k in kids if k["Type"] == 3]
            if not points:
                continue  # stroj musí mít měřicí body

            parent = by_id.get(r["Parent"])
            parent_name = parent["Name"] if parent else None

            machine_over = {}
            machine_speed_override = None
            machine_speed_history = []
            machine_iso_norm = None
            machine_ai_eval = None
            machine_ai_history = []
            machine_card = None
            machine_ewma_cfg = None
            if all_over:
                _mo = all_over.get(str(r["ID"]), {}) or {}
                machine_over = _mo.get("bearings", {}) or {}
                machine_speed_override = _mo.get("speed_hz")
                machine_speed_history = _mo.get("speed_history", []) or []
                machine_iso_norm = _mo.get("iso_norm")
                machine_ai_eval = _mo.get("ai_eval")
                machine_ai_history = _mo.get("ai_eval_history", []) or []
                machine_card = _mo.get("card")
                machine_ewma_cfg = _mo.get("ewma")

            # parametry adaptivních limitů EWMA (sloučení s výchozími)
            ewma_cfg = dict(EWMA_DEFAULTS)
            if isinstance(machine_ewma_cfg, dict):
                for k in ("enabled", "lambda", "l_warn", "l_alarm", "min_n"):
                    if machine_ewma_cfg.get(k) is not None:
                        ewma_cfg[k] = machine_ewma_cfg[k]
            ewma_enabled = ewma_cfg.get("enabled") is not False

            # limity rychlosti vibrací z ISO normy (A/B -> ab, B/C -> warning,
            # C/D -> alarm). Norma se řeší VŽDY per ložisko: jeden stroj může
            # mít v režimu "multi" několik přiřazení pro disjunktní skupiny
            # ložisek, takže jedna hodnota na úrovni stroje by je přepsala.
            _norm_cache = {}

            def _bearing_iso_limits(bkey, _norm=machine_iso_norm, _c=_norm_cache):
                if not _norm:
                    return None
                if bkey in _c:
                    return _c[bkey]
                try:
                    import ai_eval as _aie
                    lim = _aie.iso_limits_from_norm(_norm, bearing_key=bkey)
                except Exception:
                    lim = None
                _c[bkey] = lim
                return lim

            # souhrn na úrovni stroje má smysl jen v režimu "single";
            # v režimu "multi" vrací iso_limits_from_norm(bez ložiska) None
            iso_limits = _bearing_iso_limits(None)

            # ---- přednačtení všech buněk a trendů stroje (1 dotaz místo N) ----
            # Místo dotazu na buňky per bod a trendu per buňka načteme buňky
            # všech měřicích bodů stroje jedním dotazem a trendy statických
            # buněk hromadně (trend_batch). Odstraňuje problém N+1 dotazů.
            point_ids = [p["ID"] for p in points]
            cells_by_point = {pid: [] for pid in point_ids}
            if point_ids:
                ph_pts = ",".join("?" for _ in point_ids)
                cell_rows = self._con.execute(
                    f"SELECT ID, Name, DataType, Limits, Parent "
                    f"FROM Tbl_Cell WHERE Parent IN ({ph_pts}) ORDER BY Parent, ID",
                    tuple(point_ids),
                ).fetchall()
            else:
                cell_rows = []
            static_cell_ids = []
            for cr in cell_rows:
                cells_by_point.setdefault(cr["Parent"], []).append(cr)
                if cr["DataType"] in STATIC_DATATYPES:
                    static_cell_ids.append(cr["ID"])
            # hromadné načtení trendů (jen když jsou potřeba – poslední hodnota
            # se zobrazuje vždy, EWMA jen když je zapnuté)
            trends_by_cell = self.trend_batch(static_cell_ids)

            # ---- seskupení měřicích míst podle ložiska ----
            groups = {}
            group_order = []
            for p in points:
                bkey, blabel, direction = bearing_key(p["Name"])
                if bkey not in groups:
                    groups[bkey] = {
                        "bearing_key": bkey,
                        "label": blabel,
                        "points": [],
                        "quantities": {},
                    }
                    group_order.append(bkey)
                g = groups[bkey]

                cells = cells_by_point.get(p["ID"], [])
                point_quantities = []
                for c in cells:
                    if c["DataType"] not in STATIC_DATATYPES:
                        continue  # limity jen na trendové (skalární) veličiny
                    name = c["Name"]
                    db_w, db_a = self._db_limit_pair(parse_cell_limits(c["Limits"]))
                    point_quantities.append({
                        "name": name,
                        "cell_id": c["ID"],
                        "kind": "trend",
                    })
                    if name not in g["quantities"]:
                        g["quantities"][name] = {
                            "name": name,
                            "cell_ids": [],
                            "db_warning": db_w,
                            "db_alarm": db_a,
                            "cells": [],   # per směr/bod: poslední hodnota + EWMA
                        }
                    gq = g["quantities"][name]
                    gq["cell_ids"].append(c["ID"])
                    if gq["db_warning"] is None and db_w is not None:
                        gq["db_warning"] = db_w
                    if gq["db_alarm"] is None and db_a is not None:
                        gq["db_alarm"] = db_a

                    # poslední naměřená hodnota + adaptivní limit EWMA z trendu
                    # této buňky (per směr/bod). Rychlost vibrací se vylučuje.
                    # Trend se bere z přednačtené dávky (bez dalšího SQL dotazu).
                    trend_pts = trends_by_cell.get(c["ID"], [])
                    last_v = trend_pts[-1]["value"] if trend_pts else None
                    last_t = trend_pts[-1]["t"] if trend_pts else None
                    ew = None
                    if (ewma_enabled and trend_pts
                            and not is_velocity_quantity(name)):
                        ew = ewma_limits(
                            [pp["value"] for pp in trend_pts],
                            lam=ewma_cfg.get("lambda"),
                            l_warn=ewma_cfg.get("l_warn"),
                            l_alarm=ewma_cfg.get("l_alarm"),
                            min_n=ewma_cfg.get("min_n"),
                        )
                    gq["cells"].append({
                        "cell_id": c["ID"],
                        "point_id": p["ID"],
                        "point_name": p["Name"],
                        "direction": direction,
                        "last_value": last_v,
                        "last_time": last_t,
                        "n_trend": len(trend_pts),
                        "ewma_warning": (ew or {}).get("warning"),
                        "ewma_alarm": (ew or {}).get("alarm"),
                        "ewma_mean": (ew or {}).get("mean"),
                        "ewma_n": (ew or {}).get("n"),
                    })

                sev = pt_sev.get(p["ID"])
                speed = p["Speed_Hz"]
                if speed is not None and (not math.isfinite(speed) or speed > 1e30):
                    speed = None
                g["points"].append({
                    "id": p["ID"],
                    "name": p["Name"],
                    # Přenes stabilní identitu do spotřebitelů dat; report
                    # pak neporovnává lidský popis ani nehádá podobný bod.
                    "bearing_key": bkey,
                    "direction": direction,
                    "speed_hz": speed,
                    "severity_id": sev,
                    "severity_name": sev_map.get(sev, {}).get("name") if sev else None,
                    "color": sev_map.get(sev, {}).get("color") if sev else None,
                    "quantities": point_quantities,
                })

            # ---- složení výstupního seznamu ložisek vč. přepisů ----
            bearing_list = []
            for bkey in group_order:
                g = groups[bkey]
                over = machine_over.get(bkey, {}) if machine_over else {}
                over_limits = (over or {}).get("limits", {}) or {}
                over_bearing = (over or {}).get("bearing")
                # příznak klasifikace celého ložiska (výchozí True)
                bearing_classify = (over or {}).get("classify")
                bearing_classify = (bearing_classify is not False)
                # limity z normy přiřazené PRÁVĚ TOMUTO ložisku (režim "multi");
                # ložisko, které není v žádném přiřazení, normu nedostane
                b_iso_limits = _bearing_iso_limits(bkey)

                quantities = []
                for qname, q in g["quantities"].items():
                    ov = over_limits.get(qname) or {}
                    ov_w = ov.get("warning")
                    ov_a = ov.get("alarm")
                    # hranice A/B (z norem se třemi mezemi); ručně uložená hodnota
                    ov_ab = ov.get("ab")
                    # per-veličina příznak klasifikace (výchozí True); pokud je
                    # vypnuta klasifikace celého ložiska, je vypnuta i u veličiny
                    q_classify = ov.get("classify")
                    q_classify = (q_classify is not False) and bearing_classify
                    # automaticky a vždy: limity ISO RMS se odvozují z normy,
                    # pokud je nastavena třída stroje (přepíšou ruční hodnoty)
                    from_norm = False
                    if b_iso_limits and qname == "ISO RMS":
                        ov_w = b_iso_limits.get("warning")
                        ov_a = b_iso_limits.get("alarm")
                        ov_ab = b_iso_limits.get("ab")
                        from_norm = True
                    overridden = (ov_w is not None) or (ov_a is not None)
                    eff_w = ov_w if ov_w is not None else q["db_warning"]
                    # Je-li limit odvozen z normy (from_norm), je norma
                    # autoritativní: chybí-li mez C/D (alarm=None, např.
                    # ISO 14694 BV-1/BV-2), NESMÍ se doplnit z databáze –
                    # klasifikuje se pak jen do pásem A/B/C.
                    if from_norm:
                        eff_a = ov_a
                    else:
                        eff_a = ov_a if ov_a is not None else q["db_alarm"]
                    # nejvyšší adaptivní limit (EWMA) napříč směry – pro tlačítko
                    # „Převzít“ (ruční limit je sdílený přes směry, bere se max)
                    cell_list = q.get("cells", [])
                    ew_warns = [cc["ewma_warning"] for cc in cell_list
                                if cc.get("ewma_warning") is not None]
                    ew_alarms = [cc["ewma_alarm"] for cc in cell_list
                                 if cc.get("ewma_alarm") is not None]
                    ewma_warning_max = max(ew_warns) if ew_warns else None
                    ewma_alarm_max = max(ew_alarms) if ew_alarms else None
                    quantities.append({
                        "name": qname,
                        "cell_ids": q["cell_ids"],
                        "db_warning": q["db_warning"],
                        "db_alarm": q["db_alarm"],
                        "warning": eff_w,
                        "alarm": eff_a,
                        "ab": ov_ab,
                        "overridden": overridden,
                        "from_norm": from_norm,
                        "classify": q_classify,
                        "is_velocity": is_velocity_quantity(qname),
                        "cells": cell_list,
                        "ewma_warning_max": ewma_warning_max,
                        "ewma_alarm_max": ewma_alarm_max,
                    })

                sev_ids = [pt["severity_id"] for pt in g["points"]
                           if pt["severity_id"]]
                worst = max(sev_ids) if sev_ids else None

                bearing_list.append({
                    "bearing_key": bkey,
                    "label": g["label"],
                    "points": g["points"],
                    "quantities": quantities,
                    "bearing": over_bearing,
                    "classify": bearing_classify,
                    "iso_limits": b_iso_limits,
                    "severity_id": worst,
                    "severity_name": sev_map.get(worst, {}).get("name") if worst else None,
                    "color": sev_map.get(worst, {}).get("color") if worst else None,
                })

            mspeed = r["Speed_Hz"]
            if mspeed is not None and (not math.isfinite(mspeed) or mspeed > 1e30):
                mspeed = None
            # platné otáčky: uživatelský přepis má přednost před hodnotou z DB
            eff_speed = machine_speed_override if machine_speed_override is not None else mspeed
            machines.append({
                "id": r["ID"],
                "name": r["Name"],
                "parent": r["Parent"],
                "parent_name": parent_name,
                "speed_hz": eff_speed,
                "db_speed_hz": mspeed,
                "speed_overridden": machine_speed_override is not None,
                "speed_history": machine_speed_history,
                "iso_norm": machine_iso_norm,
                "iso_limits": iso_limits,
                "ai_eval": machine_ai_eval,
                "ai_eval_history": machine_ai_history,
                "card": machine_card,
                "ewma": ewma_cfg,
                "bearings": bearing_list,
            })
        return {"machines": machines, "severities": list(sev_map.values())}

    # ---------- sběr dat stroje pro AI vyhodnocení ----------
    def machine_ai_data(self, machine_id, overrides=None, trend_points=5,
                        spectrum_detail=None, speed_hz=None, with_sister=True):
        """Sestaví kompaktní přehled dat stroje pro AI diagnostiku.

        Pro každý měřicí bod a každou statickou (skalární) veličinu vrátí:
        poslední naměřenou hodnotu + čas, PLNÝ původ limitů (mez A/B, varování,
        alarm, zda pochází z normy či ručního přepisu, a jaké limity má samotná
        databáze přístroje), vypočtené pásmo A–D a krátký trend (posledních
        `trend_points` hodnot).

        Pro každé spektrum vrátí kromě overall také DETERMINISTICKY spočtené
        nálezy (`fft_analysis.analyze_spectrum`): nejvyšší vrcholy s řádem
        otáčkové frekvence, amplitudy na otáčkové frekvenci a harmonických a
        amplitudy na poruchových frekvencích přiřazeného ložiska.

        `spectrum_detail` volí podrobnost (viz `fft_analysis`); None znamená
        odvodit ji z nejhoršího pásma stroje. `speed_hz` jsou platné otáčky
        z karty stroje; bez nich se použijí otáčky z databáze.

        Vrací slovník vhodný k serializaci do JSON a vložení do promptu.
        """
        all_over = overrides or {}
        mrow = self._con.execute(
            "SELECT ID, Name, Parent, Speed_Hz FROM Tbl_Tree WHERE ID=? AND Type=2",
            (machine_id,),
        ).fetchone()
        if not mrow:
            return None
        parent = self._con.execute(
            "SELECT Name FROM Tbl_Tree WHERE ID=?", (mrow["Parent"],)
        ).fetchone()

        sev_map = {s["id"]: s for s in self.severities()}
        points = self._con.execute(
            "SELECT ID, Name, Speed_Hz FROM Tbl_Tree WHERE Parent=? AND Type=3 "
            "ORDER BY SortId, ID",
            (machine_id,),
        ).fetchall()

        # přiřazená ložiska (z přepisů stroje) — potřebujeme je už při analýze
        # spekter, aby šlo spočítat poruchové frekvence daného měřicího místa
        mover_all = all_over.get(str(machine_id), {}) or {}
        mover = mover_all.get("bearings", {}) or {}
        # Kinematika z karty stroje: počty lopatek, zubů, pólů a rozměry
        # řemenového převodu. Bez nich zůstane HADS u odhadu ze spektra.
        kinematics = mover_all.get("kinematics") or None
        # Baseline (známý dobrý stav) a sesterský stroj — opory, které
        # metodologie E.1 řadí NAD hodnocení podle normy.
        baseline_cfg = mover_all.get("baseline") or None
        baseline_time = (baseline_cfg or {}).get("time")
        sister_id = mover_all.get("sister_machine_id")
        bearings_assigned = []
        bearing_by_key = {}
        for bkey, bcfg in mover.items():
            b = (bcfg or {}).get("bearing")
            if b:
                bearings_assigned.append({"bearing_key": bkey, **b})
                bearing_by_key[bkey] = b

        mspeed = mrow["Speed_Hz"]
        if mspeed is not None and (not math.isfinite(mspeed) or mspeed > 1e30):
            mspeed = None
        # Otáčky pro přepočet na řády: karta stroje má přednost před databází,
        # stejně jako ve spektrech zobrazovaných v aplikaci.
        eff_speed = _positive_or_none(speed_hz)
        if eff_speed is None:
            eff_speed = _positive_or_none(mover_all.get("speed_hz"))
        if eff_speed is None:
            eff_speed = _positive_or_none(mspeed)
        # Detekce ze spektra se zapisuje do historie hned, ale do platných
        # otáček až po uložení karty. Bez tohoto upozornění vypadá stroj
        # v podkladech jako „otáčky nezadány“, přestože je diagnostik už
        # detekoval a myslí si, že jsou nastavené.
        detected_hz = None
        if eff_speed is None:
            history = mover_all.get("speed_history") or []
            for record in history:
                value = _positive_or_none((record or {}).get("value"))
                if value is not None:
                    detected_hz = {"value": value, "time": record.get("time")}
                    break

        out_points = []
        pending_spectra = []    # (spektrum, čáry po HP filtru, krok, ložisko)
        pending_waveforms = []  # (cíl, id buňky, název) – dekóduje se později
        for p in points:
            bkey, blabel, direction = bearing_key(p["Name"])
            cells = self._con.execute(
                "SELECT ID, Name, DataType, Limits, LastMeasured, "
                "MaxSeverityId, LastValSeverityId "
                "FROM Tbl_Cell WHERE Parent=? ORDER BY ID",
                (p["ID"],),
            ).fetchall()

            quantities = []      # statické veličiny (trendy)
            spectra = []         # parametry posledních spekter
            waveforms = []       # znaky časové vlny (doplní se po určení úrovně)
            for c in cells:
                dt = c["DataType"]
                if dt in STATIC_DATATYPES:
                    eff = self.cell_effective_limits(c["ID"], overrides=all_over) or {}
                    trend = self.trend(c["ID"])
                    recent = trend[-trend_points:] if trend else []
                    last = recent[-1] if recent else None
                    sev = c["LastValSeverityId"] or c["MaxSeverityId"]
                    value = last["value"] if last else None
                    quantities.append({
                        "name": c["Name"],
                        "unit": _quantity_unit(c["Name"]),
                        "last_value": value,
                        "last_time": last["t"] if last else None,
                        # platné meze (norma > ruční přepis > databáze přístroje)
                        "ab": eff.get("ab"),
                        "warning": eff.get("warning"),
                        "alarm": eff.get("alarm"),
                        # meze uložené přímo v .ndb — pro porovnání, když je
                        # platná mez odjinud (viz `limit_source`)
                        "db_warning": eff.get("db_warning"),
                        "db_alarm": eff.get("db_alarm"),
                        "limit_overridden": eff.get("overridden", False),
                        "limit_source": _limit_source(eff),
                        "band": _band_for(value, eff),
                        "severity": sev_map.get(sev, {}).get("name") if sev else None,
                        "recent_trend": recent,
                        # Opory hodnocení nad rámec normy (metodologie E.1):
                        # rychlost změny z CELÉHO trendu a hodnota v době
                        # známého dobrého stavu.
                        "trend_rate": _trend_rate(trend),
                        "baseline": _baseline_entry(trend, baseline_time, value),
                    })
                elif dt in SPECTRUM_DATATYPES:
                    rec = self._con.execute(
                        "SELECT ID, Time, Data, DataLength, DataStep, Speed_Hz "
                        "FROM Tbl_Cell_Dyns WHERE CellId=? ORDER BY Time DESC LIMIT 1",
                        (c["ID"],),
                    ).fetchone()
                    if not rec:
                        continue
                    vals = parse_dynamic_blob(rec["Data"], rec["DataLength"])
                    step = rec["DataStep"] or 1.0
                    overall = None
                    vals_hp = None
                    if vals and step > 0:
                        vals_hp = apply_highpass(vals, step, HP_CUTOFF_HZ)
                        overall = spectrum_overall(vals_hp, step, HP_CUTOFF_HZ)
                    spd = rec["Speed_Hz"]
                    if spd is not None and (not math.isfinite(spd) or spd > 1e30 or spd <= 0):
                        spd = None
                    entry = {
                        "name": c["Name"],
                        "overall": overall,
                        "time": ms2000_to_iso(rec["Time"]),
                        "speed_hz": spd,
                        "lines": rec["DataLength"],
                        "line_width": step,
                        # Role řídí, co se ze spektra vůbec vyvozuje: řády 1×
                        # jen z rychlosti, ložiska a ozubení jen ze zrychlení
                        # a obálky (metodologie A.5).
                        "role": fft_analysis.spectrum_role(c["Name"]),
                    }
                    spectra.append(entry)
                    if vals_hp:
                        pending_spectra.append(
                            (entry, vals_hp, step, bearing_by_key.get(bkey)))
                elif dt in TIME_DATATYPES:
                    # Vlastní dekódování až po určení úrovně podrobnosti:
                    # časový záznam má desítky tisíc vzorků a u stroje
                    # v pásmu A nemá smysl jej vůbec číst.
                    pending_waveforms.append((waveforms, c["ID"], c["Name"]))

            out_points.append({
                "name": p["Name"],
                "bearing_key": bkey,
                "direction": direction,
                "quantities": quantities,
                "spectra": spectra,
                "waveforms": waveforms,
            })

        # Nejhorší pásmo stroje řídí, kolik spektrálních podkladů má smysl
        # posílat. Je to POUZE měřítko podrobnosti promptu — nikdy se nikam
        # nevykazuje a nenahrazuje kanonický stav stroje z report.py.
        worst = _worst_band(out_points)
        level = spectrum_detail or fft_analysis.detail_level_for_band(worst)

        tol = _tolerances()
        analyses = []
        for entry, vals_hp, step, bearing in pending_spectra:
            spectrum_speed = eff_speed or entry.get("speed_hz")
            analysis = fft_analysis.analyze_spectrum(
                vals_hp, step, speed_hz=spectrum_speed,
                bearing=bearing, level=level, overall=entry.get("overall"),
                role=entry.get("role"), kinematics=kinematics, **tol)
            entry["analysis"] = analysis
            # Vhodnost rozsahu a rozlišení (metodologie B.2) — bez ní může být
            # závěr o ložisku neplatný, i když je spektrum jinak v pořádku.
            entry["range"] = fft_analysis.range_adequacy(
                step, entry.get("lines"), spectrum_speed,
                fft_analysis.bearing_defect_frequencies(bearing, spectrum_speed),
                role=entry.get("role"))
            analyses.append(analysis)
        truncated = fft_analysis.apply_machine_budget(analyses)

        # Časové vlny až tady: u stroje v pásmu A se desítky tisíc vzorků
        # vůbec nedekódují (metodologie C.7 je vyžaduje jen k rozlišení
        # přidírání a lokálních defektů, což u zdravého stroje neřešíme).
        if level == fft_analysis.LEVEL_FULL:
            for target, cell_id, name in pending_waveforms:
                rec = self._con.execute(
                    "SELECT Time, Data, DataLength, DataStep FROM Tbl_Cell_Dyns "
                    "WHERE CellId=? ORDER BY Time DESC LIMIT 1", (cell_id,)
                ).fetchone()
                if not rec:
                    continue
                metrics = fft_analysis.waveform_metrics(
                    parse_dynamic_blob(rec["Data"], rec["DataLength"]),
                    rec["DataStep"])
                if metrics:
                    target.append({"name": name,
                                   "time": ms2000_to_iso(rec["Time"]),
                                   **metrics})

        # Směrovost H/V/A na každém ložisku (metodologie krok C.5). Bere se
        # z rychlosti vibrací, která je pro tento rozbor referenční veličinou.
        directions = _direction_profiles(out_points)

        # Kontrola 1× z kroku C.1 patří na úroveň STROJE: zdravé spektrum
        # rychlosti nemusí mít 2× ani 3×, zatímco ve spektru zrychlení jsou.
        # Per spektrum by tato kontrola falešně varovala u většiny strojů.
        speed_confirmed = None
        if eff_speed:
            checked = [a.get("pattern", {}) for a in analyses
                       if (a.get("pattern") or {}).get("running_speed_amplitude")]
            if checked:
                speed_confirmed = any(p.get("running_speed_confirmed")
                                      for p in checked)

        stages = _bearing_stages(out_points)
        worst_stage = max((s["stage"] for s in stages), default=None)
        ratio = max((((a.get("pattern") or {}).get("ratio_2x_1x") or 0.0)
                     for a in analyses), default=0.0) or None
        rising = any(_is_rising(q.get("recent_trend"))
                     for point in out_points
                     for q in point.get("quantities") or [])
        priority_label, priority_reasons = fft_analysis.priority(
            worst, worst_stage, ratio, rising)
        directions_measured = max((len(d.get("values") or {})
                                   for d in directions), default=0)
        range_warnings = sum(len((s.get("range") or {}).get("warnings") or [])
                             for point in out_points
                             for s in point.get("spectra") or [])
        # Sesterský stroj vybírá diagnostik na kartě; sám se nedohledává, aby
        # se nesrovnávaly stroje, které si jen podobně jmenují. Načítá se BEZ
        # své vlastní sestry, aby nevznikl řetěz ani cyklus.
        sister = None
        if with_sister and sister_id:
            try:
                sister = self._sister_comparison(sister_id, all_over, out_points,
                                                 trend_points)
            except Exception:
                sister = None

        basis = fft_analysis.assessment_basis(
            has_trend=any(q.get("trend_rate") for point in out_points
                          for q in point.get("quantities") or []),
            has_baseline=bool(baseline_time),
            has_sister=bool(sister and sister.get("rows")),
            has_norm=bool(mover_all.get("iso_norm")))

        certainty_label, certainty_reasons = fft_analysis.certainty_ceiling(
            speed_known=bool(eff_speed),
            speed_confirmed=bool(speed_confirmed),
            directions=directions_measured,
            has_phase=False,          # .ndb fázi neobsahuje
            range_warnings=range_warnings)

        return {
            "machine_id": mrow["ID"],
            "machine_name": mrow["Name"],
            "parent_name": parent["Name"] if parent else None,
            "db_speed_hz": mspeed,
            "speed_hz_used": eff_speed,
            "speed_detected_unsaved": detected_hz,
            "spectrum_detail": level,
            "spectrum_rows_truncated": truncated,
            "worst_band": worst,
            "directions": directions,
            "speed_confirmed": speed_confirmed,
            "kinematics": kinematics,
            "baseline": baseline_cfg,
            "sister": sister,
            "assessment_basis": basis,
            "bearing_stages": stages,
            "priority": {"level": priority_label, "reasons": priority_reasons},
            "certainty": {"ceiling": certainty_label, "reasons": certainty_reasons},
            "motor": fft_analysis.induction_motor_context(eff_speed) if eff_speed else None,
            "points": out_points,
            "bearings_assigned": bearings_assigned,
        }

    def _sister_comparison(self, sister_id, all_over, points, trend_points):
        """Porovná veličiny stroje se shodným (sesterským) strojem.

        Metodologie E.1 řadí porovnání s identickým strojem za srovnatelných
        podmínek nad hodnocení podle normy. Který stroj je sesterský ale nelze
        odvodit z dat — vybírá jej diagnostik na kartě stroje, protože jen on
        ví, že jde o shodné provedení ve shodném provozu.

        Porovnává se podle DVOJICE ložisko + veličina, aby se nesrovnávala
        rychlost na jednom místě s obálkou na jiném.
        """
        node = self._con.execute(
            "SELECT ID, Name FROM Tbl_Tree WHERE ID=? AND Type=2", (sister_id,)
        ).fetchone()
        if not node:
            return {"machine_id": sister_id, "unavailable": "stroj nenalezen"}
        other = self.machine_ai_data(
            sister_id, overrides=all_over, trend_points=trend_points,
            spectrum_detail=fft_analysis.LEVEL_MINIMAL, with_sister=False)
        if not other:
            return {"machine_id": sister_id, "machine_name": node["Name"],
                    "unavailable": "data sesterského stroje nelze načíst"}

        reference = {}
        for point in other.get("points") or []:
            bkey = point.get("bearing_key")
            for quantity in point.get("quantities") or []:
                value = quantity.get("last_value")
                if bkey and value is not None:
                    # Nejvyšší hodnota přes směry — porovnává se stejný typ
                    # ukazatele, ne konkrétní směr, který se mezi stroji liší.
                    key = (bkey, quantity.get("name"))
                    if key not in reference or value > reference[key]:
                        reference[key] = value

        rows = []
        for point in points or []:
            bkey = point.get("bearing_key")
            for quantity in point.get("quantities") or []:
                key = (bkey, quantity.get("name"))
                if key not in reference:
                    continue
                verdict = fft_analysis.compare_to_reference(
                    quantity.get("last_value"), reference[key])
                if not verdict:
                    continue
                rows.append({"bearing_key": bkey,
                             # Bez směru by řádky téhož ložiska vypadaly jako
                             # duplicity; přitom H, V a A se legitimně liší.
                             "direction": point.get("direction"),
                             "quantity": quantity.get("name"),
                             "value": quantity.get("last_value"),
                             "reference": reference[key], **verdict})
        # Do promptu jde jen to, co se od sestry odlišuje; shoda napříč všemi
        # veličinami by zabrala desítky řádků a nic nesdělila.
        notable = [r for r in rows if r["verdict"] != "na úrovni reference"]
        notable.sort(key=lambda r: -r["ratio"])
        return {"machine_id": sister_id, "machine_name": node["Name"],
                "compared": len(rows), "rows": notable[:8]}

    # ---------- data jednoho měřicího bodu pro AI ----------
    def point_ai_data(self, point_id, overrides=None, trend_points=5,
                      speed_hz=None):
        """Sestaví kompaktní přehled dat JEDNOHO měřicího bodu pro AI diagnostiku.

        Obdoba `machine_ai_data`, ale jen pro jeden bod: stejný plný původ
        limitů (mez A/B, varování, alarm, zdroj meze, meze z databáze
        přístroje), stejné vypočtené pásmo A–D a stejné deterministické
        spektrální nálezy.

        Podrobnost je zde VŽDY plná: jde o jeden bod, který si diagnostik
        otevřel a cíleně zkoumá — na rozdíl od hromadné tvorby protokolu
        tu nemá smysl šetřit podklady.
        """
        all_over = overrides or {}
        prow = self._con.execute(
            "SELECT ID, Name, Parent, Speed_Hz FROM Tbl_Tree WHERE ID=? AND Type=3",
            (point_id,),
        ).fetchone()
        if not prow:
            return None
        mrow = self._con.execute(
            "SELECT ID, Name, Parent, Speed_Hz FROM Tbl_Tree WHERE ID=? AND Type=2",
            (prow["Parent"],),
        ).fetchone()
        parent = None
        if mrow:
            parent = self._con.execute(
                "SELECT Name FROM Tbl_Tree WHERE ID=?", (mrow["Parent"],)
            ).fetchone()

        sev_map = {s["id"]: s for s in self.severities()}
        bkey, blabel, direction = bearing_key(prow["Name"])

        cells = self._con.execute(
            "SELECT ID, Name, DataType, Limits, LastMeasured, "
            "MaxSeverityId, LastValSeverityId "
            "FROM Tbl_Cell WHERE Parent=? ORDER BY ID",
            (point_id,),
        ).fetchall()

        # přiřazené ložisko bodu (z přepisů stroje podle klíče ložiska) —
        # potřebujeme je už při analýze spekter kvůli poruchovým frekvencím
        assigned_bearing = None
        mover_all = {}
        if mrow:
            mover_all = all_over.get(str(mrow["ID"]), {}) or {}
            mover = mover_all.get("bearings", {}) or {}
            bcfg = mover.get(bkey) or {}
            b = (bcfg or {}).get("bearing")
            if b:
                assigned_bearing = {"bearing_key": bkey, **b}

        quantities = []      # statické veličiny (trendy)
        spectra = []         # parametry posledních spekter
        spectrum_speed_hz = None
        pending_spectra = []
        for c in cells:
            dt = c["DataType"]
            if dt in STATIC_DATATYPES:
                eff = self.cell_effective_limits(c["ID"], overrides=all_over) or {}
                trend = self.trend(c["ID"])
                recent = trend[-trend_points:] if trend else []
                last = recent[-1] if recent else None
                sev = c["LastValSeverityId"] or c["MaxSeverityId"]
                value = last["value"] if last else None
                quantities.append({
                    "name": c["Name"],
                    "unit": _quantity_unit(c["Name"]),
                    "last_value": value,
                    "last_time": last["t"] if last else None,
                    "ab": eff.get("ab"),
                    "warning": eff.get("warning"),
                    "alarm": eff.get("alarm"),
                    "db_warning": eff.get("db_warning"),
                    "db_alarm": eff.get("db_alarm"),
                    "limit_overridden": eff.get("overridden", False),
                    "limit_source": _limit_source(eff),
                    "band": _band_for(value, eff),
                    "severity": sev_map.get(sev, {}).get("name") if sev else None,
                    "recent_trend": recent,
                })
            elif dt in SPECTRUM_DATATYPES:
                rec = self._con.execute(
                    "SELECT ID, Time, Data, DataLength, DataStep, Speed_Hz "
                    "FROM Tbl_Cell_Dyns WHERE CellId=? ORDER BY Time DESC LIMIT 1",
                    (c["ID"],),
                ).fetchone()
                if not rec:
                    continue
                vals = parse_dynamic_blob(rec["Data"], rec["DataLength"])
                step = rec["DataStep"] or 1.0
                overall = None
                vals_hp = None
                if vals and step > 0:
                    vals_hp = apply_highpass(vals, step, HP_CUTOFF_HZ)
                    overall = spectrum_overall(vals_hp, step, HP_CUTOFF_HZ)
                spd = rec["Speed_Hz"]
                if spd is not None and (not math.isfinite(spd) or spd > 1e30 or spd <= 0):
                    spd = None
                entry = {
                    "name": c["Name"],
                    "overall": overall,
                    "time": ms2000_to_iso(rec["Time"]),
                    "speed_hz": spd,
                }
                spectra.append(entry)
                if vals_hp:
                    pending_spectra.append((entry, vals_hp, step))
                # otáčky ze spektra (přednostně ISO spektrum)
                if spd is not None and (
                    spectrum_speed_hz is None
                    or "ISO" in (c["Name"] or "").upper()
                ):
                    spectrum_speed_hz = spd

        eff_speed = (_positive_or_none(speed_hz)
                     or _positive_or_none(mover_all.get("speed_hz"))
                     or _positive_or_none(mrow["Speed_Hz"] if mrow else None)
                     or _positive_or_none(spectrum_speed_hz))
        tol = _tolerances()
        for entry, vals_hp, step in pending_spectra:
            entry["analysis"] = fft_analysis.analyze_spectrum(
                vals_hp, step, speed_hz=eff_speed or entry.get("speed_hz"),
                bearing=assigned_bearing, level=fft_analysis.LEVEL_FULL,
                overall=entry.get("overall"), **tol)

        def _clean(v):
            if v is not None and (not math.isfinite(v) or v > 1e30):
                return None
            return v

        db_speed = _clean(prow["Speed_Hz"])
        machine_speed = _clean(mrow["Speed_Hz"]) if mrow else None
        return {
            "point_id": prow["ID"],
            "point_name": prow["Name"],
            "machine_id": mrow["ID"] if mrow else None,
            "machine_name": mrow["Name"] if mrow else None,
            "parent_name": parent["Name"] if parent else None,
            "bearing_key": bkey,
            "bearing_label": blabel,
            "direction": direction,
            "db_speed_hz": db_speed,
            "machine_speed_hz": machine_speed,
            "spectrum_speed_hz": spectrum_speed_hz,
            "speed_hz_used": eff_speed,
            "spectrum_detail": fft_analysis.LEVEL_FULL,
            "quantities": quantities,
            "spectra": spectra,
            "assigned_bearing": assigned_bearing,
        }

    # ---------- autodetekce otáček ze spektra rychlosti (jeden bod) ----------
    def detect_point_speed_hz(self, point_id, fmin=5.0, fmax=70.0):
        """Odhadne otáčky [Hz] ze spektra rychlosti JEDNOHO měřicího bodu.

        Obdoba `detect_speed_hz`, ale prohledá pouze spektra daného bodu.
        Hledá nejvyšší amplitudu v pásmu <fmin, fmax> Hz v posledním pořízeném
        spektru rychlosti (přednostně ISO SPECTRUM, jinak DataType 7).

        Vrací {"speed_hz", "amplitude", "point_id", "point_name", "cell_id",
        "cell_name", "time", "fmin", "fmax"} nebo None.
        """
        prow = self._con.execute(
            "SELECT ID, Name FROM Tbl_Tree WHERE ID=? AND Type=3",
            (point_id,),
        ).fetchone()
        if not prow:
            return None

        cells = self._con.execute(
            "SELECT ID, Name, DataType FROM Tbl_Cell WHERE Parent=? "
            "AND DataType IN ({}) ORDER BY ID".format(
                ",".join(str(d) for d in SPECTRUM_DATATYPES)),
            (point_id,),
        ).fetchall()
        spec_cells = [c for c in cells if "ISO" in (c["Name"] or "").upper()]
        if not spec_cells:
            spec_cells = [c for c in cells if c["DataType"] == 7]

        best = None
        for c in spec_cells:
            rec = self._con.execute(
                "SELECT ID, Time, Data, DataLength, DataStep "
                "FROM Tbl_Cell_Dyns WHERE CellId=? ORDER BY Time DESC LIMIT 1",
                (c["ID"],),
            ).fetchone()
            if not rec:
                continue
            vals = parse_dynamic_blob(rec["Data"], rec["DataLength"])
            if not vals:
                continue
            step = rec["DataStep"] or 1.0
            if step <= 0:
                continue
            i_lo = max(1, int(math.ceil(fmin / step)))
            i_hi = min(len(vals) - 1, int(math.floor(fmax / step)))
            if i_hi < i_lo:
                continue
            local_best_i = i_lo
            local_best_v = vals[i_lo]
            for i in range(i_lo, i_hi + 1):
                if vals[i] > local_best_v:
                    local_best_v = vals[i]
                    local_best_i = i
            freq = round(local_best_i * step, 4)
            cand = {
                "speed_hz": freq,
                "amplitude": local_best_v,
                "point_id": prow["ID"],
                "point_name": prow["Name"],
                "cell_id": c["ID"],
                "cell_name": c["Name"],
                "time": ms2000_to_iso(rec["Time"]),
                "fmin": fmin,
                "fmax": fmax,
            }
            if best is None or cand["amplitude"] > best["amplitude"]:
                best = cand
        return best

    # ---------- přehled stavu (dashboard) ----------
    def status_overview(self, overrides=None):
        """Souhrn počtu měřicích bodů podle nejvyšší závažnosti.

        Závažnost bodu se počítá z POSLEDNÍ hodnoty vs. platné limity
        (norma > ruční přepis > DB) — viz `effective_point_severity()`.
        Body bez definovaných limitů/hodnoty se počítají jako Ok (1).

        Ke každému měřicímu bodu doplní `last_measured` = čas posledního
        naměřeného záznamu (ISO čas) a `last_measured_ms` (ms od 2000).
        Body, které nikdy neměly žádné měření (všechny buňky LastMeasured=0),
        mají `last_measured = None`.
        """
        sev_map = {s["id"]: s for s in self.severities()}
        eff_sev = self.effective_point_severity(overrides=overrides)
        rows = self._con.execute(
            "SELECT t.ID, t.Name, t.Parent, "
            "MAX(c.LastMeasured) AS last_ms "
            "FROM Tbl_Tree t JOIN Tbl_Cell c ON c.Parent=t.ID "
            "WHERE t.Type=3 GROUP BY t.ID"
        ).fetchall()
        counts = {}
        points = []
        for r in rows:
            sev = eff_sev.get(r["ID"]) or 1
            counts[sev] = counts.get(sev, 0) + 1
            # LastMeasured = 0 (nebo None) znamená „nikdy neměřeno"
            last_ms = r["last_ms"]
            if not last_ms or last_ms <= 0:
                last_ms = None
            points.append({
                "id": r["ID"],
                "name": r["Name"],
                "parent": r["Parent"],
                "severity_id": sev,
                "severity_name": sev_map.get(sev, {}).get("name"),
                "color": sev_map.get(sev, {}).get("color"),
                "last_measured": ms2000_to_iso(last_ms) if last_ms else None,
                "last_measured_ms": last_ms,
            })
        return {"counts": counts, "points": points, "severities": list(sev_map.values())}

    # ---------- autodetekce otáček ze spektra rychlosti ----------
    def detect_speed_hz(self, machine_id, fmin=5.0, fmax=70.0):
        """Odhadne otáčky stroje [Hz] ze spektra rychlosti vibrací.

        Hledá nejvyšší amplitudu v pásmu <fmin, fmax> Hz v posledním pořízeném
        spektru rychlosti (ISO SPECTRUM, DataType 7) měřicích bodů stroje.
        Prohledá všechny body stroje a vrátí kandidáta s nejvyšší amplitudou.

        Vrací {"speed_hz", "amplitude", "point_id", "point_name", "cell_id",
        "cell_name", "time", "fmin", "fmax"} nebo None, pokud žádné spektrum
        rychlosti není.
        """
        points = self._con.execute(
            "SELECT ID, Name FROM Tbl_Tree WHERE Parent=? AND Type=3 "
            "ORDER BY SortId, ID",
            (machine_id,),
        ).fetchall()
        if not points:
            return None

        best = None
        for p in points:
            cells = self._con.execute(
                "SELECT ID, Name, DataType FROM Tbl_Cell WHERE Parent=? "
                "AND DataType IN ({}) ORDER BY ID".format(
                    ",".join(str(d) for d in SPECTRUM_DATATYPES)),
                (p["ID"],),
            ).fetchall()
            # spektrum rychlosti = ISO SPECTRUM (název obsahuje „ISO"),
            # jinak první spektrum typu rychlosti (DataType 7)
            spec_cells = [c for c in cells if "ISO" in (c["Name"] or "").upper()]
            if not spec_cells:
                spec_cells = [c for c in cells if c["DataType"] == 7]
            for c in spec_cells:
                rec = self._con.execute(
                    "SELECT ID, Time, Data, DataLength, DataStep "
                    "FROM Tbl_Cell_Dyns WHERE CellId=? ORDER BY Time DESC LIMIT 1",
                    (c["ID"],),
                ).fetchone()
                if not rec:
                    continue
                vals = parse_dynamic_blob(rec["Data"], rec["DataLength"])
                if not vals:
                    continue
                step = rec["DataStep"] or 1.0
                if step <= 0:
                    continue
                i_lo = max(1, int(math.ceil(fmin / step)))
                i_hi = min(len(vals) - 1, int(math.floor(fmax / step)))
                if i_hi < i_lo:
                    continue
                local_best_i = i_lo
                local_best_v = vals[i_lo]
                for i in range(i_lo, i_hi + 1):
                    if vals[i] > local_best_v:
                        local_best_v = vals[i]
                        local_best_i = i
                freq = round(local_best_i * step, 4)
                cand = {
                    "speed_hz": freq,
                    "amplitude": local_best_v,
                    "point_id": p["ID"],
                    "point_name": p["Name"],
                    "cell_id": c["ID"],
                    "cell_name": c["Name"],
                    "time": ms2000_to_iso(rec["Time"]),
                    "fmin": fmin,
                    "fmax": fmax,
                }
                if best is None or cand["amplitude"] > best["amplitude"]:
                    best = cand
        return best
