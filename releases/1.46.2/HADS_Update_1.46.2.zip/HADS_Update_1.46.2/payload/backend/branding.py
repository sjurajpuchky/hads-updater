# -*- coding: utf-8 -*-
"""Personalizace vydavatele protokolů (logo + údaje do patičky).

MOTIVACE
--------
Do verze 1.39.1 bylo logo natvrdo v ``backend/assets/heistech_logo.jpg`` a
údaje patičky natvrdo v ``report.DEFAULT_FOOTER``.  Firma, která protokoly
vydává, je ale vlastností INSTALACE HADS, ne programu — každý zákazník chce
v protokolu vlastní logo a vlastní podpis v patičce.

Proč NE ``backend/assets/``: aktualizátor má ``backend/`` mezi
``CONTROLLED_ROOTS`` a při každé aktualizaci celou složku vymění.  Vlastní logo
uložené tam by se při první aktualizaci nenávratně ztratilo.  Personalizace
proto žije výhradně v ``data/``, kterou aktualizace nikdy nemění, kterou
``data_protection.py`` inventarizuje a kterou aktualizátor zálohuje
(``_copy_persistent_small_files``).

ÚLOŽIŠTĚ (globální pro celou instalaci, ne per-podnik)
------------------------------------------------------
    data/branding/settings.json   – texty vydavatele
    data/branding/logo.jpg        – vlastní logo (výhradně JPEG)

``data/podniky/<podnik>/company.json`` zůstává tím, čím byl: ZÁKAZNÍK, jehož
stroje se měří.  Tento modul popisuje naopak firmu, která protokol VYDÁVÁ.

Vestavěné výchozí hodnoty jsou zachovány beze změny, takže existující instalace
se bez zásahu uživatele chová přesně jako dosud.

Používá POUZE standardní knihovnu Pythonu.
"""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import threading
import time
import uuid
from typing import Any

import pdf_writer


DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DIR_NAME = "branding"
FILE_NAME = "settings.json"
LOGO_NAME = "logo.jpg"
FORMAT = 1
_LOCK = threading.RLock()

# Vestavěné logo dodávané s programem; slouží jako záloha, dokud si uživatel
# nenahraje vlastní. Leží v programové (aktualizací měněné) složce záměrně —
# je součástí vydání, nikoli uživatelských dat.
_ASSET_DIR = Path(__file__).resolve().parent / "assets"
_BUILTIN_LOGO_NAMES = ("heistech_logo.jpg", "heistech_logo.jpeg", "logo.jpg")

# Shodné s historickým report.DEFAULT_FOOTER / DEFAULT_APPROVED_BY, aby
# aktualizace stávající instalace nezměnila vzhled jediného protokolu.
DEFAULT_ISSUER = {
    "brand": "HEISTECH",
    "company": "Heistech, s.r.o.",
    "address": "Dobrkovice 111, 763 07 Dobrkovice",
    "web": "www.heistech.cz",
    "approved_by": "Ing. Lukáš Heisig, Ph.D. CTD",
}

_FIELD_LIMITS = {
    "brand": 40,       # kreslí se velkým písmem do hlavičky, musí se vejít
    "company": 120,
    "address": 160,
    "web": 120,
    "approved_by": 120,
}

# Logo musí zůstat malé: kopíruje se do každé zálohy aktualizace, kde je limit
# CONFIG_BACKUP_MAX_BYTES = 10 MB. 2 MB je pro logo víc než dost.
MAX_LOGO_BYTES = 2 * 1024 * 1024
MAX_LOGO_EDGE = 10000


# ---------------------------------------------------------------------------
# cesty (funkce, aby je testy i přenosný bootstrap mohly přesměrovat)
# ---------------------------------------------------------------------------

def _dir() -> Path:
    return DATA_DIR / DIR_NAME


def _settings_path() -> Path:
    return _dir() / FILE_NAME


def _logo_path() -> Path:
    return _dir() / LOGO_NAME


# ---------------------------------------------------------------------------
# normalizace textů
# ---------------------------------------------------------------------------

def _clean_line(value: Any, limit: int) -> str:
    """Jednořádkový bezpečný text: bez řídicích znaků, oříznutý na limit."""
    text = "" if value is None else str(value)
    # Vložený víceřádkový text (např. adresa ze schránky) se spojí mezerou,
    # ostatní neviditelné řídicí znaky se zahodí.
    text = "".join(" " if ch.isspace() else ch for ch in text if ch.isspace() or ch.isprintable())
    text = " ".join(text.split())
    return text[:limit].strip()


def _normalize_issuer(rec: Any) -> dict[str, str]:
    """Doplní chybějící pole vestavěnou výchozí hodnotou.

    Prázdné pole VŽDY znamená „použij výchozí“ — protokol tak nikdy nezůstane
    bez názvu firmy jen proto, že uživatel pole vymazal.
    """
    out = dict(DEFAULT_ISSUER)
    if isinstance(rec, dict):
        for key, limit in _FIELD_LIMITS.items():
            value = _clean_line(rec.get(key), limit)
            if value:
                out[key] = value
    return out


def _is_default(issuer: dict[str, str]) -> bool:
    return all(issuer.get(k) == v for k, v in DEFAULT_ISSUER.items())


# ---------------------------------------------------------------------------
# perzistence
# ---------------------------------------------------------------------------

def _read_state() -> dict[str, Any]:
    path = _settings_path()
    try:
        # utf-8-sig: soubor uložený z Poznámkového bloku nebo protažený
        # synchronizačním nástrojem může mít BOM. Bez toho by se personalizace
        # TIŠE vrátila na výchozí hodnoty, což je přesně ta ztráta nastavení,
        # které se chceme vyhnout.
        raw = json.loads(path.read_text(encoding="utf-8-sig")) if path.is_file() else None
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        # Poškozené nastavení nikdy nemaže logo ani nebrání vytvoření
        # protokolu — bezpečně se použijí výchozí texty.
        raw = None
    return raw if isinstance(raw, dict) else {}


def _atomic_write_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temporary.open("wb") as stream:
            stream.write(payload)
            stream.flush()
            try:
                os.fsync(stream.fileno())
            except OSError:
                pass
        os.replace(temporary, path)
    finally:
        try:
            temporary.unlink()
        except OSError:
            pass


def _write_state(state: dict[str, Any]) -> None:
    payload = json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    _atomic_write_bytes(_settings_path(), payload.encode("utf-8"))


# ---------------------------------------------------------------------------
# logo
# ---------------------------------------------------------------------------

def _builtin_logo_bytes() -> bytes | None:
    for name in _BUILTIN_LOGO_NAMES:
        candidate = _ASSET_DIR / name
        if candidate.is_file() and not candidate.is_symlink():
            try:
                return candidate.read_bytes()
            except OSError:
                continue
    return None


def _custom_logo_bytes() -> bytes | None:
    path = _logo_path()
    try:
        if path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_LOGO_BYTES:
            return path.read_bytes()
    except OSError:
        pass
    return None


def logo_bytes() -> bytes | None:
    """JPEG bajty loga do protokolu: vlastní, jinak vestavěné, jinak None.

    Volá se při každém vykreslení PDF/DOCX, takže změna loga v Nastavení se
    projeví i u znovu vygenerovaného protokolu z historie.
    """
    return _custom_logo_bytes() or _builtin_logo_bytes()


def _decode_jpeg_data_url(data_url: Any) -> bytes:
    """Ověří data URL a vrátí JPEG bajty; jinak vyhodí ValueError s českým textem.

    Přijímáme výhradně JPEG: generátor PDF (``pdf_writer.image_jpeg``) jiný
    formát neumí vložit. Frontend proto PNG předem převede na JPEG.
    """
    text = data_url if isinstance(data_url, str) else ""
    if "," not in text:
        raise ValueError("Logo nebylo předáno v očekávaném formátu.")
    head, encoded = text.split(",", 1)
    if "image/jpeg" not in head and "image/jpg" not in head:
        raise ValueError("Logo musí být ve formátu JPEG.")
    try:
        raw = base64.b64decode(encoded, validate=True)
    except Exception:
        raise ValueError("Obsah loga se nepodařilo dekódovat.") from None
    if not raw:
        raise ValueError("Soubor s logem je prázdný.")
    if len(raw) > MAX_LOGO_BYTES:
        raise ValueError("Logo je příliš velké; maximum je 2 MB.")
    if raw[:2] != b"\xff\xd8":
        raise ValueError("Soubor není platný JPEG.")
    try:
        width, height, components = pdf_writer._jpeg_info(raw)
    except Exception:
        raise ValueError("Soubor není platný JPEG.") from None
    if not (0 < width <= MAX_LOGO_EDGE and 0 < height <= MAX_LOGO_EDGE):
        raise ValueError("Logo má nepodporované rozměry.")
    if components not in (1, 3):
        # CMYK JPEG by se v PDF i DOCX vykreslil s posunutými barvami.
        raise ValueError("Logo musí být v odstínech šedi nebo RGB, nikoli CMYK.")
    return raw


def _logo_info() -> dict[str, Any]:
    """Popis loga pro UI. Nikdy nevrací bajty — ty má samostatná funkce."""
    raw = _custom_logo_bytes()
    if raw is None:
        builtin = _builtin_logo_bytes()
        return {"source": "builtin" if builtin else "none",
                "present": builtin is not None}
    info: dict[str, Any] = {"source": "custom", "present": True, "bytes": len(raw)}
    try:
        width, height, _components = pdf_writer._jpeg_info(raw)
        info["width"] = width
        info["height"] = height
    except Exception:
        # Nečitelné vlastní logo hlásíme, ale nemažeme; vykreslení použije
        # vestavěné a uživatel může nahrát nové.
        info["source"] = "invalid"
    try:
        info["updated_at"] = _logo_path().stat().st_mtime
    except OSError:
        pass
    return info


def logo_data_url() -> str:
    """Náhled loga pro Nastavení (data URL), nebo prázdný řetězec."""
    raw = logo_bytes()
    if not raw:
        return ""
    return "data:image/jpeg;base64," + base64.b64encode(raw).decode("ascii")


# ---------------------------------------------------------------------------
# veřejné API
# ---------------------------------------------------------------------------

def issuer() -> dict[str, str]:
    """Údaje vydavatele protokolů (vždy plná struktura s výchozími hodnotami)."""
    with _LOCK:
        return _normalize_issuer(_read_state().get("issuer"))


def footer() -> dict[str, str]:
    """Patička protokolu ve tvaru, který očekává ``report_pdf`` / ``report_docx``."""
    rec = issuer()
    return {"brand": rec["brand"], "company": rec["company"],
            "address": rec["address"], "web": rec["web"]}


def approved_by() -> str:
    """Výchozí jméno do pole „Schválil“ nového návrhu protokolu."""
    return issuer()["approved_by"]


def get() -> dict[str, Any]:
    """Kompletní stav personalizace pro Nastavení (bez bajtů loga)."""
    with _LOCK:
        rec = _normalize_issuer(_read_state().get("issuer"))
        return {"format": FORMAT, "issuer": rec, "defaults": dict(DEFAULT_ISSUER),
                "is_default": _is_default(rec), "logo": _logo_info()}


def save(settings: Any) -> dict[str, Any]:
    """Uloží texty vydavatele. Loga se netýká — to má vlastní endpoint."""
    with _LOCK:
        rec = _normalize_issuer((settings or {}).get("issuer") if isinstance(settings, dict) else None)
        state = _read_state()
        state["format"] = FORMAT
        state["issuer"] = rec
        state["updated_at"] = time.time()
        _write_state(state)
        return get()


def save_logo(data_url: Any) -> dict[str, Any]:
    """Ověří a uloží vlastní logo. Při jakékoli chybě nechá staré logo beze změny."""
    raw = _decode_jpeg_data_url(data_url)
    with _LOCK:
        _atomic_write_bytes(_logo_path(), raw)
        return get()


def delete_logo() -> dict[str, Any]:
    """Odstraní vlastní logo; protokol se vrátí k vestavěnému logu."""
    with _LOCK:
        try:
            _logo_path().unlink()
        except FileNotFoundError:
            pass
        except OSError as exc:
            raise ValueError("Vlastní logo se nepodařilo odstranit.") from exc
        return get()


def reset() -> dict[str, Any]:
    """Vrátí texty vydavatele na vestavěné výchozí hodnoty. Logo ponechá."""
    with _LOCK:
        state = _read_state()
        state["format"] = FORMAT
        state["issuer"] = dict(DEFAULT_ISSUER)
        state["updated_at"] = time.time()
        _write_state(state)
        return get()


def status() -> dict[str, Any]:
    """Bezpečné metadatové shrnutí pro kontrolu uložených dat."""
    rec = get()
    return {"customized": not rec["is_default"], "logo": rec["logo"]["source"]}
