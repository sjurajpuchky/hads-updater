# -*- coding: utf-8 -*-
"""Bezpečná výměna aktivní databáze z prohlížečového uploadu.

Modul záměrně nepoužívá :class:`ndb_parser.NdbDatabase` při ověřování
nahraného souboru. Tento parser při běžném otevření doplňuje výkonnostní
indexy; validace proto používá výhradně SQLite URI ``mode=ro`` a
``immutable=1`` a na zdroj nikdy nezapisuje.
"""

from __future__ import annotations

import hashlib
import hmac
import os
from pathlib import Path
import re
import shutil
import sqlite3
import threading
import time
from typing import BinaryIO, Callable
from urllib.parse import quote
import uuid
import gc
import json
import subprocess
import sys
import datetime as _dt
import secrets
from process_identity import is_verifiable_identity, process_identity, process_state


CHUNK_SIZE = 1024 * 1024
MIN_SAFETY_MARGIN = 128 * 1024 * 1024
MAX_SAFETY_MARGIN = 1024 * 1024 * 1024
WINDOWS_RETRY_DELAYS = (0.05, 0.10, 0.20, 0.35, 0.55, 0.80, 1.00)
REQUIRED_TABLES = {
    "Tbl_Info",
    "Tbl_Routes",
    "Tbl_Severity",
    "Tbl_Tree",
    "Tbl_Cell",
    "Tbl_Cell_Stats",
}


class UpdateError(RuntimeError):
    """Chyba, kterou lze bezpečně zobrazit uživateli."""


class DatabaseBusy(UpdateError):
    """Aktualizace nebo jiný výhradní zásah právě probíhá."""


class DatabaseOperationLock:
    """RW brána pro celý život požadavku pracujícího s aktivní databází.

    Čtenářský lease se drží od vstupu HTTP požadavku až po dokončení dotazů,
    reportu nebo exportu. Výhradní údržba nejprve zastaví nové čtenáře a
    potom omezeně čeká na dosavadní. Evidované HADS-owned connection cache
    lze ve výhradním stavu uzavřít najednou před manipulací se soubory.

    Zámek je reentrantní pouze pro čtení stejného vlákna. Díky tomu vnořená
    volání ``get_db()``/``_db_key()`` nezablokují sama sebe, ale žádný čtenář
    nikdy nepovýší lease na zápis (to by byl neřešitelný deadlock).
    """

    def __init__(self):
        self._condition = threading.Condition(threading.RLock())
        self._readers = 0
        self._writer = False
        self._writers_waiting = 0
        self._local = threading.local()
        self._connections: dict[int, tuple[str, str, Callable[[], None]]] = {}

    def _wait_for(self, predicate, timeout: float) -> bool:
        end = time.monotonic() + timeout
        while not predicate():
            left = end - time.monotonic()
            if left <= 0:
                return False
            self._condition.wait(left)
        return True

    def acquire_read(self, timeout: float = 5.0) -> bool:
        depth = getattr(self._local, "read_depth", 0)
        if depth:
            self._local.read_depth = depth + 1
            return True
        with self._condition:
            ok = self._wait_for(
                lambda: not self._writer and self._writers_waiting == 0, timeout
            )
            if ok:
                self._acquire_reader()
                self._local.read_depth = 1
            return ok

    def _acquire_reader(self) -> bool:
        self._readers += 1
        return True

    def release_read(self) -> None:
        depth = getattr(self._local, "read_depth", 0)
        if depth > 1:
            self._local.read_depth = depth - 1
            return
        if depth:
            self._local.read_depth = 0
        with self._condition:
            self._readers = max(0, self._readers - 1)
            if not self._readers:
                self._condition.notify_all()

    def acquire_write(self, timeout: float = 8.0) -> bool:
        if getattr(self._local, "read_depth", 0):
            raise DatabaseBusy(
                "Databázi nelze přepnout uvnitř probíhajícího čtení. Zkuste akci znovu."
            )
        with self._condition:
            self._writers_waiting += 1
            try:
                ok = self._wait_for(
                    lambda: not self._writer and self._readers == 0, timeout
                )
                if ok:
                    self._writer = True
                return ok
            finally:
                self._writers_waiting -= 1
                if not self._writers_waiting:
                    self._condition.notify_all()

    def release_write(self) -> None:
        with self._condition:
            self._writer = False
            self._condition.notify_all()

    def register_connection(
        self, path: str | Path, closer: Callable[[], None], label: str = "SQLite"
    ) -> int:
        """Zařadí HADS-owned spojení, které musí údržba explicitně uzavřít."""
        token = id(closer)
        with self._condition:
            self._connections[token] = (str(Path(path)), str(label), closer)
        return token

    def unregister_connection(self, token: int | None) -> None:
        if token is None:
            return
        with self._condition:
            self._connections.pop(token, None)

    def close_registered_connections(self, path: str | Path) -> list[str]:
        """Zavře všechny HADS-owned cache patřící jedné pracovní databázi.

        Volá se jedině pod výhradním lease. Selhání je vráceno jako popis,
        aby commit mohl bezpečně skončit před manipulací s hlavním souborem.
        """
        normalized = str(Path(path))
        with self._condition:
            entries = [
                (token, label, closer)
                for token, (registered, label, closer) in self._connections.items()
                if registered == normalized
            ]
        errors: list[str] = []
        for token, label, closer in entries:
            try:
                closer()
            except Exception as exc:
                errors.append(f"{label}: {exc}")
            finally:
                self.unregister_connection(token)
        return errors

    def registered_connection_count(self, path: str | Path | None = None) -> int:
        with self._condition:
            if path is None:
                return len(self._connections)
            normalized = str(Path(path))
            return sum(1 for registered, _, _ in self._connections.values()
                       if registered == normalized)


class _ReadLock:
    def __init__(self, lock: DatabaseOperationLock, timeout: float):
        self.lock, self.timeout = lock, timeout

    def __enter__(self):
        if not self.lock.acquire_read(self.timeout):
            raise DatabaseBusy("Databáze je právě aktualizována. Zkuste to prosím za chvíli.")
        return self

    def __exit__(self, *_):
        self.lock.release_read()


class _WriteLock:
    def __init__(self, lock: DatabaseOperationLock, timeout: float):
        self.lock, self.timeout = lock, timeout

    def __enter__(self):
        if not self.lock.acquire_write(self.timeout):
            raise DatabaseBusy("Databáze je právě používána. Aktualizaci zkuste prosím za chvíli.")
        return self

    def __exit__(self, *_):
        self.lock.release_write()


def read_locked(lock: DatabaseOperationLock, timeout: float = 5.0):
    return _ReadLock(lock, timeout)


def write_locked(lock: DatabaseOperationLock, timeout: float = 8.0):
    return _WriteLock(lock, timeout)


def _readonly_connection(path: Path) -> sqlite3.Connection:
    # immutable zabraňuje vytváření vedlejších souborů i v případě, že by
    # soubor pocházel ze sdílené složky v režimu WAL.
    uri = "file:" + quote(str(path.resolve())) + "?mode=ro&immutable=1"
    con = sqlite3.connect(uri, uri=True, timeout=2)
    con.execute("PRAGMA query_only=ON")
    return con


def validate_ndb(path: Path) -> dict:
    """Ověří SQLite/DDS strukturu bez zápisu a vrátí identitu podniku."""
    if not path.is_file() or path.stat().st_size < 100:
        raise UpdateError("Soubor je prázdný nebo příliš krátký.")
    with path.open("rb") as fh:
        if fh.read(16) != b"SQLite format 3\x00":
            raise UpdateError("Vybraný soubor není databáze SQLite ve formátu .ndb.")
    try:
        con = _readonly_connection(path)
        try:
            integrity = con.execute("PRAGMA quick_check(1)").fetchone()
            if not integrity or str(integrity[0]).casefold() != "ok":
                raise UpdateError("Kontrola integrity SQLite neprošla.")
            tables = {
                str(row[0]) for row in con.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            }
            missing = sorted(REQUIRED_TABLES - tables)
            if missing:
                raise UpdateError(
                    "Soubor nemá očekávané schéma DDS/HADS (chybí: "
                    + ", ".join(missing) + ")."
                )
            columns = {
                str(row[1]) for row in con.execute("PRAGMA table_info(Tbl_Tree)").fetchall()
            }
            if not {"ID", "Name", "Parent", "Type"}.issubset(columns):
                raise UpdateError("Tabulka stromu nemá očekávané schéma DDS/HADS.")
            root = con.execute(
                "SELECT Name FROM Tbl_Tree "
                "WHERE (Parent=0 OR Parent IS NULL) "
                "ORDER BY SortId, ID LIMIT 1"
            ).fetchone()
            if not root or not str(root[0] or "").strip():
                root = con.execute(
                    "SELECT Name FROM Tbl_Tree WHERE Type=1 ORDER BY SortId, ID LIMIT 1"
                ).fetchone()
            if (not root) or not str(root[0] or "").strip():
                root = con.execute("SELECT Name FROM Tbl_Routes LIMIT 1").fetchone()
            identity = str(root[0]).strip() if root and str(root[0] or "").strip() else None
            return {"identity": identity, "size": path.stat().st_size}
        finally:
            con.close()
    except UpdateError:
        raise
    except sqlite3.Error as exc:
        raise UpdateError(f"Soubor nelze bezpečně otevřít jako SQLite databázi: {exc}") from exc


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safety_margin(size: int) -> int:
    return max(MIN_SAFETY_MARGIN, min(MAX_SAFETY_MARGIN, max(1, size // 10)))


def ensure_space(directory: Path, incoming_size: int) -> None:
    try:
        free = shutil.disk_usage(directory).free
    except OSError as exc:
        raise UpdateError(f"Nelze zjistit volné místo na disku: {exc}") from exc
    required = int(incoming_size) + safety_margin(int(incoming_size))
    if free < required:
        raise UpdateError(
            "Na disku není dost volného místa pro bezpečnou aktualizaci "
            f"(potřeba alespoň {required / (1024 * 1024):.0f} MB, "
            f"volné {free / (1024 * 1024):.0f} MB)."
        )


def _header_value(headers: dict[str, str], name: str) -> str:
    return headers.get(name.casefold(), "")


def _parse_content_disposition(value: str) -> tuple[str | None, str | None]:
    name_m = re.search(r'(?:^|;)\s*name="([^"]*)"', value, re.I)
    file_m = re.search(r'(?:^|;)\s*filename="([^"]*)"', value, re.I)
    return (name_m.group(1) if name_m else None, file_m.group(1) if file_m else None)


def stream_multipart_ndb(
    stream: BinaryIO,
    content_length: int,
    content_type: str,
    data_dir: Path,
    preflight: Callable[[int], None] | None = None,
) -> dict:
    """Přečte multipart přímo do dočasného souboru ve ``data_dir``.

    V paměti drží jen vyhledávací okno o velikosti jednoho bloku a hlavičky
    částí. Funkce vrací cestu dočasného souboru, počet skutečně přijatých
    bajtů, SHA-256 a browserová metadata.
    """
    boundary_m = re.search(r"boundary=(?:\"([^\"]+)\"|([^;\s]+))", content_type or "", re.I)
    if not boundary_m:
        raise UpdateError("Chybí multipart boundary.")
    boundary = (boundary_m.group(1) or boundary_m.group(2)).encode("utf-8")
    if not boundary or len(boundary) > 200:
        raise UpdateError("Multipart boundary není platná.")
    remaining = int(content_length)
    if remaining <= 0:
        raise UpdateError("Upload neobsahuje data.")
    pushback = bytearray()

    def read(n: int) -> bytes:
        nonlocal remaining, pushback
        if pushback:
            take = min(n, len(pushback))
            data = bytes(pushback[:take])
            del pushback[:take]
            return data
        if remaining <= 0:
            return b""
        data = stream.read(min(n, remaining))
        remaining -= len(data)
        return data

    def unread(data: bytes) -> None:
        nonlocal pushback
        if data:
            pushback = bytearray(data) + pushback

    def readline(limit: int = 65536) -> bytes:
        chunks = bytearray()
        while len(chunks) < limit:
            piece = read(1)
            if not piece:
                break
            chunks += piece
            if piece == b"\n":
                break
        return bytes(chunks)

    first = readline()
    if first.rstrip(b"\r\n") != b"--" + boundary:
        raise UpdateError("Multipart upload nezačíná očekávanou hranicí.")

    metadata: dict[str, str] = {}
    temp_path: Path | None = None
    received = 0
    digest = hashlib.sha256()
    found_file = False
    delimiter = b"\r\n--" + boundary

    def consume_part(writer: Callable[[bytes], None]) -> bool:
        """Zapíše aktuální část, vrátí zda šlo o poslední část."""
        buffer = b""
        while True:
            chunk = read(CHUNK_SIZE)
            if not chunk:
                raise UpdateError("Upload byl ukončen před dokončením souboru.")
            buffer += chunk
            at = buffer.find(delimiter)
            if at >= 0:
                writer(buffer[:at])
                after = buffer[at + len(delimiter):]
                # Hranice může ležet ve zbytku načteného bloku. Tento zbytek
                # nesmíme zahodit; stream proto čteme po malých blocích až po
                # celou oddělovací řádku. Browser vždy posílá CRLF nebo --.
                while len(after) < 2:
                    extra = read(2 - len(after))
                    if not extra:
                        raise UpdateError("Multipart hranice není úplná.")
                    after += extra
                if after.startswith(b"--"):
                    tail = after[2:]
                    if tail and not tail.startswith(b"\r\n"):
                        raise UpdateError("Multipart ukončení není platné.")
                    return True
                if after.startswith(b"\r\n"):
                    unread(after[2:])
                    return False
                raise UpdateError("Multipart hranice není platná.")
            keep = len(delimiter) + 4
            if len(buffer) > keep:
                writer(buffer[:-keep])
                buffer = buffer[-keep:]

    try:
        while remaining > 0 or pushback:
            header_lines: list[bytes] = []
            while True:
                line = readline()
                if not line:
                    raise UpdateError("Upload byl ukončen v hlavičce části.")
                if line in (b"\r\n", b"\n"):
                    break
                header_lines.append(line)
                if len(header_lines) > 30:
                    raise UpdateError("Multipart hlavička je příliš dlouhá.")
            headers: dict[str, str] = {}
            for raw in header_lines:
                try:
                    key, value = raw.decode("utf-8", "replace").split(":", 1)
                except ValueError:
                    continue
                headers[key.strip().casefold()] = value.strip()
            field, filename = _parse_content_disposition(
                _header_value(headers, "content-disposition")
            )
            is_file = filename is not None
            if is_file:
                if found_file:
                    raise UpdateError("Požadavek smí obsahovat právě jeden soubor .ndb.")
                base = os.path.basename(filename or "")
                if not base.casefold().endswith(".ndb"):
                    raise UpdateError("Vyberte soubor s příponou .ndb.")
                declared_raw = metadata.get("declared_size", "")
                try:
                    declared = int(declared_raw)
                except (TypeError, ValueError):
                    raise UpdateError("Chybí deklarovaná velikost vybraného souboru.")
                if declared < 100:
                    raise UpdateError("Deklarovaná velikost souboru není platná.")
                if preflight:
                    preflight(declared)
                temp_path = data_dir / (".hads-update-upload-" + uuid.uuid4().hex + ".tmp")
                with temp_path.open("xb") as out:
                    def put(chunk: bytes) -> None:
                        nonlocal received
                        out.write(chunk)
                        digest.update(chunk)
                        received += len(chunk)
                    last = consume_part(put)
                found_file = True
            else:
                value = bytearray()
                def collect(chunk: bytes) -> None:
                    if len(value) + len(chunk) > 65536:
                        raise UpdateError("Multipart doprovodná hodnota je příliš dlouhá.")
                    value.extend(chunk)
                last = consume_part(collect)
                if field:
                    metadata[field] = value.decode("utf-8", "replace").strip()
            if last:
                break
        if not found_file or temp_path is None:
            raise UpdateError("Soubor .ndb nebyl v požadavku nalezen.")
        declared = int(metadata.get("declared_size", "-1"))
        if declared != received:
            raise UpdateError(
                f"Přenos souboru není úplný (očekáváno {declared} B, přijato {received} B)."
            )
        return {
            "path": temp_path,
            "declared_size": declared,
            "received_size": received,
            "sha256": digest.hexdigest(),
            "source_name": os.path.basename(filename or ""),
            "source_last_modified": metadata.get("source_last_modified") or None,
        }
    except Exception:
        if temp_path:
            try:
                temp_path.unlink()
            except OSError:
                pass
        raise


def _is_windows_sharing_error(exc: OSError) -> bool:
    return (
        isinstance(exc, PermissionError)
        or getattr(exc, "winerror", None) in (32, 33)
        or getattr(exc, "errno", None) in (13, 16)
    )


def _locked_path_error(path: Path, phase: str, exc: BaseException) -> UpdateError:
    return UpdateError(
        f"Soubor databáze je během fáze „{phase}“ stále používán jiným programem: "
        f"{path}. Zavřete měřicí/databázovou aplikaci pracující s touto databází "
        f"a aktualizaci zkuste znovu. (Původní pracovní databáze nebyla vyměněna.)"
    )


def _retry_windows_path_action(
    path: Path, phase: str, action: Callable[[], None],
    *, delays: tuple[float, ...] = WINDOWS_RETRY_DELAYS,
) -> None:
    """Krátce opakuje jen sdílecí chyby Windows 32/33, nikdy ne donekonečna."""
    last: OSError | None = None
    for attempt, delay in enumerate((*delays, 0.0), start=1):
        try:
            action()
            return
        except OSError as exc:
            if not _is_windows_sharing_error(exc):
                raise UpdateError(f"Nelze dokončit fázi „{phase}“ pro {path}: {exc}") from exc
            last = exc
            print(f"[database-update] phase={phase} retry={attempt} path={path.name}")
            if delay:
                time.sleep(delay)
    assert last is not None
    raise _locked_path_error(path, phase, last) from last


def _unlink_sidecar(path: Path, phase: str) -> None:
    if path.exists():
        _retry_windows_path_action(path, phase, path.unlink)


def _replace_path(source: Path, destination: Path, phase: str) -> None:
    _retry_windows_path_action(
        destination, phase, lambda: os.replace(str(source), str(destination))
    )


def _close_sqlite(con: sqlite3.Connection | None) -> None:
    if con is None:
        return
    try:
        con.close()
    except sqlite3.Error:
        pass


def _verify_sidecars_releasable(path: Path) -> None:
    """Ověří sdílecí zámky vedlejších souborů bez změny jejich bajtů.

    Krátký rename tam a zpět je na Windows stejná operace, která by selhala
    při mazání WAL/SHM. Dělá se *před* checkpointem, takže externě zamčený
    sidecar ponechá hlavní i vedlejší soubor zcela byte-identický.
    """
    for suffix in ("-wal", "-shm", "-journal"):
        sidecar = Path(str(path) + suffix)
        if not sidecar.exists():
            continue
        probe = Path(str(sidecar) + ".hads-release-probe-" + uuid.uuid4().hex)
        _retry_windows_path_action(
            sidecar,
            "ověření uvolnění pomocného souboru",
            lambda source=sidecar, destination=probe: os.replace(str(source), str(destination)),
        )
        try:
            _retry_windows_path_action(
                sidecar,
                "obnovení ověřeného pomocného souboru",
                lambda source=probe, destination=sidecar: os.replace(str(source), str(destination)),
            )
        except Exception as exc:
            # Pokusíme se vrátit původní jméno; chyba je i tak stop stav před
            # swapem hlavní databáze.
            if probe.exists() and not sidecar.exists():
                try:
                    _retry_windows_path_action(
                        sidecar,
                        "nouzové obnovení pomocného souboru",
                        lambda source=probe, destination=sidecar: os.replace(str(source), str(destination)),
                    )
                except Exception:
                    pass
            raise UpdateError(
                "Pomocný soubor databáze nelze bezpečně vrátit po kontrole zámku: "
                + str(exc)
            ) from exc


def _checkpoint_and_remove_sidecars(path: Path) -> None:
    """Vytvoří samostatný rollbackovatelný hlavní soubor bez starého WAL.

    Tato fáze se provádí až po uzavření všech HADS-owned connection cache a
    před přesunem hlavního souboru. Selhání zámku postranního souboru proto
    skončí *před swapem* a aktivní databáze zůstane na své cestě použitelná.
    """
    sidecars = [Path(str(path) + suffix) for suffix in ("-wal", "-shm", "-journal")]
    con: sqlite3.Connection | None = None
    try:
        if any(item.exists() for item in sidecars):
            con = sqlite3.connect(str(path), timeout=2)
            con.execute("PRAGMA busy_timeout=2000")
            # Nejdříve vloží WAL do hlavního souboru a pak přepne vlastní
            # pracovní kopii do DELETE. Následující rollback je tak jeden
            # byteově ověřitelný .ndb bez možnosti přehrát starý WAL.
            con.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchall()
            con.execute("PRAGMA journal_mode=DELETE").fetchall()
            con.commit()
    except sqlite3.Error as exc:
        raise UpdateError(
            "Nelze výhradně uzavřít pracovní databázi. Zavřete další měřicí "
            "nebo databázový program a aktualizaci zkuste znovu: " + str(exc)
        ) from exc
    finally:
        _close_sqlite(con)
    gc.collect()
    for sidecar in sidecars:
        _unlink_sidecar(sidecar, "uvolnění pomocného souboru")


def _remove_new_sidecars_before_rollback(path: Path) -> None:
    """Zajistí, že vedle obnovené pracovní kopie nezůstane WAL nové databáze."""
    try:
        _checkpoint_and_remove_sidecars(path)
    except UpdateError:
        # I při vadném novém obsahu se pokusíme odstranit přesně známé vedlejší
        # soubory; chybějící možnost je následně hlášena jako neověřený rollback.
        for suffix in ("-wal", "-shm", "-journal"):
            _unlink_sidecar(Path(str(path) + suffix), "příprava rollbacku")


class ActiveDatabaseUpdater:
    """Provádí finální výměnu s návratem původních dat při selhání.

    Callbacky drží tento nízkoúrovňový modul nezávislý na HTTP vrstvě a
    zároveň dovolují serveru zavřít/reinicializovat jeho cache obvyklou cestou.
    """

    def __init__(
        self,
        data_dir: Path,
        active_filename: Callable[[], str | None],
        close_cache: Callable[[], None],
        reopen_cache: Callable[[], None],
        invalidate: Callable[[str], None],
        lock: DatabaseOperationLock,
        verify_reopened: Callable[[], None] | None = None,
    ):
        self.data_dir = data_dir
        self.active_filename = active_filename
        self.close_cache = close_cache
        self.reopen_cache = reopen_cache
        self.invalidate = invalidate
        self.lock = lock
        self.verify_reopened = verify_reopened

    def replace(
        self,
        uploaded: dict,
        *,
        simulate_failure_after_swap: bool = False,
    ) -> dict:
        source = Path(uploaded["path"])
        try:
            source_meta = validate_ndb(source)
            with write_locked(self.lock):
                filename = self.active_filename()
                if not filename:
                    raise UpdateError("Není aktivní databáze. Nejprve ji načtěte nebo vyberte.")
                target = self.data_dir / os.path.basename(filename)
                if not target.is_file():
                    raise UpdateError("Aktivní databáze již nebyla nalezena.")
                ensure_space(self.data_dir, int(uploaded["received_size"]))
                # Neotevírej ani necheckpointuj aktivní soubor, dokud není
                # ověřeno, že jeho případný WAL/SHM/JOURNAL lze na Windows
                # bezpečně uvolnit. Externí zámek proto neovlivní ani bajt
                # současné pracovní kopie.
                _verify_sidecars_releasable(target)
                current_meta = validate_ndb(target)
                source_identity = source_meta.get("identity")
                current_identity = current_meta.get("identity")
                if bool(source_identity) != bool(current_identity):
                    raise UpdateError(
                        "Nelze ověřit shodu podniku: identita je zjistitelná jen u jedné databáze."
                    )
                if source_identity and current_identity and (
                    str(source_identity).casefold() != str(current_identity).casefold()
                ):
                    raise UpdateError(
                        "Vybraný soubor patří jinému podniku "
                        f"({source_identity}); aktivní databáze je {current_identity}."
                    )
                if (
                    int(uploaded["received_size"]) == target.stat().st_size
                    and str(uploaded.get("sha256") or "") == sha256_file(target)
                ):
                    return {
                        "ok": True,
                        "no_update": True,
                        "detail": "Vybraný soubor je shodný s aktivní databází; aktualizace není potřeba.",
                    }

                rollback = self.data_dir / (
                    ".hads-update-rollback-" + uuid.uuid4().hex + ".ndb"
                )
                failed = self.data_dir / (
                    ".hads-update-failed-" + uuid.uuid4().hex + ".ndb"
                )
                swapped = False
                rollback_hash = ""
                rollback_size = 0
                try:
                    # Výhradní lease už odmítá nové DB requesty a čekal na
                    # všechny staré. Zavřeme navíc každý evidovaný cache objekt
                    # včetně dočasných parserů, které by jinak na Windows držely
                    # .ndb-wal/.ndb-shm i po dokončení API odpovědi.
                    self.close_cache()
                    close_errors = self.lock.close_registered_connections(target)
                    if close_errors:
                        raise UpdateError(
                            "Nelze uzavřít všechna vlastní spojení HADS: "
                            + "; ".join(close_errors)
                        )
                    gc.collect()
                    _checkpoint_and_remove_sidecars(target)
                    # Tento hash je definicí přesného rollbacku: po bezpečném
                    # checkpointu je starý logický stav uložen v jediném .ndb
                    # a není k němu připojen žádný starý WAL.
                    rollback_size = target.stat().st_size
                    rollback_hash = sha256_file(target)
                    _replace_path(target, rollback, "přesun původní databáze do rollbacku")
                    swapped = True
                    _replace_path(source, target, "atomická výměna databáze")
                    if simulate_failure_after_swap:
                        raise OSError("testovací selhání po výměně")
                    # Normální inicializace přidá běžné výkonnostní indexy až
                    # po úspěšné výměně. Tím validace zdrojového souboru nikdy
                    # nemění data a uživatel má po návratu hotovou cache.
                    self.invalidate(filename)
                    self.reopen_cache()
                    if self.verify_reopened:
                        self.verify_reopened()
                    # Nová cache smí používat vlastní čerstvý WAL. Starý WAL
                    # byl odstraněn dříve, proto ho zde už nikdy nemažeme.
                    _unlink_sidecar(rollback, "odstranění ověřeného rollbacku")
                except Exception as exc:
                    restored = False
                    restore_problem: Exception | None = None
                    try:
                        self.close_cache()
                        self.lock.close_registered_connections(target)
                        gc.collect()
                        if swapped and rollback.exists():
                            if target.exists():
                                _remove_new_sidecars_before_rollback(target)
                                _replace_path(target, failed, "odklizení neúspěšné nové databáze")
                            _replace_path(rollback, target, "obnovení původní databáze")
                            restored = (
                                target.is_file()
                                and target.stat().st_size == rollback_size
                                and sha256_file(target) == rollback_hash
                            )
                            if not restored:
                                raise UpdateError(
                                    "Kontrola hash po rollbacku neodpovídá bezpečné předchozí pracovní kopii."
                                )
                        self.invalidate(filename)
                        self.reopen_cache()
                        if self.verify_reopened:
                            self.verify_reopened()
                    except Exception as restore_exc:
                        restore_problem = restore_exc
                    finally:
                        # Soubor nové verze je jen přechodný. Při Windows locku
                        # ho neodstraňujeme násilím; nebrání-li obnově, může být
                        # ponechán pouze pro ruční diagnostiku mimo aktivní cestu.
                        if failed.exists():
                            try:
                                _unlink_sidecar(Path(str(failed) + "-wal"), "úklid neúspěšného WAL")
                                _unlink_sidecar(Path(str(failed) + "-shm"), "úklid neúspěšného SHM")
                                _unlink_sidecar(Path(str(failed) + "-journal"), "úklid neúspěšného journalu")
                                _unlink_sidecar(failed, "úklid neúspěšné databáze")
                            except UpdateError:
                                pass
                    if restore_problem is not None:
                        raise UpdateError(
                            "Aktualizace selhala a návrat předchozí databáze nelze ověřit: "
                            + str(restore_problem)
                        ) from exc
                    if swapped and not restored:
                        raise UpdateError(
                            "Aktualizace selhala a návrat předchozí databáze nelze ověřit."
                        ) from exc
                    if not swapped:
                        raise UpdateError(
                            "Aktualizace nebyla provedena; aktivní pracovní databáze nebyla vyměněna: "
                            + str(exc)
                        ) from exc
                    raise UpdateError(
                        "Aktualizace selhala; hash bezpečné původní databáze byl ověřen a data byla obnovena: "
                        + str(exc)
                    ) from exc
                return {
                    "ok": True,
                    "no_update": False,
                    "filename": filename,
                    "size": int(uploaded["received_size"]),
                    "source_name": uploaded.get("source_name"),
                    "source_last_modified": uploaded.get("source_last_modified"),
                    "identity": source_identity,
                }
        finally:
            try:
                source.unlink(missing_ok=True)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# 1.34.7: post-exit replacement hand-off with an authenticated live-helper
# challenge/response.  The supervisor is HADS.exe while the ready process is
# its pythonw.exe child, therefore they intentionally have different PIDs.
#
# ActiveDatabaseUpdater is deliberately retained above only as an isolated
# compatibility utility for old unit fixtures.  Production routing must use
# DatabaseUpdateCoordinator below.  In particular, no code in this class is
# called by the HTTP endpoint: it can never rename, checkpoint or delete the
# active database or its sidecars while the backend process is alive.

JOB_FORMAT = 3
JOB_DIR_NAME = "database_jobs"
JOB_ACTIVE_NAME = "active.json"
JOB_RESULT_DIR = "results"
JOB_STAGING_DIR = "staging"
JOB_LOG_DIR = "logs"
JOB_READY_DIR = "ready"
JOB_CHALLENGE_DIR = "challenges"
JOB_RESPONSE_DIR = "responses"
JOB_CANCELLED_DIR = "cancelled"
HELPER_READY_TIMEOUT_SECONDS = 6.0


def _process_start_identity(pid: int) -> str | None:
    """Return the shared PID-reuse-resistant identity."""
    return process_identity(pid)


def _process_is_running(pid: int, identity: str | None = None) -> bool:
    actual, live = process_state(pid)
    return bool(live and actual and (identity is None or actual == identity))


def _handshake_mac(secret: str, purpose: str, *fields: object) -> str:
    """MAC a fixed, unambiguous handshake transcript with the job capability."""
    transcript = json.dumps(
        [purpose, *fields], ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    return hmac.new(secret.encode("ascii"), transcript, hashlib.sha256).hexdigest()


def _canonical(path: Path) -> Path:
    try:
        return path.resolve(strict=False)
    except OSError as exc:
        raise UpdateError(f"Nelze normalizovat cestu: {path}: {exc}") from exc


def _is_under(path: Path, root: Path) -> bool:
    try:
        _canonical(path).relative_to(_canonical(root))
        return True
    except ValueError:
        return False


def _regular_file(path: Path, label: str, *, required: bool = True) -> None:
    if path.is_symlink():
        raise UpdateError(f"{label} nesmí být symbolický odkaz: {path}")
    if not path.is_file():
        if required:
            raise UpdateError(f"Chybí bezpečný soubor {label}: {path}")
        return


def _safe_json_write(path: Path, payload: dict) -> None:
    """Atomicky zapíše job/receipt s oprávněním aktuálního uživatele."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.parent.is_symlink() or path.is_symlink():
        raise UpdateError(f"Cesta pro stav aktualizace nesmí být odkaz: {path}")
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with tmp.open("x", encoding="utf-8") as fh:
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            json.dump(payload, fh, ensure_ascii=False, separators=(",", ":"))
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def _job_timestamp() -> str:
    return _dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S_%f")


class DatabaseUpdateCoordinator:
    """Prepare a one-time, externally executed database-replacement job.

    This object does only preflight and staging.  It intentionally has no
    operation that changes ``target`` or ``target-wal/-shm/-journal``.
    """

    def __init__(
        self,
        installation_root: Path,
        data_dir: Path,
        active_filename: Callable[[], str | None],
        *,
        backend_pid: Callable[[], int] = os.getpid,
        backend_identity: Callable[[], str | None],
        installation_fingerprint: Callable[[], str],
        version: str,
        restart_executable: Path | None = None,
        helper_script: Path | None = None,
        popen: Callable[..., object] = subprocess.Popen,
    ) -> None:
        self.installation_root = _canonical(installation_root)
        self.data_dir = _canonical(data_dir)
        self.active_filename = active_filename
        self.backend_pid = backend_pid
        self.backend_identity = backend_identity
        self.installation_fingerprint = installation_fingerprint
        self.version = version
        self.restart_executable = _canonical(restart_executable or self.installation_root / "HADS.exe")
        self.helper_script = _canonical(helper_script or self.installation_root / "tools" / "hads_database_replacer.py")
        self.popen = popen

    @property
    def jobs_root(self) -> Path:
        return self.installation_root / "updates" / JOB_DIR_NAME

    @property
    def active_lock(self) -> Path:
        return self.jobs_root / JOB_ACTIVE_NAME

    def _assert_layout(self) -> None:
        if self.installation_root.is_symlink() or self.data_dir.is_symlink():
            raise UpdateError("Instalace ani data/ nesmějí být symbolický odkaz.")
        if not self.installation_root.is_dir() or not self.data_dir.is_dir():
            raise UpdateError("Instalace nebo data/ nejsou dostupné.")
        if not _is_under(self.data_dir, self.installation_root):
            raise UpdateError("data/ není uvnitř instalační složky HADS.")
        _regular_file(self.restart_executable, "HADS.exe pro restart")
        _regular_file(self.helper_script, "externí pomocník aktualizace")

    def _create_active_lock(self, job_id: str) -> None:
        self.jobs_root.mkdir(parents=True, exist_ok=True)
        if self.jobs_root.is_symlink():
            raise DatabaseBusy("Složka stavů aktualizace není bezpečná.")
        try:
            fd = os.open(str(self.active_lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError as exc:
            raise DatabaseBusy(
                "Aktualizace databáze již byla přijata. HADS se ukončuje nebo čeká na výsledek."
            ) from exc
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump({"job_id": job_id, "created_at": time.time()}, fh, ensure_ascii=False)
                fh.flush()
                os.fsync(fh.fileno())
        except Exception:
            try:
                self.active_lock.unlink()
            except OSError:
                pass
            raise

    def _remove_active_lock(self) -> None:
        try:
            self.active_lock.unlink(missing_ok=True)
        except OSError:
            pass

    def _target(self) -> Path:
        filename = self.active_filename()
        if not filename:
            raise UpdateError("Není aktivní databáze. Nejprve ji načtěte nebo vyberte.")
        # current.txt is legacy/user data, so accept only an exact direct data
        # child.  This prohibits traversal and keeps a replacement from
        # reaching per-company JSON configuration.
        if os.path.basename(filename) != filename or not filename.casefold().endswith(".ndb"):
            raise UpdateError("Aktivní databáze nemá bezpečný název .ndb.")
        target = self.data_dir / filename
        if not _is_under(target, self.data_dir) or target.parent != self.data_dir:
            raise UpdateError("Cílová databáze je mimo povolenou složku data/.")
        _regular_file(target, "aktivní databáze")
        return _canonical(target)

    def _stage(self, source: Path, job_id: str) -> Path:
        _regular_file(source, "nahraný soubor")
        if not _is_under(source, self.data_dir):
            raise UpdateError("Nahraný soubor není ve vlastněné staging složce HADS.")
        staging_dir = self.jobs_root / JOB_STAGING_DIR
        staging_dir.mkdir(parents=True, exist_ok=True)
        if staging_dir.is_symlink():
            raise UpdateError("Staging složka aktualizace nesmí být odkaz.")
        staged = staging_dir / (job_id + ".ndb")
        if staged.exists() or staged.is_symlink():
            raise UpdateError("Kolize jednorázového staging souboru.")
        # Same installation filesystem, atomic and never touches active DB.
        os.replace(source, staged)
        try:
            os.chmod(staged, 0o600)
        except OSError:
            pass
        return _canonical(staged)

    def _python_for_helper(self) -> Path:
        portable = self.installation_root / "runtime" / "pythonw.exe"
        if portable.is_file() and not portable.is_symlink():
            return _canonical(portable)
        # A system interpreter is deliberately a developer-test fallback only.
        if os.name != "nt":
            return _canonical(Path(sys.executable))
        raise UpdateError("Chybí runtime/pythonw.exe pro externí aktualizaci databáze.")

    def _supervisor_command(self, descriptor: Path) -> list[str]:
        """Use native HADS.exe as the Windows parent of the Python helper.

        A native supervisor does not inherit the HTTP server's stdout/stderr
        and explicitly requests breakaway from an optional Windows job object.
        Developer platforms use the exact portable-helper script directly.
        """
        if os.name == "nt":
            return [str(self.restart_executable), "--replace-database", str(descriptor)]
        return [str(self._python_for_helper()), "-u", str(self.helper_script), str(descriptor)]

    def _write_cancel(self, job_id: str, nonce: str, detail: str) -> None:
        _safe_json_write(
            self.jobs_root / JOB_CANCELLED_DIR / f"{job_id}.json",
            {"format": 1, "job_id": job_id, "helper_nonce": nonce, "cancelled_at": time.time(), "detail": detail},
        )

    def _validate_ready(self, path: Path, payload: dict, job: dict, supervisor: object) -> tuple[int, str]:
        if path.is_symlink() or not path.is_file():
            raise UpdateError("Externí pomocník nevytvořil bezpečné potvrzení spuštění.")
        if payload.get("format") != 2 or payload.get("job_id") != job["job_id"] or payload.get("helper_nonce") != job["helper_nonce"]:
            raise UpdateError("Potvrzení externího pomocníka neodpovídá jednorázové úloze.")
        expected = {
            "installation_root": str(self.installation_root),
            "target_path": job["target_path"],
            "staged_path": job["staged_path"],
            "log_path": job["log_path"],
        }
        if any(payload.get(key) != value for key, value in expected.items()):
            raise UpdateError("Potvrzení pomocníka má neplatnou cestu.")
        helper_pid = payload.get("helper_pid")
        identity = payload.get("helper_process_identity")
        proof = payload.get("ready_proof")
        if not isinstance(helper_pid, int) or not isinstance(identity, str) or not isinstance(proof, str):
            raise UpdateError("Potvrzení pomocníka nemá úplnou identitu živého procesu pythonw.exe.")
        expected_proof = _handshake_mac(
            job["helper_nonce"], "ready-v2", job["job_id"], helper_pid, identity,
            job["installation_root"], job["target_path"], job["staged_path"],
        )
        if not hmac.compare_digest(proof, expected_proof):
            raise UpdateError("Potvrzení pomocníka nemá platnou kryptografickou schopnost úlohy.")
        # This intentionally verifies the child pythonw.exe, not the HADS.exe
        # supervisor Popen PID.  The actual opened process handle must still
        # be live and have the exact recorded creation identity.
        if not _process_is_running(helper_pid, identity):
            raise UpdateError(
                "Potvrzení pomocníka nemá ověřitelnou identitu živého procesu pythonw.exe."
            )
        log_path = _canonical(Path(job["log_path"]))
        _regular_file(log_path, "log externího pomocníka")
        try:
            if "phase=helper_started" not in log_path.read_text(encoding="utf-8", errors="replace"):
                raise UpdateError("Pomocník nepotvrdil úvodní diagnostický zápis.")
        except OSError as exc:
            raise UpdateError(f"Nelze ověřit log externího pomocníka: {exc}") from exc
        # A Popen object may represent the native Windows supervisor or the
        # helper itself in developer tests.  It must still be alive here.
        poll = getattr(supervisor, "poll", None)
        if callable(poll) and poll() is not None:
            raise UpdateError("Externí supervizor se ukončil před potvrzením připravenosti.")
        return helper_pid, identity

    def _challenge_helper(
        self, job: dict, helper_pid: int, identity: str, supervisor: object
    ) -> None:
        """Require a post-ready response from the same still-live helper.

        A stale or copied ready JSON cannot answer the fresh challenge.  The
        answer is MACed with the one-time descriptor nonce and is checked
        together with an OS process handle before backend shutdown is allowed.
        """
        challenge_path = _canonical(Path(job["challenge_path"]))
        response_path = _canonical(Path(job["response_path"]))
        if not _is_under(challenge_path, self.jobs_root) or not _is_under(response_path, self.jobs_root):
            raise UpdateError("Cesty challenge/response pomocníka nejsou bezpečné.")
        if challenge_path.is_symlink() or response_path.is_symlink() or challenge_path.exists() or response_path.exists():
            raise UpdateError("Jednorázová challenge pomocníka již existuje nebo není bezpečná.")
        challenge = secrets.token_hex(32)
        _safe_json_write(challenge_path, {
            "format": 1, "job_id": job["job_id"], "helper_nonce": job["helper_nonce"],
            "challenge": challenge, "created_at": time.time(),
        })
        deadline = time.monotonic() + HELPER_READY_TIMEOUT_SECONDS
        last_error: Exception | None = None
        while time.monotonic() < deadline:
            poll = getattr(supervisor, "poll", None)
            if callable(poll) and poll() is not None:
                raise UpdateError("Externí supervizor se ukončil během challenge potvrzení.")
            if response_path.is_file() and not response_path.is_symlink():
                try:
                    response = json.loads(response_path.read_text(encoding="utf-8"))
                    expected = _handshake_mac(
                        job["helper_nonce"], "response-v2", job["job_id"], challenge,
                        helper_pid, identity,
                    )
                    if (
                        response.get("format") != 2
                        or response.get("job_id") != job["job_id"]
                        or response.get("helper_nonce") != job["helper_nonce"]
                        or response.get("helper_pid") != helper_pid
                        or response.get("helper_process_identity") != identity
                        or not isinstance(response.get("response_proof"), str)
                        or not hmac.compare_digest(response["response_proof"], expected)
                    ):
                        raise UpdateError("Odpověď challenge pomocníka neodpovídá jednorázové úloze.")
                    if not _process_is_running(helper_pid, identity):
                        raise UpdateError("Pomocník pythonw.exe se ukončil během challenge potvrzení.")
                    return
                except (OSError, ValueError, json.JSONDecodeError, UpdateError) as exc:
                    last_error = exc
            time.sleep(0.05)
        suffix = f" Poslední důvod: {last_error}." if last_error else ""
        raise UpdateError(
            "Externí pomocník neodpověděl na bezpečnou challenge; HADS zůstává spuštěn."
            + suffix
        )

    def _wait_for_ready(self, ready: Path, job: dict, supervisor: object) -> None:
        deadline = time.monotonic() + HELPER_READY_TIMEOUT_SECONDS
        last_error = None
        while time.monotonic() < deadline:
            poll = getattr(supervisor, "poll", None)
            if callable(poll) and poll() is not None:
                raise UpdateError(
                    f"Externí pomocník se ukončil před potvrzením připravenosti (exit {poll()}); "
                    f"zkontrolujte {job['log_path']}."
                )
            if ready.is_file() and not ready.is_symlink():
                try:
                    payload = json.loads(ready.read_text(encoding="utf-8"))
                    helper_pid, identity = self._validate_ready(ready, payload, job, supervisor)
                    self._challenge_helper(job, helper_pid, identity, supervisor)
                    # Catch the important real-world race: a child that writes
                    # ready/response and immediately dies must not cause shutdown.
                    time.sleep(0.20)
                    helper_pid, identity = self._validate_ready(ready, payload, job, supervisor)
                    if not _process_is_running(helper_pid, identity):
                        raise UpdateError("Pomocník pythonw.exe se ukončil po challenge potvrzení.")
                    return
                except (OSError, ValueError, json.JSONDecodeError, UpdateError) as exc:
                    last_error = exc
            time.sleep(0.05)
        suffix = f" Poslední důvod: {last_error}." if last_error else ""
        raise UpdateError(
            "Externí pomocník nepotvrdil bezpečné spuštění; HADS zůstává spuštěn. "
            f"Zkontrolujte {job['log_path']}.{suffix}"
        )

    def prepare_and_spawn(self, uploaded: dict) -> dict:
        """Validate, write job descriptor and start independent helper.

        A failure before a successful spawn leaves the active DB untouched.  A
        selected browser File remains selected by the frontend for a retry.
        """
        self._assert_layout()
        target = self._target()
        source = Path(uploaded["path"])
        _regular_file(source, "nahraný soubor")
        source_meta = validate_ndb(source)
        target_meta = validate_ndb(target)
        source_identity, target_identity = source_meta.get("identity"), target_meta.get("identity")
        if bool(source_identity) != bool(target_identity):
            raise UpdateError("Nelze ověřit shodu podniku: identita je zjistitelná jen u jedné databáze.")
        if source_identity and str(source_identity).casefold() != str(target_identity).casefold():
            raise UpdateError(
                f"Vybraný soubor patří jinému podniku ({source_identity}); aktivní databáze je {target_identity}."
            )
        actual_size = source.stat().st_size
        if int(uploaded.get("received_size", -1)) != actual_size:
            raise UpdateError("Velikost staging souboru neodpovídá přijatému uploadu.")
        source_hash = sha256_file(source)
        if source_hash != str(uploaded.get("sha256") or ""):
            raise UpdateError("SHA-256 staging souboru neodpovídá přijatému uploadu.")
        ensure_space(self.data_dir, actual_size)
        target_hash = sha256_file(target)
        if actual_size == target.stat().st_size and source_hash == target_hash:
            return {
                "ok": True, "no_update": True,
                "detail": "Vybraný soubor je shodný s aktivní databází; aktualizace není potřeba.",
            }

        # Capture identity once before creating a lock, moving the upload or
        # spawning the helper. A Windows job must never persist "unknown":
        # parent waiting is a security boundary against PID reuse.
        backend_pid = int(self.backend_pid())
        backend_identity = self.backend_identity()
        if not is_verifiable_identity(backend_identity):
            raise UpdateError(
                "Nelze bezpečně ověřit identitu běžícího backendu pro výměnu databáze; "
                "HADS zůstává spuštěn a databáze nebyla změněna. Zkuste akci po restartu HADS."
            )
        job_id = secrets.token_urlsafe(32).replace("-", "").replace("_", "")[:40]
        self._create_active_lock(job_id)
        staged: Path | None = None
        descriptor: Path | None = None
        supervisor = None
        try:
            staged = self._stage(source, job_id)
            # Validate the post-move staging file again, still immutable/read-only.
            if sha256_file(staged) != source_hash or staged.stat().st_size != actual_size:
                raise UpdateError("Staging soubor se po bezpečném přesunu změnil.")
            if validate_ndb(staged).get("identity") != source_identity:
                raise UpdateError("Identita staging souboru se po přesunu změnila.")
            logs = self.installation_root / "updates" / JOB_LOG_DIR
            logs.mkdir(parents=True, exist_ok=True)
            log_path = _canonical(logs / f"database_update_{job_id}.log")
            descriptor = _canonical(self.jobs_root / f"job_{job_id}.json")
            ready_path = _canonical(self.jobs_root / JOB_READY_DIR / f"{job_id}.json")
            challenge_path = _canonical(self.jobs_root / JOB_CHALLENGE_DIR / f"{job_id}.json")
            response_path = _canonical(self.jobs_root / JOB_RESPONSE_DIR / f"{job_id}.json")
            cancel_path = _canonical(self.jobs_root / JOB_CANCELLED_DIR / f"{job_id}.json")
            now = time.time()
            payload = {
                "format": JOB_FORMAT,
                "job_id": job_id,
                "created_at": now,
                "expires_at": now + 15 * 60,
                "installation_root": str(self.installation_root),
                "installation_fingerprint": self.installation_fingerprint(),
                "target_path": str(target),
                "staged_path": str(staged),
                "target_size": target.stat().st_size,
                "target_sha256": target_hash,
                "source_size": actual_size,
                "source_sha256": source_hash,
                "expected_company_identity": source_identity,
                "source_name": os.path.basename(str(uploaded.get("source_name") or "databáze.ndb")),
                "source_last_modified": uploaded.get("source_last_modified"),
                "backend_pid": backend_pid,
                "backend_process_identity": backend_identity,
                "backend_version": self.version,
                "restart_executable": str(self.restart_executable),
                "log_path": str(log_path),
                "result_path": str(self.jobs_root / JOB_RESULT_DIR / f"{job_id}.json"),
                "active_lock_path": str(self.active_lock),
                "ready_path": str(ready_path),
                "challenge_path": str(challenge_path),
                "response_path": str(response_path),
                "cancel_path": str(cancel_path),
                "helper_nonce": secrets.token_hex(32),
                "parent_wait_seconds": 180,
                "lock_retry_seconds": 12,
            }
            _safe_json_write(descriptor, payload)
            # Passing the descriptor as the only data argument gives Windows
            # CreateProcess deterministic Unicode quoting. The helper opens
            # its own log at instruction one; no backend-owned stream is
            # inherited and later closed during graceful teardown.
            kwargs = {
                "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL,
                "cwd": str(self.installation_root), "close_fds": True,
            }
            if os.name == "nt":
                kwargs["creationflags"] = (
                    getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
                    | getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
                    | getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
                    | getattr(subprocess, "CREATE_BREAKAWAY_FROM_JOB", 0x01000000)
                )
            else:
                kwargs["start_new_session"] = True
            supervisor = self.popen(self._supervisor_command(descriptor), **kwargs)
            self._wait_for_ready(ready_path, payload, supervisor)
            return {
                "ok": True, "accepted": True, "no_update": False, "job_id": job_id,
                "phase": "external_replacement_pending",
                "source_name": payload["source_name"], "size": actual_size,
            }
        except Exception as exc:
            # Only pre-spawn work happened. Keep browser selection intact and
            # leave no active lock that could block the retry. Staged data is
            # safe diagnostic staging, never an active/customer DB copy.
            if descriptor is not None:
                try:
                    self._write_cancel(job_id, payload.get("helper_nonce", ""), str(exc))
                except Exception:
                    pass
            if supervisor is not None:
                terminate = getattr(supervisor, "terminate", None)
                if callable(terminate):
                    try:
                        terminate()
                    except OSError:
                        pass
            self._remove_active_lock()
            if descriptor is not None:
                try:
                    descriptor.unlink(missing_ok=True)
                except OSError:
                    pass
            raise


def pending_database_update_receipt(installation_root: Path) -> dict | None:
    """Return the most recent unacknowledged external helper receipt."""
    results = _canonical(installation_root) / "updates" / JOB_DIR_NAME / JOB_RESULT_DIR
    if not results.is_dir() or results.is_symlink():
        return None
    candidates = [p for p in results.glob("*.json") if p.is_file() and not p.is_symlink()]
    for path in sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(payload, dict) and not payload.get("shown_at"):
                return payload
        except (OSError, ValueError, json.JSONDecodeError):
            continue
    return None


def recover_abandoned_database_update(installation_root: Path) -> dict | None:
    """Surface an interrupted 1.34.3/1.34.4 handoff on the next HADS start.

    This never touches the active database.  It only converts an orphaned
    descriptor/active marker into a one-time receipt with the concrete log
    path, so a manual relaunch cannot leave users staring at an old database
    without an explanation.
    """
    root = _canonical(installation_root)
    jobs = root / "updates" / JOB_DIR_NAME
    active = jobs / JOB_ACTIVE_NAME
    if not active.is_file() or active.is_symlink():
        return None
    try:
        marker = json.loads(active.read_text(encoding="utf-8"))
        job_id = str(marker.get("job_id") or "")
        if not re.fullmatch(r"[A-Za-z0-9]{20,80}", job_id):
            return None
        descriptor = jobs / f"job_{job_id}.json"
        result = jobs / JOB_RESULT_DIR / f"{job_id}.json"
        if result.is_file():
            return None
        job = json.loads(descriptor.read_text(encoding="utf-8")) if descriptor.is_file() and not descriptor.is_symlink() else {}
        backend_pid = int(job.get("backend_pid", 0) or 0)
        expected = str(job.get("backend_process_identity") or "")
        if backend_pid > 0 and expected and _process_is_running(backend_pid, expected):
            return None
        log_path = str(job.get("log_path") or (root / "updates" / JOB_LOG_DIR / f"database_update_{job_id}.log"))
        supervisor_marker = jobs / "supervisor_failed" / f"{job_id}.txt"
        supervisor_detail = ""
        try:
            if supervisor_marker.is_file() and not supervisor_marker.is_symlink():
                supervisor_detail = " Native supervizor: " + supervisor_marker.read_text(encoding="utf-8", errors="replace").strip()
        except OSError:
            pass
        payload = {
            "format": 1, "job_id": job_id, "completed_at": time.time(), "success": False,
            "old_verified_restored": False, "abandoned": True,
            "detail": (
                "Nalezena nedokončená externí aktualizace databáze. HADS nebyl ukončen "
                "dalším pokusem; aktivní databáze nebyla novou úlohou potvrzena." + supervisor_detail
            ),
            "source_name": job.get("source_name"), "source_last_modified": job.get("source_last_modified"),
            "source_size": job.get("source_size"), "log_path": log_path, "restart_spawned": False,
        }
        _safe_json_write(result, payload)
        active.unlink(missing_ok=True)
        return payload
    except (OSError, ValueError, json.JSONDecodeError):
        return None


def acknowledge_database_update_receipt(installation_root: Path, job_id: str) -> None:
    if not re.fullmatch(r"[A-Za-z0-9]{20,80}", str(job_id or "")):
        raise UpdateError("Neplatný identifikátor výsledku aktualizace.")
    path = _canonical(installation_root) / "updates" / JOB_DIR_NAME / JOB_RESULT_DIR / (job_id + ".json")
    if not _is_under(path, _canonical(installation_root) / "updates" / JOB_DIR_NAME / JOB_RESULT_DIR):
        raise UpdateError("Neplatná cesta výsledku aktualizace.")
    _regular_file(path, "výsledek aktualizace")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or payload.get("job_id") != job_id:
        raise UpdateError("Výsledek aktualizace není platný.")
    payload["shown_at"] = time.time()
    _safe_json_write(path, payload)
    # Completed descriptors contain only operational paths/hashes.  Once the
    # one-time result was surfaced, remove them; no staged database remains on
    # a successful job and no customer configuration is ever touched.
    descriptor = path.parent.parent / ("job_" + job_id + ".json")
    try:
        if descriptor.is_file() and not descriptor.is_symlink():
            try:
                descriptor_payload = json.loads(descriptor.read_text(encoding="utf-8"))
                staged = Path(str(descriptor_payload.get("staged_path") or ""))
                staging_root = path.parent.parent / JOB_STAGING_DIR
                if _is_under(staged, staging_root) and staged.is_file() and not staged.is_symlink():
                    staged.unlink()
            except (OSError, ValueError, json.JSONDecodeError):
                pass
            descriptor.unlink()
    except OSError:
        pass
