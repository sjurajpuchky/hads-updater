"""Lokální lifecycle a jednorázové nonce pro bezpečné ukončení aplikace."""
from __future__ import annotations

import contextlib
import hmac
import secrets
import threading
import time
from dataclasses import dataclass


class LifecycleBusy(RuntimeError):
    """Požadavek nelze bezpečně zahájit během ukončování."""


class LifecycleController:
    """Serializuje kritickou práci a přijímané ukončení bez zabití procesu."""

    def __init__(self) -> None:
        self._condition = threading.Condition(threading.RLock())
        self._state = "running"
        self._critical = 0

    @property
    def state(self) -> str:
        with self._condition:
            return self._state

    @property
    def accepting_work(self) -> bool:
        with self._condition:
            return self._state == "running"

    def begin_critical(self) -> None:
        with self._condition:
            if self._state != "running":
                raise LifecycleBusy("Aplikace se právě ukončuje; novou operaci nelze zahájit.")
            self._critical += 1

    def end_critical(self) -> None:
        with self._condition:
            self._critical = max(0, self._critical - 1)
            if not self._critical:
                # External database replacement has already started an
                # independent child. Once its request response is released,
                # complete the reserved shutdown without allowing another
                # critical operation to slip in between spawn and teardown.
                if self._state == "quiescing":
                    self._state = "shutting_down"
                self._condition.notify_all()

    @contextlib.contextmanager
    def critical(self):
        self.begin_critical()
        try:
            yield
        finally:
            self.end_critical()

    def request_shutdown(self, timeout: float) -> bool:
        """Zastaví přijetí nové kritické práce a čeká omezeně na dosavadní."""
        with self._condition:
            if self._state != "running":
                return False
            self._state = "quiescing"
            deadline = time.monotonic() + max(0.0, timeout)
            while self._critical:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self._state = "running"
                    self._condition.notify_all()
                    return False
                self._condition.wait(remaining)
            self._state = "shutting_down"
            self._condition.notify_all()
            return True

    def reserve_external_handoff(self) -> None:
        """Block new work while the caller still owns one critical section.

        Used only after a replacement helper has been spawned successfully.
        It makes the accepted HTTP response and the subsequent graceful exit a
        single lifecycle decision, without waiting for the caller's own
        critical count (which would deadlock ``request_shutdown``).
        """
        with self._condition:
            if self._state != "running":
                raise LifecycleBusy("Aplikace se právě ukončuje; novou operaci nelze zahájit.")
            self._state = "quiescing"

    def cancel_external_handoff(self) -> None:
        """Undo a not-yet-accepted handoff if response preparation failed."""
        with self._condition:
            if self._state == "quiescing":
                self._state = "running"
                self._condition.notify_all()


@dataclass
class _NonceRecord:
    value: str
    origin: str
    expires_at: float


class ShutdownNonceStore:
    """Jednorázový, časově omezený nonce svázaný s povoleným originem."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._record: _NonceRecord | None = None

    def issue(self, origin: str, lifetime_seconds: float = 180.0) -> str:
        value = secrets.token_urlsafe(32)
        with self._lock:
            self._record = _NonceRecord(value, origin, time.monotonic() + lifetime_seconds)
        return value

    def consume(self, origin: str, header_value: str | None, body_value: str | None) -> bool:
        """Porovná hodnoty konstantním časem a platný nonce ihned zneplatní."""
        with self._lock:
            record = self._record
            if record is None or time.monotonic() > record.expires_at:
                self._record = None
                return False
            valid = (
                isinstance(header_value, str)
                and isinstance(body_value, str)
                and hmac.compare_digest(origin, record.origin)
                and hmac.compare_digest(header_value, body_value)
                and hmac.compare_digest(header_value, record.value)
            )
            if valid:
                self._record = None
            return valid

    def invalidate(self) -> None:
        with self._lock:
            self._record = None
