# -*- coding: utf-8 -*-
"""Sdílené per-podnik úložiště dat (varianta 2 – fyzicky oddělené soubory).

MOTIVACE
--------
Dříve byla všechna per-podnik data v jednom sdíleném JSON souboru v ``data/``
(např. ``data/report_history.json``) klíčovaném ``"podnik:<název>"``. To
znemožňovalo bezpečnou synchronizaci složky ``data/`` mezi dvěma PC (Syncthing,
Nextcloud, OneDrive, síťový disk): když dva uživatelé pracovali na jiném
podniku, přepisovali TÝŽ soubor a vznikaly konflikty celého souboru.

Tento modul ukládá data KAŽDÉHO PODNIKU do vlastní podsložky::

    data/podniky/<slug-podniku>/machine_config.json
    data/podniky/<slug-podniku>/report_history.json
    data/podniky/<slug-podniku>/report_drafts.json
    data/podniky/<slug-podniku>/company.json
    data/podniky/<slug-podniku>/report_settings.json
    data/podniky/<slug-podniku>/_key.txt      # originální db_key (kvůli dohledání)

Každý soubor obsahuje PŘÍMO obsah daného podniku (už NE slovník klíčovaný
``podnik:<název>``). Dva uživatelé pracující na různých podnicích tak zapisují
do různých složek → žádné konflikty celého souboru při synchronizaci.

Globální data zůstávají v kořeni ``data/`` (custom_norms.json, ai_examples.json,
ai_prompts.json, ai_config.json) a NEjsou tímto modulem řízena.

``ai_config.json`` obsahuje ŽIVÉ API klíče – měl by zůstat LOKÁLNÍ na každém PC
a být vyloučen z jakékoli synchronizace.

Používá POUZE standardní knihovnu Pythonu.
"""

import hashlib
import json
import os
import re
import shutil
import unicodedata
from pathlib import Path

_BASE = Path(__file__).resolve().parent.parent
_DATA_DIR = _BASE / "data"
_PODNIKY_DIR = _DATA_DIR / "podniky"
_IDENTITY_FORMAT = 1

# Názvy per-podnik souborů (druh dat -> jméno souboru ve složce podniku).
KIND_MACHINE_CONFIG = "machine_config"
KIND_REPORT_HISTORY = "report_history"
KIND_REPORT_DRAFTS = "report_drafts"
KIND_COMPANY = "company"
KIND_REPORT_SETTINGS = "report_settings"

_FILENAMES = {
    KIND_MACHINE_CONFIG: "machine_config.json",
    KIND_REPORT_HISTORY: "report_history.json",
    KIND_REPORT_DRAFTS: "report_drafts.json",
    KIND_COMPANY: "company.json",
    KIND_REPORT_SETTINGS: "report_settings.json",
}

# Všechny per-podnik druhy dat (pro migraci a přejmenování).
ALL_KINDS = tuple(_FILENAMES.keys())

# Stará (root) umístění – používají se JEN pro jednorázovou migraci.
_LEGACY_ROOT_FILES = {
    KIND_MACHINE_CONFIG: _DATA_DIR / "machine_config.json",
    KIND_REPORT_HISTORY: _DATA_DIR / "report_history.json",
    KIND_REPORT_DRAFTS: _DATA_DIR / "report_drafts.json",
    KIND_COMPANY: _DATA_DIR / "company.json",
    KIND_REPORT_SETTINGS: _DATA_DIR / "report_settings.json",
}


def _legacy_root_file(kind):
    """Dynamic legacy location for portable installs and isolated bootstrap."""
    filename = _FILENAMES.get(kind)
    return (_DATA_DIR / filename) if filename else None


# ---------------------------------------------------------------------------
# Odvození názvu složky (slug) z klíče podniku
# ---------------------------------------------------------------------------

def slugify(db_key):
    """Převede klíč podniku (``"podnik:<název>"`` nebo jméno souboru) na
    název složky bezpečný pro souborový systém, ale stále čitelný.

    * odstraní prefix ``podnik:``
    * diakritiku ponechá (moderní FS ji zvládají), ale odstraní znaky, které
      dělají problémy napříč OS: ``/ \\ : * ? " < > |`` a řídicí znaky
    * ořízne mezery a tečky na krajích, sloučí bílé znaky
    * prázdný výsledek nahradí ``_prazdny``
    """
    key = str(db_key or "").strip()
    if key.startswith("podnik:"):
        key = key[len("podnik:"):]
    key = key.strip()
    # odstraň znaky nepovolené/nebezpečné ve jménech složek napříč OS
    key = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", key)
    # sluč bílé znaky do jedné mezery
    key = re.sub(r"\s+", " ", key).strip()
    # tečky/mezery na konci dělají problém na Windows
    key = key.rstrip(" .")
    if not key:
        return "_prazdny"
    # ochrana proti přehnaně dlouhým jménům
    return key[:120]


def podnik_dir(db_key, create=False):
    """Vrátí Path ke složce daného podniku (``data/podniky/<slug>``)."""
    d = _PODNIKY_DIR / _folder_for_key(db_key)
    if create:
        d.mkdir(parents=True, exist_ok=True)
        # ulož originální klíč pro pozdější dohledání (jen jednou)
        keyfile = d / "_key.txt"
        if not keyfile.exists():
            try:
                keyfile.write_text(str(db_key or ""), encoding="utf-8")
            except Exception:
                pass
    return d


# ---------------------------------------------------------------------------
# Trvalá identita kontextu databáze (1.38.2)
# ---------------------------------------------------------------------------
#
# `podnik:<název>` was intentionally introduced as a better key than the NDB
# filename.  It was nevertheless not an identity: a freshly created empty
# `<název>` folder prevented the old `<soubor>.ndb` folder from being moved.
# This is the exact "data exist but UI sees no technicians" failure mode.
#
# The registry below binds an intrinsic NDB fingerprint supplied by server.py
# to a *physical* folder.  It stores only hashes of aliases and enterprise
# labels; raw historical aliases remain in the legacy `_key.txt` that is
# already part of the shipped layout.  It is deliberately an index, not a
# second source of user data.

def _hash_identity(value):
    return hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()


def _empty_registry():
    return {"format": _IDENTITY_FORMAT, "contexts": {}}


def _identity_file():
    """Dynamic because tests and portable bootstrap can retarget DATA_DIR."""
    return _PODNIKY_DIR / "_identity_registry.json"


def _read_registry():
    try:
        value = json.loads(_identity_file().read_text(encoding="utf-8"))
        if (isinstance(value, dict) and value.get("format") == _IDENTITY_FORMAT
                and isinstance(value.get("contexts"), dict)):
            return value
    except Exception:
        pass
    return _empty_registry()


def _atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp-" + os.urandom(8).hex())
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")
    os.replace(temp, path)


def _write_registry(value):
    _atomic_json(_identity_file(), value)


def _folder_for_key(db_key):
    """Resolve a canonical context key through the versioned registry.

    Old callers and layouts still use a readable slug.  A registry is only
    consulted for an explicit `ctx:` key, so a partially written/corrupt index
    can never redirect historical data unexpectedly.
    """
    key = str(db_key or "")
    if key.startswith("ctx:"):
        rec = _read_registry().get("contexts", {}).get(key)
        folder = rec.get("folder") if isinstance(rec, dict) else ""
        if (isinstance(folder, str) and folder and "/" not in folder
                and "\\" not in folder and folder not in (".", "..")):
            return folder
    return slugify(key)


def _folder_has_user_data(folder):
    """True only for a recognised user file with non-empty JSON/text content."""
    for filename in _FILENAMES.values():
        path = folder / filename
        try:
            if path.is_file() and not path.is_symlink() and path.stat().st_size:
                return True
        except OSError:
            pass
    # Keep unknown attachments/annotations as user data too.  `_key.txt` and
    # the registry itself are metadata and do not make a folder non-empty.
    try:
        return any(p.name not in {"_key.txt", _identity_file().name}
                   for p in folder.iterdir())
    except OSError:
        return False


def _normal_name(value):
    """Comparison helper; never used as a fuzzy match by itself."""
    return unicodedata.normalize("NFC", str(value or "")).strip().casefold()


def _safe_json(path):
    try:
        if path.is_file() and not path.is_symlink():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return None


def _merge_report_settings(current, legacy):
    """Non-destructive, deterministic merge for technicians and blank values."""
    current = current if isinstance(current, dict) else {}
    legacy = legacy if isinstance(legacy, dict) else {}
    merged = dict(legacy)
    conflicts = []
    # Technicians are a set in the UI; retain first spelling and stable order.
    names, seen = [], set()
    for row in (legacy.get("technicians") or []) + (current.get("technicians") or []):
        text = str(row).strip()
        marker = _normal_name(text)
        if text and marker not in seen:
            names.append(text); seen.add(marker)
    merged["technicians"] = names
    for section in ("quantities",):
        old_section = legacy.get(section) if isinstance(legacy.get(section), dict) else {}
        new_section = current.get(section) if isinstance(current.get(section), dict) else {}
        section_value = dict(old_section)
        for key, value in new_section.items():
            if key in section_value and section_value[key] not in ("", None) and value not in ("", None) and section_value[key] != value:
                conflicts.append("report_settings." + str(key))
            # Current context wins only if it actually has a value.  The old
            # value is otherwise recovered; the source folder is retained.
            if value not in ("", None):
                section_value[key] = value
        if section_value:
            merged[section] = section_value
    for key, value in current.items():
        if key not in merged:
            merged[key] = value
    return merged, conflicts


def _copy_or_merge_file(source, target, filename):
    """Recover one known file without deleting or overwriting source data."""
    src, dst = source / filename, target / filename
    if not src.is_file() or src.is_symlink():
        return [], []
    if not dst.exists():
        shutil.copy2(src, dst)
        return [filename], []
    if filename == _FILENAMES[KIND_REPORT_SETTINGS]:
        old, current = _safe_json(src), _safe_json(dst)
        if isinstance(old, dict) and isinstance(current, dict):
            merged, conflicts = _merge_report_settings(current, old)
            if merged != current:
                _atomic_json(dst, merged)
            return ["merged:" + filename], conflicts
    try:
        if src.read_bytes() == dst.read_bytes():
            return [], []
    except OSError:
        pass
    return [], [filename]


def _legacy_candidates(aliases, enterprise):
    """Return folders supported by positive evidence, never slug guesses."""
    wanted = {str(item).strip() for item in aliases if item}
    enterprise_norm = _normal_name(enterprise)
    candidates = []
    if not _PODNIKY_DIR.is_dir():
        return candidates
    for folder in _PODNIKY_DIR.iterdir():
        if (not folder.is_dir() or folder.is_symlink()
                or folder.name.startswith("_") or folder.name.startswith("ctx-")):
            continue
        key = _read_keyfile(folder)
        company = _company_name(folder)
        # An exact `_key.txt` alias is direct provenance.  The persisted
        # company.json name only confirms the alias; it must never make a
        # different key eligible.  In particular, do not re-introduce the old
        # broad “same display name / same slug” recovery: that can attach a
        # single orphan of another company when no second orphan happens to
        # expose the ambiguity.
        if key in wanted and (not enterprise_norm or not company
                              or _normal_name(company) == enterprise_norm):
            candidates.append(folder)
    return candidates


def reconcile_context(stable_fingerprint, aliases=(), enterprise=""):
    """Bind current NDB identity to legacy data safely.

    Return safe diagnostic metadata.  The operation is idempotent and never
    removes a source folder.  A single verified legacy folder is made reachable
    immediately.  If an empty current folder and that legacy folder coexist,
    the registry points at the populated source.  If both contain data, only
    defined report-settings merges happen; all other conflicting files stay in
    place and are reported for explicit recovery.
    """
    stable_fingerprint = str(stable_fingerprint or "").strip()
    if not stable_fingerprint:
        return {"key": None, "status": "identity_unavailable", "code": "ID_NO_FINGERPRINT"}
    key = "ctx:" + _hash_identity(stable_fingerprint)[:32]
    aliases = tuple(str(value).strip() for value in aliases if str(value).strip())
    registry = _read_registry()
    contexts = registry["contexts"]
    known = contexts.get(key)
    if isinstance(known, dict):
        folder = _PODNIKY_DIR / str(known.get("folder") or "")
        if folder.is_dir() and not folder.is_symlink():
            return {"key": key, "status": "known", "code": "ID_KNOWN",
                    "folder_hash": _hash_identity(folder.name)[:12]}

    # First make pre-per-company root records visible to the evidence scan.
    for alias in aliases:
        for kind in ALL_KINDS:
            _migrate_kind_if_needed(kind, alias)

    direct = []
    for alias in aliases:
        candidate = _PODNIKY_DIR / slugify(alias)
        # A readable old slug is not proof.  It is eligible only when its
        # `_key.txt` names an exact historical alias; this avoids joining two
        # unrelated companies merely because a display name/slug collides.
        company_name = _company_name(candidate) if candidate.is_dir() else ""
        if (candidate.is_dir() and not candidate.is_symlink()
                and _read_keyfile(candidate) in aliases
                and (not enterprise or not company_name
                     or _normal_name(company_name) == _normal_name(enterprise))
                and candidate not in direct):
            direct.append(candidate)
    verified = _legacy_candidates(aliases, enterprise)
    candidates = []
    for folder in direct + verified:
        if folder not in candidates:
            candidates.append(folder)
    # A folder already bound to another proven intrinsic NDB identity is never
    # reused merely because the legacy display label matches.  This is the
    # critical guard for two different companies both named e.g. "Duslo".
    #
    # The one deliberately narrow exception is a replacement of the *same
    # active filename*: a device/database update may create a new intrinsic
    # fingerprint while retaining the file selected by the operator and the
    # embedded enterprise.  This is positive replacement provenance, unlike a
    # slug/name match.  It preserves the company's settings but does not merge
    # anything and cannot join two simultaneously named files.  Store the
    # first alias separately for this purpose (server always supplies filename
    # first); older registry entries simply do not qualify for this exception.
    filename_alias_hash = _hash_identity(aliases[0])[:24] if aliases else None
    owned_elsewhere = {}
    for known_key, rec in contexts.items():
        if known_key == key or not isinstance(rec, dict) or not rec.get("folder"):
            continue
        owned_elsewhere.setdefault(str(rec.get("folder")), []).append(rec)

    def _replacement_proven(folder):
        owners = owned_elsewhere.get(folder.name) or []
        return bool(filename_alias_hash and any(
            rec.get("filename_alias_hash") == filename_alias_hash
            and rec.get("enterprise_hash") == (
                _hash_identity(_normal_name(enterprise))[:24] if enterprise else None
            )
            for rec in owners
        ))

    candidates = [
        folder for folder in candidates
        if folder.name not in owned_elsewhere or _replacement_proven(folder)
    ]
    populated = [folder for folder in candidates if _folder_has_user_data(folder)]

    # Prefer an existing populated canonical/new folder only when it has
    # provenance in `_key.txt`; otherwise a single verified old source wins.
    if len(populated) == 1:
        chosen = populated[0]
        status, code = ("recovered", "ID_RECOVERED_ORPHAN")
        recovered = True
        conflicts = []
    elif not populated:
        chosen = _PODNIKY_DIR / ("ctx-" + _hash_identity(stable_fingerprint)[:20])
        chosen.mkdir(parents=True, exist_ok=True)
        status, code, recovered, conflicts = "new", "ID_NEW_CONTEXT", False, []
    else:
        # If there is a single direct target and other verified source(s), only
        # report-settings can be merged safely.  Sources are intentionally kept.
        current = next(
            (f for f in direct if f in populated
             and _read_keyfile(f).startswith("podnik:")),
            next((f for f in direct if f in populated), None),
        )
        if current is not None and len(populated) == 2:
            source = next(f for f in populated if f != current)
            copied, conflicts = [], []
            for filename in _FILENAMES.values():
                did, issue = _copy_or_merge_file(source, current, filename)
                copied.extend(did); conflicts.extend(issue)
            chosen, recovered = current, bool(copied)
            status = "merged" if copied and not conflicts else "conflict"
            code = "ID_MERGED_SAFE" if status == "merged" else "ID_CONFLICT_PRESERVED"
        else:
            # Ambiguity includes two companies with the same display name.  Do
            # not silently select either of them.
            chosen = _PODNIKY_DIR / ("ctx-" + _hash_identity(stable_fingerprint)[:20])
            chosen.mkdir(parents=True, exist_ok=True)
            status, code, recovered, conflicts = "ambiguous", "ID_AMBIGUOUS_PRESERVED", False, []

    if not (chosen / "_key.txt").exists():
        try:
            (chosen / "_key.txt").write_text(key, encoding="utf-8")
        except OSError:
            pass
    contexts[key] = {
        "folder": chosen.name,
        "alias_hashes": sorted({_hash_identity(item)[:24] for item in aliases}),
        "filename_alias_hash": filename_alias_hash,
        "enterprise_hash": _hash_identity(_normal_name(enterprise))[:24] if enterprise else None,
        "format": _IDENTITY_FORMAT,
    }
    _write_registry(registry)
    return {"key": key, "status": status, "code": code, "recovered": recovered,
            "conflicts": len(conflicts), "folder_hash": _hash_identity(chosen.name)[:12],
            "candidate_count": len(populated)}


def persistence_registry():
    """Public, secret-free description of the cross-version storage contract."""
    return {
        "format": 1,
        "per_company": {
            KIND_REPORT_SETTINGS: _FILENAMES[KIND_REPORT_SETTINGS],
            KIND_COMPANY: _FILENAMES[KIND_COMPANY],
            KIND_MACHINE_CONFIG: _FILENAMES[KIND_MACHINE_CONFIG],
            KIND_REPORT_DRAFTS: _FILENAMES[KIND_REPORT_DRAFTS],
            KIND_REPORT_HISTORY: _FILENAMES[KIND_REPORT_HISTORY],
        },
        "global": (
            "custom_norms.json", "ai_examples.json", "ai_prompts.json",
            "ai_config.json", "ai_credentials.bin", "ai_credentials.machinekey",
            "shared_updates.json", "library.json", "current.txt",
            "branding/settings.json", "branding/logo.jpg",
        ),
    }


def _file_for(kind, db_key, create=False):
    fn = _FILENAMES.get(kind)
    if not fn:
        raise ValueError("neznámý druh dat: %r" % (kind,))
    return podnik_dir(db_key, create=create) / fn


# ---------------------------------------------------------------------------
# Načtení / uložení / smazání jednoho druhu dat pro jeden podnik
# ---------------------------------------------------------------------------

def load(kind, db_key, default=None):
    """Načte obsah daného druhu dat pro podnik, nebo ``default``.

    Zároveň provede (jen jednou) migraci ze starého sdíleného root souboru,
    pokud pro tento podnik ještě per-podnik soubor neexistuje.
    """
    if not db_key:
        return default
    _migrate_kind_if_needed(kind, db_key)
    f = _file_for(kind, db_key)
    if f.exists():
        try:
            return json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            return default
    return default


def save(kind, db_key, value):
    """Uloží obsah daného druhu dat pro podnik (přepíše)."""
    if not db_key:
        return value
    f = _file_for(kind, db_key, create=True)
    f.write_text(json.dumps(value, ensure_ascii=False, indent=2),
                 encoding="utf-8")
    return value


def delete(kind, db_key):
    """Smaže soubor daného druhu dat pro podnik (pokud existuje)."""
    if not db_key:
        return
    f = _file_for(kind, db_key)
    try:
        if f.exists():
            f.unlink()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Přejmenování / přesun celého podniku (změna klíče)
# ---------------------------------------------------------------------------

def rename_podnik(old_key, new_key):
    """Přesune data podniku ze staré složky (dané ``old_key``) do nové
    (dané ``new_key``). Používá se, když se změní identita klíče podniku
    (např. přechod z jména souboru na název podniku).

    Při jednoznačném přejmenování přesune atomicky CELÝ adresář, tedy i dosud
    neznámé soubory. Pokud cílový adresář již existuje, nic nemění: dřívější
    implementace v této situaci zahazovala staré soubory, a tím mohla vytvořit
    zdánlivě ztracené techniky, historii nebo koncepty.
    """
    if not old_key or not new_key:
        return False
    old_slug = slugify(old_key)
    new_slug = slugify(new_key)
    if old_slug == new_slug:
        return False
    old_dir = _PODNIKY_DIR / old_slug
    if not old_dir.exists():
        return False
    new_dir = _PODNIKY_DIR / new_slug
    if new_dir.exists():
        return False
    try:
        _PODNIKY_DIR.mkdir(parents=True, exist_ok=True)
        os.replace(old_dir, new_dir)
        keyfile = new_dir / "_key.txt"
        if not keyfile.exists():
            keyfile.write_text(str(new_key), encoding="utf-8")
        return True
    except Exception:
        return False


def _read_keyfile(folder):
    keyfile = folder / "_key.txt"
    try:
        if keyfile.is_file() and not keyfile.is_symlink():
            return keyfile.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return ""


def _company_name(folder):
    try:
        path = folder / _FILENAMES[KIND_COMPANY]
        if not path.is_file() or path.is_symlink():
            return ""
        value = json.loads(path.read_text(encoding="utf-8"))
        name = value.get("name") if isinstance(value, dict) else ""
        return str(name).strip() if name else ""
    except Exception:
        return ""


def repair_orphan_mapping(db_key, aliases=()):
    """Bezpečně opraví jediný dohledatelný osiřelý adresář podniku.

    Oprava je záměrně konzervativní: cílový adresář nesmí existovat a přesně
    jeden zdroj musí odpovídat uloženému ``_key.txt`` (nebo zadanému starému
    názvu databáze), případně názvu podniku v ``company.json``. Při kolizi či
    nejistotě nedělá nic – zachování dat má přednost před heuristikou.
    """
    if not db_key:
        return {"status": "invalid"}
    target = _PODNIKY_DIR / slugify(db_key)
    if target.exists() or not _PODNIKY_DIR.is_dir():
        return {"status": "not_needed" if target.exists() else "missing_root"}
    wanted = {str(db_key).strip()}
    wanted.update(str(item).strip() for item in aliases if item)
    enterprise = str(db_key).split(":", 1)[1].strip() if str(db_key).startswith("podnik:") else ""
    candidates = []
    try:
        folders = [p for p in _PODNIKY_DIR.iterdir() if p.is_dir() and not p.is_symlink()]
    except Exception:
        return {"status": "unreadable"}
    for folder in folders:
        key = _read_keyfile(folder)
        if key in wanted or (enterprise and _company_name(folder) == enterprise):
            candidates.append(folder)
    if len(candidates) != 1:
        return {"status": "ambiguous" if candidates else "not_found", "candidates": len(candidates)}
    source = candidates[0]
    try:
        os.replace(source, target)
        (target / "_key.txt").write_text(str(db_key), encoding="utf-8")
        return {"status": "repaired", "from": source.name, "to": target.name}
    except Exception:
        return {"status": "failed", "from": source.name, "to": target.name}


# ---------------------------------------------------------------------------
# Jednorázová migrace ze starých sdílených root JSON souborů
# ---------------------------------------------------------------------------

def _migrate_kind_if_needed(kind, db_key):
    """Pokud pro daný podnik ještě NEexistuje per-podnik soubor, ale ve
    starém sdíleném root souboru je záznam pro tento klíč, přenese ho.

    Root soubor se NEmaže (nedestruktivní) – jen se z něj čte. Jakmile má
    podnik svůj soubor, tato migrace se pro něj už neprovede.
    """
    if not db_key:
        return
    target = _file_for(kind, db_key)
    if target.exists():
        return  # už migrováno / vytvořeno
    legacy = _legacy_root_file(kind)
    if not legacy or not legacy.exists():
        return
    try:
        alldata = json.loads(legacy.read_text(encoding="utf-8")) or {}
    except Exception:
        return
    if not isinstance(alldata, dict):
        return
    key = str(db_key)
    if key not in alldata:
        return
    # přenes záznam do per-podnik souboru
    try:
        save(kind, db_key, alldata[key])
    except Exception:
        pass


def migrate_all_legacy():
    """Projde všechny staré root soubory a rozdělí je do per-podnik složek.

    Volá se jednou při startu serveru. Nedestruktivní: root soubory ponechá
    (přejmenuje je na ``*.migrated`` až po úspěšném rozdělení, aby se migrace
    neopakovala a zároveň zůstala záloha).
    """
    for kind in ALL_KINDS:
        legacy = _legacy_root_file(kind)
        if not legacy.exists():
            continue
        try:
            alldata = json.loads(legacy.read_text(encoding="utf-8")) or {}
        except Exception:
            continue
        if not isinstance(alldata, dict) or not alldata:
            continue
        wrote_any = False
        for key, value in alldata.items():
            if not key:
                continue
            target = _file_for(kind, key)
            if target.exists():
                continue  # už existuje per-podnik soubor – nepřepisuj
            try:
                save(kind, key, value)
                wrote_any = True
            except Exception:
                pass
        # po úspěšném rozdělení odsuň starý root soubor stranou (záloha)
        if wrote_any:
            try:
                backup = legacy.with_suffix(legacy.suffix + ".migrated")
                if not backup.exists():
                    legacy.rename(backup)
            except Exception:
                pass
