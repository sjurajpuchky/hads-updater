# -*- coding: utf-8 -*-
"""Bezpečný TAGOVANÝ import závěrů/doporučení z DOCX zpět do protokolu.

Princip bezpečnosti (velmi důležité — čti před úpravou):

  * Import čte VÝHRADNĚ prostý text uvnitř skrytých strojových značek
    `[[HADS:<pole>:<machine_id>:START]] … [[HADS:<pole>:<machine_id>:END]]`,
    které do dokumentu vkládá `report_docx.py` (viz `TAG_OPEN`/`TAG_CLOSE`).
  * Podporovaná pole jsou POUZE `zaver` (Závěry) a `doporuceni`
    (Doporučení) — žádné jiné pole se ze DOCX nikdy nenačítá.
  * Z DOCX se NIKDY nenačítají technická/naměřená data (rychlosti,
    pásma A–D, stav ložisek, limity, datumy měření apod.) — i kdyby
    uživatel takový text do dokumentu vepsal, tato pole importér vůbec
    neparsuje ani nezapisuje zpět do doc["machines"].
  * `machine_id` ve značce se musí shodovat s existujícím strojem v
    AKTUÁLNÍM návrhu protokolu (doc), jinak se položka NEPOUŽIJE
    (a nahlásí se jako "unmatched").
  * Import je vždy DVOUKROKOVÝ: `extract_preview()` vrátí náhled změn
    (per stroj: starý text / nový text / stav shody), aplikace teprve
    `apply_selected()` s explicitním výběrem uživatele (selective apply).
    Nic se nezapíše automaticky bez potvrzení uživatelem.
  * Pokud v DOCX chybí očekávané značky (např. dokument byl vytvořen mimo
    tuto aplikaci, nebo uživatel značky smazal), import pro daný
    stroj/pole prostě nic nevrátí — NIKDY neodhaduje obsah "chytře" podle
    pozice v dokumentu, aby nedošlo k záměně stroje.
"""

import re
import zipfile
import io

FIELD_LABELS = {
    "zaver": "Závěry",
    "doporuceni": "Doporučení",
}

_TAG_RE = re.compile(
    r"\[\[HADS:(zaver|doporuceni):([^:\]]+):START\]\](.*?)"
    r"\[\[HADS:\1:\2:END\]\]",
    re.DOTALL,
)

# Pro odstranění případných zbytkových XML entit po extrakci z <w:t>
_WS_RE = re.compile(r"[ \t]+\n")


class DocxImportError(Exception):
    pass


def _read_document_xml(file_bytes):
    try:
        with zipfile.ZipFile(io.BytesIO(file_bytes)) as z:
            names = z.namelist()
            if "word/document.xml" not in names:
                raise DocxImportError(
                    "Soubor nevypadá jako platný .docx (chybí "
                    "word/document.xml).")
            return z.read("word/document.xml").decode("utf-8", "replace")
    except zipfile.BadZipFile:
        raise DocxImportError(
            "Soubor se nepodařilo otevřít jako .docx (poškozený nebo "
            "nejde o ZIP/DOCX formát).")


def _extract_plain_text_stream(document_xml):
    """Převede WordprocessingML XML na PROSTÝ text, ale ZACHOVÁ značky
    `[[HADS:...]]` v pořadí, v jakém se vyskytují (i když by byly rozdělené
    do více <w:t> run-ů, což Word běžně dělá při jakékoli úpravě textu).

    Zpracovává <w:t> (text) a <w:tab/>/<w:br/> jako mezery/zalomení, aby se
    slova při rekonstrukci nespojila. Vše ostatní (formátování, tabulky,
    obrázky) ignoruje — nezajímá nás vzhled, jen obsah značek a textu mezi
    nimi.
    """
    # <w:p ...> -> oddělovač odstavců (dvojitý newline), aby text uvnitř tagu
    # zůstal čitelný i po formátovacích úpravách uživatele
    out = []
    # najdi všechny <w:t ...>text</w:t>, <w:tab/>, <w:br/>, </w:p> v pořadí
    token_re = re.compile(
        r"<w:t(?:\s[^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br/>|</w:p>", re.DOTALL)
    for m in token_re.finditer(document_xml):
        if m.group(0) == "<w:tab/>":
            out.append("\t")
        elif m.group(0) == "<w:br/>":
            out.append("\n")
        elif m.group(0) == "</w:p>":
            out.append("\n\n")
        else:
            text = m.group(1) or ""
            text = (text.replace("&amp;", "&").replace("&lt;", "<")
                        .replace("&gt;", ">").replace("&quot;", '"')
                        .replace("&apos;", "'"))
            out.append(text)
    return "".join(out)


def _norm_text(s):
    """Normalizuje extrahovaný text — ořízne okraje, sjednotí prázdné řádky."""
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    # smaž nadbytečné mezery na koncích řádků
    s = "\n".join(ln.rstrip() for ln in s.split("\n"))
    # sjednoť 3+ prázdné řádky na max. 1
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def extract_tagged_fields(file_bytes):
    """Načte DOCX bytes a vrátí dict {(machine_id_str, field): text}.

    Nikdy nevyhazuje pro "cizí" DOCX bez značek — vrátí prázdný dict.
    Vyhazuje `DocxImportError` jen při nečitelném/poškozeném souboru.
    """
    xml = _read_document_xml(file_bytes)
    plain = _extract_plain_text_stream(xml)
    result = {}
    for m in _TAG_RE.finditer(plain):
        field, mid, text = m.group(1), m.group(2), m.group(3)
        result[(mid, field)] = _norm_text(text)
    return result


def extract_preview(file_bytes, current_doc):
    """Sestaví NÁHLED importu proti aktuálnímu návrhu protokolu `current_doc`.

    Vrací seznam položek (jedna na dvojici stroj+pole), každá:
      {
        "machine_id": <id z doc, typ dle doc>,
        "machine_name": <jméno stroje, pokud nalezen>,
        "field": "zaver" | "doporuceni",
        "field_label": "Závěry" | "Doporučení",
        "old_text": <aktuální text v návrhu>,
        "new_text": <text z DOCX>,
        "changed": bool,     # liší se new_text od old_text
        "matched": bool,     # machine_id byl nalezen v current_doc
      }
    a souhrn {"tagged_count", "matched_count", "changed_count", "unmatched": [..]}.

    NEPROVÁDÍ žádný zápis — je čistě informativní pro UI náhledu.
    """
    tagged = extract_tagged_fields(file_bytes)
    machines = (current_doc or {}).get("machines", []) or []
    by_id = {}
    for m in machines:
        mid = m.get("machine_id")
        if mid is not None:
            by_id[str(mid)] = m

    items = []
    unmatched_ids = set()
    for (mid, field), new_text in tagged.items():
        m = by_id.get(str(mid))
        matched = m is not None
        if not matched:
            unmatched_ids.add(mid)
        old_text = (m.get(field) or "") if matched else ""
        items.append({
            "machine_id": mid,
            "machine_name": (m.get("name") if matched else None) or
                            ("Neznámý stroj (id %s)" % mid),
            "field": field,
            "field_label": FIELD_LABELS.get(field, field),
            "old_text": old_text,
            "new_text": new_text,
            "changed": matched and (old_text or "").strip() != (new_text or "").strip(),
            "matched": matched,
        })

    # seřaď: nejprve podle jména stroje, pak pole (zaver před doporuceni)
    field_order = {"zaver": 0, "doporuceni": 1}
    items.sort(key=lambda it: (
        0 if it["matched"] else 1,
        (it["machine_name"] or ""),
        field_order.get(it["field"], 9),
    ))

    summary = {
        "tagged_count": len(items),
        "matched_count": sum(1 for it in items if it["matched"]),
        "changed_count": sum(1 for it in items if it["changed"]),
        "unmatched": sorted(unmatched_ids, key=lambda x: str(x)),
    }
    return items, summary


def apply_selected(current_doc, items, selected_keys):
    """Aplikuje VYBRANÉ položky náhledu do `current_doc` (kopie) a vrátí ji.

    `selected_keys` je množina/seznam řetězců `"<machine_id>|<field>"`
    identifikujících, které položky z `items` (výstup `extract_preview`) se
    mají skutečně zapsat. Nevybrané položky se ignorují. Nezpracovává nic
    mimo pole `zaver` / `doporuceni` u odpovídajícího stroje — žádná
    technická hodnota (pásma, limity, data měření) se NIKDY nemění.

    Vrací (new_doc, applied_count).
    """
    selected = set(str(k) for k in (selected_keys or []))
    new_doc = dict(current_doc or {})
    new_machines = [dict(m) for m in new_doc.get("machines", []) or []]
    by_id_idx = {}
    for i, m in enumerate(new_machines):
        mid = m.get("machine_id")
        if mid is not None:
            by_id_idx[str(mid)] = i

    applied = 0
    for it in items or []:
        if not it.get("matched"):
            continue
        field = it.get("field")
        if field not in ("zaver", "doporuceni"):
            continue  # bezpečnostní pojistka: jiná pole se nikdy nezapisují
        key = "%s|%s" % (it.get("machine_id"), field)
        if key not in selected:
            continue
        idx = by_id_idx.get(str(it.get("machine_id")))
        if idx is None:
            continue
        new_machines[idx][field] = it.get("new_text") or ""
        applied += 1

    new_doc["machines"] = new_machines
    return new_doc, applied
