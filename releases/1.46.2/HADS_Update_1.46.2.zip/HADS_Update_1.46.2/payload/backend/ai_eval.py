"""AI vyhodnocení stavu stroje pomocí LLM (OpenAI nebo Anthropic Claude).

Používá POUZE standardní knihovnu Pythonu (urllib) — nevyžaduje instalaci
balíčků `openai` ani `anthropic`. Sestaví odborný prompt (role: senior vibrační
diagnostik), do kterého vloží data stroje (poslední měření + krátký trend,
limity, ložiska, otáčky) a normu pro hodnocení rychlosti vibrací, a podle
zvoleného modelu zavolá OpenAI nebo Anthropic Claude.

Klíče se NIKDY neukládají do zdrojového kódu ani do ``ai_config.json``.
Načítají se (v tomto pořadí) z proměnných prostředí a z lokálního trezoru
``data/ai_credentials.bin``.  Na Windows je trezor DPAPI LocalMachine,
svázaný s instalací; na ostatních systémech se používá zdokumentovaný lokální
soubor 0600 s odděleným klíčem 0600. ``ai_config.json`` zachovává pouze model.
"""

import json
import math
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path
import threading

from ai_secrets import LocalSecretStore, SecretStorageError
import ai_prompts
import fft_analysis

_BASE = Path(__file__).resolve().parent.parent
_CFG_FILE = _BASE / "data" / "ai_config.json"
_CFG_LOCK = threading.RLock()

OPENAI_URL = "https://api.openai.com/v1/chat/completions"
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_MODEL = "gpt-4o"
_TIMEOUT_S = 120


class AIResponseFormatError(RuntimeError):
    """Bezpečná chyba nekompatibilního tvaru odpovědi AI.

    Je záměrně bez detailů odpovědi poskytovatele: ty mohou obsahovat
    uživatelská data, interní diagnostiku nebo jiné neověřené hodnoty.
    """

    public_message = (
        "AI odpověď nemá podporovaný tvar pro návrh protokolu. "
        "Zkuste akci zopakovat nebo změňte model."
    )

    def __init__(self):
        super().__init__(self.public_message)


def public_error_message(_error=None) -> str:
    """Return a deliberately non-sensitive UI/API error.

    Upstream provider bodies and network/agent exception text are untrusted:
    they can echo request headers or contain arbitrary diagnostics.  They must
    never be serialized into the local HTTP API, a generated report or logs.
    """
    return ("AI služba požadavek nedokončila. Zkontrolujte nastavení AI, "
            "zvolený model a připojení, potom akci opakujte.")


def public_response_format_message() -> str:
    """Vrátí jediný bezpečný text pro nekompatibilní AI odpověď."""
    return AIResponseFormatError.public_message


def _require_text(value):
    """Přijme pouze textový blok podporovaný kontraktem AI odpovědi."""
    if not isinstance(value, str):
        raise AIResponseFormatError()
    return value


def _require_mapping(value):
    if not isinstance(value, dict):
        raise AIResponseFormatError()
    return value

# --- Anthropic AI Agent (beta Managed Agents / Sessions REST API) ---
# Jde o samostatně nakonfigurovaného agenta v Anthropic Console (systémový
# prompt, případné nástroje) — odlišné od běžného Messages API výše.
# Volá se PŘÍMO přes urllib (stejně jako OpenAI/Anthropic výše) — žádný
# externí balíček (`anthropic`) se NEVYŽADUJE. Používá stejný
# ANTHROPIC_API_KEY jako běžná Claude volání (musí mít ale povolený
# přístup k beta Managed Agents API).
AI_AGENT_API_BASE = "https://api.anthropic.com/v1"
AI_AGENT_BETA_HEADER = "managed-agents-2026-04-01"
AI_AGENT_ID = "agent_01QsAUxakwcygA5HQbnYGS3r"
AI_AGENT_ENVIRONMENT_ID = "env_013Cj9o68zkYn2GMQYsCcQQF"
AI_AGENT_MODEL_ID = "anthropic-agent-protokol"
_AGENT_POLL_TIMEOUT_S = 180

# Katalog dostupných modelů (zobrazí se ve výběru na kartě stroje).
# provider určuje, které API a který klíč se použije.
MODELS = [
    {"id": "gpt-4o", "label": "OpenAI GPT-4o", "provider": "openai"},
    {"id": "gpt-4o-mini", "label": "OpenAI GPT-4o mini", "provider": "openai"},
    {"id": "claude-sonnet-4-6",
     "label": "Anthropic Claude Sonnet 4.6", "provider": "anthropic"},
    {"id": "claude-haiku-4-5-20251001",
     "label": "Anthropic Claude Haiku 4.5", "provider": "anthropic"},
    {"id": AI_AGENT_MODEL_ID,
     "label": "Anthropic AI Agent (protokol)", "provider": "anthropic_agent"},
]


def _provider_for(model):
    """Určí poskytovatele (openai/anthropic) podle id modelu."""
    for m in MODELS:
        if m["id"] == model:
            return m["provider"]
    # heuristika pro neznámé modely
    return "anthropic" if str(model).startswith("claude") else "openai"


# ----------------------- konfigurace / klíč -----------------------
def _load_cfg():
    if _CFG_FILE.exists():
        try:
            return json.loads(_CFG_FILE.read_text(encoding="utf-8")) or {}
        except Exception:
            return {}
    return {}


def _save_cfg(cfg):
    _CFG_FILE.parent.mkdir(exist_ok=True)
    # Nikdy znovu nezapíše historická tajemství, ani pokud je vloží starší
    # volající funkce. Ukládá se pouze kompatibilní ne-secret konfigurace.
    clean = {"schema": 2, "model": str(cfg.get("model") or DEFAULT_MODEL)}
    tmp = _CFG_FILE.with_name(_CFG_FILE.name + ".tmp")
    tmp.write_text(json.dumps(clean, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        import os
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    tmp.replace(_CFG_FILE)


def _secret_store():
    return LocalSecretStore(_CFG_FILE.parent)


def _migrate_plaintext_once():
    """Jednorázově převede historické klíče; při chybě nic nemaže."""
    with _CFG_LOCK:
        cfg = _load_cfg()
        legacy = {
            "openai": str(cfg.get("openai_api_key") or "").strip(),
            "anthropic": str(cfg.get("anthropic_api_key") or "").strip(),
        }
        if not any(legacy.values()) and not any(k in cfg for k in ("openai_api_key", "anthropic_api_key")):
            return
        store = _secret_store()
        if any(legacy.values()):
            # save() je atomické; plaintext se maže až po úspěšném zápisu blobu.
            existing = store.load()
            existing.update({k: v for k, v in legacy.items() if v})
            store.save(existing)
            # Ověření musí proběhnout před odstraněním plaintextu.
            migrated = store.load()
            if any(migrated.get(k) != v for k, v in legacy.items() if v):
                raise SecretStorageError("Převod historických přístupových údajů nelze ověřit.")
        _save_cfg(cfg)


def get_api_key(provider="openai"):
    """Vrátí klíč jen pro právě prováděné volání (nikdy jej nevrací API)."""
    import os
    if provider == "anthropic":
        env = os.environ.get("ANTHROPIC_API_KEY")
        secret_provider = "anthropic"
    else:
        env = os.environ.get("OPENAI_API_KEY")
        secret_provider = "openai"
    if env and env.strip():
        return env.strip()
    _migrate_plaintext_once()
    return _secret_store().load().get(secret_provider) or None


def get_model():
    _migrate_plaintext_once()
    return _load_cfg().get("model") or DEFAULT_MODEL


def has_api_key(provider="openai"):
    return bool(get_api_key(provider))


def has_any_key():
    try:
        return has_api_key("openai") or has_api_key("anthropic")
    except SecretStorageError:
        # Volající, který chce AI skutečně použít, nesmí pád nastavení změnit
        # na 500. Detail pro člověka poskytne /api/ai/status; blob zde nikdy
        # nemažeme ani nepřepisujeme.
        return False


def status():
    """Vrátí stav konfigurace AI bez klíčů a bez tajných diagnostik.

    Jeden nečitelný credential blob nesmí shodit celou stránku Nastavení.
    Stav proto rozlišuje nenastaveno, funkčně dostupný klíč a uložený, ale na
    tomto počítači nečitelný klíč.  Proměnné prostředí mají přednost.
    """
    import os
    environment = {
        "openai": bool(str(os.environ.get("OPENAI_API_KEY") or "").strip()),
        "anthropic": bool(str(os.environ.get("ANTHROPIC_API_KEY") or "").strip()),
    }
    stored: dict[str, str] = {}
    storage_error = False
    safe_store = _secret_store().diagnostic_state()
    try:
        # Retains compatible plaintext migration, but only after its protected
        # write-and-verify path succeeds. A failure preserves every source file.
        _migrate_plaintext_once()
        stored = _secret_store().load()
    except SecretStorageError:
        storage_error = True

    provider_states = {}
    for provider in ("openai", "anthropic"):
        if environment[provider] or bool(stored.get(provider)):
            state = "configured"
        elif storage_error and bool(safe_store.get("stored")):
            state = "stored_unavailable"
        else:
            state = "not_configured"
        provider_states[provider] = state
    has_openai = provider_states["openai"] == "configured"
    has_anthropic = provider_states["anthropic"] == "configured"
    return {
        "has_openai_key": has_openai,
        "has_anthropic_key": has_anthropic,
        "has_key": has_openai or has_anthropic,
        "providers": provider_states,
        "credential_storage": (
            "stored_unavailable" if storage_error and bool(safe_store.get("stored"))
            else "ok"
        ),
        # Čtení modelu je nezávislé na trezoru. Status proto zůstane funkční i
        # při vadném blobu/machinekey páru.
        "model": _load_cfg().get("model") or DEFAULT_MODEL,
        "models": MODELS,
    }


def set_config(*, model=None, provider=None, api_key=None):
    """Uloží pouze neprázdnou náhradu jednoho poskytovatele a/nebo model.

    Prázdné textové pole je záměrně no-op. Mazání smí provést jen
    ``delete_provider`` přes samostatný, potvrzený endpoint.
    """
    with _CFG_LOCK:
        _migrate_plaintext_once()
        cfg = _load_cfg()
        if model is not None and str(model).strip():
            candidate = str(model).strip()
            if candidate not in {item["id"] for item in MODELS}:
                raise ValueError("Neznámý model AI.")
            cfg["model"] = candidate
        if provider is not None:
            if provider not in ("openai", "anthropic"):
                raise ValueError("Neznámý poskytovatel AI.")
            value = str(api_key or "").strip()
            if value:
                values = _secret_store().load()
                values[provider] = value
                _secret_store().save(values)
        _save_cfg(cfg)
    return status()


def delete_provider(provider):
    """Explicitně odstraní lokálně uložený klíč daného poskytovatele."""
    if provider not in ("openai", "anthropic"):
        raise ValueError("Neznámý poskytovatel AI.")
    with _CFG_LOCK:
        _migrate_plaintext_once()
        values = _secret_store().load()
        values.pop(provider, None)
        _secret_store().save(values)
    return status()


# ----------------------- katalog norem -----------------------
# Jednotný katalog všech podporovaných norem pro hodnocení rychlosti vibrací.
# Každá norma má:
#   - label:   krátký název pro select (ten je klíčem v uloženém iso_norm.standard)
#   - long:    delší popis pro prompt AI
#   - classes: seznam tříd/kategorií (klíč = machine_class), každá obsahuje:
#       * label:    název kategorie (musí odpovídat klíči)
#       * band:     textový popis pásem pro AI prompt (volitelné)
#       * warning:  limit varování v mm/s RMS (mapuje se do ISO RMS)
#       * alarm:    limit alarmu v mm/s RMS (mapuje se do ISO RMS)
#
# Mapování pro propsání do bodů: warning -> Varování, alarm -> Alarm.
# Přidání nové normy = doplnit záznam do NORMS. Backend i frontend katalog
# načítají dynamicky (viz norms_catalog() a /api/norms/catalog).
NORMS = {
    "ČSN ISO 20816-3": {
        "label": "ČSN ISO 20816-3 (novější)",
        "long": "ČSN ISO 20816-3 – hodnocení stavu strojů měřením vibrací "
                "na nerotujících částech (rychlost vibrací, RMS).",
        "classes": {
            "Skupina 1 (velké stroje, tuhý základ)": {
                "band": "A/B ≤ 2,3; B/C ≤ 4,5; C/D ≤ 7,1 mm/s RMS",
                "ab": 2.3,
                "warning": 4.5,
                "alarm": 7.1,
            },
            "Skupina 1 (velké stroje, pružný základ)": {
                "band": "A/B ≤ 3,5; B/C ≤ 7,1; C/D ≤ 11,0 mm/s RMS",
                "ab": 3.5,
                "warning": 7.1,
                "alarm": 11.0,
            },
            "Skupina 2 (střední stroje, tuhý základ)": {
                "band": "A/B ≤ 1,4; B/C ≤ 2,8; C/D ≤ 4,5 mm/s RMS",
                "ab": 1.4,
                "warning": 2.8,
                "alarm": 4.5,
            },
            "Skupina 2 (střední stroje, pružný základ)": {
                "band": "A/B ≤ 2,3; B/C ≤ 4,5; C/D ≤ 7,1 mm/s RMS",
                "ab": 2.3,
                "warning": 4.5,
                "alarm": 7.1,
            },
        },
    },
    "ČSN ISO 20816-9 Převodovky": {
        "label": "ČSN ISO 20816-9 Převodovky",
        "long": "ČSN ISO 20816-9 Převodovky – hodnocení vibrací převodovek "
                "měřením rychlosti vibrací (RMS). Třídy VR vymezují pásma "
                "A/B, B/C a C/D v mm/s RMS.",
        "classes": {
            "VR 3,15": {
                "band": "A/B 2,0; B/C 3,15; C/D 5,0 mm/s RMS",
                "ab": 2.0,
                "warning": 3.15,
                "alarm": 5.0,
            },
            "VR 5": {
                "band": "A/B 3,15; B/C 5,0; C/D 8,0 mm/s RMS",
                "ab": 3.15,
                "warning": 5.0,
                "alarm": 8.0,
            },
            "VR 8": {
                "band": "A/B 5,0; B/C 8,0; C/D 12,5 mm/s RMS",
                "ab": 5.0,
                "warning": 8.0,
                "alarm": 12.5,
            },
            "VR 12,5": {
                "band": "A/B 8,0; B/C 12,5; C/D 20,0 mm/s RMS",
                "ab": 8.0,
                "warning": 12.5,
                "alarm": 20.0,
            },
            "VR 20": {
                "band": "A/B 12,5; B/C 20,0; C/D 31,5 mm/s RMS",
                "ab": 12.5,
                "warning": 20.0,
                "alarm": 31.5,
            },
        },
    },
    "ČSN 20 0065": {
        "label": "ČSN 20 0065 (frézky)",
        "long": "ČSN 20 0065 – přípustné hodnoty vibrací obráběcích strojů, "
                "konkrétně frézek. Limity jsou dány průměrem dutiny ve vřetenu.",
        "classes": {
            "Frézky – dutina ve vřetenu do 50 mm": {
                "band": "Varování 0,90 mm/s (80 % z alarmu); Alarm 1,12 mm/s RMS",
                "warning": 0.90,
                "alarm": 1.12,
            },
            "Frézky – dutina ve vřetenu nad 50 mm": {
                "band": "Varování 1,44 mm/s (80 % z alarmu); Alarm 1,80 mm/s RMS",
                "warning": 1.44,
                "alarm": 1.80,
            },
        },
    },
    "ISO 14694": {
        "label": "ISO 14694 (ventilátory)",
        "long": "ISO 14694 – vibrační limity průmyslových ventilátorů (in situ, "
                "tabulka 5, efektivní rychlost vibrací / RMS). Mapování do pásem: "
                "Počáteční → A/B, Výstraha → B/C (varování), Odstavení → C/D (alarm). "
                "U BV-1 a BV-2 není mez odstavení (C/D) normou definována "
                "(Poznámka 1) – klasifikuje se pouze do pásem A/B/C.",
        "classes": {
            "Ventilátory BV-1 – tuhé uložení": {
                "band": "A/B 10,0; B/C 10,6 mm/s RMS; C/D neuvedeno (tuhé uložení)",
                "ab": 10.0,
                "warning": 10.6,
                "alarm": None,
            },
            "Ventilátory BV-1 – pružné uložení": {
                "band": "A/B 11,2; B/C 14,0 mm/s RMS; C/D neuvedeno (pružné uložení)",
                "ab": 11.2,
                "warning": 14.0,
                "alarm": None,
            },
            "Ventilátory BV-2 – tuhé uložení": {
                "band": "A/B 5,6; B/C 9,0 mm/s RMS; C/D neuvedeno (tuhé uložení)",
                "ab": 5.6,
                "warning": 9.0,
                "alarm": None,
            },
            "Ventilátory BV-2 – pružné uložení": {
                "band": "A/B 9,0; B/C 14,0 mm/s RMS; C/D neuvedeno (pružné uložení)",
                "ab": 9.0,
                "warning": 14.0,
                "alarm": None,
            },
            "Ventilátory BV-3 – tuhé uložení": {
                "band": "A/B 4,5; B/C 7,1; C/D 9,0 mm/s RMS (tuhé uložení)",
                "ab": 4.5,
                "warning": 7.1,
                "alarm": 9.0,
            },
            "Ventilátory BV-3 – pružné uložení": {
                "band": "A/B 6,3; B/C 11,8; C/D 12,5 mm/s RMS (pružné uložení)",
                "ab": 6.3,
                "warning": 11.8,
                "alarm": 12.5,
            },
            "Ventilátory BV-4 – tuhé uložení": {
                "band": "A/B 2,8; B/C 4,5; C/D 7,1 mm/s RMS (tuhé uložení)",
                "ab": 2.8,
                "warning": 4.5,
                "alarm": 7.1,
            },
            "Ventilátory BV-4 – pružné uložení": {
                "band": "A/B 4,5; B/C 7,1; C/D 11,2 mm/s RMS (pružné uložení)",
                "ab": 4.5,
                "warning": 7.1,
                "alarm": 11.2,
            },
            "Ventilátory BV-5 – tuhé uložení": {
                "band": "A/B 1,8; B/C 4,0; C/D 5,6 mm/s RMS (tuhé uložení)",
                "ab": 1.8,
                "warning": 4.0,
                "alarm": 5.6,
            },
            "Ventilátory BV-5 – pružné uložení": {
                "band": "A/B 2,8; B/C 5,6; C/D 7,1 mm/s RMS (pružné uložení)",
                "ab": 2.8,
                "warning": 5.6,
                "alarm": 7.1,
            },
        },
    },
}


# ----------------------- vlastní (uživatelské) normy -----------------------
# Vlastní normy se ukládají globálně do data/custom_norms.json a sloučí se
# do katalogu vedle vestavěných norem (NORMS). Vestavěné normy mají přednost
# – nelze je vlastní normou přepsat.
#
# Každá třída vlastní normy může mít tři meze:
#   * ab      = hranice A/B (volitelná),
#   * warning = hranice B/C (mez výstrahy, žlutá) – povinná,
#   * alarm   = hranice C/D (mez alarmu, červená) – povinná.
_CUSTOM_NORMS_FILE = _BASE / "data" / "custom_norms.json"


def _to_float(v):
    """Převede hodnotu na float; akceptuje i český desetinný oddělovač (čárku)."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", ".")
    if not s:
        return None
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def _load_custom_norms_raw():
    """Načte seznam vlastních norem ze souboru (nebo prázdný seznam)."""
    try:
        if _CUSTOM_NORMS_FILE.exists():
            data = json.loads(_CUSTOM_NORMS_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
    except Exception:
        pass
    return []


def _save_custom_norms_raw(norms):
    """Uloží seznam vlastních norem do souboru."""
    _CUSTOM_NORMS_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CUSTOM_NORMS_FILE.write_text(
        json.dumps(norms, ensure_ascii=False, indent=2), encoding="utf-8")


def _custom_norms_dict():
    """Vrátí vlastní normy ve stejném tvaru jako NORMS (dict).

    {standard: {label, long, classes: {machine_class: {ab, warning, alarm, band}}}}

    Zápisy v souboru se normalizují deterministicky:
      * vestavěný standard se z vlastního souboru zcela ignoruje;
      * opakovaný vlastní standard se sloučí;
      * při opakování třídy vyhraje poslední záznam v souboru.

    Vestavěná norma tedy nikdy nezíská třídu ani limit z custom_norms.json a
    uživatelské normy s jiným názvem zůstávají doplňkem katalogu.
    """
    out = {}
    for rec in _load_custom_norms_raw():
        rec = rec or {}
        std = str(rec.get("standard") or "").strip()
        if not std or std in NORMS:
            continue
        existing = out.get(std)
        classes = dict((existing or {}).get("classes") or {})
        for c in (rec.get("classes") or []):
            c = c or {}
            cname = str(c.get("machine_class") or "").strip()
            if not cname:
                continue
            w = _to_float(c.get("warning"))
            a = _to_float(c.get("alarm"))
            ab = _to_float(c.get("ab"))
            # Stačí alespoň mez B/C (warning). Mez C/D (alarm) je volitelná
            # (např. Poznámka 1) – klasifikuje se pak jen do pásem A/B/C.
            if w is None and a is None:
                continue
            classes[cname] = {
                "ab": ab,
                "warning": w,
                "alarm": a,
                "band": c.get("band") or "",
            }
        if not classes:
            continue
        out[std] = {
            "label": rec.get("label") or (existing or {}).get("label") or std,
            "long": rec.get("long") or (existing or {}).get("long") or "",
            "classes": classes,
            "_custom": True,
        }
    return out


def all_norms():
    """Sloučí vestavěné normy (NORMS) s vlastními. Vestavěné mají přednost."""
    merged = {}
    for std, rec in _custom_norms_dict().items():
        merged[std] = rec
    for std, rec in NORMS.items():
        merged[std] = rec  # vestavěné přepisují případný konflikt
    return merged


def list_custom_norms():
    """Vrátí normalizované vlastní normy pro frontend.

    Vestavěné standardy v případném starším ``custom_norms.json`` se zde
    záměrně nevrací: jsou autoritativně poskytovány z :data:`NORMS` přes
    ``norms_catalog()`` a v uživatelském rozhraní proto nemohou vzniknout
    duplicitní standardy ani třídy.
    """
    out = []
    for std, rec in _custom_norms_dict().items():
        classes = []
        for cname, c in (rec.get("classes") or {}).items():
            classes.append({
                "machine_class": cname,
                "ab": _to_float(c.get("ab")),
                "warning": _to_float(c.get("warning")),
                "alarm": _to_float(c.get("alarm")),
            })
        out.append({
            "standard": std,
            "label": rec.get("label") or std,
            "classes": classes,
        })
    return out


def save_custom_norm(data):
    """Přidá nebo upraví vlastní normu.

    Vstup (flexibilní):
      {standard, label?, machine_class, ab?, warning, alarm}          # jedna třída
      {standard, label?, classes:[{machine_class, ab?, warning, alarm}, ...]}

    Chování:
      * Nelze přepsat vestavěnou normu (stejný název jako v NORMS) → ValueError.
      * Pokud norma se stejným názvem už existuje, třídy se sloučí
        (třída se stejným názvem se přepíše – tím se řeší EDITACE).
      * Vyžaduje alespoň jednu třídu s platnými mezemi warning+alarm.
    Vrací aktualizovaný seznam vlastních norem (list_custom_norms()).
    """
    data = data or {}
    std = str(data.get("standard") or "").strip()
    if not std:
        raise ValueError("Chybí název normy.")
    if std in NORMS:
        raise ValueError("Nelze přepsat vestavěnou normu „%s“." % std)
    label = str(data.get("label") or std).strip() or std

    # normalizuj vstupní třídy do seznamu
    in_classes = data.get("classes")
    if not in_classes:
        # plochý tvar (jedna třída)
        in_classes = [{
            "machine_class": data.get("machine_class"),
            "ab": data.get("ab"),
            "warning": data.get("warning"),
            "alarm": data.get("alarm"),
        }]
    new_classes = []
    for c in in_classes:
        c = c or {}
        cname = str(c.get("machine_class") or "").strip()
        w = _to_float(c.get("warning"))
        a = _to_float(c.get("alarm"))
        ab = _to_float(c.get("ab"))
        if not cname:
            raise ValueError("Chybí název třídy stroje.")
        # Povinná je alespoň mez B/C (varování). Mez C/D (alarm) je volitelná –
        # nezadá-li se (např. ISO 14694 BV-1/BV-2, Poznámka 1), klasifikuje se
        # jen do pásem A/B/C.
        if w is None:
            raise ValueError("U třídy „%s“ chybí mez B/C (varování)." % cname)
        if a is not None and a <= w:
            raise ValueError("U třídy „%s“ musí být mez C/D (alarm) větší než B/C (varování)." % cname)
        if ab is not None and ab >= w:
            raise ValueError("U třídy „%s“ musí být mez A/B menší než B/C (varování)." % cname)
        new_classes.append({
            "machine_class": cname,
            "ab": ab,
            "warning": w,
            "alarm": a,
        })
    if not new_classes:
        raise ValueError("Norma musí mít alespoň jednu třídu.")

    norms = _load_custom_norms_raw()
    existing = None
    for rec in norms:
        if str((rec or {}).get("standard") or "").strip() == std:
            existing = rec
            break
    if existing is None:
        norms.append({"standard": std, "label": label, "classes": new_classes})
    else:
        existing["label"] = label
        cur = existing.get("classes") or []
        by_name = {str((c or {}).get("machine_class") or "").strip(): c for c in cur}
        for nc in new_classes:
            by_name[nc["machine_class"]] = nc  # přidej nebo přepiš (editace třídy)
        existing["classes"] = list(by_name.values())
    _save_custom_norms_raw(norms)
    return list_custom_norms()


def delete_custom_norm(standard, machine_class=None):
    """Smaže celou vlastní normu, nebo jen jednu její třídu (je-li zadána).

    Vrací aktualizovaný seznam vlastních norem.
    """
    std = str(standard or "").strip()
    if not std:
        raise ValueError("Chybí název normy.")
    norms = _load_custom_norms_raw()
    cname = str(machine_class or "").strip()
    if cname:
        for rec in norms:
            if str((rec or {}).get("standard") or "").strip() == std:
                rec["classes"] = [
                    c for c in (rec.get("classes") or [])
                    if str((c or {}).get("machine_class") or "").strip() != cname
                ]
        # odstraň normy, které zůstaly bez tříd
        norms = [r for r in norms if (r.get("classes") or [])]
    else:
        norms = [r for r in norms
                 if str((r or {}).get("standard") or "").strip() != std]
    _save_custom_norms_raw(norms)
    return list_custom_norms()


def norms_catalog():
    """Vrátí katalog všech norem ve tvaru vhodném pro frontend/JSON API.

    Struktura:
        [
          {
            "standard":    <klíč normy>,   # ukládá se do iso_norm.standard
            "label":       <text v selectu>,
            "classes": [
               {
                 "machine_class": <klíč třídy>,  # ukládá se do iso_norm.machine_class
                 "label":         <text v selectu>,
                 "warning":       <mm/s RMS>,
                 "alarm":         <mm/s RMS>,
                 "band":          <textový popis>,
               }, ...
            ]
          }, ...
        ]
    Frontend katalog přes /api/norms/catalog – žádné duplicity mezi FE a BE.
    """
    out = []
    for std_key, std in all_norms().items():
        classes = []
        for cls_key, cls in (std.get("classes") or {}).items():
            classes.append({
                "machine_class": cls_key,
                "label": cls_key,
                "ab": cls.get("ab"),
                "warning": cls.get("warning"),
                "alarm": cls.get("alarm"),
                "band": cls.get("band") or "",
            })
        out.append({
            "standard": std_key,
            "label": std.get("label") or std_key,
            "builtin": std_key in NORMS,
            "classes": classes,
        })
    return out


def _find_class(iso_norm):
    """Najde záznam třídy v katalogu podle uloženého iso_norm.

    Kompatibilita se starými zápisy: pokud standard není v katalogu, projde
    všechny normy a hledá machine_class napříč nimi (aby starší uložená
    nastavení dál fungovala).
    """
    if not iso_norm:
        return None, None
    catalog = all_norms()
    std = (iso_norm.get("standard") or "").strip()
    cls = (iso_norm.get("machine_class") or "").strip()
    if not cls:
        return catalog.get(std), None
    norm = catalog.get(std)
    if norm and cls in (norm.get("classes") or {}):
        return norm, norm["classes"][cls]
    # fallback: hledej třídu napříč katalogem (staré uložené hodnoty)
    for n in catalog.values():
        classes = n.get("classes") or {}
        if cls in classes:
            return n, classes[cls]
    return norm, None


def _norm_description(iso_norm):
    """Vytvoří textový popis normy pro prompt z uloženého nastavení karty."""
    if not iso_norm:
        return ("Norma pro hodnocení rychlosti vibrací nebyla na kartě stroje "
                "určena. Použij obecné principy ČSN ISO 20816 a uveď, že "
                "konkrétní třída stroje nebyla zadána.")
    custom = (iso_norm.get("custom") or "").strip()
    # Režim více norem dle ložisek – popíšeme jednotlivá přiřazení.
    if (iso_norm.get("mode") or "single") == "multi":
        parts = ["Pro jednotlivá ložiska stroje jsou nastaveny různé normy:"]
        for a in (iso_norm.get("assignments") or []):
            std_a = (a.get("standard") or "").strip()
            cls_a = (a.get("machine_class") or "").strip()
            brgs = ", ".join(a.get("bearings") or [])
            lim = iso_limits_for_class(cls_a, std_a) if cls_a else None
            band = ""
            if lim:
                band = (f" (orientačně A/B={_fmt_num(lim.get('ab'))}, "
                        f"B/C={_fmt_num(lim.get('warning'))}, "
                        f"C/D={_fmt_num(lim.get('alarm'))} mm/s RMS)")
            parts.append(f"– Ložiska {brgs}: {std_a} / {cls_a}{band}.")
        if custom:
            parts.append(f"Doplňující kritéria zadaná uživatelem: {custom}")
        return " ".join(parts)
    std = (iso_norm.get("standard") or "").strip()
    cls = (iso_norm.get("machine_class") or "").strip()
    norm_rec, cls_rec = _find_class(iso_norm)
    parts = []
    if std:
        long_desc = (norm_rec or {}).get("long") if norm_rec else ""
        if long_desc:
            parts.append(long_desc)
        else:
            parts.append(f"Norma: {std}.")
    if cls:
        band = (cls_rec or {}).get("band") if cls_rec else ""
        if band:
            parts.append(f"Třída/kategorie: {cls}. "
                         f"Orientační limity rychlosti vibrací: {band}.")
        else:
            parts.append(f"Třída/kategorie: {cls}.")
    if custom:
        parts.append(f"Doplňující kritéria zadaná uživatelem: {custom}")
    if not parts:
        return ("Norma nebyla jednoznačně určena; použij principy "
                "ČSN ISO 20816.")
    return " ".join(parts)


# ----------------------- sestavení promptu -----------------------
def _fmt_num(v, dec=2):
    if v is None:
        return "—"
    try:
        return f"{float(v):.{dec}f}"
    except (TypeError, ValueError):
        return str(v)


def _methodology_text():
    """Aktuální společná metodologie; při chybě bezpečně výchozí text."""
    try:
        return ai_prompts.get_snapshot(ai_prompts.METHODOLOGY_ID).text
    except Exception:
        return ai_prompts._DEFINITIONS[ai_prompts.METHODOLOGY_ID]["template"]


_LIMIT_SOURCE_LABEL = {
    "norm": "z normy (má přednost před limity v databázi přístroje)",
    "manual": "ruční přepis na kartě stroje",
    "db": "z databáze přístroje",
    "none": "nejsou definovány",
}


def _quantity_lines(q):
    """Řádky jedné statické veličiny včetně PŮVODU platných mezí.

    Záměrně se vypisuje jak platná mez, tak (liší-li se) mez uložená přímo
    v .ndb. Bez toho by AI nemohla korektně napsat, proti čemu hodnotu
    porovnává, a u strojů s přiřazenou normou by uváděla cizí limit.
    """
    unit = q.get("unit") or ""
    band = q.get("band")
    head = (f"  - {q.get('name')}: poslední = {_fmt_num(q.get('last_value'))} {unit} "
            f"(čas {q.get('last_time') or '—'})")
    head += f"; pásmo {band}" if band else "; pásmo neurčeno"
    lines = [head]

    source = q.get("limit_source") or "none"
    if source == "none":
        lines.append("      platné meze: nejsou definovány (hodnotu nelze klasifikovat)")
    else:
        parts = []
        if q.get("ab") is not None:
            parts.append(f"A/B = {_fmt_num(q.get('ab'))}")
        parts.append(f"varování B/C = {_fmt_num(q.get('warning'))}")
        parts.append(f"alarm C/D = {_fmt_num(q.get('alarm'))}")
        lines.append("      platné meze [" + _LIMIT_SOURCE_LABEL[source] + "]: "
                     + ", ".join(parts))
        db_w = q.get("db_warning")
        db_a = q.get("db_alarm")
        if source != "db" and (db_w is not None or db_a is not None):
            lines.append(
                f"      meze v databázi přístroje (NEPOUŽITY): varování = "
                f"{_fmt_num(db_w)}, alarm = {_fmt_num(db_a)}")
    if q.get("severity"):
        lines.append(f"      původní stav hlášený přístrojem: {q.get('severity')}")
    trend = q.get("recent_trend") or []
    if len(trend) > 1:
        seq = ", ".join(_fmt_num(t.get("value")) for t in trend)
        lines.append(f"      trend (posl. {len(trend)}): {seq} {unit}")
    rate = q.get("trend_rate")
    # Vypisuje se jen nezanedbatelná změna — jinak by řádek přibyl u každé
    # veličiny a zaplavil podklady bez sdělení.
    if rate and abs(rate.get("pct_per_30d") or 0) >= fft_analysis.TREND_NOTABLE_PCT:
        lines.append(
            "      rychlost změny: %s %% za 30 dní (z %d měření za %s dní)"
            % (_fmt_num(rate.get("pct_per_30d"), 0), rate.get("points", 0),
               _fmt_num(rate.get("span_days"), 0)))
    base = q.get("baseline")
    if base and base.get("value") is not None:
        text = ("      baseline %s %s (měřeno %s)"
                % (_fmt_num(base.get("value")), unit,
                   str(base.get("time") or "—")[:16]))
        compare = base.get("compare")
        if compare:
            text += " → nyní %s %% (%s)" % (_fmt_num(compare.get("pct"), 0),
                                            compare.get("verdict"))
        lines.append(text)
    return lines


def _deviation(row):
    """Odchylka nalezené čáry od vypočtené frekvence, je-li nezanedbatelná.

    Naměřená složka málokdy padne přesně na vypočtenou frekvenci (kolísání
    otáček, prokluz valivých elementů, konečné rozlišení spektra). Uvedení
    skutečné odchylky dělá z tolerance viditelný údaj — model i čtenář pak
    poznají, jak těsná shoda to byla, místo aby ji brali jako přesnou.
    """
    value = row.get("deviation_pct")
    try:
        value = float(value)
    except (TypeError, ValueError):
        return ""
    if not math.isfinite(value) or abs(value) < 0.5:
        return ""
    return ", odch. %+.1f %%" % value


def _spectrum_lines(s):
    """Řádky jednoho spektra: overall + deterministicky spočtené nálezy.

    Vše na těchto řádcích spočítal `fft_analysis` z naměřených čar spektra.
    Model tato čísla NESMÍ přepočítávat ani domýšlet — jen interpretovat.
    """
    role = s.get("role")
    lines = [
        f"  - spektrum {s.get('name')}"
        + (f" [{role}]" if role else "")
        + f": overall = {_fmt_num(s.get('overall'))} "
        f"(čas {s.get('time') or '—'}"
        + (f", otáčky {_fmt_num(s.get('speed_hz'))} Hz" if s.get("speed_hz") else "")
        + ")"
    ]
    analysis = s.get("analysis") or {}
    peaks = analysis.get("peaks") or []
    if peaks:
        items = []
        for peak in peaks:
            text = f"{_fmt_num(peak.get('freq'), 1)} Hz"
            order = peak.get("order")
            if order is not None:
                text += f" ({_fmt_num(order, 2)}× ot)"
            text += f" = {_fmt_num(peak.get('amplitude'), 2)}"
            if peak.get("match"):
                text += f" ← {peak['match']}{_deviation(peak)}"
            items.append(text)
        lines.append("      vrcholy: " + " | ".join(items))
    harmonics = analysis.get("harmonics") or []
    if harmonics:
        items = [f"{h.get('order')}× ({_fmt_num(h.get('freq'), 1)} Hz"
                 f"{_deviation(h)}) = {_fmt_num(h.get('amplitude'), 2)}"
                 for h in harmonics]
        lines.append("      otáčková a harmonické: " + " | ".join(items))
    defects = analysis.get("defects") or []
    if defects:
        items = [f"{d.get('key')} ({_fmt_num(d.get('freq'), 1)} Hz"
                 f"{_deviation(d)}) = {_fmt_num(d.get('amplitude'), 2)}"
                 for d in defects]
        lines.append("      poruchové frekvence ložiska: " + " | ".join(items))
    for row in analysis.get("sidebands") or []:
        lines.append(
            "      postranní pásma kolem %s: odstup %s (%s Hz), %s"
            % (row.get("carrier"), row.get("label"),
               _fmt_num(row.get("spacing"), 1), _pairs(row.get("pairs", 0))))
    kinematic = analysis.get("kinematic") or []
    items = ["%s (%s Hz%s) = %s"
             % (row.get("label"), _fmt_num(row.get("freq"), 1),
                _deviation(row), _fmt_num(row.get("amplitude"), 2))
             for row in kinematic if row.get("freq")]
    if items:
        lines.append("      kinematické frekvence: " + " | ".join(items))
    for row in kinematic:
        if row.get("warning"):
            lines.append("      POZOR k zadané kinematice: " + row["warning"])
    mismatch = analysis.get("blade_mismatch")
    if mismatch:
        lines.append(
            "      POZOR: zadaný počet lopatek %d neodpovídá dominantnímu "
            "řádu ve spektru (%s× ot). Buď je údaj na kartě stroje chybný, "
            "nebo složka pochází z něčeho jiného."
            % (mismatch.get("configured"),
               ", ".join(str(o) for o in mismatch.get("detected") or [])))
    for item in analysis.get("families") or []:
        text = ("      dominantní celočíselný řád %d× ot (%s Hz) = %s"
                % (item.get("order"), _fmt_num(item.get("freq"), 1),
                   _fmt_num(item.get("amplitude"), 2)))
        if item.get("implies"):
            text += " — odpovídalo by %s %d; ověř na stroji" % (
                item["implies"], item.get("order"))
        else:
            text += " — kinematický původ neurčen (na kartě stroje není zadán)"
        lines.append(text)
    belt = analysis.get("belt")
    if belt:
        lines.append(
            "      řada %d harmonických POD otáčkovou frekvencí, základ %s Hz "
            "(%s× ot) — typické pro řemenový převod"
            % (belt.get("members", 0), _fmt_num(belt.get("base"), 1),
               _fmt_num(belt.get("order"), 2)))
    lines.extend(_pattern_lines(analysis.get("pattern") or {}))
    for warning in (s.get("range") or {}).get("warnings") or []:
        lines.append("      POZOR k rozsahu měření: " + warning)
    if analysis.get("level") == "minimal":
        lines.append("      (spektrální nálezy nebyly vyžádány — stroj je v pásmu A)")
    return lines


def _waveform_lines(w):
    """Znaky časové vlny (metodologie C.7): ořezání, rázovost, periodicita."""
    parts = ["peak %s" % _fmt_num(w.get("peak"), 2),
             "RMS %s" % _fmt_num(w.get("rms"), 2)]
    if w.get("crest_factor") is not None:
        parts.append("činitel výkmitu %s%s"
                     % (_fmt_num(w.get("crest_factor"), 1),
                        " (výrazně rázový)" if w.get("impulsive") else ""))
    if w.get("clipped"):
        parts.append("OŘEZANÁ vlna (%s %% vzorků u extrému)"
                     % _fmt_num((w.get("clipping_ratio") or 0) * 100, 1))
    lines = ["  - časová vlna %s: %s" % (w.get("name"), " | ".join(parts))]
    if w.get("impact_freq_hz"):
        lines.append(
            "      periodicita rázů %s Hz (perioda %s ms) — porovnej s "
            "otáčkovou a poruchovými frekvencemi"
            % (_fmt_num(w.get("impact_freq_hz"), 1),
               _fmt_num((w.get("impact_period_s") or 0) * 1000, 2)))
    return lines


def _pairs(count):
    """České skloňování počtu symetrických dvojic postranních pásem."""
    count = int(count or 0)
    if count == 1:
        return "1 symetrická dvojice"
    if 2 <= count <= 4:
        return "%d symetrické dvojice" % count
    return "%d symetrických dvojic" % count


# Práh, nad kterým má smysl o prahu šumu vůbec mluvit. U čistého spektra
# s ostrými špičkami vyjde medián prakticky nulový a řádek „práh šumu 0 %“
# by jen zabíral místo.
_NOISE_FLOOR_NOTABLE = 0.05


def _pattern_lines(pattern):
    """Strukturní znaky spektra (metodologie krok C.4) v jednom řádku."""
    if not pattern:
        return []
    parts = []
    orders = pattern.get("harmonic_orders")
    if orders:
        parts.append("harmonické nad 20 %% z 1×: %s"
                     % ", ".join("%d×" % o for o in orders))
    if pattern.get("ratio_2x_1x") is not None:
        parts.append("2×/1× = %s %%" % _fmt_num(pattern["ratio_2x_1x"] * 100, 0))
    if pattern.get("subharmonic_orders"):
        parts.append("subharmonické: %s"
                     % ", ".join("%s×" % _fmt_num(o, 1)
                                 for o in pattern["subharmonic_orders"]))
    if pattern.get("fractional_orders"):
        parts.append("zlomkové 1/n: %s"
                     % ", ".join("%s×" % _fmt_num(o, 2)
                                 for o in pattern["fractional_orders"]))
    ratio = pattern.get("noise_floor_ratio")
    if ratio is not None and ratio >= _NOISE_FLOOR_NOTABLE:
        parts.append("ZVÝŠENÝ práh šumu (%s %% nejvyšší čáry)"
                     % _fmt_num(ratio * 100, 0))
    sub = pattern.get("subsynchronous")
    if sub:
        parts.append("subsynchronní složka %s× ot (%s Hz) = %s"
                     % (_fmt_num(sub.get("order"), 2), _fmt_num(sub.get("freq"), 1),
                        _fmt_num(sub.get("amplitude"), 2)))
    return ["      vzorec spektra: " + " | ".join(parts)] if parts else []


def build_prompt(machine_data, speed_hz, iso_norm, with_task=True):
    """Sestaví (system, user) zprávy pro OpenAI z dat stroje.

    `with_task=False` vrátí jen podklady bez závěrečného bloku „ÚKOL".
    Používá to návrh protokolu a chat: tam strukturu odpovědi určuje
    šablona z Nastavení → AI prompty, respektive průběh konverzace, a druhý
    předpis struktury by ten první přebil.
    """
    system = (
        "Jsi senior vibrační diagnostik s mnohaletými zkušenostmi v "
        "prediktivní údržbě rotačních strojů. Hodnotíš naměřená data podle "
        "platných norem a osvědčené praxe. Vyjadřuješ se odborně, věcně a v "
        "ČEŠTINĚ. Tvým úkolem je posoudit stav stroje, porovnat hladiny "
        "vibrací s příslušnými limity a rychlost vibrací s uvedenou normou, "
        "identifikovat možné závady (nevyváženost, nesouosost, uvolnění, "
        "poškození ložisek, rezonance apod.) a navrhnout doporučení. "
        "Pokud data nestačí k jednoznačnému závěru, jasně to uveď. "
        "Nevymýšlej si hodnoty, které nejsou v datech."
    )

    lines = []
    lines.append(f"STROJ: {machine_data.get('machine_name')}")
    if machine_data.get("parent_name"):
        lines.append(f"Nadřazený uzel: {machine_data.get('parent_name')}")
    lines.append(f"Provozní otáčky pro diagnostiku: "
                 f"{_fmt_num(speed_hz)} Hz "
                 f"({_fmt_num((speed_hz or 0) * 60, 0)} ot/min)"
                 if speed_hz else "Provozní otáčky: nezadány")
    lines.append("")
    lines.append("NORMA PRO HODNOCENÍ RYCHLOSTI VIBRACÍ:")
    lines.append(_norm_description(iso_norm))
    lines.append("")

    # přiřazená ložiska
    bsa = machine_data.get("bearings_assigned") or []
    if bsa:
        lines.append("PŘIŘAZENÁ LOŽISKA:")
        for b in bsa:
            desig = b.get("designation") or "—"
            mfg = b.get("manufacturer") or ""
            freqs = []
            for k in ("FTF", "BSF", "BPFO", "BPFI"):
                if b.get(k) is not None:
                    freqs.append(f"{k}={_fmt_num(b.get(k), 3)}×ot")
            lines.append(
                f"  • {b.get('bearing_key')}: {desig} {mfg} "
                + ("(" + ", ".join(freqs) + ")" if freqs else "")
            )
        lines.append("")

    kin = machine_data.get("kinematics") or {}
    if kin:
        labels = {"blade_count": "lopatek", "pole_count": "pólů",
                  "gear_teeth_driver": "zubů hnacího kola",
                  "gear_teeth_driven": "zubů hnaného kola",
                  "line_freq_hz": "síťová frekvence [Hz]",
                  "belt_length_mm": "délka řemene [mm]",
                  "pulley_driver_mm": "průměr hnací řemenice [mm]",
                  "pulley_driven_mm": "průměr hnané řemenice [mm]",
                  "drive_type": "typ pohonu"}
        shown = ", ".join("%s: %s" % (labels[k], kin[k])
                          for k in labels if kin.get(k) is not None)
        if shown:
            lines.append("")
            lines.append("KINEMATIKA ZADANÁ NA KARTĚ STROJE: " + shown)
            lines.append("  Tyto údaje zadal diagnostik, takže odvozené "
                         "frekvence jsou vypočtené, nikoli odhadnuté.")

    motor = machine_data.get("motor")
    if motor:
        note = ("věrohodné" if motor.get("plausible") else
                "NEVĚROHODNÉ — otáčky neodpovídají žádným synchronním; "
                "jde nejspíš o hnaný stroj za převodem, ne o hřídel motoru")
        lines.append("")
        lines.append(
            "ODVOZENÝ KONTEXT ASYNCHRONNÍHO MOTORU (dopočet z otáček, %s):" % note)
        lines.append(
            "  počet pólů %d, synchronní %s Hz, skluz %s Hz (%s %%), "
            "F_P = %s Hz, F_L = %s Hz, 2F_L = %s Hz"
            % (motor.get("poles"), _fmt_num(motor.get("synchronous_hz"), 2),
               _fmt_num(motor.get("slip_hz"), 2), _fmt_num(motor.get("slip_pct"), 1),
               _fmt_num(motor.get("pole_pass_hz"), 2),
               _fmt_num(motor.get("line_freq"), 0),
               _fmt_num(2 * (motor.get("line_freq") or 0), 0)))

    basis = machine_data.get("assessment_basis")
    if basis is not None:
        lines.append("")
        if basis.get("available"):
            lines.append(
                "OPORY HODNOCENÍ (v pořadí spolehlivosti dle metodologie): %s"
                % ", ".join(basis["available"]))
            if basis.get("norm_only"):
                lines.append("  K dispozici je POUZE norma. Ta je určena pro "
                             "stroj bez historie — závěr formuluj opatrněji a "
                             "doporuč založit baseline nebo srovnání se "
                             "shodným strojem.")
        else:
            # Nejslabší možná situace: hodnotu není čím ukotvit. Model to musí
            # vědět, jinak by absolutní číslo vydával za posouzení stavu.
            lines.append(
                "OPORY HODNOCENÍ: ŽÁDNÁ — chybí použitelný trend, baseline, "
                "sesterský stroj i norma. Hodnoty nelze relativně ukotvit; "
                "závěr formuluj jako předběžný a doporuč doplnit alespoň "
                "jednu oporu.")

    baseline = machine_data.get("baseline") or {}
    if baseline.get("time"):
        note = (" — %s" % baseline["note"]) if baseline.get("note") else ""
        lines.append("")
        lines.append("BASELINE (známý dobrý stav): %s%s"
                     % (baseline["time"], note))
        lines.append("  Hodnoty z tohoto data jsou u jednotlivých veličin níže. "
                     "Porovnání proti baseline má přednost před normou.")

    sister = machine_data.get("sister") or {}
    if sister:
        lines.append("")
        if sister.get("unavailable"):
            lines.append("SESTERSKÝ STROJ: vybrán, ale %s." % sister["unavailable"])
        else:
            lines.append(
                "SESTERSKÝ STROJ „%s“ (porovnáno %d veličin podle dvojice "
                "ložisko + veličina):"
                % (sister.get("machine_name") or "—", sister.get("compared", 0)))
            rows = sister.get("rows") or []
            if not rows:
                lines.append("  Žádná veličina se od sesterského stroje nápadně "
                             "neliší — oba stroje jsou na srovnatelné úrovni.")
            for row in rows:
                lines.append(
                    "  %s%s / %s: %s vs %s u sestry → %s %% (%s)"
                    % (row.get("bearing_key"), row.get("direction") or "",
                       row.get("quantity"),
                       _fmt_num(row.get("value")), _fmt_num(row.get("reference")),
                       _fmt_num(row.get("pct"), 0), row.get("verdict")))
            lines.append("  Pozn.: sesterský stroj vybral diagnostik. Platí jen "
                         "za srovnatelných provozních podmínek — liší-li se "
                         "zatížení či otáčky, porovnání neuváděj jako důkaz.")

    stages = machine_data.get("bearing_stages")
    if stages:
        lines.append("")
        lines.append("INDIKACE ETAP POŠKOZENÍ LOŽISEK (jen ze zrychlení a obálky):")
        for row in stages:
            lines.append("  %s: %s — %s"
                         % (row.get("bearing_key"), row.get("label"),
                            "; ".join(row.get("reasons") or [])))
        lines.append("  Pozn.: metodologie váže na etapu 3 výměnu ložiska bez "
                     "ohledu na amplitudu. Etapa je odhad z uvedených znaků, "
                     "ne měřená veličina — formuluj ji jako indikaci.")

    priority = machine_data.get("priority") or {}
    certainty = machine_data.get("certainty") or {}
    if priority.get("level") or certainty.get("ceiling"):
        lines.append("")
        if priority.get("level"):
            lines.append("NAVRŽENÁ PRIORITA: %s (%s)"
                         % (priority["level"],
                            "; ".join(priority.get("reasons") or [])))
        if certainty.get("ceiling"):
            reasons = "; ".join(certainty.get("reasons") or []) or "všechny podmínky splněny"
            lines.append("STROP MÍRY JISTOTY: %s — %s. Vyšší jistotu než tento "
                         "strop v závěru neuváděj."
                         % (certainty["ceiling"], reasons))

    directions = machine_data.get("directions")
    if directions:
        lines.append("")
        lines.append("SMĚROVOST (rychlost vibrací podle směru na každém ložisku):")
        for row in directions:
            values = row.get("values") or {}
            shown = " ".join("%s %s" % (k, _fmt_num(values[k], 2))
                             for k in ("H", "V", "A") if k in values)
            traits = ", ".join(row.get("traits") or []) or "—"
            lines.append("  %s: %s → %s" % (row.get("bearing_key"), shown, traits))
        lines.append("  Pozn.: fáze není v databázi přístroje k dispozici, "
                     "takže směrovost je jediný dostupný způsob, jak odlišit "
                     "nevyváženost od nesouososti. Závěr podle ní formuluj "
                     "nejvýše se STŘEDNÍ jistotou.")

    # měřicí body a veličiny
    lines.append("")
    lines.append("NAMĚŘENÁ DATA (poslední měření + krátký trend):")
    if not machine_data.get("speed_hz_used"):
        lines.append("  POZOR: otáčky nejsou známy, proto NELZE určit řády "
                     "(× ot) ani poruchové frekvence ložisek. Frekvence "
                     "vrcholů neinterpretuj jako konkrétní závadu.")
        detected = machine_data.get("speed_detected_unsaved")
        if detected:
            lines.append(
                "  Poznámka: na kartě stroje je v historii detekce hodnota "
                "%s Hz (%s), ale NENÍ uložena jako platné otáčky, takže se "
                "nepoužívá. Do doporučení uveď, že stačí ji na kartě stroje "
                "uložit a analýzu zopakovat."
                % (_fmt_num(detected.get("value")),
                   str(detected.get("time") or "—")[:16]))
    elif machine_data.get("speed_confirmed") is False:
        lines.append("  POZOR: ani v jednom spektru stroje není významná "
                     "složka na 2× ani 3× zadané otáčkové frekvence. Ověř, "
                     "že zadané otáčky opravdu odpovídají 1× — jinak jsou "
                     "všechny uvedené řády neplatné.")
    if machine_data.get("spectrum_rows_truncated"):
        lines.append("  (seznam spektrálních nálezů byl zkrácen na rozumný "
                     "rozsah; nejsilnější a spárované nálezy zůstaly)")
    for p in machine_data.get("points", []):
        lines.append(f"\nMěřicí bod: {p.get('name')} "
                     f"[ložisko {p.get('bearing_key')}, "
                     f"směr {p.get('direction') or '—'}]")
        qs = p.get("quantities") or []
        if not qs:
            lines.append("  (žádné trendové veličiny)")
        for q in qs:
            lines.extend(_quantity_lines(q))
        for s in (p.get("spectra") or []):
            lines.extend(_spectrum_lines(s))
        for w in (p.get("waveforms") or []):
            lines.extend(_waveform_lines(w))

    if with_task:
        lines.append("")
        lines.append(
            "ÚKOL: Na základě výše uvedených dat proveď odborné vibrodiagnostické "
            "vyhodnocení stroje. Strukturuj odpověď do těchto částí:\n"
            "1) ZÁVĚR – celkové posouzení stavu stroje (vyhovuje / zvýšené "
            "vibrace / kritický stav) s odůvodněním porovnáním vůči limitům a "
            "normě.\n"
            "2) HODNOCENÍ RYCHLOSTI VIBRACÍ dle normy – zařazení do pásma "
            "(A/B/C/D) tam, kde je to možné.\n"
            "3) MOŽNÉ ZÁVADY – co naměřené hodnoty a trendy naznačují.\n"
            "4) DOPORUČENÍ – konkrétní kroky (sledovat, naplánovat zásah, "
            "okamžitý zásah) a případná další měření.\n"
            "Piš stručně a věcně, používej odbornou terminologii. Odpověz česky."
        )

    user = "\n".join(lines)
    return system, user


# ----------------------- prompt pro JEDEN měřicí bod -----------------------
def build_point_prompt(point_data, speed_hz, iso_norm):
    """Sestaví (system, user) pro lokální diagnostiku JEDNOHO měřicího bodu.

    Do promptu vloží naměřená data bodu (statické veličiny + spektra),
    přiřazené ložisko a jeho defektní frekvence přepočtené do Hz
    (frekvence [Hz] = koeficient ×ot × otáčky [Hz]).
    """
    # Poradce u bodu se drží TÉŽE metodologie jako protokol, aby diagnostik
    # nedostal na dvou místech aplikace dvě různé odborné úvahy nad týmiž daty.
    system = (
        _methodology_text()
        + "\n\nÚKOL: Provádíš LOKÁLNÍ vyhodnocení JEDNOHO měřicího bodu na "
        "ložisku rotačního stroje. Posuď stav daného měřicího místa a se "
        "zaměřením na přiřazené ložisko identifikuj možné závady (poškození "
        "ložiska – vnější/vnitřní kroužek, valivé elementy, klec; dále "
        "nevyváženost, nesouosost, uvolnění, rezonance apod.)."
    )

    lines = []
    lines.append(f"MĚŘICÍ BOD: {point_data.get('point_name')}")
    if point_data.get("machine_name"):
        lines.append(f"Stroj: {point_data.get('machine_name')}")
    if point_data.get("parent_name"):
        lines.append(f"Nadřazený uzel: {point_data.get('parent_name')}")
    lines.append(
        f"Ložisko (měřicí místo): {point_data.get('bearing_label') or point_data.get('bearing_key') or '—'}"
        f", směr {point_data.get('direction') or '—'}"
    )
    rpm = (speed_hz or 0) * 60
    lines.append(
        f"Provozní otáčky pro diagnostiku: {_fmt_num(speed_hz)} Hz "
        f"({_fmt_num(rpm, 0)} ot/min)"
        if speed_hz else "Provozní otáčky: nezadány"
    )
    lines.append("")
    lines.append("NORMA PRO HODNOCENÍ RYCHLOSTI VIBRACÍ:")
    lines.append(_norm_description(iso_norm))
    lines.append("")

    # přiřazené ložisko + defektní frekvence v Hz (koef ×ot × otáčky)
    b = point_data.get("assigned_bearing")
    if b:
        desig = b.get("designation") or "—"
        mfg = b.get("manufacturer") or ""
        btype = b.get("type") or ""
        lines.append("PŘIŘAZENÉ LOŽISKO:")
        lines.append(
            f"  Označení: {desig}"
            + (f", výrobce: {mfg}" if mfg else "")
            + (f", typ: {btype}" if btype else "")
        )
        labels = {
            "FTF": "FTF (klec)",
            "BSF": "BSF (valivý element)",
            "BPFO": "BPFO (vnější kroužek)",
            "BPFI": "BPFI (vnitřní kroužek)",
        }
        lines.append("  Defektní frekvence ložiska:")
        any_freq = False
        for k in ("FTF", "BSF", "BPFO", "BPFI"):
            coef = b.get(k)
            if coef is None:
                continue
            any_freq = True
            try:
                hz = float(coef) * float(speed_hz) if speed_hz else None
            except (TypeError, ValueError):
                hz = None
            hz_txt = f"{_fmt_num(hz, 2)} Hz" if hz is not None else "— Hz (otáčky nezadány)"
            lines.append(
                f"    • {labels[k]}: {_fmt_num(coef, 3)} ×ot = {hz_txt}"
            )
        if not any_freq:
            lines.append("    (defektní frekvence nejsou u ložiska zadány)")
        lines.append("")
    else:
        lines.append("PŘIŘAZENÉ LOŽISKO: nepřiřazeno (na kartě stroje není pro "
                     "toto místo zadáno ložisko).")
        lines.append("")

    # naměřená data bodu
    lines.append("NAMĚŘENÁ DATA BODU (poslední měření + krátký trend):")
    qs = point_data.get("quantities") or []
    if not qs:
        lines.append("  (žádné trendové veličiny)")
    for q in qs:
        lines.extend(_quantity_lines(q))
    for s in (point_data.get("spectra") or []):
        lines.extend(_spectrum_lines(s))

    lines.append("")
    lines.append(
        "ÚKOL: Na základě výše uvedených dat proveď LOKÁLNÍ vibrodiagnostické "
        "vyhodnocení tohoto měřicího bodu a jeho ložiska. Strukturuj odpověď do "
        "těchto částí:\n"
        "1) ZÁVĚR – posouzení stavu měřicího místa (vyhovuje / zvýšené vibrace / "
        "kritický stav) s odůvodněním porovnáním vůči limitům a normě.\n"
        "2) HODNOCENÍ RYCHLOSTI VIBRACÍ dle normy – zařazení do pásma (A/B/C/D) "
        "tam, kde je to možné.\n"
        "3) STAV LOŽISKA – posouzení s ohledem na defektní frekvence (FTF, BSF, "
        "BPFO, BPFI) a jejich možné projevy ve spektru.\n"
        "4) MOŽNÉ ZÁVADY – co naměřené hodnoty a trendy v tomto bodě naznačují.\n"
        "5) DOPORUČENÍ – konkrétní kroky (sledovat, naplánovat zásah, okamžitý "
        "zásah) a případná další měření.\n"
        "Piš stručně a věcně, používej odbornou terminologii. Odpověz česky."
    )

    user = "\n".join(lines)
    return system, user


def evaluate_point(point_data, speed_hz, iso_norm, model=None):
    """Zavolá zvolený model pro JEDEN bod a vrátí (text, prompt_user, model).

    Podle modelu zvolí poskytovatele (OpenAI / Anthropic). Vyhazuje RuntimeError.
    """
    model = model or get_model()
    provider = _provider_for(model)
    key_provider = "anthropic" if provider == "anthropic_agent" else provider
    api_key = get_api_key(key_provider)
    if not api_key:
        if key_provider == "anthropic":
            raise RuntimeError(
                "Není nastaven Claude (Anthropic) API klíč. Zadejte jej v nastavení AI."
            )
        raise RuntimeError(
            "Není nastaven OpenAI API klíč. Zadejte jej v nastavení AI."
        )
    system, user = build_point_prompt(point_data, speed_hz, iso_norm)
    if provider == "anthropic_agent":
        text = _call_anthropic_agent(api_key, system, user)
    elif provider == "anthropic":
        text = _call_anthropic(api_key, model, system, user)
    else:
        text = _call_openai(api_key, model, system, user)
    return text, user, model


# ----------------------- ISO limity pro propsání do bodů -----------------------
# Numerické limity rychlosti vibrací (RMS, mm/s) se čtou přímo z katalogu NORMS.
# Mapování pro propsání do bodů: warning -> Varování, alarm -> Alarm.
def iso_limits_for_class(machine_class, standard=None):
    """Vrátí {"warning", "alarm", "ab"} (mm/s RMS) pro danou třídu, nebo None.

    warning = mez B/C, alarm = mez C/D, ab = mez A/B (volitelná; může být None).

    Pokud je zadán `standard`, hledá třídu předně v něm; jinak (nebo při
    nenalezení) hledá třídu napříč celým katalogem (vestavěné + vlastní) –
    zajištěna zpětná kompatibilita se staršími zápisy karet strojů.
    """
    if not machine_class:
        return None
    catalog = all_norms()
    key = str(machine_class).strip()
    # Norma je platná, má-li alespoň jednu z mezí B/C (warning) nebo C/D (alarm).
    # Některé třídy (např. ISO 14694 BV-1/BV-2) nemají mez odstavení C/D
    # (alarm=None) – klasifikuje se pak jen do pásem A/B/C.
    def _valid(cls):
        return bool(cls) and (cls.get("warning") is not None or cls.get("alarm") is not None)
    if standard:
        norm = catalog.get(str(standard).strip())
        if norm:
            cls = (norm.get("classes") or {}).get(key)
            if _valid(cls):
                return {"warning": cls.get("warning"), "alarm": cls.get("alarm"), "ab": cls.get("ab")}
    # fallback: hledej třídu napříč všemi normami
    for n in catalog.values():
        cls = (n.get("classes") or {}).get(key)
        if _valid(cls):
            return {"warning": cls.get("warning"), "alarm": cls.get("alarm"), "ab": cls.get("ab")}
    return None


def _norm_for_bearing(iso_norm, bearing_key):
    """V režimu více norem (mode="multi") vybere přiřazení (standard +
    machine_class) pro dané ložisko podle seznamu `assignments`.

    Každé přiřazení má tvar {standard, machine_class, bearings:["L1","L2",...]}.
    Porovnává se necitlivě na velikost písmen a mezery. Vrací dvojici
    (standard, machine_class) nebo (None, None), když ložisko nespadá pod žádné
    přiřazení (pak se ISO RMS pro daný bod neklasifikuje z normy).
    """
    if not iso_norm or not bearing_key:
        return None, None
    bk = str(bearing_key).strip().upper()
    for a in (iso_norm.get("assignments") or []):
        if not isinstance(a, dict):
            continue
        keys = {str(b).strip().upper() for b in (a.get("bearings") or []) if str(b).strip()}
        if bk in keys:
            return (a.get("standard") or "").strip(), (a.get("machine_class") or "").strip()
    return None, None


def iso_limits_from_norm(iso_norm, bearing_key=None):
    """Z uloženého nastavení normy karty vrátí limity pro ISO RMS, nebo None.

    Režimy:
      * jedna norma pro celý stroj (mode chybí nebo "single") – použije se
        iso_norm.standard + iso_norm.machine_class pro všechny body;
      * více norem dle ložisek (mode="multi") – podle `bearing_key` se vybere
        příslušné přiřazení ze seznamu `assignments`. Když ložisko není nikde
        zaškrtnuté, vrátí None (bod se z normy neklasifikuje).
    """
    if not iso_norm:
        return None
    if (iso_norm.get("mode") or "single") == "multi":
        std, cls = _norm_for_bearing(iso_norm, bearing_key)
        if not cls:
            return None
        return iso_limits_for_class(cls, std)
    return iso_limits_for_class(
        (iso_norm or {}).get("machine_class"),
        (iso_norm or {}).get("standard"),
    )


# ----------------------- volání AI (OpenAI / Anthropic) -----------------------
def _data_url_parts(image):
    """Z datové URL obrázku vytáhne (media_type, base64_data) nebo None.

    Očekává formát 'data:image/<typ>;base64,<data>'. Používá se pro vložení
    obrázku stroje do AI promptu (vision).
    """
    if not image or not isinstance(image, str):
        return None
    if not image.startswith("data:image/"):
        return None
    try:
        header, data = image.split(",", 1)
        media_type = header[len("data:"):].split(";", 1)[0]
        if not data:
            return None
        return media_type, data
    except Exception:
        return None


def _call_openai(api_key, model, system, user, image=None):
    # uživatelský obsah: buď prostý text, nebo text + obrázek (vision)
    parts = _data_url_parts(image)
    if parts:
        user_content = [
            {"type": "text", "text": user},
            {"type": "image_url", "image_url": {"url": image}},
        ]
    else:
        user_content = user
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user_content},
        ],
        "temperature": 0.2,
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        OPENAI_URL, data=data, method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT_S) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise RuntimeError("OpenAI vrátilo chybu služby (%s)." % e.code)
    except urllib.error.URLError:
        raise RuntimeError("Nelze se připojit k OpenAI. Zkontrolujte připojení k internetu.")
    try:
        result = json.loads(body)
        _require_mapping(result)
        choice = _require_mapping(result["choices"][0])
        message = _require_mapping(choice["message"])
        return _require_text(message["content"]).strip()
    except AIResponseFormatError:
        raise
    except (KeyError, IndexError, TypeError, ValueError):
        raise RuntimeError("Neočekávaná odpověď od OpenAI.")


def _call_anthropic(api_key, model, system, user, image=None):
    parts = _data_url_parts(image)
    if parts:
        media_type, b64 = parts
        user_content = [
            {"type": "text", "text": user},
            {"type": "image", "source": {
                "type": "base64",
                "media_type": media_type,
                "data": b64,
            }},
        ]
    else:
        user_content = user
    payload = {
        "model": model,
        "max_tokens": 2000,
        "temperature": 0.2,
        "system": system,
        "messages": [{"role": "user", "content": user_content}],
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        ANTHROPIC_URL, data=data, method="POST",
        headers={
            "content-type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": ANTHROPIC_VERSION,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT_S) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise RuntimeError("Claude (Anthropic) vrátilo chybu služby (%s)." % e.code)
    except urllib.error.URLError:
        raise RuntimeError("Nelze se připojit k Anthropic. Zkontrolujte připojení k internetu.")
    try:
        result = json.loads(body)
        result = _require_mapping(result)
        parts = result.get("content")
        if not isinstance(parts, list):
            raise AIResponseFormatError()
        text_parts = []
        for part in parts:
            part = _require_mapping(part)
            if part.get("type") == "text":
                text_parts.append(_require_text(part.get("text")))
        text = "".join(text_parts)
        if not text:
            text = _require_text(_require_mapping(parts[0]).get("text"))
        return text.strip()
    except AIResponseFormatError:
        raise
    except (KeyError, IndexError, TypeError, ValueError):
        raise RuntimeError("Neočekávaná odpověď od Claude (Anthropic).")


def _agent_headers(api_key):
    return {
        "Content-Type": "application/json",
        "x-api-key": api_key,
        "anthropic-version": ANTHROPIC_VERSION,
        "anthropic-beta": AI_AGENT_BETA_HEADER,
    }


def _agent_request(url, api_key, method="GET", payload=None, timeout=_TIMEOUT_S):
    """Proví jedno HTTP volání na Managed Agents REST API (čistý urllib,
    žádná závislost na balíčku `anthropic`). Vrací deserializované JSON tělo.
    """
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(
        url, data=data, method=method, headers=_agent_headers(api_key),
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise RuntimeError("AI Agent (Anthropic) vrátil chybu služby (%s)." % e.code)
    except urllib.error.URLError:
        raise RuntimeError(
            "Nelze se připojit k Anthropic AI Agentovi. Zkontrolujte připojení k internetu."
        )
    if not body:
        return {}
    try:
        return json.loads(body)
    except ValueError:
        raise RuntimeError("Neočekávaná odpověď od AI Agenta (Anthropic).")


def _call_anthropic_agent(api_key, system, user, image=None,
                          agent_id=None, environment_id=None):
    """Pošle dotaz předem nakonfigurovanému Anthropic AI Agentovi přes beta
    Managed Agents / Sessions REST API (POUŽE `urllib` ze standardní
    knihovny — žádný externí balíček se nevyžaduje, konzistentně se
    zbytkem aplikace, která nic neinstaluje).

    Na rozdíl od `_call_anthropic` (běžné Messages API) tady agent má svůj
    VLASTNÍ systémový prompt nastavený v Anthropic Console — parametr
    `system` z našeho promptu se agentovi NEPřEDÁVÁ jako system prompt,
    místo toho se připojí na začátek uživatelské zprávy jako instrukce/
    kontext, aby agent věděl, jaký výstup má vytvořit (JSON se závěrem a
    doporučením dle našeho formátu pro protokol).

    Postup: POST /v1/sessions (vytvoří session) → POST /v1/sessions/{id}/events
    (pošle uživatelskou zprávu) → GET /v1/sessions/{id}/events (polling, dokud
    session nemá status „idle“ nebo není překročen časový limit) →
    POST /v1/sessions/{id}/archive (úklid, best-effort).

    Vrací textovou odpověď agenta (očekává se JSON s klíči
    problem/zaver/doporuceni, stejně jako u běžných modelů).
    """
    agent_id = agent_id or AI_AGENT_ID
    environment_id = environment_id or AI_AGENT_ENVIRONMENT_ID

    combined_text = system.strip() + "\n\n" + user.strip()
    content = [{"type": "text", "text": combined_text}]
    parts = _data_url_parts(image)
    if parts:
        media_type, b64 = parts
        content.append({
            "type": "image",
            "source": {"type": "base64", "media_type": media_type, "data": b64},
        })

    session_id = None
    try:
        session = _agent_request(
            f"{AI_AGENT_API_BASE}/sessions", api_key, method="POST",
            payload={"agent": agent_id, "environment_id": environment_id},
        )
        session_id = session.get("id") if isinstance(session, dict) else None
        if not isinstance(session_id, str) or not session_id:
            raise RuntimeError("AI Agent: vytvoření session se nezdařilo (chybí id).")

        _agent_request(
            f"{AI_AGENT_API_BASE}/sessions/{session_id}/events", api_key,
            method="POST",
            payload={"events": [{"type": "user.message", "content": content}]},
        )

        result_text = ""
        start = time.monotonic()
        seen_event_ids = set()
        status = "working"
        while True:
            if time.monotonic() - start > _AGENT_POLL_TIMEOUT_S:
                raise RuntimeError(
                    "AI Agent překročil časový limit "
                    f"({_AGENT_POLL_TIMEOUT_S}s) bez dokončení odpovědi."
                )
            listing = _agent_request(
                f"{AI_AGENT_API_BASE}/sessions/{session_id}/events?limit=200",
                api_key, method="GET",
            )
            if not isinstance(listing, dict):
                raise AIResponseFormatError()
            events = listing.get("data")
            if not isinstance(events, list):
                raise AIResponseFormatError()
            for event in events:
                event = _require_mapping(event)
                ev_id = event.get("id")
                if ev_id is not None:
                    if ev_id in seen_event_ids:
                        continue
                    seen_event_ids.add(ev_id)
                etype = event.get("type")
                if etype == "agent.message":
                    blocks = event.get("content")
                    if not isinstance(blocks, list):
                        raise AIResponseFormatError()
                    for block in blocks:
                        block = _require_mapping(block)
                        if block.get("type") == "text":
                            result_text += _require_text(block.get("text"))
                elif etype == "session.status_idle":
                    status = "idle"
                elif etype == "session.status_failed" or etype == "session.status_error":
                    raise RuntimeError("AI Agent selhal při zpracování požadavku.")
            if status == "idle":
                break
            time.sleep(1.5)

        if not result_text.strip():
            raise RuntimeError("AI Agent vrátil prázdnou odpověď.")
        return result_text.strip()
    except RuntimeError:
        raise
    except Exception:
        raise RuntimeError("Chyba při volání AI Agenta (Anthropic Sessions API).")
    finally:
        if session_id:
            try:
                _agent_request(
                    f"{AI_AGENT_API_BASE}/sessions/{session_id}/archive",
                    api_key, method="POST", payload={},
                )
            except Exception:
                pass


def evaluate(machine_data, speed_hz, iso_norm, model=None):
    """Zavolá zvolený model a vrátí (text, prompt_user, model).

    Podle modelu zvolí poskytovatele (OpenAI / Anthropic). Vyhazuje RuntimeError.
    """
    model = model or get_model()
    provider = _provider_for(model)
    key_provider = "anthropic" if provider == "anthropic_agent" else provider
    api_key = get_api_key(key_provider)
    if not api_key:
        if key_provider == "anthropic":
            raise RuntimeError(
                "Není nastaven Claude (Anthropic) API klíč. Zadejte jej v nastavení AI."
            )
        raise RuntimeError(
            "Není nastaven OpenAI API klíč. Zadejte jej v nastavení AI."
        )
    system, user = build_prompt(machine_data, speed_hz, iso_norm)
    if provider == "anthropic_agent":
        text = _call_anthropic_agent(api_key, system, user)
    elif provider == "anthropic":
        text = _call_anthropic(api_key, model, system, user)
    else:
        text = _call_openai(api_key, model, system, user)
    return text, user, model

def build_brief_prompt(machine_data, speed_hz, iso_norm, severity_label=None,
                       user_context=None, has_image=False, report_version=None,
                       machine_kind=None, severity=None, fault=None,
                       use_examples=True, prompt_snapshot=None,
                       canonical_report_context=None):
    """Sestaví (system, user) pro závěr + doporučení do protokolu.

    Varianta B (učení z minulých protokolů): pokud `use_examples` a ve
    znalostní bázi (`ai_knowledge`) existují schválené vzory odpovídající
    `report_version` / `machine_kind` / `severity` / `fault`, vloží se do
    user promptu blok PŘÍKLADŮ, podle nichž model napodobí styl a odbornou
    úvahu diagnostika (bez přebírání konkrétních hodnot).

    Výstup AI má být JSON: {"problem": <krátký popis problému, max 1 věta>,
    "zaver": <text závěru>, "doporuceni": <1-2 stručné věty>}.

    `report_version` volí POUZE šablonu (`report_brief_v1/v2/v3`). Rozsah
    a strukturu závěru — počet bodů, jejich pořadí i to, co se má vůbec
    hodnotit — určuje text té šablony, tedy Nastavení → AI prompty. Tato
    funkce do struktury nemluví; jediné, co je pevné, je JSON obal odpovědi
    z `{report_contract}`, aby šel výsledek rozparsovat do editoru.

    `user_context` = volitelný doplňující prompt od uživatele (podmínky měření,
    koncepce stroje, co vyhodnotit a co ne). `has_image` přidá pokyn využít
    přiložený obrázek stroje.
    """
    if report_version == 3:
        version = 3
    elif report_version == 2:
        version = 2
    else:
        version = 1
    expected_prompt_id = ai_prompts.prompt_id_for_report_version(version)
    snapshot = prompt_snapshot or ai_prompts.get_snapshot(expected_prompt_id)
    if snapshot.identifier != expected_prompt_id:
        raise ValueError("Neplatná šablona AI pro zvolenou verzi protokolu.")
    # Upravovatelná část zůstává oddělená od neměnného kontraktu JSON a
    # faktického ukotvení. Render nepoužívá Python str.format.
    system = ai_prompts.render_snapshot(snapshot)
    # Bez bloku „ÚKOL": strukturu závěru protokolu určuje šablona verze
    # protokolu, ne tenhle obecný předpis pro volné hodnocení stroje.
    _sys, user = build_prompt(machine_data, speed_hz, iso_norm, with_task=False)
    if severity_label:
        user += ("\n\nCELKOVÉ HODNOCENÍ STROJE (dle pásem A–D): "
                 + str(severity_label))
    canonical = (canonical_report_context or "").strip()
    if canonical:
        user += (
            "\n\nKANONICKÉ HODNOTY PROTOKOLU (tyto hodnoty a směry jsou "
            "závazné pro závěr; nepřepočítávej je z historie):\n" + canonical[:8000])
    if has_image:
        user += ("\n\nSoučástí zadání je PŘILOŽENÝ OBRÁZEK STROJE — využij jej "
                 "pro lepší pochopení koncepce a typu stroje při hodnocení.")
    # --- varianta B: vlož schválené vzory (few-shot ze znalostní báze) ---
    if use_examples:
        try:
            import ai_knowledge
            ex_block = ai_knowledge.examples_block(
                report_version=version, machine_kind=machine_kind,
                severity=severity, fault=fault, limit=3)
        except Exception:
            ex_block = ""
        if ex_block:
            user += ex_block
            system += (" Drž se stylu, struktury a odborné úrovně přiložených "
                       "PŘÍKLADŮ z dřívějších protokolů, ale konkrétní hodnoty a "
                       "pásma ber vždy pouze z aktuálně naměřených dat.")
    if version == 3:
        # Jediná verzní zvláštnost, která NENÍ pokyn ke stylu ani struktuře:
        # popis dat, jež má model k dispozici jen u vyvažování.
        user += (
            "\n\nJEDNÁ SE O PROTOKOL Z VYVAŽOVÁNÍ. K dispozici máš hodnoty "
            "PŘED vyvážením (vel_prev) i PO vyvážení (vel_cur) s příslušnými "
            "pásmy A–D."
        )
    # Rozsah a strukturu závěru řídí VÝHRADNĚ šablona verze protokolu
    # (Nastavení → AI prompty) a pokyny diagnostika níže. Dřív tu stál pevný
    # odstavec s počtem bodů, který upravenou šablonu přebil, protože model
    # četl jako poslední jeho.
    ctx = (user_context or "").strip()
    if ctx:
        # Pokyny k jednomu konkrétnímu protokolu stojí nad šablonou: jen tak
        # lze říct „je to třídič, rychlost dle normy nehodnoť". Naměřené
        # hodnoty, pásma a meze ale nemění — ty pocházejí vždy ze zadání.
        user += (
            "\n\nPOKYNY DIAGNOSTIKA K TOMUTO PROTOKOLU (podmínky měření, "
            "koncepce/typ strojů, co vyhodnotit a co ne) — MAJÍ PŘEDNOST před "
            "rozsahem i strukturou závěru uvedenými výše. Nemění však naměřené "
            "hodnoty, pásma ani meze:\n" + ctx[:4000])
    return system, user


def _parse_brief_json(text):
    """Ověří přesný JSON kontrakt výsledku AI pro návrh protokolu.

    Nepřevádí čísla, pole ani objekty pomocí ``str``: taková normalizace by
    poškozenou odpověď maskovala a mohla ji propustit až do editoru/PDF.
    """
    raw = _require_text(text).strip()
    # odstran případné ```json ... ``` oplocení
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:]
    # najdi první { ... poslední }
    i = raw.find("{")
    j = raw.rfind("}")
    if i != -1 and j != -1 and j > i:
        raw = raw[i:j + 1]
    try:
        obj = json.loads(raw)
    except Exception:
        raise AIResponseFormatError()
    if not isinstance(obj, dict):
        raise AIResponseFormatError()
    fields = ("problem", "zaver", "doporuceni")
    if any(field not in obj or not isinstance(obj[field], str) for field in fields):
        raise AIResponseFormatError()
    return {
        "problem": obj["problem"].strip(),
        "zaver": obj["zaver"].strip(),
        "doporuceni": obj["doporuceni"].strip(),
    }


def evaluate_brief(machine_data, speed_hz, iso_norm, model=None,
                   severity_label=None, user_context=None, image=None,
                   report_version=None, machine_kind=None, severity=None,
                   fault=None, use_examples=True, prompt_snapshot=None,
                   canonical_report_context=None):
    """Zavolá model a vrátí {problem, zaver, doporuceni} pro protokol.

    `user_context` = volitelný doplňující prompt; `image` = datová URL obrázku
    stroje (vloží se do promptu jako vision vstup). `report_version` řídí
    formát závěru (1 = stručný, 2 = detailní strukturovaný do 4 bodů —
    viz `build_brief_prompt`). Vyhazuje RuntimeError při chybě (chybějící
    klíč, chyba API).
    """
    model = model or get_model()
    provider = _provider_for(model)
    # AI Agent používá stejný klíč jako běžné Claude volání (ANTHROPIC_API_KEY),
    # jen musí mít navíc povolený přístup k beta Sessions/Agent API.
    key_provider = "anthropic" if provider == "anthropic_agent" else provider
    api_key = get_api_key(key_provider)
    if not api_key:
        if key_provider == "anthropic":
            raise RuntimeError(
                "Není nastaven Claude (Anthropic) API klíč. Zadejte jej v nastavení AI."
            )
        raise RuntimeError(
            "Není nastaven OpenAI API klíč. Zadejte jej v nastavení AI."
        )
    has_image = _data_url_parts(image) is not None
    system, user = build_brief_prompt(
        machine_data, speed_hz, iso_norm, severity_label,
        user_context=user_context, has_image=has_image,
        report_version=report_version, machine_kind=machine_kind,
        severity=severity, fault=fault, use_examples=use_examples,
        prompt_snapshot=prompt_snapshot,
        canonical_report_context=canonical_report_context)
    img = image if has_image else None
    if provider == "anthropic_agent":
        text = _call_anthropic_agent(api_key, system, user, image=img)
    elif provider == "anthropic":
        text = _call_anthropic(api_key, model, system, user, image=img)
    else:
        text = _call_openai(api_key, model, system, user, image=img)
    return _parse_brief_json(text), model


# ======================================================================
#  CHAT S AI AGENTEM (varianta A: celý kontext stroje na začátku)
# ======================================================================
#  Agent dostane na začátku konverzace kompletní podklady stroje
#  (stejná data jako jednorázové vyhodnocení) a dále odpovídá na dotazy
#  uživatele s pamětí celé konverzace. Používá pouze stdlib (urllib).
# ======================================================================

# System prompt pro chatovacího diagnostika (volnější než pevné vyhodnocení)
CHAT_SYSTEM = (
    "Jsi senior vibrační diagnostik s mnohaletými zkušenostmi v prediktivní "
    "údržbě rotačních strojů. Vedeš odborný dialog s technikem/diagnostikem. "
    "Hodnotíš naměřená data podle platných norem (ČSN ISO 10816/20816, "
    "ISO 13373) a osvědčené praxe. Odpovídáš odborně, věcně a v ČEŠTINĚ. "
    "Vycházej VÝHRADNĚ z dat, která máš v konverzaci k dispozici "
    "(podklady stroje a naměřené hodnoty). Pokud na dotaz data nestačí, "
    "jasně to uveď a navrhni, jaké další měření nebo údaj by pomohl. "
    "Nevymýšlej si hodnoty, které v datech nejsou. Odpovídej přiměřeně "
    "stručně; delší rozbor podej jen tam, kde to dotaz vyžaduje."
)

# Maximální počet zpráv historie (uživatel+agent), které se posílají modelu.
# Kontext stroje (první zpráva) se posílá vždy zvlášť a do limitu se nepočítá.
CHAT_MAX_HISTORY = 16


def build_chat_context(machine_data, speed_hz, iso_norm):
    """Sestaví textový blok s kompletními podklady stroje pro úvod konverzace.

    Využívá stejné sestavení dat jako jednorázové vyhodnocení (build_prompt),
    ale bez závěrečného „ÚKOL" — slouží jen jako kontext, na který se agent
    bude v dalších zprávách odkazovat.
    """
    # Pro chat nechceme vynucovat strukturovaný protokol, jen předat data
    # jako kontext.
    _system, user = build_prompt(machine_data, speed_hz, iso_norm, with_task=False)
    intro = (
        "PODKLADY STROJE PRO DIAGNOSTICKÝ DIALOG\n"
        "Níže jsou aktuální naměřená data a parametry stroje. Vycházej z nich "
        "při odpovědích. Pokud uživatel požádá o vyhodnocení, použij normy a "
        "porovnání s limity.\n\n"
    )
    return intro + user


def _sanitize_history(history):
    """Očistí historii zpráv z frontendu na [{role, content}] s povolenými rolemi."""
    out = []
    for m in (history or []):
        if not isinstance(m, dict):
            continue
        role = m.get("role")
        content = m.get("content")
        if role not in ("user", "assistant"):
            continue
        if not isinstance(content, str) or not content.strip():
            continue
        out.append({"role": role, "content": content.strip()})
    # ponech jen posledních CHAT_MAX_HISTORY zpráv
    if len(out) > CHAT_MAX_HISTORY:
        out = out[-CHAT_MAX_HISTORY:]
    return out


def _chat_openai(api_key, model, system, messages, image=None):
    """Zavolá OpenAI chat completions s celou historií zpráv.

    `messages` je seznam {role, content} (user/assistant). `image` (datová URL)
    se připojí k PRVNÍ uživatelské zprávě (kontext stroje s obrázkem).
    """
    msgs = [{"role": "system", "content": system}]
    img_attached = False
    parts = _data_url_parts(image)
    for m in messages:
        if (not img_attached) and parts and m["role"] == "user":
            msgs.append({"role": "user", "content": [
                {"type": "text", "text": m["content"]},
                {"type": "image_url", "image_url": {"url": image}},
            ]})
            img_attached = True
        else:
            msgs.append({"role": m["role"], "content": m["content"]})
    payload = {"model": model, "messages": msgs, "temperature": 0.3}
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        OPENAI_URL, data=data, method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT_S) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise RuntimeError("OpenAI vrátilo chybu služby (%s)." % e.code)
    except urllib.error.URLError:
        raise RuntimeError("Nelze se připojit k OpenAI. Zkontrolujte připojení k internetu.")
    try:
        result = json.loads(body)
        return result["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, ValueError):
        raise RuntimeError("Neočekávaná odpověď od OpenAI.")


def _chat_anthropic(api_key, model, system, messages, image=None):
    """Zavolá Anthropic Claude s celou historií zpráv."""
    parts = _data_url_parts(image)
    out_msgs = []
    img_attached = False
    for m in messages:
        if (not img_attached) and parts and m["role"] == "user":
            media_type, b64 = parts
            out_msgs.append({"role": "user", "content": [
                {"type": "text", "text": m["content"]},
                {"type": "image", "source": {
                    "type": "base64", "media_type": media_type, "data": b64}},
            ]})
            img_attached = True
        else:
            out_msgs.append({"role": m["role"], "content": m["content"]})
    payload = {
        "model": model,
        "max_tokens": 2000,
        "temperature": 0.3,
        "system": system,
        "messages": out_msgs,
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        ANTHROPIC_URL, data=data, method="POST",
        headers={
            "content-type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": ANTHROPIC_VERSION,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT_S) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        raise RuntimeError("Claude (Anthropic) vrátilo chybu služby (%s)." % e.code)
    except urllib.error.URLError:
        raise RuntimeError("Nelze se připojit k Anthropic. Zkontrolujte připojení k internetu.")
    try:
        result = json.loads(body)
        result = _require_mapping(result)
        parts2 = result.get("content")
        if not isinstance(parts2, list):
            raise AIResponseFormatError()
        text_parts = []
        for part in parts2:
            part = _require_mapping(part)
            if part.get("type") == "text":
                text_parts.append(_require_text(part.get("text")))
        text = "".join(text_parts)
        if not text:
            text = _require_text(_require_mapping(parts2[0]).get("text"))
        return text.strip()
    except AIResponseFormatError:
        raise
    except (KeyError, IndexError, TypeError, ValueError):
        raise RuntimeError("Neočekávaná odpověď od Claude (Anthropic).")


def _messages_to_text(messages):
    """Sloučí seznam {role, content} do jednoho textu pro AI Agenta
    (Sessions API nevede konverzaci přes messages pole jako Messages API,
    proto se celá historie připojí jako kontext do jedné zprávy).
    """
    lines = []
    for m in messages:
        role_label = "Diagnostik" if m["role"] == "assistant" else "Uživatel"
        lines.append(f"{role_label}: {m['content']}")
    return "\n\n".join(lines)


def chat(machine_data, speed_hz, iso_norm, history, model=None, image=None):
    """Vede konverzaci s AI agentem nad daty stroje.

    Parametry:
      machine_data – data stroje (z ndb_parser.machine_ai_data)
      speed_hz, iso_norm – otáčky a norma
      history – seznam {role, content} z frontendu (user/assistant); poslední
                položka je nový dotaz uživatele
      model – volitelný model (jinak výchozí)
      image – volitelná datová URL obrázku stroje (vision)

    Vrací (odpověď_agenta, použitý_model). Vyhazuje RuntimeError.
    """
    model = model or get_model()
    provider = _provider_for(model)
    key_provider = "anthropic" if provider == "anthropic_agent" else provider
    api_key = get_api_key(key_provider)
    if not api_key:
        if key_provider == "anthropic":
            raise RuntimeError(
                "Není nastaven Claude (Anthropic) API klíč. Zadejte jej v nastavení AI.")
        raise RuntimeError("Není nastaven OpenAI API klíč. Zadejte jej v nastavení AI.")

    hist = _sanitize_history(history)
    if not hist or hist[-1]["role"] != "user":
        raise RuntimeError("Chybí dotaz uživatele.")

    # kontext stroje jako úvodní uživatelská zpráva + potvrzení agenta,
    # aby model bral data jako podklad a nezačal je rovnou „vyhodnocovat"
    context_text = build_chat_context(machine_data, speed_hz, iso_norm)
    messages = [
        {"role": "user", "content": context_text},
        {"role": "assistant", "content":
            "Rozumím, mám k dispozici podklady tohoto stroje. Jsem připraven "
            "odpovídat na dotazy k jeho stavu a diagnostice."},
    ] + hist

    if provider == "anthropic_agent":
        combined_user = _messages_to_text(messages)
        text = _call_anthropic_agent(api_key, CHAT_SYSTEM, combined_user, image=image)
    elif provider == "anthropic":
        text = _chat_anthropic(api_key, model, CHAT_SYSTEM, messages, image=image)
    else:
        text = _chat_openai(api_key, model, CHAT_SYSTEM, messages, image=image)
    return text, model


def now_iso():
    return datetime.now(timezone.utc).astimezone().replace(
        microsecond=0).isoformat()
