# -*- coding: utf-8 -*-
"""Perzistence editovatelného NÁVRHU protokolu (per podnik a databáze).

Ukládá poslední rozpracovaný návrh protokolu per-podnik do
data/podniky/<slug>/report_drafts.json (dříve jeden sdílený
data/report_drafts.json klíčovaný podnik:<název>).
Tak lze protokol rozpracovat, upravit a znovu otevřít bez ztráty úprav.

Používá POUZE standardní knihovnu Pythonu.
"""

import copy

import data_store

_KIND = data_store.KIND_REPORT_DRAFTS


_FORMAT = 2


def _context_key(context_key):
    """Normalizuje kontext aktivní .ndb bez heuristického slučování.

    Název podniku je záměrně jen první část identity úložiště. Jeden podnik
    může mít více samostatných exportů/databází se stejným kořenem stromu a
    jejich rozpracované protokoly se proto nesmějí navzájem přepisovat.
    """
    return str(context_key or "").strip()


def _is_container(value):
    return (isinstance(value, dict) and value.get("format") == _FORMAT
            and isinstance(value.get("drafts"), dict))


def get_draft(db_key, context_key=None):
    """Vrátí návrh pro podnik + konkrétní aktivní databázi, nebo ``None``.

    Starší jednokontextový soubor se čte jako kompatibilní návrh. Při prvním
    zápisu se bezpečně převede do kontejneru; nekopíruje se do všech databází.
    """
    if not db_key:
        return None
    stored = data_store.load(_KIND, db_key)
    if not _is_container(stored):
        return copy.deepcopy(stored) if isinstance(stored, dict) else None
    ctx = _context_key(context_key)
    if not ctx:
        return None
    draft = stored["drafts"].get(ctx)
    return copy.deepcopy(draft) if isinstance(draft, dict) else None


def save_draft(db_key, doc, context_key=None):
    """Uloží návrh protokolu pro daný podnik a databázový kontext.

    Pokud klient posílá identifikátor relace a monotónní revizi, odmítne se
    opožděná odpověď/starší požadavek téže relace. To chrání koncept před
    závodem mezi debouncovaným autosave a návratem do záložky.
    """
    if not db_key:
        return None
    ctx = _context_key(context_key)
    if not ctx:
        # Zpětná kompatibilita pro interní/externí volání bez kontextu.
        data_store.save(_KIND, db_key, doc)
        return doc
    stored = data_store.load(_KIND, db_key)
    drafts = (copy.deepcopy(stored.get("drafts", {}))
              if _is_container(stored) else {})
    current = drafts.get(ctx)
    if isinstance(current, dict) and isinstance(doc, dict):
        same_session = (current.get("_draft_session_id")
                        and current.get("_draft_session_id") == doc.get("_draft_session_id"))
        try:
            stale = int(doc.get("_draft_revision", 0)) < int(current.get("_draft_revision", 0))
        except (TypeError, ValueError):
            stale = False
        if same_session and stale:
            return copy.deepcopy(current)
    drafts[ctx] = copy.deepcopy(doc)
    data_store.save(_KIND, db_key, {"format": _FORMAT, "drafts": drafts})
    return doc


def delete_draft(db_key, context_key=None):
    if not db_key:
        return
    ctx = _context_key(context_key)
    if ctx:
        stored = data_store.load(_KIND, db_key)
        if _is_container(stored):
            drafts = copy.deepcopy(stored["drafts"])
            drafts.pop(ctx, None)
            data_store.save(_KIND, db_key, {"format": _FORMAT, "drafts": drafts})
        return
    data_store.delete(_KIND, db_key)


def migrate_key(old_key, new_key):
    """Přesune data podniku ze staré složky do nové (deleguje na
    data_store.rename_podnik). Ponecháno kvůli zpětné kompatibilitě API.
    """
    if not old_key or not new_key or old_key == new_key:
        return
    data_store.rename_podnik(old_key, new_key)
