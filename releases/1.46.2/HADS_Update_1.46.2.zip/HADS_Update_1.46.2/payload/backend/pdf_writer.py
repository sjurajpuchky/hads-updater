# -*- coding: utf-8 -*-
"""Minimalistický generátor PDF využívající POUZE standardní knihovnu Pythonu.

Podporuje:
  * stránky A4,
  * text v UTF-8 (vložený TrueType font DejaVu Sans jako CIDFont Identity-H,
    plná podpora české diakritiky),
  * měření šířky textu (z tabulky hmtx fontu) → zalamování a zarovnání,
  * čáry, obdélníky (výplň i obrys), kruhové výseče (koláčový graf),
  * vložení obrázku JPEG (DCTDecode) — pro obrázek stroje z karty.

Žádné externí balíčky (reportlab apod.) nejsou potřeba.
"""

import struct
import zlib
import io


# ----------------------- čtení TrueType fontu -----------------------
class TrueTypeFont:
    """Načte TrueType font a poskytne metriky + binární data pro vložení."""

    def __init__(self, path):
        with open(path, "rb") as f:
            self.data = f.read()
        self._tables = {}
        self.units_per_em = 1000
        self.cmap = {}          # unicode -> glyph id
        self.advance = {}       # glyph id -> advance width (font units)
        self._num_glyphs = 0
        self._parse()

    def _parse(self):
        d = self.data
        (sfnt, num_tables, _sr, _es, _rs) = struct.unpack(">IHHHH", d[:12])
        off = 12
        for _ in range(num_tables):
            tag = d[off:off + 4].decode("latin-1")
            (_chk, toff, tlen) = struct.unpack(">III", d[off + 4:off + 16])
            self._tables[tag] = (toff, tlen)
            off += 16
        self._parse_head()
        self._parse_maxp()
        self._parse_hmtx()
        self._parse_cmap()

    def _tbl(self, tag):
        if tag not in self._tables:
            return None
        o, l = self._tables[tag]
        return self.data[o:o + l]

    def _parse_head(self):
        t = self._tbl("head")
        if not t:
            return
        self.units_per_em = struct.unpack(">H", t[18:20])[0] or 1000
        self._index_to_loc = struct.unpack(">h", t[50:52])[0]

    def _parse_maxp(self):
        t = self._tbl("maxp")
        if t:
            self._num_glyphs = struct.unpack(">H", t[4:6])[0]

    def _parse_hmtx(self):
        hhea = self._tbl("hhea")
        hmtx = self._tbl("hmtx")
        if not hhea or not hmtx:
            return
        num_hm = struct.unpack(">H", hhea[34:36])[0]
        adv = 0
        for i in range(self._num_glyphs):
            if i < num_hm:
                adv = struct.unpack(">H", hmtx[i * 4:i * 4 + 2])[0]
            self.advance[i] = adv

    def _parse_cmap(self):
        t = self._tbl("cmap")
        if not t:
            return
        (_ver, ntab) = struct.unpack(">HH", t[:4])
        best = None
        for i in range(ntab):
            pid, eid, sub_off = struct.unpack(">HHI", t[4 + i * 8:4 + i * 8 + 8])
            # preferuj Unicode (3,1) nebo (3,10) nebo (0,*)
            score = 0
            if pid == 3 and eid == 10:
                score = 5
            elif pid == 3 and eid == 1:
                score = 4
            elif pid == 0:
                score = 3
            if best is None or score > best[0]:
                best = (score, sub_off)
        if not best:
            return
        sub = t[best[1]:]
        fmt = struct.unpack(">H", sub[:2])[0]
        if fmt == 4:
            self._parse_cmap4(sub)
        elif fmt == 12:
            self._parse_cmap12(sub)
        elif fmt == 6:
            self._parse_cmap6(sub)

    def _parse_cmap4(self, sub):
        (_fmt, _len, _lang, segx2) = struct.unpack(">HHHH", sub[:8])
        segc = segx2 // 2
        o = 14
        end = struct.unpack(">%dH" % segc, sub[o:o + segx2]); o += segx2
        o += 2  # reservedPad
        start = struct.unpack(">%dH" % segc, sub[o:o + segx2]); o += segx2
        delta = struct.unpack(">%dh" % segc, sub[o:o + segx2]); o += segx2
        ro_off = o
        rangeoff = struct.unpack(">%dH" % segc, sub[o:o + segx2]); o += segx2
        for i in range(segc):
            for c in range(start[i], end[i] + 1):
                if c == 0xFFFF:
                    continue
                if rangeoff[i] == 0:
                    g = (c + delta[i]) & 0xFFFF
                else:
                    gi = ro_off + i * 2 + rangeoff[i] + (c - start[i]) * 2
                    if gi + 2 > len(sub):
                        continue
                    g = struct.unpack(">H", sub[gi:gi + 2])[0]
                    if g != 0:
                        g = (g + delta[i]) & 0xFFFF
                if g != 0:
                    self.cmap[c] = g

    def _parse_cmap12(self, sub):
        (_fmt, _r, _len, _lang, ngroups) = struct.unpack(">HHIII", sub[:16])
        o = 16
        for _ in range(ngroups):
            sc, ec, sg = struct.unpack(">III", sub[o:o + 12]); o += 12
            for c in range(sc, ec + 1):
                self.cmap[c] = sg + (c - sc)

    def _parse_cmap6(self, sub):
        (_fmt, _len, _lang, first, count) = struct.unpack(">HHHHH", sub[:10])
        o = 10
        for i in range(count):
            g = struct.unpack(">H", sub[o:o + 2])[0]; o += 2
            self.cmap[first + i] = g

    def gid(self, ch):
        return self.cmap.get(ord(ch), 0)

    def char_width(self, ch, size):
        """Šířka znaku v bodech pro danou velikost."""
        g = self.gid(ch)
        adv = self.advance.get(g, self.advance.get(0, 0))
        return adv * size / self.units_per_em

    def text_width(self, text, size):
        return sum(self.char_width(c, size) for c in (text or ""))


# ----------------------- generátor PDF -----------------------
class PDF:
    """Sestaví jednoduchý vícestránkový PDF dokument.

    Souřadný systém PDF: počátek vlevo dole, jednotka = bod (1/72 palce).
    Pro pohodlí pracujeme v souřadnicích „shora": y_top měřeno od horního
    okraje stránky. Metoda _y() to převede.
    """
    PAGE_W = 595.28   # A4 šířka v bodech
    PAGE_H = 841.89   # A4 výška v bodech

    def __init__(self, font_path, font_bold_path=None):
        self.font = TrueTypeFont(font_path)
        self.font_bold = TrueTypeFont(font_bold_path) if font_bold_path else self.font
        self._pages = []          # seznam content streamů (bytes)
        self._cur = None          # aktuální stream (list[bytes])
        self._used_glyphs = set()        # GID použité v regular fontu
        self._used_glyphs_bold = set()   # GID použité v bold fontu
        self._images = []         # vložené obrázky: list dict
        self._links = []          # interní odkazy: list dict {page,x,y_top,w,h,dest}
        self.new_page()

    # ---- interní odkazy (klik v PDF na jinou stranu) ----
    def current_page_index(self):
        """Index strany, která se právě kreslí (0-based)."""
        return len(self._pages)

    def add_link(self, x, y_top, w, h, dest_page, src_page=None):
        """Zaznamená klikací obdélník mířící na dest_page (0-based).

        src_page (0-based) určuje stranu, na které odkaz leží; výchozí = právě
        kreslená strana. Lze tak přidat odkaz na již vykreslenou stranu.
        """
        self._links.append({
            "page": self.current_page_index() if src_page is None else int(src_page),
            "x": x, "y_top": y_top, "w": w, "h": h, "dest": int(dest_page),
        })

    # ---- správa stránek ----
    def new_page(self):
        if self._cur is not None:
            self._pages.append(b"".join(self._cur))
        self._cur = []

    def _finish(self):
        if self._cur is not None:
            self._pages.append(b"".join(self._cur))
            self._cur = None

    def _y(self, y_top):
        return self.PAGE_H - y_top

    # ---- kreslení ----
    def _esc_hex(self, text, bold=False):
        """Převede text na hex řetězec GID (Identity-H) a zaznamená glyfy."""
        font = self.font_bold if bold else self.font
        used = self._used_glyphs_bold if bold else self._used_glyphs
        out = []
        for ch in (text or ""):
            g = font.gid(ch)
            if g == 0 and ch != " ":
                g = font.gid("?")
            used.add(g)
            out.append("%04X" % g)
        return "".join(out)

    def text(self, x, y_top, text, size=10, bold=False, color=(0, 0, 0)):
        if text is None or text == "":
            return
        hexs = self._esc_hex(str(text), bold)
        fname = "/FB" if bold else "/FR"
        r, g, b = color
        self._cur.append((
            "q %.3f %.3f %.3f rg BT %s %.2f Tf 1 0 0 1 %.2f %.2f Tm <%s> Tj ET Q\n"
            % (r, g, b, fname, size, x, self._y(y_top), hexs)
        ).encode("latin-1"))

    def text_width(self, text, size=10, bold=False):
        font = self.font_bold if bold else self.font
        return font.text_width(str(text), size)

    def text_centered(self, cx, y_top, text, size=10, bold=False, color=(0, 0, 0)):
        w = self.text_width(text, size, bold)
        self.text(cx - w / 2.0, y_top, text, size, bold, color)

    def text_right(self, x_right, y_top, text, size=10, bold=False, color=(0, 0, 0)):
        w = self.text_width(text, size, bold)
        self.text(x_right - w, y_top, text, size, bold, color)

    def _split_long_word(self, word, size, max_w, bold=False):
        """Rozdělí jedno „slovo“ bez mezer na části, které se vejdou do max_w.

        Řeší případ dlouhých souvislých řetězců (bez mezer), které by jinak
        přetekly za pravý okraj bloku. Zlom se provede po znacích.
        """
        if self.text_width(word, size, bold) <= max_w or max_w <= 0:
            return [word]
        parts = []
        cur = ""
        for ch in word:
            trial = cur + ch
            if self.text_width(trial, size, bold) <= max_w or not cur:
                cur = trial
            else:
                parts.append(cur)
                cur = ch
        if cur:
            parts.append(cur)
        return parts or [word]

    def wrap_text(self, text, size, max_w, bold=False):
        """Zalomí text do řádků o maximální šířce max_w (v bodech).

        Dlouhá slova bez mezer (delší než max_w) se rozdělí po znacích, aby
        text nikdy nepřetekl za pravý okraj bloku.
        """
        raw_words = str(text or "").split()
        # Nejdřív rozbij příliš dlouhá slova na části, které se vejdou do max_w.
        words = []
        for w in raw_words:
            words.extend(self._split_long_word(w, size, max_w, bold))
        lines = []
        cur = ""
        for w in words:
            trial = (cur + " " + w).strip()
            if self.text_width(trial, size, bold) <= max_w or not cur:
                cur = trial
            else:
                lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        return lines or [""]

    def text_block(self, x, y_top, text, size, max_w, leading=None,
                   bold=False, color=(0, 0, 0), justify=False):
        """Vykreslí zalomený odstavec; vrátí novou y pozici (spodek bloku).

        `justify=True` zarovná text do bloku (roztažením mezer mezi slovy tak,
        aby pravý okraj řádku lícoval s `max_w`) — poslední řádek odstavce
        zůstává zarovnaný doleva jako obvykle.
        """
        leading = leading or size * 1.35
        y = y_top
        lines = self.wrap_text(text, size, max_w, bold)
        n = len(lines)
        for i, ln in enumerate(lines):
            if justify and i < n - 1:
                self._text_justified(x, y, ln, size, max_w, bold, color)
            else:
                self.text(x, y, ln, size, bold, color)
            y += leading
        return y

    def _text_justified(self, x, y_top, line, size, target_w, bold, color):
        """Vykreslí jeden řádek se slovy roztaženými tak, aby zaplnil target_w.

        Pokud řádek obsahuje jen jedno slovo (nelze roztáhnout mezerami),
        vykreslí se normálně zarovnaný doleva.
        """
        words = line.split(" ")
        if len(words) < 2:
            self.text(x, y_top, line, size, bold, color)
            return
        words_w = sum(self.text_width(w, size, bold) for w in words)
        gaps = len(words) - 1
        space_w = (target_w - words_w) / gaps if gaps else 0
        # Nikdy nedovol záporné nebo extrémně velké mezery (ochrana proti
        # okrajovým případům s velmi krátkým posledním slovem apod.)
        space_w = max(space_w, self.text_width(" ", size, bold) * 0.6)
        cx = x
        for w in words:
            self.text(cx, y_top, w, size, bold, color)
            cx += self.text_width(w, size, bold) + space_w

    def paragraph_block(self, x, y_top, text, size, max_w, leading=None,
                        color=(0, 0, 0), para_gap=None, justify=False):
        """Vykreslí text jako posloupnost odstavců oddělených prázdným řádkem.

        Každé zalomení řádku (Enter) v textu zahajuje NOVÝ odstavec; mezi
        odstavci se vloží malá mezera `para_gap`, aby text nebyl souvislý.
        Číslování se NEpřidává. Vrací novou y pozici (spodek bloku).
        """
        leading = leading or size * 1.35
        para_gap = para_gap if para_gap is not None else leading * 0.55
        paras = [p.strip() for p in str(text or "").replace("\r", "").split("\n")]
        paras = [p for p in paras if p]
        y = y_top
        for i, p in enumerate(paras):
            y = self.text_block(x, y, p, size, max_w, leading,
                                color=color, justify=justify)
            if i < len(paras) - 1:
                y += para_gap
        return y

    def paragraph_block_height(self, text, size, max_w, leading=None,
                               para_gap=None):
        """Odhadne výšku bloku vykresleného pomocí `paragraph_block`."""
        leading = leading or size * 1.35
        para_gap = para_gap if para_gap is not None else leading * 0.55
        paras = [p.strip() for p in str(text or "").replace("\r", "").split("\n")]
        paras = [p for p in paras if p]
        if not paras:
            return 0.0
        total = 0.0
        for p in paras:
            total += len(self.wrap_text(p, size, max_w)) * leading
        total += para_gap * (len(paras) - 1)
        return total

    def numbered_block(self, x, y_top, text, size, max_w, leading=None,
                        color=(0, 0, 0), item_gap=None, justify=False):
        """Vykreslí text jako číslovaný seznam (1. 2. 3. …), pokud text tuto
        strukturu obsahuje; jinak jej vykreslí jako běžný odstavec.

        Každá položka má vlastní číslo v hangingu (číslo vlevo, text
        odsazený) a zalamuje se do šířky `max_w` minus odsazení. Vrací novou
        y pozici (spodek bloku).
        """
        import re
        leading = leading or size * 1.35
        item_gap = item_gap if item_gap is not None else leading * 0.35
        items = self._split_numbered_items(text)
        y = y_top
        if len(items) < 2:
            # Text nemá rozpoznatelnou číslovanou strukturu — vykresli jako
            # běžný odstavec (příp. zarovnaný do bloku).
            return self.text_block(x, y_top, text, size, max_w, leading,
                                    color=color, justify=justify)
        indent = self.text_width("9.", size, bold=True) + 6
        text_w = max_w - indent
        for num, item_text in items:
            label = "%s." % num
            self.text(x, y, label, size, bold=True, color=color)
            lines = self.wrap_text(item_text, size, text_w)
            n = len(lines)
            for i, ln in enumerate(lines):
                if justify and i < n - 1:
                    self._text_justified(x + indent, y, ln, size, text_w,
                                          False, color)
                else:
                    self.text(x + indent, y, ln, size, False, color)
                y += leading
            y += item_gap
        return y - item_gap

    def numbered_block_height(self, text, size, max_w, leading=None,
                              item_gap=None):
        """Odhadne výšku bloku vykresleného pomocí `numbered_block`
        (bez skutečného vykreslení) — pro výpočty zalomení stránky."""
        leading = leading or size * 1.35
        item_gap = item_gap if item_gap is not None else leading * 0.35
        items = self._split_numbered_items(text)
        if len(items) < 2:
            return len(self.wrap_text(text, size, max_w)) * leading
        indent = self.text_width("9.", size, bold=True) + 6
        text_w = max_w - indent
        total = 0.0
        for _num, item_text in items:
            n_lines = len(self.wrap_text(item_text, size, text_w))
            total += n_lines * leading + item_gap
        return total - item_gap

    @staticmethod
    def _split_numbered_items(text):
        """Rozdělí text na číslované položky '1. ... 2. ... 3. ...'.

        Rozpozná číslo následované tečkou a mezerou, které stojí buď na začátku
        textu, nebo na začátku nového řádku, nebo bezprostředně za koncem
        předchozí věty (tečka/vykřičník/otázník + mezera). Vrací seznam
        dvojic (číslo_jako_str, text_položky). Pokud nic nenajde, vrátí [].
        """
        import re
        s = (text or "").strip()
        if not s:
            return []
        pattern = re.compile(r'(?:(?<=^)|(?<=[\n])|(?<=[.!?]\s))(\d{1,2})\.\s+')
        matches = list(pattern.finditer(s))
        if len(matches) < 2:
            return []
        items = []
        for i, m in enumerate(matches):
            num = m.group(1)
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(s)
            item_text = s[start:end].strip()
            if item_text:
                items.append((num, item_text))
        return items

    def line(self, x1, y1_top, x2, y2_top, width=0.7, color=(0, 0, 0)):
        r, g, b = color
        self._cur.append((
            "q %.3f %.3f %.3f RG %.2f w %.2f %.2f m %.2f %.2f l S Q\n"
            % (r, g, b, width, x1, self._y(y1_top), x2, self._y(y2_top))
        ).encode("latin-1"))

    def dash_line(self, x1, y1_top, x2, y2_top, width=0.7, color=(0, 0, 0),
                  dash=3, gap=2):
        """Čárkovaná čára (pro hladiny limitů apod.)."""
        r, g, b = color
        self._cur.append((
            "q %.3f %.3f %.3f RG %.2f w [%.1f %.1f] 0 d "
            "%.2f %.2f m %.2f %.2f l S Q\n"
            % (r, g, b, width, dash, gap, x1, self._y(y1_top),
               x2, self._y(y2_top))
        ).encode("latin-1"))

    def rect(self, x, y_top, w, h, fill=None, stroke=None, width=0.7):
        """Obdélník; (x,y_top) = levý horní roh, h dolů."""
        y_bottom = self._y(y_top + h)
        parts = ["q"]
        if fill is not None:
            parts.append("%.3f %.3f %.3f rg" % fill)
        if stroke is not None:
            parts.append("%.3f %.3f %.3f RG %.2f w" % (stroke + (width,)))
        parts.append("%.2f %.2f %.2f %.2f re" % (x, y_bottom, w, h))
        if fill is not None and stroke is not None:
            parts.append("B")
        elif fill is not None:
            parts.append("f")
        else:
            parts.append("S")
        parts.append("Q\n")
        self._cur.append((" ".join(parts)).encode("latin-1"))

    def pie_slice(self, cx, cy_top, radius, a0, a1, fill):
        """Vykreslí výseč koláče od úhlu a0 do a1 (stupně, 0=nahoře, po směru)."""
        import math
        cy = self._y(cy_top)
        steps = max(2, int(abs(a1 - a0) / 6) + 1)
        parts = ["q", "%.3f %.3f %.3f rg" % fill]
        parts.append("%.2f %.2f m" % (cx, cy))
        for i in range(steps + 1):
            ang = a0 + (a1 - a0) * i / steps
            rad = math.radians(90 - ang)  # 0° nahoře, po směru hod. ručiček
            px = cx + radius * math.cos(rad)
            py = cy + radius * math.sin(rad)
            parts.append("%.2f %.2f l" % (px, py))
        parts.append("h f Q\n")
        self._cur.append((" ".join(parts)).encode("latin-1"))

    def polyline(self, pts, width=0.8, color=(0, 0, 0)):
        """Spojnice bodů [(x, y_top), …] (souřadnice shora). Pro vektorové grafy."""
        if not pts or len(pts) < 2:
            return
        r, g, b = color
        parts = ["q", "%.3f %.3f %.3f RG %.2f w" % (r, g, b, width),
                 "1 J 1 j"]  # zaoblené konce i spoje
        x0, y0 = pts[0]
        parts.append("%.2f %.2f m" % (x0, self._y(y0)))
        for (px, py) in pts[1:]:
            parts.append("%.2f %.2f l" % (px, self._y(py)))
        parts.append("S Q\n")
        self._cur.append((" ".join(parts)).encode("latin-1"))

    def polygon(self, pts, fill=None, stroke=None, width=0.6):
        """Vyplněný / obrysový mnohoúhelník z bodů [(x, y_top), …]."""
        if not pts or len(pts) < 2:
            return
        parts = ["q"]
        if fill is not None:
            parts.append("%.3f %.3f %.3f rg" % fill)
        if stroke is not None:
            parts.append("%.3f %.3f %.3f RG %.2f w" % (stroke + (width,)))
        x0, y0 = pts[0]
        parts.append("%.2f %.2f m" % (x0, self._y(y0)))
        for (px, py) in pts[1:]:
            parts.append("%.2f %.2f l" % (px, self._y(py)))
        parts.append("h")
        if fill is not None and stroke is not None:
            parts.append("B")
        elif fill is not None:
            parts.append("f")
        else:
            parts.append("S")
        parts.append("Q\n")
        self._cur.append((" ".join(parts)).encode("latin-1"))

    def dot(self, x, y_top, radius=1.6, fill=(0, 0, 0)):
        """Malý vyplněný kroužek (bod trendu) — aproximace kruhu 4 Bézierovými oblouky."""
        cy = self._y(y_top)
        k = radius * 0.5523
        r = radius
        rr, gg, bb = fill
        self._cur.append((
            "q %.3f %.3f %.3f rg %.2f %.2f m "
            "%.2f %.2f %.2f %.2f %.2f %.2f c "
            "%.2f %.2f %.2f %.2f %.2f %.2f c "
            "%.2f %.2f %.2f %.2f %.2f %.2f c "
            "%.2f %.2f %.2f %.2f %.2f %.2f c f Q\n" % (
                rr, gg, bb,
                x + r, cy,
                x + r, cy + k, x + k, cy + r, x, cy + r,
                x - k, cy + r, x - r, cy + k, x - r, cy,
                x - r, cy - k, x - k, cy - r, x, cy - r,
                x + k, cy - r, x + r, cy - k, x + r, cy,
            )
        ).encode("latin-1"))

    def image_jpeg(self, jpeg_bytes, x, y_top, w, h):
        """Vloží JPEG obrázek (DCTDecode). Vrací True při úspěchu."""
        try:
            width, height, comps = _jpeg_info(jpeg_bytes)
        except Exception:
            return False
        idx = len(self._images)
        name = "/Im%d" % idx
        cs = "/DeviceRGB" if comps == 3 else ("/DeviceGray" if comps == 1
                                              else "/DeviceCMYK")
        self._images.append({
            "data": jpeg_bytes, "w": width, "h": height,
            "cs": cs, "name": name,
        })
        y_bottom = self._y(y_top + h)
        self._cur.append((
            "q %.2f 0 0 %.2f %.2f %.2f cm %s Do Q\n"
            % (w, h, x, y_bottom, name)
        ).encode("latin-1"))
        return True

    # ---- výstup ----
    def output(self):
        self._finish()
        return _build_pdf(self)


# ----------------------- JPEG info -----------------------
def _jpeg_info(data):
    """Vrátí (width, height, components) z JPEG hlavičky (SOF marker)."""
    i = 2
    n = len(data)
    while i < n:
        if data[i] != 0xFF:
            i += 1
            continue
        marker = data[i + 1]
        if marker in (0xC0, 0xC1, 0xC2, 0xC3):
            h = struct.unpack(">H", data[i + 5:i + 7])[0]
            w = struct.unpack(">H", data[i + 7:i + 9])[0]
            comps = data[i + 9]
            return w, h, comps
        seglen = struct.unpack(">H", data[i + 2:i + 4])[0]
        i += 2 + seglen
    raise ValueError("Neplatný JPEG")


# ----------------------- sestavení PDF souboru -----------------------
def _build_pdf(pdf):
    objs = []  # list of bytes (tělo objektu bez "N 0 obj")

    def add(obj_bytes):
        objs.append(obj_bytes)
        return len(objs)  # číslo objektu (1-based)

    # rezervace: 1=catalog, 2=pages — doplníme později
    objs.append(b"")  # 1 catalog
    objs.append(b"")  # 2 pages

    # --- fonty (regular + bold) jako CIDFontType2 Identity-H ---
    font_objs = {}
    for tag, ttf, used in (("FR", pdf.font, pdf._used_glyphs),
                           ("FB", pdf.font_bold, pdf._used_glyphs_bold)):
        used = set(used)
        used.add(0)
        # embedded font file
        ff_data = zlib.compress(ttf.data)
        ff_num = add(
            b"<< /Length %d /Length1 %d /Filter /FlateDecode >>\nstream\n"
            % (len(ff_data), len(ttf.data)) + ff_data + b"\nendstream")
        # CIDFontType2 descriptor
        psname = ("DejaVuSans" + ("Bold" if tag == "FB" else "")).encode()
        desc_num = add(
            b"<< /Type /FontDescriptor /FontName /%s /Flags 32 "
            b"/FontBBox [-1021 -463 1793 1233] /ItalicAngle 0 /Ascent 928 "
            b"/Descent -236 /CapHeight 928 /StemV 87 /FontFile2 %d 0 R >>"
            % (psname, ff_num))
        # W pole (šířky glyfů) — jen použité glyfy
        scale = 1000.0 / ttf.units_per_em
        w_items = []
        for g in sorted(used):
            adv = ttf.advance.get(g, 0)
            w_items.append(b"%d [%d]" % (g, int(round(adv * scale))))
        w_arr = b"[" + b" ".join(w_items) + b"]"
        # CIDToGIDMap = Identity
        cid_num = add(
            b"<< /Type /Font /Subtype /CIDFontType2 /BaseFont /%s "
            b"/CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) "
            b"/Supplement 0 >> /FontDescriptor %d 0 R /CIDToGIDMap /Identity "
            b"/DW 500 /W %s >>" % (psname, desc_num, w_arr))
        # ToUnicode CMap (aby byl text v PDF kopirovatelny/prohledatelny)
        rev = {}
        for cp, g in ttf.cmap.items():
            if g in used and g not in rev:
                rev[g] = cp
        cmap_lines = []
        for g in sorted(rev):
            cmap_lines.append(b"<%04X> <%04X>" % (g, rev[g]))
        cmap_body = (
            b"/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n"
            b"/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n"
            b"/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n"
            b"1 begincodespacerange <0000> <FFFF> endcodespacerange\n")
        # bfchar po blocich max 100
        for i in range(0, len(cmap_lines), 100):
            chunk = cmap_lines[i:i + 100]
            cmap_body += b"%d beginbfchar\n" % len(chunk)
            cmap_body += b"\n".join(chunk) + b"\nendbfchar\n"
        cmap_body += (b"endcmap\nCMapName currentdict /CMap defineresource pop\n"
                      b"end\nend\n")
        cmap_comp = zlib.compress(cmap_body)
        tounicode_num = add(
            b"<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(cmap_comp)
            + cmap_comp + b"\nendstream")
        # Type0 font
        type0_num = add(
            b"<< /Type /Font /Subtype /Type0 /BaseFont /%s "
            b"/Encoding /Identity-H /DescendantFonts [%d 0 R] "
            b"/ToUnicode %d 0 R >>"
            % (psname, cid_num, tounicode_num))
        font_objs[tag] = type0_num

    # --- obrázky (XObject) ---
    image_objs = {}
    for img in pdf._images:
        num = add(
            b"<< /Type /XObject /Subtype /Image /Width %d /Height %d "
            b"/ColorSpace %s /BitsPerComponent 8 /Filter /DCTDecode "
            b"/Length %d >>\nstream\n"
            % (img["w"], img["h"], img["cs"].encode(), len(img["data"]))
            + img["data"] + b"\nendstream")
        image_objs[img["name"]] = num

    # --- obsah a stránky ---
    page_nums = []
    # resources dict (sdílené)
    img_res = b""
    if image_objs:
        img_res = b"/XObject << " + b" ".join(
            b"%s %d 0 R" % (name.encode(), num)
            for name, num in image_objs.items()) + b" >> "
    res = (b"<< /Font << /FR %d 0 R /FB %d 0 R >> %s>>"
           % (font_objs["FR"], font_objs["FB"], img_res))

    content_nums = []
    for content in pdf._pages:
        comp = zlib.compress(content)
        cnum = add(b"<< /Length %d /Filter /FlateDecode >>\nstream\n"
                   % len(comp) + comp + b"\nendstream")
        content_nums.append(cnum)

    # rezervujeme čísla objektů stran předem (kvůli interním odkazům mezi stranami)
    n_pages = len(content_nums)
    page_nums = [add(b"") for _ in range(n_pages)]

    # --- anotace interních odkazů (Link -> /Dest na cílovou stranu) ---
    page_annots = {}  # page_index -> list[annot_obj_num]
    for lk in getattr(pdf, "_links", []):
        di = lk["dest"]
        if di < 0 or di >= n_pages:
            continue
        x = lk["x"]
        y_bottom = pdf.PAGE_H - (lk["y_top"] + lk["h"])
        y_top_pdf = pdf.PAGE_H - lk["y_top"]
        rect = b"[%.2f %.2f %.2f %.2f]" % (x, y_bottom, x + lk["w"], y_top_pdf)
        dest = b"[%d 0 R /XYZ null null null]" % page_nums[di]
        anum = add(
            b"<< /Type /Annot /Subtype /Link /Rect %s /Border [0 0 0] "
            b"/Dest %s >>" % (rect, dest))
        page_annots.setdefault(lk["page"], []).append(anum)

    for pi, cnum in enumerate(content_nums):
        annots = page_annots.get(pi)
        annots_b = b""
        if annots:
            annots_b = b"/Annots [%s] " % b" ".join(
                b"%d 0 R" % a for a in annots)
        objs[page_nums[pi] - 1] = (
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %d %d] "
            b"/Resources %s %s/Contents %d 0 R >>"
            % (int(pdf.PAGE_W), int(pdf.PAGE_H), res, annots_b, cnum))

    # doplň catalog + pages
    kids = b" ".join(b"%d 0 R" % n for n in page_nums)
    objs[0] = b"<< /Type /Catalog /Pages 2 0 R >>"
    objs[1] = (b"<< /Type /Pages /Count %d /Kids [%s] >>"
               % (len(page_nums), kids))

    # --- serializace + xref ---
    out = io.BytesIO()
    out.write(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0] * (len(objs) + 1)
    for i, body in enumerate(objs, start=1):
        offsets[i] = out.tell()
        out.write(b"%d 0 obj\n" % i)
        out.write(body)
        out.write(b"\nendobj\n")
    xref_pos = out.tell()
    out.write(b"xref\n0 %d\n" % (len(objs) + 1))
    out.write(b"0000000000 65535 f \n")
    for i in range(1, len(objs) + 1):
        out.write(b"%010d 00000 n \n" % offsets[i])
    out.write(b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n"
              % (len(objs) + 1, xref_pos))
    return out.getvalue()
