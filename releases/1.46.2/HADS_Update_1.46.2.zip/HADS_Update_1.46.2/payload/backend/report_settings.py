"""Perzistence nastavení protokolu vázaných na databázi (.ndb).

Pro každou databázi (podnik) se ukládá:

  * mapování veličin do sloupců protokolu (které měřené veličiny se berou
    jako RYCHLOST, ZRYCHLENÍ a OBÁLKA zrychlení),
  * seznam jmen techniků nabízený jako výběr do polí Vypracoval / Měřil /
    Schválil při tvorbě protokolu.

Data jsou uložena per-podnik v data/podniky/<slug>/report_settings.json:
    {
      "quantities": {
        "velocity": "<název veličiny rychlosti>",
        "accel":    "<název veličiny zrychlení>",
        "env":      "<název veličiny obálky>"
      },
      "technicians": ["Jméno 1", "Jméno 2", ...]
    }
(dříve jeden sdílený data/report_settings.json klíčovaný klíčem podniku).

Prázdné (nevyplněné) mapování znamená, že se použijí výchozí názvy veličin
z modulu report.py (zpětná kompatibilita).

Používá POUZE standardní knihovnu Pythonu.
"""

import data_store

_KIND = data_store.KIND_REPORT_SETTINGS


def _empty():
    return {
        "quantities": {"velocity": "", "accel": "", "env": ""},
        "technicians": [],
    }


def _normalize(rec):
    """Doplní chybějící klíče na výchozí strukturu."""
    out = _empty()
    if isinstance(rec, dict):
        q = rec.get("quantities") or {}
        if isinstance(q, dict):
            for k in ("velocity", "accel", "env"):
                v = q.get(k)
                out["quantities"][k] = str(v).strip() if v else ""
        techs = rec.get("technicians") or []
        if isinstance(techs, list):
            seen = set()
            clean = []
            for t in techs:
                name = str(t or "").strip()
                if name and name.lower() not in seen:
                    seen.add(name.lower())
                    clean.append(name)
            out["technicians"] = clean
    return out


def get(db_key):
    """Vrátí nastavení protokolu pro daný klíč podniku (vždy plná struktura)."""
    if not db_key:
        return _empty()
    return _normalize(data_store.load(_KIND, db_key))


def save(db_key, settings):
    """Uloží (přepíše) nastavení protokolu pro daný klíč podniku.

    Vrací uloženou (znormalizovanou) strukturu.
    """
    if not db_key:
        return _empty()
    rec = _normalize(settings)
    data_store.save(_KIND, db_key, rec)
    return rec


def quantity_map(db_key):
    """Vrátí mapu vybraných veličin {velocity, accel, env} pro daný podnik.

    Nevyplněné položky jsou prázdný řetězec — volající pak použije výchozí
    název veličiny z report.py.
    """
    return get(db_key).get("quantities", {})


def technicians(db_key):
    """Vrátí seznam jmen techniků uložených pro daný podnik."""
    return get(db_key).get("technicians", [])


def migrate_key(old_key, new_key):
    """Přesune data podniku ze staré složky do nové (deleguje na
    data_store.rename_podnik). Ponecháno kvůli zpětné kompatibilitě API.
    """
    if not old_key or not new_key or old_key == new_key:
        return False
    return data_store.rename_podnik(old_key, new_key)
