# -*- coding: utf-8 -*-
"""Vykreslení protokolu z měření vibrací do PDF (zdrojová DDS databáze) — design v1.12,
od verze 1.22.0 s podporou dvou šablon (verze 1 / verze 2).

Střízlivý, technický, převážně černobílý design s důrazem na to, aby zákazník
získal hlavní informace hned na prvních stranách bez listování:

  * STRANA 1 — kompaktní hlavička + DASHBOARD: stavový přehled parku strojů
    (semafor + KPI), pod tím prioritizovaná akční tabulka kritických strojů
    (Alarm / Výstraha) seřazená dle závažnosti. STEJNÁ pro obě šablony.
  * STRANA 2 — metodika (úvod) + sekce 04 s přehledem VŠECH strojů. Obsah
    sekce 04 se LIŠÍ dle verze:
      - VERZE 1: "Přehled všech strojů" (stav, nejhorší pásmo, datum měření,
        stručné doporučení/poznámka na stroj).
      - VERZE 2: "Závěry a doporučení" (stav, nejhorší pásmo, PLNÝ text
        závěru i doporučení na stroj, BEZ sloupce s datem měření).
  * DETAILNÍ STRANY — liší se dle `doc["report_version"]`:
      - VERZE 1 (stručná, výchozí): jedna stránka na stroj, pouze pro stroje
        se stavem Alarm / Výstraha; sjednocená tabulka s hodnotami přesně
        maxima vybraných nezávislých směrů H/V/A, obrázek
        stroje (je-li k dispozici) + závěr/doporučení a volitelné vektorové
        grafy (trendy / FFT) přímo pod tabulkou stroje.
      - VERZE 2 (detailní): sekce "Hodnocení technického stavu" — pro
        VŠECHNY stroje, kompaktní tabulky (stejný formát jako u verze 1,
        navíc se sloupcem předchozí hodnoty rychlosti) řazené PLYNULE ZA
        SEBOU bez nucené nové stránky pro každý stroj a BEZ obrázku stroje.
        Grafy (trendy / FFT spektra) jsou u verze 2 přesunuty do samostatné
        sekce "Příloha — grafy: trendy a FFT spektra" na konci protokolu.

Používá pdf_writer (pouze standardní knihovna Pythonu).
"""

import base64
from pathlib import Path

import branding
import pdf_writer
import report as report_mod

_FONT_DIR = Path(__file__).resolve().parent / "fonts"
_ASSET_DIR = Path(__file__).resolve().parent / "assets"


def _logo_bytes():
    """Logo (JPEG) do hlavičky: vlastní z Nastavení, jinak vestavěné.

    Záměrně bez cache — změna loga v Nastavení se tak projeví i u protokolu
    znovu vygenerovaného z historie, bez restartu HADS.
    """
    return branding.logo_bytes()


def _footer_values(doc):
    """Patička protokolu z aktuální personalizace instalace.

    Vydavatel protokolu je vlastnost instalace, ne jednotlivého návrhu, takže
    znovu vygenerovaný starý protokol nese aktuální logo i aktuální patičku.
    Uložená hodnota v návrhu slouží už jen jako záloha pro pole, která
    personalizace nezná.
    """
    values = dict(doc.get("footer") or {})
    values.update(branding.footer())
    return values

# ----- střízlivá paleta: převážně černobílá, barva jen u stavů/pásem -----
INK = (0.12, 0.13, 0.15)        # hlavní text (téměř černá)
MUTED = (0.40, 0.43, 0.48)      # popisky, sekundární text
FAINT = (0.62, 0.65, 0.70)      # nejjemnější text
RULE = (0.18, 0.20, 0.23)       # silné dělicí linky
HAIR = (0.80, 0.82, 0.85)       # vlasové linky tabulek
ZEBRA = (0.965, 0.970, 0.976)   # jemné podbarvení sudých řádků
PANEL = (0.945, 0.950, 0.957)   # výplň panelů (KPI karty)
WHITE = (1, 1, 1)

# stavové barvy (jediná barva v dokumentu) — tlumenější, technické odstíny
SEV_RGB = {
    "ok": (0.16, 0.62, 0.42),       # zelená (provoz)
    "alarm": (0.90, 0.70, 0.12),    # žlutá (alarm)
    "warn": (0.84, 0.26, 0.24),     # červená (výstraha)
    "none": (0.66, 0.69, 0.73),     # šedá (neměřeno)
}
SEV_TEXT = {
    "ok": (1, 1, 1),
    "alarm": (0.12, 0.12, 0.12),
    "warn": (1, 1, 1),
    "none": (1, 1, 1),
}
SEV_RANK = {"none": 0, "ok": 1, "alarm": 2, "warn": 3}

MARGIN_L = 56
MARGIN_R = 539          # 595 - 56
PAGE_W = 595.28
PAGE_H = 841.89
CONTENT_W = MARGIN_R - MARGIN_L


# =========================== drobné pomůcky ===========================
def _fmt_num(v, dec=1):
    if v is None:
        return "—"
    try:
        return ("%.*f" % (dec, float(v))).replace(".", ",")
    except (TypeError, ValueError):
        return "—"


def _decode_image(data_url):
    """Z data URL vrátí JPEG bytes nebo None (podporujeme jen JPEG)."""
    if not data_url or "," not in data_url:
        return None
    head, b64 = data_url.split(",", 1)
    if "image/jpeg" not in head and "image/jpg" not in head:
        return None
    try:
        return base64.b64decode(b64)
    except Exception:
        return None


def _clip(pdf, text, max_w, size, bold=False):
    """Zkrátí text s '…', přesáhne-li max_w."""
    if pdf.text_width(text, size, bold=bold) <= max_w:
        return text
    ell = "…"
    out = text
    while out and pdf.text_width(out + ell, size, bold=bold) > max_w:
        out = out[:-1]
    return out + ell


def _band_rgb(band):
    sev = report_mod.band_severity(band)
    return SEV_RGB.get(sev, (1, 1, 1)), SEV_TEXT.get(sev, (0, 0, 0))


def _sev_dot(pdf, cx, cy_top, r, sev):
    """Malé barevné kolečko stavu (semafor v řádku tabulky)."""
    pdf.dot(cx, cy_top, r, SEV_RGB.get(sev, SEV_RGB["none"]))


def _band_chip(pdf, x, y_top, w, h, band, size=7.5, manual=False):
    """Buňka obarvená dle pásma s písmenem pásma uprostřed."""
    if band:
        fill, tcol = _band_rgb(band)
        pdf.rect(x, y_top, w, h, fill=fill)
        pdf.text_centered(x + w / 2.0, y_top + h / 2.0 + size * 0.35,
                          str(band) + ("*" if manual else ""), size,
                          bold=True, color=tcol)


def _section(pdf, x, y, num, title, w):
    """Číslovaný nadpis sekce v technickém stylu: '01  NÁZEV' + linka."""
    pdf.text(x, y, num, 11, bold=True, color=MUTED)
    pdf.text(x + 26, y, title.upper(), 11, bold=True, color=INK)
    pdf.line(x, y + 7, x + w, y + 7, 1.0, RULE)
    return y + 22


# =========================== hlavička / patička ===========================
def _running_header(pdf, doc, page_no):
    """Záhlaví na stranách >1 a společná patička."""
    if page_no > 1:
        title = doc.get("header_left") or "Vibrační diagnostika"
        company = doc.get("company_name") or ""
        pdf.text(MARGIN_L, 38, title.upper(), 7.5, bold=True, color=MUTED)
        if company:
            pdf.text_right(MARGIN_R, 38, company, 7.5, color=MUTED)
        pdf.line(MARGIN_L, 46, MARGIN_R, 46, 0.5, HAIR)
    _footer(pdf, doc, page_no)


def _footer(pdf, doc, page_no):
    foot = _footer_values(doc)
    fy = 806
    pdf.line(MARGIN_L, fy, MARGIN_R, fy, 0.5, HAIR)
    pdf.text(MARGIN_L, fy + 12, foot.get("company", ""),
             7.5, bold=True, color=MUTED)
    pdf.text(MARGIN_L, fy + 22, foot.get("address", ""), 7.5, color=FAINT)
    pdf.text_centered(PAGE_W / 2, fy + 17, foot.get("web", ""),
                      8, bold=True, color=MUTED)
    pdf.text_right(MARGIN_R, fy + 17, "%d" % page_no, 9, bold=True, color=INK)


# =========================== STRANA 1: hlavička + dashboard ===========================
def _counts(machines):
    counts = {"none": 0, "ok": 0, "alarm": 0, "warn": 0}
    for m in machines:
        s = m.get("severity", "none")
        counts[s] = counts.get(s, 0) + 1
    return counts


def _dashboard_page(pdf, doc):
    machines = doc.get("machines", [])
    counts = _counts(machines)
    total = len(machines)
    measured = counts["ok"] + counts["alarm"] + counts["warn"]

    # ----- titulní hlavička: logo HEISTECH vlevo + kicker vpravo -----
    y = 52
    logo = _logo_bytes()
    placed = False
    if logo:
        try:
            lw0, lh0, _ = pdf_writer._jpeg_info(logo)
            lh = 30.0
            lw = lw0 * (lh / lh0)
            pdf.image_jpeg(logo, MARGIN_L, y, lw, lh)
            placed = True
        except Exception:
            placed = False
    if not placed:
        # textová varianta značky (fallback)
        brand = _footer_values(doc).get("brand", "")
        pdf.text(MARGIN_L, y + 16, brand, 20, bold=True, color=INK)
        pdf.text(MARGIN_L, y + 28, "TECHNICKÁ DIAGNOSTIKA A MONITORING", 7,
                 bold=True, color=MUTED)
    pdf.text_right(MARGIN_R, y + 20, "PROTOKOL Z MĚŘENÍ VIBRACÍ", 8.5,
                   bold=True, color=MUTED)
    y += 38
    pdf.line(MARGIN_L, y, MARGIN_R, y, 1.2, RULE)
    # větší mezera mezi hlavičkou a názvem zprávy
    y += 34

    # ----- název zprávy (pod hlavičkou) -----
    pdf.text(MARGIN_L, y, doc.get("report_title", "Zpráva z měření vibrací"),
             17, bold=True, color=INK)
    y += 16

    # ----- pruh metadat: dva řádky po čtyřech polích -----
    def _meta_field(mx, mw, lab, val, sub=None, right=False):
        # right=True: zarovnání k pravému okraji sloupce (poslední sloupec),
        # aby text nepřetékal za okraj stránky
        rx = mx + mw
        if right:
            pdf.text_right(rx, y, lab, 6.5, bold=True, color=FAINT)
            pdf.text_right(rx, y + 12,
                           _clip(pdf, str(val or "—"), mw - 2, 9, bold=True),
                           9, bold=True, color=INK)
            if sub:
                pdf.text_right(rx, y + 22, _clip(pdf, str(sub), mw - 2, 7),
                               7, color=MUTED)
        else:
            pdf.text(mx, y, lab, 6.5, bold=True, color=FAINT)
            pdf.text(mx, y + 12,
                     _clip(pdf, str(val or "—"), mw - 8, 9, bold=True),
                     9, bold=True, color=INK)
            if sub:
                pdf.text(mx, y + 22, _clip(pdf, str(sub), mw - 8, 7), 7,
                         color=MUTED)

    addr = doc.get("company_address") or ""
    place = doc.get("measured_at") or doc.get("measured_place") or ""
    # Měření mohli provést až dva technici – spoj je čárkou na jeden řádek.
    _mb1 = (doc.get("measured_by") or "").split("\n")[0].strip()
    _mb2 = (doc.get("measured_by2") or "").split("\n")[0].strip()
    _mb_parts = [p for p in (_mb1, _mb2) if p]
    measured_by = ", ".join(_mb_parts) if _mb_parts else "—"
    approved_by = (doc.get("approved_by") or "—").split("\n")[0]

    mw = CONTENT_W / 4.0
    # OBA řádky sdílejí STEJNÉ šířky sloupců, aby byla pole zarovnaná pod sebou
    # (MÍSTO MĚŘENÍ pod SCHVÁLIL, ČÍSLO ZAKÁZKY pod TERMÍN MĚŘENÍ atd.).
    # Sloupce 1 a 2 jsou širší (dlouhá jména / názvy), 3 a 4 užší (data).
    # Poslední sloupec je zarovnán vpravo, aby text nepřetékal za okraj.
    # podíly šířky (součet = 4)
    col_units = [1.4, 1.4, 0.6, 0.6]
    # x-pozice začátků sloupců (sdílené oběma řádky)
    col_x = [MARGIN_L]
    for u in col_units:
        col_x.append(col_x[-1] + mw * u)
    n_cols = len(col_units)

    def _meta_row(fields):
        for i, (lab, val, sub) in enumerate(fields):
            cw = mw * col_units[i]
            _meta_field(col_x[i], cw, lab, val, sub, right=(i == n_cols - 1))

    # řádek 1
    _meta_row([
        ("ZÁKAZNÍK", doc.get("company_name") or "—", addr or None),
        ("MÍSTO MĚŘENÍ", place or "—", None),
        ("ČÍSLO ZAKÁZKY", doc.get("order_number") or "—", None),
        ("RÁMCOVÁ SMLOUVA", doc.get("contract_number") or "—", None),
    ])
    y += 34
    # řádek 2 (ROZSAH → VYHOTOVENO)
    _meta_row([
        ("MĚŘENÍ PROVEDL", measured_by, None),
        ("SCHVÁLIL", approved_by, None),
        ("TERMÍN MĚŘENÍ", doc.get("date_measured") or "—", None),
        ("VYHOTOVENO", doc.get("date_created") or "—", None),
    ])
    y += 26
    pdf.line(MARGIN_L, y, MARGIN_R, y, 0.5, HAIR)
    y += 20

    # ----- sekce 01: stavový přehled parku -----
    y = _section(pdf, MARGIN_L, y, "01", "Stavový přehled", CONTENT_W)

    # KPI karty (4) — SJEDNOCENÉ STAVY:
    #   OK (A/B, zelená) / Upozornění (C, žlutá) / Výstraha (D, červená)
    kpis = [
        ("STROJŮ CELKEM", total, None),
        ("OK", counts["ok"], "ok"),
        ("UPOZORNĚNÍ", counts["alarm"], "alarm"),
        ("VÝSTRAHA", counts["warn"], "warn"),
    ]
    gap = 10
    kw = (CONTENT_W - gap * 3) / 4.0
    kh = 58
    for i, (lab, val, sev) in enumerate(kpis):
        kx = MARGIN_L + i * (kw + gap)
        pdf.rect(kx, y, kw, kh, fill=PANEL)
        # barevný proužek vlevo dle stavu
        if sev:
            pdf.rect(kx, y, 4, kh, fill=SEV_RGB[sev])
        pdf.text(kx + 12, y + 38, str(val), 26, bold=True, color=INK)
        pdf.text(kx + 12, y + 51, lab, 7, bold=True, color=MUTED)
    y += kh + 14

    # vodorovný stavový pruh (proporce naměřených strojů)
    if measured > 0:
        pdf.text(MARGIN_L, y, "ROZLOŽENÍ STAVU NAMĚŘENÝCH STROJŮ", 7,
                 bold=True, color=MUTED)
        y += 9
        bar_h = 18
        bx = MARGIN_L
        for sev in ("ok", "alarm", "warn"):
            c = counts[sev]
            if c <= 0:
                continue
            seg_w = CONTENT_W * c / float(measured)
            pdf.rect(bx, y, seg_w, bar_h, fill=SEV_RGB[sev])
            if seg_w > 16:
                pdf.text_centered(bx + seg_w / 2.0, y + 12, str(c), 8.5,
                                  bold=True, color=SEV_TEXT[sev])
            bx += seg_w
        # tenký rámeček kolem baru
        pdf.rect(MARGIN_L, y, CONTENT_W, bar_h, stroke=HAIR, width=0.5)
        # výrazná mezera mezi barem a legendou, aby nesplývaly
        y += bar_h + 20
        # legenda — vlastní řádek, čtverečky + popis s počty
        lx = MARGIN_L
        for sev, lab in (("ok", "OK (A/B)"), ("alarm", "Upozornění (C)"),
                         ("warn", "Výstraha (D)"), ("none", "Neměřeno")):
            pdf.rect(lx, y - 8, 9, 9, fill=SEV_RGB[sev])
            txt = "%s: %d" % (lab, counts[sev])
            pdf.text(lx + 14, y, txt, 8, color=INK)
            lx += 14 + pdf.text_width(txt, 8) + 26
        y += 18
    else:
        pdf.text(MARGIN_L, y, "Zatím nejsou k dispozici žádná měření.", 9,
                 color=MUTED)
        y += 16

    y += 8

    # ----- sekce 02: prioritní akční tabulka (kritické stroje) -----
    critical = [m for m in machines if m.get("severity") in ("warn", "alarm")]
    critical.sort(key=lambda m: SEV_RANK.get(m.get("severity"), 0), reverse=True)

    y = _section(pdf, MARGIN_L, y, "02", "Co je potřeba řešit", CONTENT_W)
    link_rects = []
    if not critical:
        pdf.rect(MARGIN_L, y, CONTENT_W, 30, fill=PANEL)
        pdf.dot(MARGIN_L + 16, y + 15, 5, SEV_RGB["ok"])
        pdf.text(MARGIN_L + 30, y + 19,
                 "Žádný stroj nevyžaduje okamžitou pozornost. "
                 "Všechny naměřené stroje jsou v přijatelném stavu.",
                 9.5, color=INK)
        y += 40
    else:
        y, link_rects = _action_table(pdf, MARGIN_L, y, critical, CONTENT_W)

    _running_header(pdf, doc, 1)
    # link_rects nesou souřadnice řádků na straně 1 (index 0) – render()
    # je prováže s odpovídajícími detailními stranami strojů.
    return link_rects


def _action_table(pdf, x0, y, machines, w):
    """Prioritní tabulka: stav (puntík) | stroj | doporučená akce.

    Pásmo se v této sekci nezobrazuje – stav stroje reprezentuje pouze
    barevný puntík (OK / Upozornění / Výstraha).

    Vrací (y, link_rects), kde link_rects je seznam
    {machine_id, x, y_top, w, h} pro klikací řádky (odkaz na detail stroje).
    """
    link_rects = []
    # rozvržení sloupců (bez sloupce PÁSMO)
    c_dot = x0 + 4
    c_name = x0 + 22
    w_name = w * 0.34
    c_act = c_name + w_name + 12
    x_end = x0 + w

    # hlavička
    pdf.text(c_name, y, "STROJ", 7, bold=True, color=MUTED)
    pdf.text(c_act, y, "DOPORUČENÁ AKCE", 7, bold=True, color=MUTED)
    y += 5
    pdf.line(x0, y, x_end, y, 0.8, RULE)

    for idx, m in enumerate(machines):
        sev = m.get("severity", "none")
        rec = (m.get("doporuceni") or "").strip() or \
            (m.get("problem") or "").strip() or "Doporučujeme detailní kontrolu stroje."
        # výška řádku dle zalomení akce
        act_w = x_end - c_act - 4
        lines = pdf.wrap_text(rec, 8.5, act_w)
        lines = lines[:3]
        rh = max(24, 10 + len(lines) * 11)
        if idx % 2 == 1:
            pdf.rect(x0, y, w, rh, fill=ZEBRA)
        # klikací oblast celého řádku (provázání na detail stroje)
        link_rects.append({
            "machine_id": m.get("machine_id"),
            "x": x0, "y_top": y, "w": w, "h": rh,
        })
        # stav kolečko
        _sev_dot(pdf, c_dot + 5, y + 11, 4.5, sev)
        # název + případně lokace
        pdf.text(c_name, y + 12, _clip(pdf, m.get("name", ""), w_name - 6, 9.5,
                 bold=True), 9.5, bold=True, color=INK)
        loc = (m.get("card", {}) or {}).get("tech_location") or m.get("parent_name") or ""
        if loc:
            pdf.text(c_name, y + 22, _clip(pdf, str(loc), w_name - 6, 7), 7,
                     color=MUTED)
        # doporučená akce (víceřádkově)
        ty = y + 12
        for ln in lines:
            pdf.text(c_act, ty, ln, 8.5, color=INK)
            ty += 11
        y += rh
        pdf.line(x0, y, x_end, y, 0.4, HAIR)
    return y + 6, link_rects


# =========================== STRANA 2: úvod + přehled strojů ===========================
def _summary_page(pdf, doc, version):
    """Strana 2: úvod (metodika) + sekce 04.

    Obsah sekce 04 se LIŠÍ dle verze protokolu:
      * VERZE 1: "Přehled všech strojů" — stav | stroj | pásmo | měřeno |
        doporučení/poznámka (jeden řádek na stroj, beze změny oproti dřívějšímu
        chování).
      * VERZE 2: "Závěry a doporučení" — stav | stroj | pásmo, bez sloupce s
        datem měření, s PLNÝM textem závěru i doporučení pro každý stroj. Tato
        sekce může přetéct na další stranu (plynule, bez nuceného zalomení na
        stroj), proto vrací aktuální číslo strany.

    Vrací číslo poslední použité strany (2, nebo více u verze 2 při přetoku).
    """
    machines = doc.get("machines", [])
    y = 64
    y = _section(pdf, MARGIN_L, y, "03", "Metodika měření", CONTENT_W)
    intro = doc.get("intro", "") or ""
    for para in intro.split("\n\n"):
        if para.strip():
            y = pdf.text_block(MARGIN_L, y, para.strip(), 9, CONTENT_W,
                               leading=13, justify=True) + 8
    y += 4

    if version in (2, 3):
        return _conclusions_section(pdf, doc, machines, y, page_no=2)

    y = _section(pdf, MARGIN_L, y, "04", "Přehled všech strojů", CONTENT_W)
    _full_summary_table(pdf, MARGIN_L, y, machines, CONTENT_W)
    _running_header(pdf, doc, 2)
    return 2


def _full_summary_table(pdf, x0, y, machines, w):
    """Kompletní tabulka všech strojů: stav (puntík) | stroj | měřeno | doporučení.

    Pásmo se v této sekci nezobrazuje – stav stroje reprezentuje pouze
    barevný puntík (OK / Upozornění / Výstraha).
    Použito pouze pro VERZI 1 protokolu (viz `_conclusions_section` pro V2).
    """
    # seřaď dle závažnosti (nejhorší nahoru), pak dle jména
    ms = sorted(machines, key=lambda m: (-SEV_RANK.get(m.get("severity"), 0),
                                         m.get("name") or ""))
    c_dot = x0 + 4
    c_name = x0 + 22
    w_name = w * 0.32
    c_date = c_name + w_name + 8
    w_date = 64
    c_rec = c_date + w_date + 8
    x_end = x0 + w

    pdf.text(c_name, y, "STROJ", 7, bold=True, color=MUTED)
    pdf.text(c_date, y, "MĚŘENO", 7, bold=True, color=MUTED)
    pdf.text(c_rec, y, "DOPORUČENÍ / POZNÁMKA", 7, bold=True, color=MUTED)
    y += 5
    pdf.line(x0, y, x_end, y, 0.8, RULE)

    for idx, m in enumerate(ms):
        sev = m.get("severity", "none")
        rec = (m.get("doporuceni") or "").strip() or \
            (m.get("problem") or "").strip()
        if not rec:
            rec = "V pořádku — bez nutnosti zásahu." if sev == "ok" else (
                "Neměřeno." if sev == "none" else "—")
        rec_w = x_end - c_rec - 4
        lines = pdf.wrap_text(rec, 8, rec_w)[:2]
        rh = max(20, 8 + len(lines) * 10)
        if idx % 2 == 1:
            pdf.rect(x0, y, w, rh, fill=ZEBRA)
        _sev_dot(pdf, c_dot + 5, y + 10, 4, sev)
        pdf.text(c_name, y + 11, _clip(pdf, m.get("name", ""), w_name - 6, 9,
                 bold=True), 9, bold=True, color=INK)
        pdf.text(c_date, y + 11, m.get("last_measured") or "—", 7.5, color=MUTED)
        ty = y + 11
        for ln in lines:
            pdf.text(c_rec, ty, ln, 8, color=INK)
            ty += 10
        y += rh
        pdf.line(x0, y, x_end, y, 0.4, HAIR)
    return y + 6


def _conclusion_block_height(pdf, m, w_text):
    """Odhadne výšku (v bodech) jednoho řádku závěrů/doporučení pro stroj m."""
    zaver = (m.get("zaver") or "").strip()
    dop = (m.get("doporuceni") or "").strip()
    if not zaver and not dop:
        sev = m.get("severity", "none")
        dop = "V pořádku — bez nutnosti zásahu." if sev == "ok" else (
            "Neměřeno." if sev == "none" else "—")
    head_h = 16
    body_h = 0
    if zaver:
        body_h += 10 + pdf.paragraph_block_height(zaver, 8.5, w_text, leading=10.5)
    if dop:
        body_h += 10 + pdf.paragraph_block_height(dop, 8.5, w_text, leading=10.5)
    return head_h + body_h + 12


def _conclusions_section(pdf, doc, machines, y, page_no):
    """Sekce 04 "Závěry a doporučení" pro verzi 2: stav | stroj | pásmo v
    hlavičce každého stroje, následované PLNÝM textem závěru a doporučení.
    Bez sloupce s datem měření. Řádky strojů plynou za sebou, stránka se
    zalomí jen když se blok dalšího stroje už nevejde. Vrací poslední page_no.
    """
    BOTTOM = 778
    x0 = MARGIN_L
    w = CONTENT_W
    x_end = x0 + w
    c_dot = x0 + 4
    c_name = x0 + 22
    w_name = w * 0.5
    c_band = x0 + 22 + w_name
    w_band = 40
    text_x = x0
    text_w = w

    y = _section(pdf, x0, y, "04", "Závěry a doporučení", w)
    intro = (
        "Následující přehled uvádí pro každý stroj v okruhu jeho aktuální stav, "
        "nejhorší pásmo a stručný závěr s doporučením dalšího postupu."
    )
    y = pdf.text_block(x0, y, intro, 9, w, leading=13, justify=True) + 12

    ms = sorted(machines, key=lambda m: (-SEV_RANK.get(m.get("severity"), 0),
                                         m.get("name") or ""))

    first_on_page = True
    for m in ms:
        need_h = _conclusion_block_height(pdf, m, text_w)
        if not first_on_page and y + need_h > BOTTOM:
            _running_header(pdf, doc, page_no)
            pdf.new_page()
            page_no += 1
            y = 64
            first_on_page = True

        sev = m.get("severity", "none")
        _sev_dot(pdf, c_dot + 5, y + 6, 4, sev)
        pdf.text(c_name, y + 7, _clip(pdf, m.get("name", ""), w_name - 6, 10,
                 bold=True), 10, bold=True, color=INK)
        if m.get("worst_band"):
            _band_chip(pdf, c_band, y - 1, w_band, 14, m.get("worst_band"), size=8)
        else:
            pdf.text_centered(c_band + w_band / 2.0, y + 7, "—", 8, color=FAINT)
        y += 18
        pdf.line(x0, y, x_end, y, 0.4, HAIR)
        y += 8

        zaver = (m.get("zaver") or "").strip()
        dop = (m.get("doporuceni") or "").strip()
        if not zaver and not dop:
            dop = "V pořádku — bez nutnosti zásahu." if sev == "ok" else (
                "Neměřeno." if sev == "none" else "—")

        if zaver:
            pdf.text(text_x, y, "ZÁVĚR", 6.5, bold=True, color=FAINT)
            y += 10
            y = pdf.paragraph_block(text_x, y, zaver, 8.5, text_w, leading=10.5,
                                    color=INK, justify=True) + 8
        if dop:
            pdf.text(text_x, y, "DOPORUČENÍ", 6.5, bold=True, color=FAINT)
            y += 10
            y = pdf.paragraph_block(text_x, y, dop, 8.5, text_w, leading=10.5,
                                    color=INK, justify=True) + 8

        y += 6
        first_on_page = False

    _running_header(pdf, doc, page_no)
    return page_no


# =========================== DETAILNÍ STRANA STROJE ===========================
def _machine_page(pdf, doc, m, page_no, detailed=False):
    """Detailní strana stroje — použito pouze pro VERZI 1 protokolu.

    Jedna celá strana na stroj (jen pro stroje Alarm/Výstraha): sjednocená
    tabulka s max. hodnotou rychlosti přes směry, obrázek stroje (je-li),
    závěr/doporučení a grafy pod tím.

    Pozn.: verze 2 používá místo této funkce `_technical_assessment_block`
    (plynulé řazení strojových tabulek bez obrázku) a grafy vykresluje až v
    příloze pomocí `_graphs_appendix`.
    """
    sev = m.get("severity", "none")
    y = 60

    # ---- záhlaví stroje: barevný proužek + název + stav ----
    pdf.rect(MARGIN_L, y, 5, 30, fill=SEV_RGB[sev])
    pdf.text(MARGIN_L + 14, y + 14, _clip(pdf, m.get("name", ""), 340, 15,
             bold=True), 15, bold=True, color=INK)
    loc = (m.get("card", {}) or {}).get("tech_location") or m.get("parent_name") or ""
    if loc:
        pdf.text(MARGIN_L + 14, y + 27, str(loc), 8.5, color=MUTED)
    # stavový štítek vpravo
    lbl = (m.get("severity_label") or "").upper()
    if lbl:
        lw = pdf.text_width(lbl, 9, bold=True) + 20
        pdf.rect(MARGIN_R - lw, y + 4, lw, 20, fill=SEV_RGB[sev])
        pdf.text_centered(MARGIN_R - lw / 2.0, y + 18, lbl, 9, bold=True,
                          color=SEV_TEXT[sev])
    y += 42

    # ---- info pruh (parametry stroje na jednom řádku/dvou) ----
    card = m.get("card", {}) or {}
    params = []
    if card.get("drive_no"):
        params.append(("Č. pohonu", card["drive_no"]))
    if card.get("power_kw"):
        pw = str(card["power_kw"])
        params.append(("Výkon", pw + ("" if pw.lower().endswith("kw") else " kW")))
    rpm = card.get("rpm") or _rpm_from_speed(m.get("speed_hz"))
    if rpm:
        params.append(("Otáčky", str(rpm) + " rpm"))
    if card.get("impeller_diameter"):
        params.append(("Ø oběž. kola", str(card["impeller_diameter"])))
    params.append(("Norma", report_mod.norm_label(m.get("iso_norm"))))
    params.append(("Měřeno", m.get("last_measured") or "—"))

    pdf.rect(MARGIN_L, y, CONTENT_W, 30, fill=PANEL)
    pw_each = CONTENT_W / float(max(1, len(params)))
    for i, (lab, val) in enumerate(params):
        px = MARGIN_L + 8 + i * pw_each
        pdf.text(px, y + 12, lab.upper(), 6.5, bold=True, color=FAINT)
        pdf.text(px, y + 24, _clip(pdf, str(val), pw_each - 12, 8.5, bold=True),
                 8.5, bold=True, color=INK)
    y += 42

    # ---- dva sloupce: vlevo tabulky, vpravo obrázek (pokud je) ----
    jpeg = _decode_image(card.get("image"))
    has_img = jpeg is not None
    left_w = CONTENT_W * (0.66 if has_img else 1.0)

    # verze 1 i verze 2: stejná sjednocená tabulka celkových hodnot (jako
    # v ukázkovém protokolu); verze 2 (detailed=True) navíc přidá sloupec
    # s předchozí hodnotou rychlosti vibrací.
    ty = _overall_table(pdf, MARGIN_L, y, m, left_w,
                        with_prev=bool(doc.get("show_previous", detailed)))

    # obrázek stroje vpravo (pokud je) — sledujeme jeho dolní okraj, aby na
    # něj následný text (ZÁVĚR / DOPORUČENÍ) nenavázal a nepřekrýval se s ním.
    img_bottom = y
    if has_img:
        ix = MARGIN_L + left_w + 16
        iw = MARGIN_R - ix
        try:
            w0, h0, _ = pdf_writer._jpeg_info(jpeg)
            scale = min(iw / w0, 150.0 / h0)
            dw, dh = w0 * scale, h0 * scale
            pdf.text(ix, y, "STROJ", 6.5, bold=True, color=FAINT)
            pdf.image_jpeg(jpeg, ix, y + 6, dw, dh)
            img_bottom = y + 6 + dh
        except Exception:
            pass

    # text začíná až pod tabulkou I pod obrázkem (co je níž)
    y = max(ty, img_bottom) + 8

    # ---- závěr (na šířku tabulky) + doporučení (na celou šířku stranky pod ním) ----
    pdf.line(MARGIN_L, y, MARGIN_R, y, 0.6, HAIR)
    y += 14
    # ZÁVĚR — šířka jako tabulka (left_w). Bez číslování: odstavce (Enter =
    # nový odstavec oddělený malou mezerou).
    pdf.text(MARGIN_L, y, "ZÁVĚR", 8, bold=True, color=MUTED)
    y += 13
    y = pdf.paragraph_block(MARGIN_L, y, m.get("zaver") or "—", 9, left_w,
                            leading=12.5, justify=True)
    y += 12
    # DOPORUČENÍ — na celou šířku stranky, pod závěrem
    pdf.text(MARGIN_L, y, "DOPORUČENÍ", 8, bold=True, color=MUTED)
    y += 13
    y = pdf.paragraph_block(MARGIN_L, y, m.get("doporuceni") or "Bez doporučení", 9,
                            CONTENT_W, leading=12.5, justify=True)
    y += 14

    _running_header(pdf, doc, page_no)

    # ---- grafy (trendy / FFT) ----
    graphs = m.get("graphs", []) or []
    if not graphs:
        return page_no

    GRAPH_H = 168
    GAP = 18
    half_w = (CONTENT_W - GAP) / 2.0
    BOTTOM = 778

    if y > BOTTOM - GRAPH_H - 24:
        pdf.new_page()
        page_no += 1
        y = 70
        _running_header(pdf, doc, page_no)
    pdf.text(MARGIN_L, y, "MĚŘENÉ GRAFY — TRENDY A FFT SPEKTRA", 9,
             bold=True, color=MUTED)
    pdf.line(MARGIN_L, y + 7, MARGIN_R, y + 7, 0.8, RULE)
    y += 20

    col = 0
    row_start = 0
    for gi, g in enumerate(graphs):
        if col == 0:
            row_start = gi
            row_note_h = _graph_row_note_height(pdf, graphs[gi:gi + 2], half_w)
            if y + GRAPH_H + row_note_h > BOTTOM:
                pdf.new_page()
                page_no += 1
                y = 70
                _running_header(pdf, doc, page_no)
        gx = MARGIN_L + col * (half_w + GAP)
        _draw_graph(pdf, g, gx, y, half_w, GRAPH_H)
        col += 1
        if col >= 2:
            col = 0
            row_note_h = _graph_row_note_height(
                pdf, graphs[row_start:row_start + 2], half_w)
            y += GRAPH_H + row_note_h + GAP
    if col != 0:
        row_note_h = _graph_row_note_height(
            pdf, graphs[row_start:row_start + 1], half_w)
        y += GRAPH_H + row_note_h + GAP
    return page_no


def _rpm_from_speed(speed_hz):
    if not speed_hz:
        return None
    try:
        return int(round(float(speed_hz) * 60))
    except (TypeError, ValueError):
        return None


# =========================== tabulky stroje ===========================
def _table_header(pdf, x0, y, cols, xs, title, total_w):
    """Společné záhlaví tabulky: titulek + hlavičkový řádek. Vrací y dat."""
    pdf.text(x0, y, title, 8, bold=True, color=MUTED)
    y += 6
    hy = y + 9
    for i, (label, _f, align) in enumerate(cols):
        if align == "r":
            pdf.text_right(xs[i + 1] - 4, hy, label, 7, bold=True, color=FAINT)
        elif align == "c":
            pdf.text_centered((xs[i] + xs[i + 1]) / 2.0, hy, label, 7, bold=True, color=FAINT)
        else:
            pdf.text(xs[i] + 3, hy, label, 7, bold=True, color=FAINT)
    hy += 4
    pdf.line(x0, hy, x0 + total_w, hy, 0.8, RULE)
    return hy


def _vel_max_by_place(rows):
    """Vrátí řádek rychlosti pro každé měřicí místo.

    Aktuální protokol sestavuje `report.build_machine_report` výhradně ze
    směru H, takže nejde o maximum přes H/V/A. Zachované seskupení chrání
    export i při načtení staršího návrhu, který by obsahoval duplicitní řádky.
    """
    best = {}
    order = []
    for r in rows or []:
        p = r.get("place") or ""
        cur = r.get("vel_cur")
        cur = float("-inf") if cur is None else cur
        if p not in best:
            best[p] = r
            order.append(p)
        else:
            bc = best[p].get("vel_cur")
            bc = float("-inf") if bc is None else bc
            if cur > bc:
                best[p] = r
    return [best[p] for p in order]


def _overall_table(pdf, x0, y, m, table_w, with_prev=False, balance=False):
    """Sjednocená tabulka celkových hodnot — jeden řádek na ložisko (místo):
    hodnoty vybraných veličin v horizontálním směru H + stav ložiska.

    Zrcadlí editor (renderOverallTable). Pásmo (barevný chip) zobrazujeme
    pouze u rychlosti a u stavu ložiska — ne u zrychlení a obálky.

    `with_prev=True` (verze 2 protokolu) přidá sloupec s předchozí naměřenou
    hodnotou rychlosti H pro přímé
    porovnání vývoje.

    `balance=True` (verze 3 — vyvažování) rozdělí rychlost do dvou sloupců
    (před / po) s vlastními pásmy A–D a přidá sloupec úspěšnosti vyvážení
    v procentech.
    """
    rows = m.get("rows", []) or []
    brg = m.get("bearings_summary", []) or []
    vel_max = _vel_max_by_place(rows)
    if not vel_max and not brg:
        return y
    vel_by_place = {}
    for r in vel_max:
        vel_by_place[r.get("place") or ""] = r
    brg_by_place = {}
    for b in brg:
        brg_by_place[b.get("place") or ""] = b
    # pořadí míst: primárně dle ložisek, doplněné o místa jen s rychlostí
    places = []
    seen = set()
    for b in brg:
        p = b.get("place") or ""
        if p not in seen:
            seen.add(p)
            places.append(p)
    for r in vel_max:
        p = r.get("place") or ""
        if p not in seen:
            seen.add(p)
            places.append(p)

    # Pásmo je samostatná klasifikace rychlosti. Poslední sloupec je stav
    # ložiska z efektivních pásem zrychlení a obálky, bez rychlosti.
    if balance:
        cols = [("Ložisko", .14, "l"), ("porovnání", .09, "r"), ("p.", .06, "c"),
                ("aktuální", .09, "r"), ("Pásmo", .07, "c"), ("úsp. [%]", .09, "r"),
                ("zrychlení H", .13, "r"), ("obálka H", .13, "r"),
                ("Stav ložiska", .20, "c")]
    elif with_prev:
        cols = [("Ložisko", .15, "l"), ("porovnání max.", .12, "r"),
                ("rychlost max.", .14, "r"), ("Pásmo", .09, "c"),
                ("zrychlení H", .14, "r"), ("obálka H", .14, "r"),
                ("Stav ložiska", .22, "c")]
    else:
        cols = [("Ložisko", .18, "l"), ("rychlost max.", .16, "r"), ("Pásmo", .10, "c"),
                ("zrychlení H", .16, "r"), ("obálka H", .16, "r"),
                ("Stav ložiska", .24, "c")]
    xs = [x0]
    for _, frac, _a in cols:
        xs.append(xs[-1] + table_w * frac)
    if balance:
        title = ("RYCHLOST MAX. H/V/A — POROVNÁNÍ / AKTUÁLNÍ [mm/s], "
                 "LOŽISKA Z H [g]")
    else:
        title = "CELKOVÉ HODNOTY: RYCHLOST MAX. H/V/A, LOŽISKO Z H [mm/s, g]"
    hy = _table_header(pdf, x0, y, cols, xs, title, table_w)
    # Export nezobrazuje editor, ale musí vysvětlit tutéž kanonickou
    # per-direction semantiku jako UI.
    pdf.text(
        x0, hy + 7,
        "Rychlost = max. vybraných H/V/A, (H/V/A) = vítězný směr; zrychlení a obálka pouze z H.",
        6.2, color=MUTED,
    )
    hy += 10
    row_h = 16
    ry = hy
    for idx, p in enumerate(places):
        v = vel_by_place.get(p, {})
        b = brg_by_place.get(p, {})
        if idx % 2 == 1:
            pdf.rect(x0, ry, table_w, row_h, fill=ZEBRA)
        vel_cur = v.get("vel_cur")
        vdir = v.get("direction")
        vel_txt = "—"
        if vel_cur is not None:
            vel_txt = _fmt_num(vel_cur, 2)
            if vdir:
                vel_txt += " (" + str(vdir) + ")"
        cells = [("lb", p, None)]
        if balance:
            # před: hodnota + pásmo předchozího měření
            vel_prev = v.get("vel_prev")
            vel_prev_band = v.get("vel_prev_band")
            prev_txt = _fmt_num(vel_prev, 2) if vel_prev is not None else "—"
            if vel_prev is not None and v.get("vel_prev_dir"):
                prev_txt += " (" + str(v.get("vel_prev_dir")) + ")"
            cells.append(("r", prev_txt, None))
            cells.append(("band", None, vel_prev_band))
            # po: aktuální hodnota + pásmo
            cells.append(("r", vel_txt, None))
            cells.append(("band", None, v.get("vel_band"), bool(v.get("vel_band_override"))))
            # úspěšnost vyvážení v %
            pct = v.get("balance_success_pct")
            pct_txt = ("{:+.0f} %".format(pct)
                       if isinstance(pct, (int, float)) else "—")
            cells.append(("r", pct_txt, None))
            # ložiska
            cells += [
                ("r", _fmt_num(b.get("acc_cur"), 2) + (" (" + str(b.get("acc_dir")) + ")" if b.get("acc_cur") is not None and b.get("acc_dir") else "") if b.get("acc_cur") is not None else "—", None),
                ("r", _fmt_num(b.get("env_cur"), 2) + (" (" + str(b.get("env_dir")) + ")" if b.get("env_cur") is not None and b.get("env_dir") else "") if b.get("env_cur") is not None else "—", None),
                ("band", None, b.get("bearing_state"),
                 bool(b.get("acc_band_override") or b.get("env_band_override"))),
            ]
        else:
            if with_prev:
                vel_prev = v.get("vel_prev")
                prev_txt = _fmt_num(vel_prev, 2) if vel_prev is not None else "—"
                if vel_prev is not None and v.get("vel_prev_dir"):
                    prev_txt += " (" + str(v.get("vel_prev_dir")) + ")"
                cells.append(("r", prev_txt, None))
            cells += [
                ("r", vel_txt, None),
                ("band", None, v.get("vel_band"), bool(v.get("vel_band_override"))),
                ("r", _fmt_num(b.get("acc_cur"), 2) + (" (" + str(b.get("acc_dir")) + ")" if b.get("acc_cur") is not None and b.get("acc_dir") else "") if b.get("acc_cur") is not None else "—", None),
                ("r", _fmt_num(b.get("env_cur"), 2) + (" (" + str(b.get("env_dir")) + ")" if b.get("env_cur") is not None and b.get("env_dir") else "") if b.get("env_cur") is not None else "—", None),
                ("band", None, b.get("bearing_state"),
                 bool(b.get("acc_band_override") or b.get("env_band_override"))),
            ]
        for i, entry in enumerate(cells):
            kind, val, band = entry[:3]
            manual = len(entry) > 3 and entry[3]
            cw = xs[i + 1] - xs[i]
            if kind == "band":
                if band:
                    _band_chip(pdf, xs[i] + 2, ry + 2, cw - 4, row_h - 4,
                               band, size=8, manual=manual)
            elif kind == "r":
                pdf.text_right(xs[i + 1] - 4, ry + 11, str(val), 8.5, color=INK)
            elif kind == "lb":
                pdf.text(xs[i] + 3, ry + 11, str(val), 8.5, bold=True, color=INK)
            else:
                pdf.text(xs[i] + 3, ry + 11, str(val), 8.5, color=INK)
        ry += row_h
    pdf.line(x0, ry, x0 + table_w, ry, 0.8, RULE)
    has_manual = (
        any(r.get("vel_band_override") for r in rows)
        or any(b.get("acc_band_override") or b.get("env_band_override") for b in brg)
    )
    if has_manual:
        pdf.text(x0, ry + 8, "* pásmo označené hvězdičkou bylo pro tento protokol určeno ručně.", 6.5, color=MUTED)
        return ry + 18
    return ry + 10


# Pozn.: dřívější samostatné funkce _velocity_table/_bearing_table (oddělená
# tabulka rychlosti po směrech + samostatná tabulka ložisek) byly nahrazeny
# jedinou sjednocenou tabulkou _overall_table(with_prev=True), aby verze 2
# vypadala stejně jako ukázkový protokol (jedna tabulka na stroj), jen s
# navíc přidaným sloupcem předchozí hodnoty rychlosti.


# ================ VERZE 2: sekce "Hodnocení technického stavu" ================
def _assessment_table_height(m):
    """Odhadne výšku (v bodech) tabulky jednoho stroje včetně záhlaví stroje,
    aby šlo předem rozhodnout o zalomení stránky před jejím vykreslením.
    """
    rows = m.get("rows", []) or []
    brg = m.get("bearings_summary", []) or []
    vel_max = _vel_max_by_place(rows)
    places = set()
    for b in brg:
        places.add(b.get("place") or "")
    for r in vel_max:
        places.add(r.get("place") or "")
    n = len(places)
    header_h = 28   # název stroje + otáčky
    table_head_h = 19 if n else 0
    rows_h = n * 16
    footer_h = 10 if n else 0
    gap_h = 14      # mezera pod tabulkou před dalším strojem
    return header_h + table_head_h + rows_h + footer_h + gap_h


def _assessment_machine_block(pdf, x0, y, m, balance=False, show_previous=True):
    """Vykreslí kompaktní blok jednoho stroje pro sekci "Hodnocení technického
    stavu" (verze 2 / 3): název stroje + otáčky/místo na jednom řádku, pak
    sjednocená tabulka celkových hodnot. Verze 3 (`balance=True`) vykreslí
    tabulku s hodnotami PŘED / PO vyvážení a % úspěšností.
    BEZ obrázku stroje. Vrací y pod blokem (včetně mezery před dalším strojem).
    """
    sev = m.get("severity", "none")
    pdf.rect(x0, y, 4, 18, fill=SEV_RGB[sev])
    pdf.text(x0 + 12, y + 13, _clip(pdf, m.get("name", ""), CONTENT_W * 0.6,
             11, bold=True), 11, bold=True, color=INK)
    rpm = (m.get("card", {}) or {}).get("rpm") or _rpm_from_speed(m.get("speed_hz"))
    bits = []
    if rpm:
        bits.append(str(rpm) + " min\u207b\u00b9")
    # Záhlaví tabulek v sekci "Hodnocení technického stavu" záměrně
    # NEUVÁDÍ název zákazníka (dříve tech_location / parent_name).
    # norma, dle které je stroj hodnocen — jen samotný název skutečně zadané
    # normy (např. "ČSN 20 0065") bez třídy stroje či dalšího komentáře.
    if not balance:
        bits.append(report_mod.norm_label(m.get("iso_norm"), name_only=True))
    if m.get("last_measured"):
        bits.append("m\u011b\u0159eno " + str(m["last_measured"]))
    if bits:
        pdf.text_right(MARGIN_R, y + 13, " \u00b7 ".join(bits), 8, color=MUTED)
    y += 26
    if balance and show_previous:
        y = _overall_table(pdf, x0, y, m, CONTENT_W, balance=True)
    else:
        y = _overall_table(pdf, x0, y, m, CONTENT_W, with_prev=show_previous)
    return y + 4


def _technical_assessment_section(pdf, doc, machines, page_no, balance=False,
                                  show_previous=True):
    """Sekce "Hodnocení technického stavu" (verze 2) resp. "Zhodnocení
    vyvažování" (verze 3): všechny stroje, kompaktní tabulky řazené PLYNULE
    ZA SEBOU, bez obrázku stroje. Nová stránka se přidá jen když se tabulka
    daného stroje již nevejde na aktuální stránku. Vrací
    (poslední_page_no, mapa machine_id -> page_index) pro vnitřní odkazy.
    """
    BOTTOM = 778
    y = 64
    if balance:
        y = _section(pdf, MARGIN_L, y, "05",
                     "Zhodnocen\u00ed vyva\u017eov\u00e1n\u00ed", CONTENT_W)
        intro = (
            "N\u00e1sleduj\u00edc\u00ed tabulky uv\u00e1d\u011bj\u00ed pro ka\u017ed\u00fd "
            "vyva\u017eovan\u00fd stroj nam\u011b\u0159en\u00e9 hodnoty rychlosti vibrac\u00ed "
            "P\u0158ED a PO vyv\u00e1\u017een\u00ed spolu s p\u0159\u00edslu\u0161n\u00fdmi p\u00e1smy "
            "A\u2013D, procentu\u00e1ln\u00ed \u00fasp\u011b\u0161nost\u00ed vyv\u00e1\u017een\u00ed a stavem "
            "valiv\u00fdch lo\u017eisek."
        )
    else:
        y = _section(pdf, MARGIN_L, y, "05",
                     "Hodnocen\u00ed technick\u00e9ho stavu", CONTENT_W)
        intro = (
            "N\u00e1sleduj\u00edc\u00ed tabulky uv\u00e1d\u011bj\u00ed pro ka\u017ed\u00fd stroj nejvy\u0161\u0161\u00ed nam\u011b\u0159enou "
            "rychlost vibrac\u00ed (RMS) v jednotliv\u00fdch m\u011b\u0159ic\u00edch m\u00edstech spolu s "
            "p\u0159edchoz\u00ed hodnotou pro porovn\u00e1n\u00ed v\u00fdvoje a stavem valiv\u00fdch lo\u017eisek."
        )
    y = pdf.text_block(MARGIN_L, y, intro, 9, CONTENT_W, leading=13, justify=True) + 12

    page_index_by_id = {}
    first_on_page = True
    for m in machines:
        need_h = _assessment_table_height(m)
        if not first_on_page and y + need_h > BOTTOM:
            _running_header(pdf, doc, page_no)
            pdf.new_page()
            page_no += 1
            y = 64
            first_on_page = True
        page_index_by_id[m.get("machine_id")] = pdf.current_page_index()
        y = _assessment_machine_block(pdf, MARGIN_L, y, m, balance=balance,
                                      show_previous=show_previous)
        first_on_page = False
    _running_header(pdf, doc, page_no)
    return page_no, page_index_by_id


def _graphs_appendix(pdf, doc, machines, page_no):
    """P\u0159\u00edloha \u2014 grafy: trendy a FFT spektra (verze 2 / 3). Grafy jsou zde
    seskupen\u00e9 po strojích, oddělen\u011b od tabulek v sekci "Hodnocen\u00ed
    technick\u00e9ho stavu", stejn\u011b jako v uk\u00e1zkov\u00e9m protokolu (P\u0159\u00edloha 1:
    frekven\u010dn\u00ed anal\u00fdza \u2014 spektra FFT vibra\u010dn\u00edch sign\u00e1l\u016f).

    Verze 3 (vyva\u017eov\u00e1n\u00ed) nav\u00edc na konec p\u0159\u00edlohy p\u0159id\u00e1 extern\u00ed obr\u00e1zek
    (typicky graf polar\u00edch vektor\u016f z měřicího přístroje), pokud je v dokumentu
    ulo\u017een pod kl\u00ed\u010dem ``appendix_image`` jako JPEG data URL.
    """
    with_graphs = [m for m in machines if m.get("graphs")]
    appendix_img_jpeg = _decode_image(doc.get("appendix_image"))
    if not with_graphs and appendix_img_jpeg is None:
        return page_no

    BOTTOM = 778
    GRAPH_H = 168
    GAP = 18
    half_w = (CONTENT_W - GAP) / 2.0

    pdf.new_page()
    page_no += 1
    y = 64
    y = _section(pdf, MARGIN_L, y, "", "P\u0159\u00edloha \u2014 grafy: trendy a FFT spektra",
                 CONTENT_W)
    intro = (
        "Vybran\u00e9 vektorov\u00e9 grafy (trendy nam\u011b\u0159en\u00fdch hodnot a frekven\u010dn\u00ed "
        "spektra FFT) pro stroje, u kter\u00fdch byly grafy k dispozici."
    )
    y = pdf.text_block(MARGIN_L, y, intro, 9, CONTENT_W, leading=13, justify=True) + 10

    for m in with_graphs:
        graphs = m.get("graphs") or []
        if not graphs:
            continue
        if y > BOTTOM - 20:
            _running_header(pdf, doc, page_no)
            pdf.new_page()
            page_no += 1
            y = 64
        pdf.text(MARGIN_L, y, m.get("name", "").upper(), 9.5, bold=True, color=INK)
        pdf.line(MARGIN_L, y + 6, MARGIN_R, y + 6, 0.6, HAIR)
        y += 18
        col = 0
        row_start = 0
        for gi, g in enumerate(graphs):
            if col == 0:
                row_start = gi
                row_note_h = _graph_row_note_height(
                    pdf, graphs[gi:gi + 2], half_w)
                if y + GRAPH_H + row_note_h > BOTTOM:
                    _running_header(pdf, doc, page_no)
                    pdf.new_page()
                    page_no += 1
                    y = 64
            gx = MARGIN_L + col * (half_w + GAP)
            _draw_graph(pdf, g, gx, y, half_w, GRAPH_H)
            col += 1
            if col >= 2:
                col = 0
                row_note_h = _graph_row_note_height(
                    pdf, graphs[row_start:row_start + 2], half_w)
                y += GRAPH_H + row_note_h + GAP
        if col != 0:
            row_note_h = _graph_row_note_height(
                pdf, graphs[row_start:row_start + 1], half_w)
            y += GRAPH_H + row_note_h + GAP
        y += 6

    # externí obrázek (jen verze 3) — typicky graf polarích vektorů
    if appendix_img_jpeg is not None:
        try:
            w0, h0, _ = pdf_writer._jpeg_info(appendix_img_jpeg)
        except Exception:
            w0, h0 = 0, 0
        if w0 > 0 and h0 > 0:
            MAX_H = 420.0
            scale = min(CONTENT_W / w0, MAX_H / h0)
            dw, dh = w0 * scale, h0 * scale
            caption = (doc.get("appendix_image_caption") or
                       "Graf vektor\u016f vyva\u017eov\u00e1n\u00ed (zdrojová DDS databáze)")
            need_h = dh + 32
            if y + need_h > BOTTOM:
                _running_header(pdf, doc, page_no)
                pdf.new_page()
                page_no += 1
                y = 64
            pdf.text(MARGIN_L, y, caption.upper(), 9.5, bold=True, color=INK)
            pdf.line(MARGIN_L, y + 6, MARGIN_R, y + 6, 0.6, HAIR)
            y += 18
            ix = MARGIN_L + (CONTENT_W - dw) / 2.0
            try:
                pdf.image_jpeg(appendix_img_jpeg, ix, y, dw, dh)
            except Exception:
                pass
            y += dh + 8

    _running_header(pdf, doc, page_no)
    return page_no



# =========================== vektorové grafy ===========================
AXIS = (0.35, 0.38, 0.42)
GRID = (0.90, 0.91, 0.93)
PLOT = (0.18, 0.22, 0.28)       # tmavá křivka (technický vzhled)
PLOT_FILL = (0.86, 0.88, 0.91)  # světlá výplň plochy spektra

# barvy hladin limitů v trendu (dle překročeného pásma)
LIMIT_RGB = {
    "A/B": SEV_RGB["ok"],     # zelená — hranice dobrého stavu
    "B/C": SEV_RGB["alarm"],  # žlutá — mez výstrahy
    "C/D": SEV_RGB["warn"],   # červená — mez alarmu
}


def _nice_max(v):
    if not v or v <= 0:
        return 1.0
    import math
    exp = math.floor(math.log10(v))
    base = 10 ** exp
    for mult in (1, 2, 2.5, 5, 10):
        if v <= mult * base:
            return mult * base
    return 10 * base


# barvy značek ve spektru dle druhu
MARKER_RGB = {
    "speed": SEV_RGB["ok"],       # otáčková – zelená
    "harmonics": (0.20, 0.45, 0.80),  # harmonické – modrá
    "bearing": SEV_RGB["warn"],   # ložiskové – červená
    "user": (0.55, 0.35, 0.75),   # uživatelské – fialová
}

# odstíny uživatelských značek dle typu čáry (base/harm/sb)
MARKER_USER_RGB = {
    "base": (0.55, 0.35, 0.75),   # základní – sytá fialová
    "harm": (0.66, 0.50, 0.82),   # harmonické – světlejší fialová
    "sb":   (0.78, 0.66, 0.88),   # postranní pásma – nejsvětlejší
}


def _draw_spectrum_markers(pdf, g, px0, py0, pw, ph, xmax, xmin=0.0):
    """Vykreslí do FFT spektra svislé frekvenční značky se štítky.

    Značky (g['markers']) jsou list {freq, label, kind}. Kreslí se jako
    tenké svislé čárkované čáry s popiskem nahoře; štítky se skládají do
    několika řádků, aby se při blízkých frekvencích nepřekrývaly.

    `xmin`/`xmax` určují frekvenční rozsah osy (kvůli zoomu); značky mimo
    rozsah se přeskakují.
    """
    markers = g.get("markers") or []
    span = (xmax - xmin)
    if not markers or span <= 0:
        return
    py1 = py0 + ph
    # seřaď podle frekvence a přiděl řádek popisku dle vodorovné vzdálenosti
    ms = sorted((m for m in markers
                 if m.get("freq") is not None and xmin <= float(m["freq"]) <= xmax),
                key=lambda m: float(m["freq"]))
    if not ms:
        return
    # nejdřív vykresli svislé čáry přes celou plochu
    xs = []
    for m in ms:
        freq = float(m["freq"])
        mx = px0 + pw * ((freq - xmin) / span)
        kind = m.get("kind", "speed")
        line = m.get("line")
        if kind == "user" and line in MARKER_USER_RGB:
            col = MARKER_USER_RGB[line]
        else:
            col = MARKER_RGB.get(kind, MUTED)
        # postranní pásma tenčí a hustěji čárkovaná
        lw = 0.45 if line == "sb" else 0.6
        dsh = 1 if line == "sb" else 2
        pdf.dash_line(mx, py0, mx, py1, lw, col, dash=dsh, gap=2)
        xs.append(mx)
    # odhad šířky štítku (v bodech) pro rozlišení kolizí
    lbl_fs = 5.5
    def _lbl_w(txt):
        return max(8.0, len(str(txt)) * lbl_fs * 0.62)
    # přiděl každému štítku řádek tak, aby se vodorovně nepřekrýval s jiným
    # štítkem ve stejném řádku (dynamický počet řádků – žádný pevný limit 2)
    row_last_right = []   # pravý okraj posledního štítku v daném řádku
    row_h = 6.5           # výška jednoho řádku štítků
    max_rows = max(1, int((ph - 4) // row_h))
    for mx, m in zip(xs, ms):
        label = m.get("label", "")
        kind = m.get("kind", "speed")
        line = m.get("line")
        if kind == "user" and line in MARKER_USER_RGB:
            col = MARKER_USER_RGB[line]
        else:
            col = MARKER_RGB.get(kind, MUTED)
        # postranní pásma nemají štítek – přeskoč rozvržení řádku
        if not label:
            continue
        half = _lbl_w(label) / 2.0
        left = mx - half
        row = 0
        while row < len(row_last_right) and (left - row_last_right[row]) < 2:
            row += 1
        if row >= max_rows:
            # přeteklo dostupné řádky – recykluj poslední řádek
            row = max_rows - 1
        if row < len(row_last_right):
            row_last_right[row] = mx + half
        else:
            row_last_right.append(mx + half)
        # štítky uvnitř horní části plochy grafu (nad křivkou), aby nekolidovaly
        # s názvem grafu nad plochou
        ly = py0 + 2 + row * row_h
        pdf.text_centered(mx, ly, label, lbl_fs, bold=True, color=col)


def _draw_trend_user_markers(pdf, g, px0, py0, pw, ph, n):
    """Vykreslí do trendu svislé uživatelské značky se štítky.

    Značky (g['user_markers']) jsou list {freq, label}, kde `freq` je index
    bodu v původním (nezoomovaném) trendu. Mapuje se na aktuálně vykreslený
    podrozsah [i0, i1]; značky mimo rozsah se přeskakují.
    """
    ums = g.get("user_markers") or []
    if not ums or n <= 1:
        return
    i0 = g.get("i0", 0)
    i1 = g.get("i1", n - 1)
    span = (i1 - i0) or 1
    py1 = py0 + ph
    col = MARKER_RGB.get("user", MUTED)
    lbl_fs = 5.5
    def _lbl_w(txt):
        return max(8.0, len(str(txt)) * lbl_fs * 0.62)
    row_last_right = []
    row_h = 6.5
    max_rows = max(1, int((ph - 4) // row_h))
    ms = sorted((m for m in ums if m.get("freq") is not None
                 and i0 <= float(m["freq"]) <= i1),
                key=lambda m: float(m["freq"]))
    for m in ms:
        idx = float(m["freq"])
        mx = px0 + pw * ((idx - i0) / span)
        pdf.dash_line(mx, py0, mx, py1, 0.6, col, dash=2, gap=2)
        label = m.get("label", "")
        half = _lbl_w(label) / 2.0
        left = mx - half
        row = 0
        while row < len(row_last_right) and (left - row_last_right[row]) < 2:
            row += 1
        if row >= max_rows:
            row = max_rows - 1
        if row < len(row_last_right):
            row_last_right[row] = mx + half
        else:
            row_last_right.append(mx + half)
        ly = py0 + 2 + row * row_h
        pdf.text_centered(mx, ly, label, lbl_fs, bold=True, color=col)


def _draw_graph(pdf, g, x0, y_top, w, h):
    """Vykreslí vektorový graf (trend nebo FFT spektrum). Vrací y pod grafem."""
    title = g.get("title", "")
    pdf.text(x0, y_top, _clip(pdf, title, w, 9, bold=True), 9, bold=True, color=INK)
    pad_l, pad_r, pad_t, pad_b = 40, 8, 12, 18
    px0 = x0 + pad_l
    py0 = y_top + 8 + pad_t
    pw = w - pad_l - pad_r
    ph = h - 8 - pad_t - pad_b
    py1 = py0 + ph

    # rámeček plochy
    pdf.rect(px0, py0, pw, ph, stroke=HAIR, width=0.5)

    ys = g.get("y") or []
    if not ys:
        pdf.text_centered(px0 + pw / 2, py0 + ph / 2, "Bez dat", 8, color=FAINT)
        return y_top + h
    # u trendu zahrneme do rozsahu i mez výstrahy (B/C), aby byla viditelná
    data_max = max(ys)
    if g.get("type") != "spectrum":
        for lim in (g.get("limits") or []):
            if lim.get("band") == "B/C" and lim.get("value"):
                data_max = max(data_max, float(lim["value"]) * 1.05)
    ymax = _nice_max(data_max)
    ymin = 0.0
    if ymax >= 100:
        ydec = 0
    elif ymax >= 10:
        ydec = 1
    elif ymax >= 1:
        ydec = 2
    else:
        ydec = 3

    for k in range(5):
        gy = py1 - ph * k / 4.0
        if 0 < k < 4:
            pdf.line(px0, gy, px0 + pw, gy, 0.3, GRID)
        val = ymin + (ymax - ymin) * k / 4.0
        pdf.text_right(px0 - 4, gy + 3, _fmt_num(val, ydec), 6, color=MUTED)
    pdf.line(px0, py0, px0, py1, 0.7, AXIS)
    pdf.line(px0, py1, px0 + pw, py1, 0.7, AXIS)

    def _sx(i, n):
        return px0 if n <= 1 else px0 + pw * i / float(n - 1)

    def _sy(v):
        return py1 - ph * (v - ymin) / (ymax - ymin or 1)

    n = len(ys)
    if g.get("type") == "spectrum":
        poly = [(px0, py1)]
        for i, v in enumerate(ys):
            poly.append((_sx(i, n), _sy(v)))
        poly.append((_sx(n - 1, n), py1))
        pdf.polygon(poly, fill=PLOT_FILL)
        pdf.polyline([(_sx(i, n), _sy(v)) for i, v in enumerate(ys)], 0.7, PLOT)
        xmax = g.get("x_max") or 0
        xmin = g.get("x_min") or 0
        span = (xmax - xmin) or 1
        unit = g.get("x_unit", "Hz")
        # popisky osy X od xmin do xmax (zohledněn zoom rozsah)
        for k in range(4):
            gx = px0 + pw * k / 4.0
            lbl = _fmt_num(xmin + span * k / 4.0, 0)
            if k == 0:
                pdf.text(gx, py1 + 11, lbl, 6, color=MUTED)
            else:
                pdf.text_centered(gx, py1 + 11, lbl, 6, color=MUTED)
        pdf.text_right(px0 + pw, py1 + 11, "%s [%s]" % (_fmt_num(xmax, 0), unit),
                       6, color=MUTED)
        # frekvenční značky (otáčková / harmonické / ložiskové / uživatelské)
        _draw_spectrum_markers(pdf, g, px0, py0, pw, ph, xmax, xmin=xmin)
    else:
        # hladiny limitů pásem (vodorovné čáry) — vykreslí se POD křivku
        for lim in (g.get("limits") or []):
            lv = lim.get("value")
            if lv is None or lv <= ymin or lv > ymax:
                continue
            band = lim.get("band", "")
            # barva dle právy překročeného pásma: B/C → alarm (žlutá), C/D → warn
            lc = LIMIT_RGB.get(band, FAINT)
            ly = _sy(lv)
            pdf.dash_line(px0, ly, px0 + pw, ly, 0.7, lc, dash=3, gap=2)
            pdf.text_right(px0 + pw - 2, ly - 2.5, band, 5.5, bold=True, color=lc)
        pts = [(_sx(i, n), _sy(v)) for i, v in enumerate(ys)]
        pdf.polyline(pts, 1.1, PLOT)
        if n <= 30:
            for (dx, dy) in pts:
                pdf.dot(dx, dy, 1.8, PLOT)
        pdf.text(px0, py1 + 11, g.get("x_first", ""), 6, color=MUTED)
        pdf.text_right(px0 + pw, py1 + 11, g.get("x_last", ""), 6, color=MUTED)
        # uživatelské značky trendu (svislé čáry na indexu bodu)
        _draw_trend_user_markers(pdf, g, px0, py0, pw, ph, n)
    yunit = g.get("y_unit")
    if yunit:
        pdf.text(x0, py0 - 4, "[%s]" % yunit, 6, color=MUTED)
    # volitelný popis grafu pod plochou — zarovnaný do bloku pod obrázek,
    # zalomený do celé šířky grafu (bez přetékání doprava, bez ořezu).
    note = (g.get("note") or "").strip()
    y_below = y_top + h
    if note:
        ny = py1 + 22
        ny = pdf.text_block(x0, ny, note, GRAPH_NOTE_SIZE, w,
                            leading=GRAPH_NOTE_LEAD, color=MUTED, justify=True)
        y_below = max(y_below, ny + 2)
    return y_below


# velikost a řádkování popisu pod grafem (sdíleno s výpočtem výšky řádku)
GRAPH_NOTE_SIZE = 6.5
GRAPH_NOTE_LEAD = 9.0


def _graph_note_height(pdf, g, w):
    """Výška (v bodech) popisu pod jedním grafem při šířce sloupce w.
    Vrací 0, pokud graf nemá popis. Slouží k rezervaci místa v mřížce grafů,
    aby delší popisy nepřetékaly do dalšího řádku.
    """
    note = (g.get("note") or "").strip()
    if not note:
        return 0.0
    n_lines = len(pdf.wrap_text(note, GRAPH_NOTE_SIZE, w))
    # 22 = odsazení popisu pod plochou grafu (py1 + 22 - py1) uvnitř GRAPH_H
    over = max(0.0, 22 + n_lines * GRAPH_NOTE_LEAD - (168 - 150))
    return over


def _graph_row_note_height(pdf, row_graphs, w):
    """Nejvyšší dodatečná výška popisu v jednom řádku dvojice grafů."""
    return max([_graph_note_height(pdf, g, w) for g in row_graphs] or [0.0])


# =========================== PŘÍLOHA: použité normy ===========================
def _fmt_mm(v):
    """Naformátuje mez v mm/s (česká des. čárka), nebo „–“ když chybí."""
    if v is None:
        return "–"
    try:
        f = float(v)
    except (TypeError, ValueError):
        return "–"
    s = ("%.2f" % f).rstrip("0").rstrip(".")
    return s.replace(".", ",")


def _used_norms_block(pdf, doc, y):
    """Vypíše SKUTEČNě použité normy (z ``doc['used_norms']``) včetně jejich
    mezních hodnot rychlosti vibrací [mm/s RMS]: A/B, B/C (výstraha),
    C/D (alarm). Když není známá žádná norma, vypíše obecný popis ČSN ISO 20816
    (zpětně kompatibilní fallback)."""
    used = doc.get("used_norms") or []
    # Pojistka pro starší uložené drafty bez ``used_norms``: dopočítej je
    # ze strojů v dokumentu, ať příloha ukazuje reálné normy i zpětně.
    if not used:
        try:
            used = report_mod.collect_used_norms(doc.get("machines") or [])
        except Exception:
            used = []

    # nadpis sekce
    if used:
        pdf.text(MARGIN_L, y, "Použité normy a jejich mezní hodnoty", 9.5,
                 bold=True, color=INK)
        y += 14
        intro = (
            "Níže jsou uvedeny normy, dle kterých byly stroje v tomto protokolu "
            "skutečně klasifikovány, včetně mezních efektivních hodnot rychlosti "
            "vibrací (RMS) [mm/s] oddělujících pásma stavu A/B, B/C a C/D."
        )
        y = pdf.text_block(MARGIN_L, y, intro, 9, CONTENT_W, leading=13,
                           justify=True) + 8

        # záhlaví tabulky
        col_norm = MARGIN_L
        col_ab = MARGIN_R - 210
        col_bc = MARGIN_R - 140
        col_cd = MARGIN_R - 70
        pdf.text(col_norm, y, "Norma / třída", 7.5, bold=True, color=MUTED)
        pdf.text(col_ab, y, "A/B", 7.5, bold=True, color=MUTED)
        pdf.text(col_bc, y, "B/C (výstraha)", 7.5, bold=True, color=MUTED)
        pdf.text(col_cd, y, "C/D (alarm)", 7.5, bold=True, color=MUTED)
        y += 5
        pdf.line(MARGIN_L, y, MARGIN_R, y, 0.6, HAIR)
        y += 4

        for rec in used:
            std = (rec.get("standard") or "–").strip() or "–"
            mc = (rec.get("machine_class") or "").strip()
            label = std if not mc else ("%s – %s" % (std, mc))
            # zalomí dlouhý název normy do šířky sloupce
            name_w = col_ab - col_norm - 8
            lines = pdf.wrap_text(label, 9, name_w) or [label]
            row_h = max(14, len(lines) * 12)
            ty = y + 10
            for ln in lines:
                pdf.text(col_norm, ty, ln, 9, color=INK)
                ty += 12
            pdf.text(col_ab, y + 10, _fmt_mm(rec.get("ab")), 9, color=INK)
            pdf.text(col_bc, y + 10, _fmt_mm(rec.get("warning")), 9, color=INK)
            pdf.text(col_cd, y + 10, _fmt_mm(rec.get("alarm")), 9, color=INK)
            # doplňkový řádek: kterých strojů/ložisek se norma týká
            extra = ""
            brgs = rec.get("bearings") or []
            machs = rec.get("machines") or []
            if brgs:
                extra = "ložiska: " + ", ".join(brgs)
            elif machs:
                extra = "stroje: " + ", ".join(machs)
            if extra:
                for ln in (pdf.wrap_text(extra, 7.5, CONTENT_W) or [extra]):
                    pdf.text(col_norm, ty, ln, 7.5, color=MUTED)
                    ty += 10
            y = max(ty, y + row_h) + 2
            pdf.line(MARGIN_L, y, MARGIN_R, y, 0.4, HAIR)
            y += 4
        y += 6
        _pozn = ("Pozn.: Mezní hodnoty odpovídají třídě stroje nastavené na "
                 "kartě (Nastavení → Normy). Hodnota „–“ znamená, že norma danou "
                 "mez neuvádí.")
        y = pdf.text_block(MARGIN_L, y, _pozn, 7.5, CONTENT_W, leading=10,
                           color=MUTED) + 16
        return y

    # --- fallback: žádné známé normy → obecný popis ČSN ISO 20816 ---
    pdf.text(MARGIN_L, y, "ČSN ISO 20816 — Mechanické vibrace", 9.5, bold=True,
             color=INK)
    y += 14
    p1 = (
        "ČSN ISO 20816 (dříve ČSN ISO 10816) stanovuje pravidla pro hodnocení "
        "mechanických vibrací strojů měřením na nerotujících částech (skříních ložisek). "
        "Základním hodnotícím parametrem je efektivní hodnota (RMS) rychlosti vibrací "
        "[mm/s] v pásmu 10–1000 Hz. Stroje se dělí do skupin podle výkonu a způsobu "
        "uložení (tuhé / poddajné základy), pro které platí odlišné mezní hodnoty."
    )
    y = pdf.text_block(MARGIN_L, y, p1, 9, CONTENT_W, leading=13, justify=True) + 10
    return y


def _norms_appendix_page(pdf, doc, page_no):
    """Závěrečná příloha s informacemi o použitých normách a metodice hodnocení."""
    y = 64
    y = _section(pdf, MARGIN_L, y, "", "Příloha — použité normy a hodnocení",
                 CONTENT_W)

    # Úvodní text přílohy je editovatelný (doc['appendix_intro']); když je prázdný,
    # použije se výchozí formulace.
    intro = (doc.get("appendix_intro") or "").strip() or (
        "Hodnocení stavu strojů v tomto protokolu vychází z níže uvedených norem a "
        "metod. Měření i vyhodnocení bylo provedeno měřicí a softwarovou "
        "technologií HADS."
    )
    y = pdf.text_block(MARGIN_L, y, intro, 9, CONTENT_W, leading=13, justify=True) + 12

    # --- SKUTEČNĚ použité normy + jejich limity (mm/s RMS) ---
    y = _used_norms_block(pdf, doc, y)

    # --- tabulka pásem A–D ---
    pdf.text(MARGIN_L, y, "PÁSMA STAVU (A–D)", 7.5, bold=True, color=MUTED)
    y += 6
    bands = [
        ("A", "ok", "Vibrace nově uvedených strojů do provozu — stroj v bezvadném "
                    "stavu."),
        ("B", "ok", "Stroj vhodný pro dlouhodobý nepřetržitý provoz bez omezení."),
        ("C", "alarm", "Stav nevyhovující pro dlouhodobý trvalý provoz; stroj lze "
                       "provozovat omezenou dobu — naplánujte nápravné opatření."),
        ("D", "warn", "Vibrace nebezpečné — mohou způsobit poškození stroje; nutný "
                      "okamžitý zásah."),
    ]
    cw_band = 34
    cx_txt = MARGIN_L + cw_band + 12
    for band, sev, desc in bands:
        lines = pdf.wrap_text(desc, 9, MARGIN_R - cx_txt)
        rh = max(22, 8 + len(lines) * 12)
        pdf.rect(MARGIN_L, y, cw_band, 18, fill=SEV_RGB[sev])
        pdf.text_centered(MARGIN_L + cw_band / 2.0, y + 13, band, 11, bold=True,
                          color=SEV_TEXT[sev])
        ty = y + 10
        for ln in lines:
            pdf.text(cx_txt, ty, ln, 9, color=INK)
            ty += 12
        y += rh
        pdf.line(MARGIN_L, y, MARGIN_R, y, 0.4, HAIR)
    y += 6
    _pozn = ("Pozn.: Meze A/B, B/C a C/D rychlosti vibrací vycházejí "
             "z použité normy (Nastavení → Normy). Není-li hranice A/B "
             "v normě uvedena, odhadne se jako polovina meze výstrahy "
             "(B/C). U zrychlení a obálky se pásmo A/B neodhaduje — "
             "pracuje se pouze se skutečně zadanými mezemi výstrahy "
             "a alarmu.")
    y = pdf.text_block(MARGIN_L, y, _pozn, 7.5, CONTENT_W, leading=10,
                       color=MUTED) + 14

    # --- metoda obálky + FFT ---
    pdf.text(MARGIN_L, y, "Analýza valivých ložisek — metoda obálky zrychlení",
             9.5, bold=True, color=INK)
    y += 14
    p2 = (
        "Stav valivých ložisek se hodnotí metodou obálky signálu zrychlení (ACC "
        "ENV), která zvýrazňuje rázové děje vznikající při poškození valivých "
        "elementů a drah. Doplňkově se sleduje celkové zrychlení vibrací (ACC RMS) "
        "a ukazatel stavu ložisek (BEARING). Hodnoty jsou uvedeny v jednotkách g "
        "(1 g ≈ 9,81 m/s²)."
    )
    y = pdf.text_block(MARGIN_L, y, p2, 9, CONTENT_W, leading=13, justify=True) + 10

    pdf.text(MARGIN_L, y, "Frekvenční analýza (FFT)", 9.5, bold=True, color=INK)
    y += 14
    p3 = (
        "Rychlá Fourierova transformace (FFT) rozkládá měřený časový signál na "
        "frekvenční složky. Z polohy a amplitudy výrazných složek ve spektru lze "
        "identifikovat příčinu zvýšených vibrací (nevyváženost, nesouosost, "
        "mechanické uvolnění, závady ložisek či ozubení apod.)."
    )
    y = pdf.text_block(MARGIN_L, y, p3, 9, CONTENT_W, leading=13, justify=True) + 4

    _running_header(pdf, doc, page_no)
    return page_no


# =========================== hlavní funkce ===========================
def render(doc):
    """Z dokumentu (návrhu protokolu) sestaví PDF a vrátí bytes.

    `doc["report_version"]` volí šablonu (1 = stručná, 2 = detailní,
    3 = vyvažování). Strana 1 (dashboard) a strana 2 (souhrn) jsou u všech
    verzí stejné — liší se až následující části (detailní strany / sekce
    hodnocení + příloha grafy).

    VERZE 1: jedna celá strana na stroj (jen Alarm/Výstraha), s obrázkem
    stroje a grafy přímo pod tabulkou.
    VERZE 2: plynulá sekce "Hodnocení technického stavu" (všechny stroje,
    bez obrázku, tabulky za sebou) + samostatná příloha s grafy na konci.
    VERZE 3: obdoba V2 pro VYVAŽOVÁNÍ — tabulka rychlostí před/po vyvážení s
    procenty úspěšnosti a stavem ložisek + příloha grafy s volitelným
    externím obrázkem (graf vektorů).
    """
    doc = dict(doc or {})
    if not isinstance(doc.get("footer"), dict):
        doc["footer"] = dict(report_mod.DEFAULT_FOOTER)
    version = report_mod.norm_report_version(doc.get("report_version"))
    pdf = pdf_writer.PDF(str(_FONT_DIR / "DejaVuSans.ttf"),
                         str(_FONT_DIR / "DejaVuSans-Bold.ttf"))
    # STRANA 1 — hlavička + dashboard (vrací klikací řádky sekce 02)
    link_rects = _dashboard_page(pdf, doc) or []
    # STRANA 2 — úvod (metodika) + sekce 04 (obsah dle verze, může přetéct
    # na další stranu u verze 2)
    pdf.new_page()
    page_no = _summary_page(pdf, doc, version)
    detail_page_by_id = {}

    if version in (2, 3):
        # VERZE 2 / 3: sekce "Hodnocení technického stavu" resp. "Zhodnocení
        # vyvažování" — VŠECHNY stroje, plynule za sebou, bez obrázku; grafy
        # až v samostatné příloze níže.
        detail = list(doc.get("machines", []))
        detail.sort(key=lambda m: (-SEV_RANK.get(m.get("severity"), 0),
                                   m.get("name") or ""))
        pdf.new_page()
        page_no += 1
        show_previous = bool(doc.get("show_previous", version == 2))
        page_no, detail_page_by_id = _technical_assessment_section(
            pdf, doc, detail, page_no, balance=(version == 3),
            show_previous=show_previous)
    else:
        # VERZE 1: jedna celá strana na stroj, jen Alarm / Výstraha.
        detail = [m for m in doc.get("machines", [])
                  if m.get("severity") in ("warn", "alarm")]
        detail.sort(key=lambda m: (-SEV_RANK.get(m.get("severity"), 0),
                                   m.get("name") or ""))
        for m in detail:
            pdf.new_page()
            detail_page_by_id[m.get("machine_id")] = pdf.current_page_index()
            page_no += 1
            page_no = _machine_page(pdf, doc, m, page_no, detailed=False)

    # interní odkazy: řádek stroje v sekci 02 (strana 1) → detailní strana/sekce
    for lk in link_rects:
        di = detail_page_by_id.get(lk.get("machine_id"))
        if di is None:
            continue
        pdf.add_link(lk["x"], lk["y_top"], lk["w"], lk["h"], di, src_page=0)

    # PŘÍLOHA — grafy: trendy a FFT spektra (verze 2 a 3; verze 1 má grafy u
    # každého stroje přímo na jeho detailní straně). Verze 3 navíc přidá
    # externí obrázek (graf vektorů vyvažování).
    if version in (2, 3):
        page_no = _graphs_appendix(pdf, doc, detail, page_no)

    # PŘÍLOHA — použité normy a hodnocení
    pdf.new_page()
    page_no += 1
    _norms_appendix_page(pdf, doc, page_no)
    return pdf.output()
