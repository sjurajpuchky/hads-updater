# -*- coding: utf-8 -*-
"""Znalostní báze schválených vzorů pro AI závěry (varianta B).

Uchovává ručně schválené („zlaté") dvojice *situace → závěr + doporučení*,
které se vkládají do promptu jako příklady stylu a odborné úvahy diagnostika.
Na rozdíl od surové historie protokolů (`report_history.py`) jde POUZE o
kurátorované, kvalitou ověřené vzory – do promptu tak nikdy nejde
nezkontrolovaná formulace.

Data se ukládají do ``data/ai_examples.json`` ve tvaru::

    { "examples": [ <vzor>, <vzor>, ... ] }

Každý vzor::

    {
      "id": "<uuid>",
      "created_at": "<ISO 8601>",
      "updated_at": "<ISO 8601>",
      "enabled": true,
      "machine_kind": "ventilator",   # ručně volený štítek typu stroje
      "report_version": 2,             # 1 | 2 | 3 – pro kterou šablonu závěru
      "severity": "warn",             # ok | alarm | warn | "" (nezáleží)
      "fault": ["nevyvaha", "loziska"],# volitelné příznaky závady
      "situation": "<krátký popis situace stroje>",
      "zaver": "<schválený text závěru>",
      "doporuceni": "<schválené doporučení>",
      "source_entry_id": "<id z report_history, odkud vzor pochází>"
    }

Používá POUZE standardní knihovnu Pythonu.
"""

import json
import uuid
import datetime
from pathlib import Path

_BASE = Path(__file__).resolve().parent.parent
_FILE = _BASE / "data" / "ai_examples.json"

# povolené číselníky (validace + nabídka do UI)
MACHINE_KINDS = (
    "obecne", "ventilator", "cerpadlo", "motor",
    "prevodovka", "kompresor", "loziskovy_uzel",
)
SEVERITIES = ("", "ok", "alarm", "warn")
REPORT_VERSIONS = (1, 2, 3)


def _now_iso():
    now = datetime.datetime.now()
    return now.replace(microsecond=(now.microsecond // 1000) * 1000).isoformat()


def _load_all():
    if _FILE.exists():
        try:
            data = json.loads(_FILE.read_text(encoding="utf-8")) or {}
            ex = data.get("examples")
            return ex if isinstance(ex, list) else []
        except Exception:
            return []
    return []


def _save_all(examples):
    _FILE.parent.mkdir(parents=True, exist_ok=True)
    _FILE.write_text(
        json.dumps({"examples": examples}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _norm_version(v):
    try:
        iv = int(v)
    except Exception:
        return 1
    return iv if iv in REPORT_VERSIONS else 1


def _norm_kind(k):
    k = (str(k or "")).strip().lower()
    return k if k in MACHINE_KINDS else "obecne"


def _norm_severity(s):
    s = (str(s or "")).strip().lower()
    return s if s in SEVERITIES else ""


def _norm_fault(f):
    if isinstance(f, str):
        f = [p.strip() for p in f.split(",")]
    if not isinstance(f, list):
        return []
    out = []
    for p in f:
        p = str(p or "").strip().lower()
        if p and p not in out:
            out.append(p)
    return out


def _sanitize(payload):
    """Z libovolného vstupu sestaví validní tělo vzoru (bez id/časů)."""
    d = payload if isinstance(payload, dict) else {}
    return {
        "enabled": bool(d.get("enabled", True)),
        "machine_kind": _norm_kind(d.get("machine_kind")),
        "report_version": _norm_version(d.get("report_version")),
        "severity": _norm_severity(d.get("severity")),
        "fault": _norm_fault(d.get("fault")),
        "situation": str(d.get("situation") or "").strip()[:1500],
        "zaver": str(d.get("zaver") or "").strip()[:4000],
        "doporuceni": str(d.get("doporuceni") or "").strip()[:2000],
        "source_entry_id": str(d.get("source_entry_id") or "").strip(),
    }


# ------------------------------- CRUD -------------------------------

def list_examples():
    """Vrátí všechny vzory (nejnovější první)."""
    ex = _load_all()
    return sorted(ex, key=lambda e: e.get("created_at") or "", reverse=True)


def get_example(example_id):
    for e in _load_all():
        if e.get("id") == example_id:
            return e
    return None


def add_example(payload):
    """Přidá nový vzor. Vrací uložený vzor."""
    body = _sanitize(payload)
    if not body["situation"] or not body["zaver"]:
        return None  # situace i závěr jsou povinné
    now = _now_iso()
    rec = {"id": uuid.uuid4().hex, "created_at": now, "updated_at": now}
    rec.update(body)
    ex = _load_all()
    ex.insert(0, rec)
    _save_all(ex)
    return rec


def update_example(example_id, payload):
    """Přepíše existující vzor. Vrací aktualizovaný vzor, nebo None."""
    body = _sanitize(payload)
    ex = _load_all()
    for i, e in enumerate(ex):
        if e.get("id") == example_id:
            e.update(body)
            e["updated_at"] = _now_iso()
            ex[i] = e
            _save_all(ex)
            return e
    return None


def delete_example(example_id):
    ex = _load_all()
    new = [e for e in ex if e.get("id") != example_id]
    if len(new) == len(ex):
        return False
    _save_all(new)
    return True


# --------------------------- výběr vzorů ---------------------------

def select_examples(report_version, machine_kind=None, severity=None,
                    fault=None, limit=3):
    """Vybere až `limit` nejrelevantnějších schválených vzorů.

    Tvrdá podmínka: shoda `report_version` (aby se ke stručnému protokolu
    nevložil vzor psaný pro detailní/vyvažovací formát) + `enabled`.

    Skóre:
      + 3  shoda machine_kind
      + 2  shoda severity
      + 1  za každý společný příznak závady (fault)
    Při rovnosti skóre preferuje novější vzor.
    """
    rv = _norm_version(report_version)
    want_kind = _norm_kind(machine_kind) if machine_kind else None
    want_sev = _norm_severity(severity) if severity else None
    want_fault = set(_norm_fault(fault))

    scored = []
    for e in _load_all():
        if not e.get("enabled", True):
            continue
        if _norm_version(e.get("report_version")) != rv:
            continue
        score = 0
        if want_kind and e.get("machine_kind") == want_kind:
            score += 3
        if want_sev and e.get("severity") and e.get("severity") == want_sev:
            score += 2
        if want_fault:
            score += len(want_fault & set(e.get("fault") or []))
        scored.append((score, e.get("created_at") or "", e))

    # nejvyšší skóre, pak nejnovější
    scored.sort(key=lambda t: (t[0], t[1]), reverse=True)
    return [e for _s, _c, e in scored[:max(0, int(limit or 0))]]


def examples_block(report_version, machine_kind=None, severity=None,
                   fault=None, limit=3):
    """Sestaví textový blok příkladů pro vložení do promptu (nebo "").

    Blok je konstruovaný tak, aby model bral z příkladů POUZE styl a
    strukturu, NIKDY konkrétní hodnoty (ty se berou z aktuálních dat).
    """
    ex = select_examples(report_version, machine_kind=machine_kind,
                         severity=severity, fault=fault, limit=limit)
    if not ex:
        return ""
    parts = [
        "\n\nPŘÍKLADY, JAK DIAGNOSTIK DŘÍVE FORMULOVAL ZÁVĚRY PRO PODOBNÉ "
        "STROJE. Napodob STYL, strukturu a odbornou úvahu těchto příkladů, "
        "ale NEPŘEBÍREJ z nich žádné konkrétní hodnoty ani pásma — ta ber "
        "VÝHRADNĚ z aktuálně naměřených dat výše:"
    ]
    for i, e in enumerate(ex, 1):
        parts.append(
            "\n— Příklad %d —\n"
            "  Situace: %s\n"
            "  Závěr: %s\n"
            "  Doporučení: %s"
            % (i, e.get("situation") or "—",
               e.get("zaver") or "—",
               e.get("doporuceni") or "—")
        )
    return "\n".join(parts)
