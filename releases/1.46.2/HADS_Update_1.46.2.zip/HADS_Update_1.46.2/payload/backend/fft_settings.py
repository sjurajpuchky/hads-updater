# -*- coding: utf-8 -*-
"""Globální nastavení spektrální analýzy (tolerance shody frekvencí).

Naměřená složka nikdy neleží přesně na vypočtené frekvenci: otáčky kolísají
se zatížením, valivé elementy prokluzují a samotné spektrum má konečné
rozlišení. Amplituda se proto odečítá v TOLERANČNÍM PÁSMU kolem cílové
frekvence a shoda vrcholu se posuzuje stejným pásmem.

Ukládá se do ``data/fft_settings.json``, tedy do složky, kterou aktualizace
programu nikdy nepřepisuje. Nastavení je globální pro celou instalaci —
stejně jako normy, AI prompty a metodologie.

Modul ``fft_analysis`` zůstává záměrně bez vstupů a výstupů (čistá matematika),
aby jej mohl ``ndb_parser`` importovat bez cyklu; perzistence je proto zde.

Používá POUZE standardní knihovnu Pythonu.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import threading
import time
import uuid
from typing import Any

import fft_analysis


DATA_DIR = Path(__file__).resolve().parent.parent / "data"
FILE_NAME = "fft_settings.json"
FORMAT = 1
_LOCK = threading.RLock()

DEFAULTS = {
    "order_tolerance_pct": fft_analysis.ORDER_TOLERANCE_PCT,
    "bearing_tolerance_pct": fft_analysis.BEARING_TOLERANCE_PCT,
}


def _path() -> Path:
    return DATA_DIR / FILE_NAME


def _read_state() -> dict[str, Any]:
    try:
        # utf-8-sig: soubor otevřený v Poznámkovém bloku může dostat BOM.
        raw = json.loads(_path().read_text(encoding="utf-8-sig")) if _path().is_file() else None
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        # Poškozené nastavení nikdy nesmí zabránit vyhodnocení spektra.
        raw = None
    return raw if isinstance(raw, dict) else {}


def _normalize(rec: Any) -> dict[str, float]:
    """Hodnoty mimo rozumný rozsah se tiše nahradí výchozími."""
    rec = rec if isinstance(rec, dict) else {}
    return {
        key: fft_analysis.clamp_tolerance(rec.get(key), default)
        for key, default in DEFAULTS.items()
    }


def tolerances() -> dict[str, float]:
    """Platné tolerance [%] pro přepočet spekter."""
    with _LOCK:
        return _normalize(_read_state().get("tolerances"))


def get() -> dict[str, Any]:
    """Stav pro Nastavení včetně výchozích hodnot a povolených mezí."""
    current = tolerances()
    return {
        "format": FORMAT,
        "tolerances": current,
        "defaults": dict(DEFAULTS),
        "is_default": current == DEFAULTS,
        "min_pct": fft_analysis.TOLERANCE_MIN_PCT,
        "max_pct": fft_analysis.TOLERANCE_MAX_PCT,
    }


def save(settings: Any) -> dict[str, Any]:
    """Uloží tolerance. Neplatná hodnota se nahradí výchozí, nikdy nechybí."""
    payload = (settings or {}).get("tolerances") if isinstance(settings, dict) else None
    rec = _normalize(payload)
    with _LOCK:
        state = _read_state()
        state["format"] = FORMAT
        state["tolerances"] = rec
        state["updated_at"] = time.time()
        path = _path()
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
        try:
            temporary.write_text(
                json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                encoding="utf-8", newline="\n")
            os.replace(temporary, path)
        finally:
            try:
                temporary.unlink()
            except OSError:
                pass
    return get()


def reset() -> dict[str, Any]:
    """Vrátí tolerance na vestavěné výchozí hodnoty."""
    return save({"tolerances": dict(DEFAULTS)})
