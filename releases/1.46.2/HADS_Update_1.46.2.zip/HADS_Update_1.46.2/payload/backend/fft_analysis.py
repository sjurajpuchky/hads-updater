# -*- coding: utf-8 -*-
"""Deterministická interpretace FFT spekter pro podklady AI.

MOTIVACE
--------
Do verze 1.41.0 dostávala AI ze spektra JEDINÉ číslo — celkovou hodnotu
(overall). Přesto po ní šablona detailního protokolu chtěla „zhodnocení FFT
spektra a možnou příčinu“. Model tedy komentoval data, která nikdy neviděl.

Tento modul připraví z pole čar spektra HOTOVOU tabulku nálezů:

  * nejvyšší vrcholy s frekvencí a amplitudou,
  * přepočet každé frekvence na ŘÁD otáčkové frekvence (× ot),
  * amplitudu přímo NA otáčkové frekvenci a jejích harmonických,
  * amplitudu přímo NA poruchových frekvencích přiřazeného ložiska
    (FTF / BSF / BPFO / BPFI) a jejich násobcích.

Veškerá ARITMETIKA — násobení koeficientů otáčkami, hledání maxim, porovnání
frekvencí v toleranci — probíhá zde a je ověřitelná testem. Jazykový model
dostane výsledek a jeho úkolem je pouze odborná INTERPRETACE, nikdy výpočet.
Je to stejný princip, na kterém stojí pásma A–D nebo kanonický výběr H/V/A:
čísla počítá aplikace, AI píše text.

Modul je záměrně bez závislosti na ostatních modulech HADS (čistá matematika
nad polem čísel), aby jej mohl `ndb_parser` importovat bez cyklu.

Používá POUZE standardní knihovnu Pythonu.
"""
from __future__ import annotations

import math

# Úrovně podrobnosti. Volí se podle nejhoršího pásma stroje: čím horší stav,
# tím víc podkladů má smysl posílat (a tím spíš se vyplatí delší prompt).
LEVEL_MINIMAL = "minimal"     # jen overall — stroj celý v pásmu A
LEVEL_REDUCED = "reduced"     # spárované nálezy + tři nejvyšší vrcholy
LEVEL_FULL = "full"           # vrcholy + harmonické + poruchové frekvence

FULL_PEAK_COUNT = 6
REDUCED_PEAK_COUNT = 3
HARMONIC_COUNT = 6            # 1× až 6× otáčkové frekvence
DEFECT_HARMONIC_COUNT = 3     # BPFO, 2× BPFO, 3× BPFO …

# Tolerance shody frekvence [%]. Vždy se bere jako MAXIMUM z relativní
# tolerance a jedné čáry spektra — u hrubého rozlišení by jinak shoda nikdy
# nevyšla (na 9 Hz jsou 2 % jen 0,18 Hz, ale čára bývá široká 0,5 Hz).
#
# Dvě různé hodnoty odpovídají fyzice: otáčkovou frekvenci známe přesně, takže
# její řády stačí hledat těsně. Valivé elementy naopak prokluzují a skutečné
# BPFO/BPFI/BSF/FTF se od vypočtených o jednotky procent liší.
ORDER_TOLERANCE_PCT = 1.0        # otáčková frekvence a její harmonické
BEARING_TOLERANCE_PCT = 2.0      # poruchové frekvence ložisek

# Rozumné meze pro uživatelské nastavení.
TOLERANCE_MIN_PCT = 0.1
TOLERANCE_MAX_PCT = 10.0

# Potlačení okolí už nalezeného vrcholu, aby se jeden kopec nevykázal víckrát.
# ZÁMĚRNĚ se neodvozuje od tolerance shody: ta roste s frekvencí, takže by
# na 4 kHz při 2 % zahodila i vrchol vzdálený 80 Hz, tedy zcela samostatnou
# složku spektra. Šířka kopce souvisí s rozlišením, ne s frekvencí.
#
# Malý relativní podíl je tu jako pojistka pro ZOOMOVANÁ spektra: u rozlišení
# 0,015 Hz by dvě čáry vůbec téhož kopce (0,03 Hz od sebe) prošly jako dva
# samostatné nálezy. Metodologie zoom výslovně doporučuje pro rozlišení
# postranních pásem, takže na to spektrum dřív nebo později narazíme.
PEAK_SEPARATION_LINES = 2
PEAK_SEPARATION_PCT = 0.15

# Harmonická/poruchová frekvence se do podkladů vypíše jen tehdy, má-li
# nezanedbatelnou amplitudu. Vypisovat složku na úrovni šumu stojí tokeny
# a svádí model k jejímu „vysvětlení“.
MIN_RELATIVE_AMPLITUDE = 0.02

# Amplituda pod touto hodnotou se v podkladech vypíše jako „0.00“. Takový
# řádek nenese žádnou informaci a jen svádí model k jeho vysvětlování, proto
# se vynechá úplně. Odpovídá přesnosti, se kterou se hodnoty do promptu píší.
MIN_REPORTABLE_AMPLITUDE = 0.005

# Strop na jeden stroj. Chrání prompt u strojů s mnoha měřicími body.
MAX_ROWS_PER_MACHINE = 150

DEFECT_KEYS = ("BPFO", "BPFI", "BSF", "FTF")

# ---------------------------------------------------------------------------
# Role spektra podle měřené veličiny
# ---------------------------------------------------------------------------
#
# Každá veličina zvýrazňuje jiné frekvenční pásmo, a tím i jiný druh závady
# (metodologie A.5). Nízkofrekvenční dynamika v řádech otáčkové frekvence —
# nevývaha, nesouosost, uvolnění, ohnutá hřídel, nakřivo nasazené ložisko,
# řemenový převod — patří VÝHRADNĚ do spektra RYCHLOSTI. Vysokofrekvenční
# poškození — valivá ložiska, ozubení, přidírání, kavitace — se hodnotí ze
# spektra ZRYCHLENÍ a OBÁLKY zrychlení.
#
# Dělení se promítá i do toho, co se vůbec počítá: v obálkovém spektru nemá
# smysl rozebírat harmonickou řadu 1×, a ve spektru rychlosti nemá smysl
# vydávat shodu s BPFO za nález poškozeného ložiska.
ROLE_VELOCITY = "rychlost"
ROLE_ACCELERATION = "zrychlení"
ROLE_ENVELOPE = "obálka zrychlení"


def spectrum_role(name):
    """Určí roli spektra z názvu veličiny; None u nerozpoznané."""
    text = (name or "").upper()
    if not text:
        return None
    # Pořadí je podstatné: „ACC ENV SPEC“ obsahuje obojí a je to obálka.
    if "ENV" in text or "OBÁLK" in text or "OBALK" in text:
        return ROLE_ENVELOPE
    if "ACC" in text or "ZRYCHL" in text:
        return ROLE_ACCELERATION
    if "ISO" in text or "VEL" in text or "RYCHL" in text:
        return ROLE_VELOCITY
    return None


def role_covers_orders(role):
    """Smí se z tohoto spektra vyvozovat nízkofrekvenční dynamika v řádech?"""
    return role in (ROLE_VELOCITY, None)


def role_covers_defects(role):
    """Smí se z tohoto spektra vyvozovat poškození ložisek a ozubení?"""
    return role in (ROLE_ACCELERATION, ROLE_ENVELOPE, None)

_HP_CUTOFF_HZ = 1.0           # shodné s ndb_parser.HP_CUTOFF_HZ


def detail_level_for_band(band):
    """Úroveň podrobnosti podle nejhoršího pásma stroje (A/B/C/D).

    Neznámé pásmo záměrně NEznamená nejnižší úroveň: u stroje bez limitů je
    lepší poslat o něco víc podkladů než tvrdit závěr bez opory.
    """
    if band in ("C", "D"):
        return LEVEL_FULL
    if band == "B":
        return LEVEL_REDUCED
    if band == "A":
        return LEVEL_MINIMAL
    return LEVEL_REDUCED


def _finite(value):
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def clamp_tolerance(value, default):
    """Ověří uživatelem zadanou toleranci [%]; jinak vrátí výchozí."""
    out = _finite(value)
    if out is None or not (TOLERANCE_MIN_PCT <= out <= TOLERANCE_MAX_PCT):
        return default
    return out


def _tolerance_hz(freq, step, tolerance_pct=BEARING_TOLERANCE_PCT):
    """Tolerance shody v Hz: relativní podíl, nejméně však POLOVINA čáry.

    Polovina čáry odpovídá pravidlu „vezmi nejbližší dostupnou čáru“. Dřívější
    podlaha o šířce celé čáry spolu se zaokrouhlováním okna nahoru dávala u
    nízkých frekvencí pásmo ±2 čáry — u FTF na 8,8 Hz při rozlišení 1 Hz to
    znamenalo shodu s odchylkou přes 13 %, tedy zcela mimo zadaná procenta.
    """
    relative = abs(freq) * (tolerance_pct / 100.0)
    return max(relative, abs(step or 0.0) / 2.0)


def _fmt_hz(value):
    number = _finite(value)
    return "%.2f" % number if number is not None else "—"


def _deviation_pct(found, target):
    """Skutečná odchylka nalezené čáry od vypočtené frekvence [%]."""
    if not target:
        return None
    return (found - target) / target * 100.0


def find_peaks(values, step, limit=FULL_PEAK_COUNT, cutoff=_HP_CUTOFF_HZ):
    """Nejvyšší lokální maxima spektra, setříděná sestupně podle amplitudy.

    Sousední čáry téhož vrcholu se nevrací dvakrát: po výběru vrcholu se
    potlačí jeho okolí (nejméně dvě čáry), takže `limit` znamená `limit`
    různých nálezů, ne `limit` čar jednoho kopce.
    """
    step = _finite(step) or 1.0
    if not values or step <= 0 or limit <= 0:
        return []
    start = max(int(math.ceil(cutoff / step - 1e-9)), 1)
    candidates = []
    for i in range(start, len(values) - 1):
        amp = _finite(values[i])
        if amp is None or amp <= 0:
            continue
        left = _finite(values[i - 1]) or 0.0
        right = _finite(values[i + 1]) or 0.0
        # Neostrá podmínka vpravo zachytí i vrchol na dvou stejných čarách.
        if amp > left and amp >= right:
            candidates.append((amp, i))
    # Sestupně podle amplitudy; při shodě rozhoduje nižší index (determinismus).
    candidates.sort(key=lambda item: (-item[0], item[1]))

    chosen = []
    for amp, index in candidates:
        freq = index * step
        separation = max(PEAK_SEPARATION_LINES * step,
                         freq * (PEAK_SEPARATION_PCT / 100.0))
        if any(abs(freq - other["freq"]) <= separation for other in chosen):
            continue
        chosen.append({"freq": freq, "amplitude": amp})
        if len(chosen) >= limit:
            break
    return chosen


def amplitude_at(values, step, freq, tolerance_pct=BEARING_TOLERANCE_PCT):
    """Nejvyšší amplituda v okně ±tolerance kolem cílové frekvence.

    Vrací ``{"freq": <frekvence nalezené čáry>, "amplitude": <hodnota>}`` nebo
    ``None``, leží-li cílová frekvence mimo rozsah spektra. Okno se používá
    proto, že skutečná složka nemusí padnout přesně na čáru a otáčky mohou být
    zadané s drobnou odchylkou.
    """
    step = _finite(step) or 1.0
    target = _finite(freq)
    if not values or step <= 0 or target is None or target <= 0:
        return None
    tolerance = _tolerance_hz(target, step, tolerance_pct)
    # Do okna patří jen čáry, jejichž frekvence SKUTEČNĚ leží v toleranci.
    # Zaokrouhlování ven (floor/ceil) pásmo rozšiřovalo až o čáru na každé
    # straně, takže výsledná odchylka mohla mnohonásobně překročit zadaná %.
    low = max(int(math.ceil((target - tolerance) / step - 1e-9)), 0)
    high = min(int(math.floor((target + tolerance) / step + 1e-9)), len(values) - 1)
    if low > high:
        # Tolerance užší než rozteč čar: použij nejbližší dostupnou čáru.
        nearest = int(round(target / step))
        if 0 <= nearest < len(values):
            amp = _finite(values[nearest])
            if amp is not None:
                return {"freq": nearest * step, "amplitude": amp}
        return None
    best_index = None
    best_amp = None
    for i in range(low, high + 1):
        amp = _finite(values[i])
        if amp is None:
            continue
        if best_amp is None or amp > best_amp:
            best_amp = amp
            best_index = i
    if best_index is None:
        return None
    return {"freq": best_index * step, "amplitude": best_amp}


def bearing_defect_frequencies(bearing, speed_hz):
    """Poruchové frekvence ložiska v Hz = koeficient × otáčková frekvence.

    `bearing` je záznam s koeficienty FTF/BSF/BPFO/BPFI v násobcích otáček
    (tak, jak je vede interní databáze ložisek i ruční zadání na kartě stroje).
    """
    speed = _finite(speed_hz)
    if not isinstance(bearing, dict) or not speed or speed <= 0:
        return {}
    out = {}
    for key in DEFECT_KEYS:
        coefficient = _finite(bearing.get(key))
        if coefficient and coefficient > 0:
            out[key] = coefficient * speed
    return out


def describe_order(freq, speed_hz):
    """Řád frekvence vůči otáčkám (např. 2,00 pro dvojnásobek); jinak None."""
    speed = _finite(speed_hz)
    frequency = _finite(freq)
    if not speed or speed <= 0 or frequency is None:
        return None
    return frequency / speed


def match_frequency(freq, speed_hz, defect_frequencies, step,
                    order_tolerance_pct=ORDER_TOLERANCE_PCT,
                    bearing_tolerance_pct=BEARING_TOLERANCE_PCT):
    """Popisek nálezu na dané frekvenci a jeho odchylka, nebo (None, None).

    Pořadí rozhodování je záměrné: celočíselný násobek otáček je jednoznačnější
    a diagnosticky nosnější údaj než shoda s poruchovou frekvencí, která u
    nízkých násobků může padnout do stejné tolerance.
    """
    frequency = _finite(freq)
    if frequency is None or frequency <= 0:
        return None, None
    speed = _finite(speed_hz)
    if speed and speed > 0:
        order = frequency / speed
        nearest = int(round(order))
        target = nearest * speed
        if (1 <= nearest <= HARMONIC_COUNT
                and abs(frequency - target)
                <= _tolerance_hz(target, step, order_tolerance_pct)):
            return "%d× ot" % nearest, _deviation_pct(frequency, target)
    best = None
    for key in DEFECT_KEYS:
        base = _finite((defect_frequencies or {}).get(key))
        if not base or base <= 0:
            continue
        for order in range(1, DEFECT_HARMONIC_COUNT + 1):
            candidate = base * order
            if abs(frequency - candidate) <= _tolerance_hz(candidate, step,
                                                           bearing_tolerance_pct):
                label = key if order == 1 else ("%d× %s" % (order, key))
                # Nejtěsnější shoda vyhrává; při rovnosti nižší násobek.
                distance = abs(frequency - candidate)
                if best is None or distance < best[0]:
                    best = (distance, label, _deviation_pct(frequency, candidate))
    return (best[1], best[2]) if best else (None, None)


def analyze_spectrum(values, step, speed_hz=None, bearing=None,
                     level=LEVEL_FULL, overall=None,
                     order_tolerance_pct=ORDER_TOLERANCE_PCT,
                     bearing_tolerance_pct=BEARING_TOLERANCE_PCT,
                     role=None, kinematics=None):
    """Připraví strukturované nálezy jednoho spektra pro vložení do promptu.

    Vrací slovník s klíči ``peaks``, ``harmonics`` a ``defects``; u úrovně
    ``minimal`` je prázdný. Nic v něm není odhad ani interpretace — jen
    naměřené amplitudy na vypočtených frekvencích.
    """
    if level == LEVEL_MINIMAL or not values:
        return {"level": LEVEL_MINIMAL, "role": role, "peaks": [],
                "harmonics": [], "defects": []}

    orders_apply = role_covers_orders(role)
    defects_apply = role_covers_defects(role)

    step_value = _finite(step) or 1.0
    speed = _finite(speed_hz)
    if speed is not None and speed <= 0:
        speed = None
    defects = (bearing_defect_frequencies(bearing, speed)
               if bearing and defects_apply else {})
    reference = _finite(overall)
    threshold = (reference * MIN_RELATIVE_AMPLITUDE) if reference and reference > 0 else 0.0

    peaks = []
    for peak in find_peaks(values, step_value, limit=FULL_PEAK_COUNT):
        label, deviation = match_frequency(
            peak["freq"], speed, defects, step_value,
            order_tolerance_pct, bearing_tolerance_pct)
        peaks.append({
            "freq": peak["freq"],
            "amplitude": peak["amplitude"],
            "order": describe_order(peak["freq"], speed),
            "match": label,
            "deviation_pct": deviation,
        })

    if level == LEVEL_REDUCED:
        # Zkrácená úroveň: spárované nálezy (ty nesou diagnostický význam)
        # plus tři nejvyšší vrcholy celkově, bez duplicit a v pořadí amplitud.
        matched = [p for p in peaks if p["match"]]
        top = peaks[:REDUCED_PEAK_COUNT]
        merged = []
        for item in matched + top:
            if item not in merged:
                merged.append(item)
        merged.sort(key=lambda item: -item["amplitude"])
        return {"level": level, "peaks": merged, "harmonics": [], "defects": []}

    # Cílové frekvence, jejichž amplitudu chceme odečíst přímo (i když na nich
    # není vrchol): otáčková a harmonické + poruchové frekvence ložiska.
    targets = []
    if speed and orders_apply:
        for order in range(1, HARMONIC_COUNT + 1):
            targets.append({"kind": "harmonic", "order": order,
                            "label": "%d×" % order, "target": speed * order,
                            "tolerance": order_tolerance_pct})
    for key in DEFECT_KEYS:
        base = defects.get(key)
        if not base:
            continue
        for order in range(1, DEFECT_HARMONIC_COUNT + 1):
            targets.append({
                "kind": "defect", "order": order,
                "label": key if order == 1 else ("%d× %s" % (order, key)),
                "target": base * order,
                "tolerance": bearing_tolerance_pct,
            })

    # JEDNA ČÁRA SPEKTRA = JEDEN POPISEK. Dvě blízké cílové frekvence (např.
    # 2× BPFO a 3× BSF) mohou v toleranci ukázat na tutéž čáru; bez tohoto
    # kroku by se stejný vrchol vykázal jako dvě různé závady a protokol by
    # tvrdil poškození, které měření nedokládá. Vyhrává nejtěsnější shoda.
    claimed = {}
    for item in targets:
        found = amplitude_at(values, step_value, item["target"], item["tolerance"])
        if not found:
            continue
        # Nečitelně malá amplituda se nevypisuje nikdy — ani u otáčkové
        # frekvence. Řádek „= 0.00“ není nález, jen šum v promptu.
        if found["amplitude"] < MIN_REPORTABLE_AMPLITUDE:
            continue
        # Otáčkovou frekvenci jinak uvádíme vždy: je to základní diagnostický
        # údaj (nevývaha) i tehdy, když je nízká a stroj je v pořádku.
        always = item["kind"] == "harmonic" and item["order"] == 1
        if not always and found["amplitude"] < threshold:
            continue
        item["freq"] = found["freq"]
        item["amplitude"] = found["amplitude"]
        item["offset"] = abs(found["freq"] - item["target"])
        key = round(found["freq"] / step_value)
        rival = claimed.get(key)
        if rival is None or item["offset"] < rival["offset"]:
            claimed[key] = item

    winners = sorted(claimed.values(), key=lambda item: item["freq"])
    harmonics = [{"order": item["order"], "freq": item["freq"],
                  "amplitude": item["amplitude"],
                  "deviation_pct": _deviation_pct(item["freq"], item["target"])}
                 for item in winners if item["kind"] == "harmonic"]
    defect_rows = [{"key": item["label"], "freq": item["freq"],
                    "amplitude": item["amplitude"],
                    "deviation_pct": _deviation_pct(item["freq"], item["target"])}
                   for item in winners if item["kind"] == "defect"]
    harmonics.sort(key=lambda row: row["order"])

    # ---- strukturní znaky (metodologie C.4) ----
    # Práh šumu má smysl u obou rolí: ve spektru rychlosti ukazuje na uvolnění
    # typu C, ve zrychlení na pozdní etapu poškození ložiska. Rozbor řádů 1×
    # naopak patří jen k rychlosti.
    pattern = spectrum_pattern(values, step_value,
                               speed if orders_apply else None,
                               reference, order_tolerance_pct)
    families = dominant_orders(values, step_value, speed, reference,
                               order_tolerance_pct, role=role, peaks=peaks,
                               drive_type=(kinematics or {}).get("drive_type"))
    belt = (subsynchronous_family(peaks, speed, order_tolerance_pct)
            if orders_apply else None)

    # ---- modulace kolem nejsilnějších nálezů (metodologie D.9.2) ----
    spacings = []
    if speed:
        spacings.append(("1× ot", speed))
    if defects.get("FTF"):
        spacings.append(("FTF", defects["FTF"]))
    motor = induction_motor_context(speed) if speed else None
    if motor and motor.get("plausible") and motor.get("pole_pass_hz"):
        spacings.append(("F_P", motor["pole_pass_hz"]))
        spacings.append(("2F_L", 2.0 * motor["line_freq"]))

    sidebands = []
    carriers = [(row["key"], row["freq"], row["amplitude"]) for row in defect_rows]
    carriers += [(f"{item['order']}× ot", item["freq"], item["amplitude"])
                 for item in families]
    for label, freq, amplitude in carriers[:4]:
        found = find_sidebands(values, step_value, freq, spacings,
                               order_tolerance_pct, carrier_amplitude=amplitude)
        if found:
            sidebands.append({"carrier": label, "carrier_freq": freq, **found})

    # ---- kinematické frekvence ze zadání karty stroje (etapa 3) ----
    kinematic = kinematic_rows(values, step_value, kinematics, speed, role,
                               reference, order_tolerance_pct)
    mismatch = blade_count_mismatch(families, kinematics) if orders_apply else None
    # Je-li počet lopatek či zubů zadán, odhad ze spektra už nemá co dodat.
    if kinematic and kinematics:
        families = []

    return {"level": level, "role": role, "peaks": peaks,
            "harmonics": harmonics, "defects": defect_rows, "pattern": pattern,
            "families": families, "belt": belt, "sidebands": sidebands,
            "kinematic": kinematic, "blade_mismatch": mismatch,
            "motor": motor if speed else None}


# ---------------------------------------------------------------------------
# Postranní pásma (metodologie D.9.2, D.12, D.13, D.14)
# ---------------------------------------------------------------------------

SIDEBAND_MAX_ORDER = 3
# Jedna symetrická dvojice je při několika kandidátech na odstup snadno dílem
# náhody. Metodologie mluví o postranních pásmech jako o VZORCI, ne o jedné
# složce, proto se vyžadují alespoň dvě dvojice a nezanedbatelná amplituda.
SIDEBAND_MIN_PAIRS = 2
SIDEBAND_MIN_RATIO = 0.15      # podíl amplitudy pásma vůči nosné


def find_sidebands(values, step, carrier_freq, spacings,
                   tolerance_pct=ORDER_TOLERANCE_PCT,
                   max_order=SIDEBAND_MAX_ORDER, carrier_amplitude=None):
    """Najde modulaci kolem nosné složky a pojmenuje ODSTUP pásem.

    Odstup identifikuje modulující prvek — u ložisek rozliší vnitřní kroužek
    (odstup 1× ot) od valivého elementu (odstup FTF); u ozubení a motorů
    ukazuje na konkrétní hřídel či na elektrický původ. Bez něj nelze podle
    metodologie většinu těchto závad od sebe odlišit.

    `spacings` je seznam dvojic ``(popisek, frekvence v Hz)``. Vrací nejlépe
    doloženou variantu, nebo None. Počítají se pouze SYMETRICKÉ dvojice —
    jednostranná složka není modulace.
    """
    carrier = _finite(carrier_freq)
    if not values or carrier is None or carrier <= 0:
        return None
    step_value = _finite(step) or 1.0
    reference = _finite(carrier_amplitude)
    if reference is None:
        found = amplitude_at(values, step_value, carrier, tolerance_pct)
        reference = found["amplitude"] if found else None
    if not reference or reference <= 0:
        return None
    threshold = reference * SIDEBAND_MIN_RATIO

    best = None
    for label, spacing in spacings or ():
        gap = _finite(spacing)
        if not gap or gap <= 0:
            continue
        # Pásmo užší než dvě čáry spektra nelze od nosné odlišit.
        if gap < 2 * step_value:
            continue
        pairs = []
        for order in range(1, max_order + 1):
            offset = gap * order
            low = amplitude_at(values, step_value, carrier - offset, tolerance_pct)
            high = amplitude_at(values, step_value, carrier + offset, tolerance_pct)
            if not low or not high:
                continue
            weakest = min(low["amplitude"], high["amplitude"])
            if weakest < max(threshold, MIN_REPORTABLE_AMPLITUDE):
                continue
            pairs.append({"order": order, "amplitude": weakest})
        if len(pairs) < SIDEBAND_MIN_PAIRS:
            continue
        strength = sum(p["amplitude"] for p in pairs) / reference
        record = {"label": label, "spacing": gap, "pairs": len(pairs),
                  "strength": strength}
        # Víc doložených dvojic vyhrává; při shodě silnější modulace.
        if best is None or (record["pairs"], record["strength"]) > (best["pairs"], best["strength"]):
            best = record
    return best


# ---------------------------------------------------------------------------
# Vzorec spektra (metodologie krok C.4)
# ---------------------------------------------------------------------------

SUBHARMONIC_ORDERS = (0.5, 1.5, 2.5)
FRACTIONAL_ORDERS = (1.0 / 3.0, 1.0 / 4.0, 1.0 / 5.0)
PATTERN_HARMONIC_MAX = 10
PATTERN_MIN_RATIO = 0.20        # SKF: harmonická nad 20 % z 1× se počítá


def _median(numbers):
    ordered = sorted(numbers)
    count = len(ordered)
    if not count:
        return 0.0
    middle = count // 2
    if count % 2:
        return ordered[middle]
    return (ordered[middle - 1] + ordered[middle]) / 2.0


def spectrum_pattern(values, step, speed_hz=None, overall=None,
                     tolerance_pct=ORDER_TOLERANCE_PCT):
    """Strukturní znaky spektra, ze kterých metodologie odvozuje závadu.

    Nevrací diagnózu — jen měřitelné znaky (délka harmonické řady, přítomnost
    subharmonických, zvýšený práh šumu, širokopásmová energie). Rozhodovací
    pravidla nad nimi patří do metodologie, kterou čte model.
    """
    step_value = _finite(step) or 1.0
    if not values or step_value <= 0:
        return {}
    finite = [v for v in (_finite(x) for x in values) if v is not None and v >= 0]
    if not finite:
        return {}
    total_energy = sum(v * v for v in finite)
    noise_floor = _median(finite)
    peak_level = max(finite)

    out = {
        "noise_floor": noise_floor,
        # Poměr mediánu k nejvyšší čáře. Nízký = čisté spektrum s ostrými
        # špičkami, vysoký = zvýšený práh šumu (uvolnění typu C, pozdní etapa
        # ložiska, opotřebené kluzné ložisko).
        "noise_floor_ratio": (noise_floor / peak_level) if peak_level > 0 else 0.0,
    }

    speed = _finite(speed_hz)
    if not speed or speed <= 0:
        return out

    base = amplitude_at(values, step_value, speed, tolerance_pct)
    base_amp = base["amplitude"] if base else 0.0
    out["running_speed_amplitude"] = base_amp
    if base_amp <= 0:
        return out
    limit = base_amp * PATTERN_MIN_RATIO

    # Souvislá řada celočíselných harmonických nad 20 % z 1×.
    run = 0
    significant = []
    for order in range(2, PATTERN_HARMONIC_MAX + 1):
        found = amplitude_at(values, step_value, speed * order, tolerance_pct)
        if found and found["amplitude"] >= limit:
            significant.append(order)
            if order == run + 2:
                run = order - 1
    out["harmonic_orders"] = significant
    out["harmonic_run"] = run
    out["harmonic_count"] = len(significant)

    # Poměr 2×/1× — metodologie D.4.5 na něj váže přímé rozhodnutí.
    second = amplitude_at(values, step_value, speed * 2, tolerance_pct)
    if second:
        out["ratio_2x_1x"] = second["amplitude"] / base_amp

    # Kontrola z kroku C.1: skutečná 1× má mít harmonické. Nemá-li je, je
    # pravděpodobné, že za 1× byla označena jiná složka (řemenová frekvence,
    # subharmonická) a všechny řády ve spektru jsou pak neplatné.
    out["running_speed_confirmed"] = any(order in significant for order in (2, 3))

    def _orders_present(candidates):
        present = []
        for order in candidates:
            target = speed * order
            if target < step_value:
                continue
            found = amplitude_at(values, step_value, target, tolerance_pct)
            if found and found["amplitude"] >= limit:
                present.append(round(order, 3))
        return present

    out["subharmonic_orders"] = _orders_present(SUBHARMONIC_ORDERS)
    out["fractional_orders"] = _orders_present(FRACTIONAL_ORDERS)

    # Subsynchronní pásmo 0,40–0,48× (metodologie D.10.2). U valivých ložisek
    # ho NEdiagnostikujeme, jen hlásíme jako nevysvětlený nález.
    low = max(int(math.ceil(0.40 * speed / step_value)), 1)
    high = min(int(math.floor(0.48 * speed / step_value)), len(values) - 1)
    if high >= low:
        window = [v for v in (_finite(values[i]) for i in range(low, high + 1))
                  if v is not None]
        if window and max(window) >= limit:
            index = low + window.index(max(window))
            out["subsynchronous"] = {"freq": index * step_value,
                                     "order": index * step_value / speed,
                                     "amplitude": max(window)}

    # Podíl energie na celočíselných řádech vůči celkové energii spektra.
    if total_energy > 0:
        synchronous = 0.0
        for order in range(1, PATTERN_HARMONIC_MAX + 1):
            found = amplitude_at(values, step_value, speed * order, tolerance_pct)
            if found:
                synchronous += found["amplitude"] ** 2
        out["synchronous_ratio"] = min(synchronous / total_energy, 1.0)
    return out


# ---------------------------------------------------------------------------
# Rodiny složek bez znalosti kinematiky (metodologie C.3, D.11, D.12, D.16)
# ---------------------------------------------------------------------------

BLADE_ORDER_RANGE = (3, 24)      # počty lopatek ventilátorů a čerpadel
GEAR_ORDER_RANGE = (15, 200)     # počty zubů
FAMILY_MIN_RATIO = 0.15
FAMILY_MAX_CANDIDATES = 2


def dominant_orders(values, step, speed_hz, overall=None,
                    tolerance_pct=ORDER_TOLERANCE_PCT, role=None, peaks=None,
                    drive_type=None):
    """Najde silné CELOČÍSELNÉ řády a odvodí z nich chybějící kinematiku.

    Metodologie počítá s tím, že známe počet lopatek a zubů. V praxi u
    převodovek přesné schéma často chybí. Protože ale platí
    ``BPF = počet lopatek × 1×`` a ``GMF = počet zubů × 1×``, je dominantní
    celočíselný řád sám o sobě ODHADEM toho počtu — a diagnostik jej může
    potvrdit nebo vyvrátit z pohledu na stroj.

    Vrací kandidáty, nikdy ne diagnózu; rozlišení lopatky/zuby plyne z
    velikosti řádu a přítomnosti postranních pásem, což posoudí model.
    """
    step_value = _finite(step) or 1.0
    speed = _finite(speed_hz)
    if not values or not speed or speed <= 0:
        return []
    base = amplitude_at(values, step_value, speed, tolerance_pct)
    reference = max((base["amplitude"] if base else 0.0), _finite(overall) or 0.0)
    if reference <= 0:
        return []
    limit = max(reference * FAMILY_MIN_RATIO, MIN_REPORTABLE_AMPLITUDE)

    # Lopatková frekvence je nízkofrekvenční jev a patří k rychlosti; záběr
    # zubů je vysokofrekvenční a patří ke zrychlení či obálce.
    if role == ROLE_VELOCITY:
        low, high = BLADE_ORDER_RANGE
    elif role in (ROLE_ACCELERATION, ROLE_ENVELOPE):
        low, high = GEAR_ORDER_RANGE
    else:
        low, high = BLADE_ORDER_RANGE[0], GEAR_ORDER_RANGE[1]

    # Kandidát musí odpovídat některému ze skutečně DOMINANTNÍCH vrcholů
    # spektra. Bez této podmínky projde jako „kinematická složka“ kdejaký řád,
    # který jen překročí práh — u jednoho ventilátoru jich tak vyšly desítky.
    peak_freqs = [p.get("freq") for p in peaks or [] if p.get("freq")]

    nyquist = (len(values) - 1) * step_value
    out = []
    for order in range(low, high + 1):
        target = speed * order
        if target > nyquist:
            break
        if peak_freqs and not any(
                abs(freq - target) <= _tolerance_hz(target, step_value, tolerance_pct)
                for freq in peak_freqs):
            continue
        found = amplitude_at(values, step_value, target, tolerance_pct)
        if not found or found["amplitude"] < limit:
            continue
        # Sousední řády musí být zřetelně nižší, jinak jde jen o člen dlouhé
        # harmonické řady (uvolnění), ne o samostatnou kinematickou složku.
        neighbours = []
        for delta in (-1, 1):
            near = amplitude_at(values, step_value, speed * (order + delta),
                                tolerance_pct)
            if near:
                neighbours.append(near["amplitude"])
        if neighbours and max(neighbours) > found["amplitude"] * 0.6:
            continue
        # Násobek už přijatého kandidáta je jeho harmonická, ne další rodina:
        # u lopatkové frekvence 23× je 46× druhá harmonická téhož jevu.
        if any(other["order"] and order % other["order"] == 0 for other in out):
            continue
        # Interpretace řádu jako počtu lopatek či zubů je HYPOTÉZA o mechanismu
        # a nabízí se jen tam, kde pro ni je opora: lopatky u nízkofrekvenčního
        # spektra rychlosti (ventilátory a čerpadla), zuby jen tehdy, je-li na
        # kartě stroje uveden ozubený převod. Jinak se vypíše samotný řád —
        # ten je fakt, kdežto „47 zubů“ u ventilátoru je smyšlenka.
        if role == ROLE_VELOCITY and order <= BLADE_ORDER_RANGE[1]:
            kind = "počtu lopatek"
        elif drive_type == "ozubení" and role in (ROLE_ACCELERATION, ROLE_ENVELOPE):
            kind = "počtu zubů"
        else:
            kind = None
        out.append({"order": order, "freq": found["freq"],
                    "amplitude": found["amplitude"], "implies": kind})
    out.sort(key=lambda item: -item["amplitude"])
    return out[:FAMILY_MAX_CANDIDATES]


def subsynchronous_family(peaks, speed_hz, tolerance_pct=ORDER_TOLERANCE_PCT):
    """Řada tří a více harmonických POD otáčkovou frekvencí.

    Metodologie D.16.1 uvádí, že řemenové frekvence leží pod 1× a bývají
    doprovázeny třemi až čtyřmi harmonickými. Bez rozměrů řemenic je to
    jediný způsob, jak řemenový převod ze spektra vůbec rozpoznat.
    """
    speed = _finite(speed_hz)
    if not speed or speed <= 0 or not peaks:
        return None
    below = sorted((p for p in peaks if 0 < p.get("freq", 0) < speed * 0.95),
                   key=lambda p: p["freq"])
    for candidate in below:
        base = candidate["freq"]
        if base <= 0:
            continue
        members = [base]
        for other in peaks:
            freq = other.get("freq") or 0
            if freq <= base:
                continue
            ratio = freq / base
            nearest = round(ratio)
            if nearest < 2 or nearest > 4:
                continue
            if abs(ratio - nearest) <= max(tolerance_pct / 100.0 * nearest, 0.06):
                members.append(freq)
        if len(members) >= 3:
            return {"base": base, "order": base / speed, "members": len(members),
                    "amplitude": candidate.get("amplitude")}
    return None


# ---------------------------------------------------------------------------
# Asynchronní motory (metodologie D.13)
# ---------------------------------------------------------------------------

LINE_FREQUENCY_HZ = 50.0
POLE_CANDIDATES = (2, 4, 6, 8, 10)
PLAUSIBLE_SLIP_PCT = (0.1, 5.0)


def induction_motor_context(speed_hz, line_freq=LINE_FREQUENCY_HZ):
    """Odvodí počet pólů a skluz z otáček — bez dalšího vstupu od uživatele.

    Synchronní otáčky jsou ``2 × F_L / počet pólů`` [Hz]. Naměřené otáčky jsou
    o skluz nižší, takže nejbližší kandidát dává počet pólů. Výsledek se
    označí jako věrohodný jen tehdy, když skluz vyjde v obvyklém rozmezí —
    u hnaného stroje za řemenem totiž otáčky s žádnou synchronní hodnotou
    souviset nemusí.
    """
    speed = _finite(speed_hz)
    line = _finite(line_freq) or LINE_FREQUENCY_HZ
    if not speed or speed <= 0 or line <= 0:
        return None
    best = None
    for poles in POLE_CANDIDATES:
        synchronous = 2.0 * line / poles
        if synchronous < speed:
            continue
        slip_pct = (synchronous - speed) / synchronous * 100.0
        if best is None or slip_pct < best["slip_pct"]:
            best = {"poles": poles, "synchronous_hz": synchronous,
                    "slip_hz": synchronous - speed, "slip_pct": slip_pct}
    if best is None:
        return None
    best["plausible"] = PLAUSIBLE_SLIP_PCT[0] <= best["slip_pct"] <= PLAUSIBLE_SLIP_PCT[1]
    # F_P = skluzová frekvence × počet pólů (metodologie D.13)
    best["pole_pass_hz"] = best["slip_hz"] * best["poles"]
    best["line_freq"] = line
    return best


# ---------------------------------------------------------------------------
# Vhodnost rozsahu a rozlišení (metodologie B.2)
# ---------------------------------------------------------------------------

BEARING_NATURAL_HZ = 2000.0        # pásmo vlastních frekvencí ložisek
SIDEBAND_RESOLUTION_DIVISOR = 4    # šířka čáry musí být ≤ 1× / 4


def range_adequacy(step, line_count, speed_hz=None, defect_frequencies=None,
                   gear_freq=None, role=None):
    """Ověří, že rozsah a rozlišení spektra na zamýšlenou diagnózu stačí.

    Metodologie varuje, že při nevhodně zvolené F_max může být závěr neplatný.
    Všechny vstupy jsou v záznamu měření, takže kontrolu lze udělat bez
    jakéhokoli dalšího údaje od uživatele.

    Každá výtka platí jen pro spektrum, které se k dané diagnóze používá —
    proto `role`. Bez ní by se u spektra RYCHLOSTI vytýkalo, že nepokrývá
    pásmo vlastních frekvencí ložisek, ačkoli se z něj ložiska stejně
    neposuzují, a u OBÁLKY totéž, ačkoli demodulace vysoké frekvence
    z principu odstraňuje a poruchové frekvence leží v desítkách až
    stovkách Hz.
    """
    step_value = _finite(step)
    lines = _finite(line_count)
    if not step_value or step_value <= 0 or not lines or lines <= 0:
        return {}
    f_max = step_value * lines
    out = {"f_max": f_max, "lines": int(lines), "line_width": step_value,
           "warnings": []}
    speed = _finite(speed_hz)

    if speed and speed > 0:
        out["orders_covered"] = f_max / speed
        # Řády 1×–nX se čtou jen ze spektra rychlosti; jen tam má smysl žádat
        # rozsah v násobcích otáčkové frekvence.
        if role_covers_orders(role) and f_max < 20 * speed:
            out["warnings"].append(
                "F_max %.0f Hz pokrývá jen %.0f× otáčky; metodologie žádá "
                "u obecného stroje alespoň 20×." % (f_max, f_max / speed))
        # Rozlišení postranních pásem s odstupem 1× ot je relevantní ve všech
        # rolích — sytá modulace se hledá i v obálce.
        if step_value > speed / SIDEBAND_RESOLUTION_DIVISOR:
            out["warnings"].append(
                "Šířka čáry %.2f Hz je na rozlišení postranních pásem s "
                "odstupem 1× ot (%.1f Hz) hrubá; metodologie žádá nejvýše "
                "čtvrtinu." % (step_value, speed))

    if role_covers_defects(role):
        worst_defect = max((_finite(v) or 0.0
                            for v in (defect_frequencies or {}).values()),
                           default=0.0)
        if worst_defect and f_max < 3 * worst_defect:
            out["warnings"].append(
                "F_max %.0f Hz nestačí na tři harmonické nejvyšší poruchové "
                "frekvence ložiska (%.0f Hz)." % (f_max, worst_defect))

        gear = _finite(gear_freq)
        if gear and f_max < 3.25 * gear:
            out["warnings"].append(
                "F_max %.0f Hz nestačí na 3,25× frekvenci záběru zubů (%.0f Hz)."
                % (f_max, gear))

    # Vlastní frekvence ložisek (jednotky kHz) budí jen NEDEMODULOVANÉ
    # spektrum zrychlení. Obálka je z definice nese už přepočtené dolů na
    # poruchové frekvence, spektrum rychlosti je neřeší vůbec, a u neznámé
    # role nelze rozhodnout — v obou případech mlčíme, protože falešná výtka
    # k rozsahu měření znehodnotí jinak platný nález.
    if role == ROLE_ACCELERATION and f_max < BEARING_NATURAL_HZ:
        out["warnings"].append(
            "F_max %.0f Hz nepokrývá pásmo vlastních frekvencí ložisek "
            "(do 2000 Hz); druhá etapa poškození nemusí být vidět." % f_max)
    return out


# ---------------------------------------------------------------------------
# Směrovost H / V / A (metodologie krok C.5)
# ---------------------------------------------------------------------------

# Metodologie (A.4) říká, že u zdravého stroje má být axiální složka NEJNIŽŠÍ,
# a tabulka kroku C.5 váže nesouosost na „axiální ≥ radiální“. Mezistupeň je
# proto samostatný: srovnatelná axiální složka už normální není, ale ještě
# nesplňuje znak z tabulky.
AXIAL_DOMINANT_RATIO = 1.0
AXIAL_NOTABLE_RATIO = 0.7
HV_HIGH_RATIO = 2.0         # H nad dvojnásobkem V


def direction_profile(by_direction):
    """Porovná amplitudy H / V / A jednoho ložiska.

    Metodologie staví na tom, že zdravý stroj má H > V > A, a z odchylek
    odvozuje závadu. HADS má všechny tři směry v datech, ale dosud je nikdy
    neporovnával — přitom právě směrovost je jediná dostupná náhrada za fázi,
    kterou databáze přístroje neobsahuje.

    Vrací naměřené poměry a slovní znaky, NIKOLI diagnózu.
    """
    values = {}
    for key in ("H", "V", "A"):
        value = _finite((by_direction or {}).get(key))
        if value is not None and value >= 0:
            values[key] = value
    if len(values) < 2:
        return None

    radial = [values[k] for k in ("H", "V") if k in values]
    out = {"values": values}
    traits = []
    if radial:
        max_radial = max(radial)
        out["max_radial"] = max_radial
        if "A" in values and max_radial > 0:
            ratio = values["A"] / max_radial
            out["axial_ratio"] = ratio
            if ratio >= AXIAL_DOMINANT_RATIO:
                traits.append("axiální ≥ radiální")
            elif ratio >= AXIAL_NOTABLE_RATIO:
                traits.append("axiální srovnatelný s radiálním")
            else:
                traits.append("radiální > axiální (očekávané)")
    if "H" in values and "V" in values and values["V"] > 0:
        ratio = values["H"] / values["V"]
        out["hv_ratio"] = ratio
        if ratio >= HV_HIGH_RATIO:
            traits.append("H ≫ V")
        elif ratio >= 1.0:
            traits.append("H > V (očekávané)")
        else:
            traits.append("V ≥ H")
    out["traits"] = traits
    return out


# ---------------------------------------------------------------------------
# Časová vlna (metodologie krok C.7, D.8, D.12.7)
# ---------------------------------------------------------------------------

CLIPPING_BAND = 0.02          # pásmo u extrému, ve kterém se vzorky počítají
# Kalibrace podle harmonického průběhu: u čisté sinusovky leží do 2 % od
# špičky asi 12,7 % vzorků, u sinusovky ořezané na polovinu kolem 67 %.
# Práh 25 % je proto mezi nimi a na neořezaný signál nesepne.
CLIPPING_NOTABLE = 0.25
# Ořezání současně SNIŽUJE činitel výkmitu pod hodnotu sinusovky (√2), zatímco
# rázový signál jej zvyšuje. Obě podmínky společně odliší zploštělou vlnu od
# jinak nápadného, ale nezploštělého průběhu.
CLIPPING_MAX_CREST = 1.35
CREST_IMPULSIVE = 4.0         # nad tuto hodnotu je signál výrazně rázový
ENVELOPE_BLOCKS = 1024        # decimace pro hledání periodicity rázů


def waveform_metrics(values, step_ms=None):
    """Amplitudové znaky časové vlny, které metodologie používá k rozlišení.

    Ořezaná (zploštělá) vlna je podle dokumentu charakteristickým znakem
    PŘIDÍRÁNÍ a odlišuje je od mechanického uvolnění, které dává spektrálně
    velmi podobný obraz. Činitel výkmitu a periodicita rázů zase odhalí
    lokální defekt — u ozubení prasklý zub, u ložiska bodové poškození.

    `step_ms` je krok časové osy v milisekundách (tak, jak jej ukládá .ndb).
    """
    finite = [v for v in (_finite(x) for x in values or ()) if v is not None]
    count = len(finite)
    if count < 16:
        return {}
    peak = max(abs(v) for v in finite)
    rms = math.sqrt(sum(v * v for v in finite) / count)
    out = {"samples": count, "peak": peak, "rms": rms}
    if rms > 0:
        out["crest_factor"] = peak / rms
        out["impulsive"] = out["crest_factor"] >= CREST_IMPULSIVE
    if peak <= 0:
        return out

    # Podíl vzorků těsně u extrému — u ořezané vlny výrazně vyšší než u
    # harmonického průběhu, kde se špička dotkne extrému jen na okamžik.
    edge = peak * (1.0 - CLIPPING_BAND)
    clipped = sum(1 for v in finite if abs(v) >= edge)
    out["clipping_ratio"] = clipped / count
    out["clipped"] = (out["clipping_ratio"] >= CLIPPING_NOTABLE
                      and out.get("crest_factor", 99.0) <= CLIPPING_MAX_CREST)

    step = _finite(step_ms)
    if not step or step <= 0:
        return out
    out["duration_s"] = count * step / 1000.0

    # Periodicita rázů: obálka |x| se decimuje na blokové maximum a v ní se
    # hledá nejsilnější opakování. Autokorelace na plném záznamu (desítky
    # tisíc vzorků) by byla zbytečně drahá a jemnější rozlišení nepotřebujeme.
    block = max(count // ENVELOPE_BLOCKS, 1)
    envelope = [max(abs(v) for v in finite[i:i + block])
                for i in range(0, count - block + 1, block)]
    n = len(envelope)
    if n < 32:
        return out
    mean = sum(envelope) / n
    centred = [v - mean for v in envelope]
    energy = sum(v * v for v in centred)
    if energy <= 0:
        return out
    best_lag, best_score = 0, 0.0
    for lag in range(2, n // 2):
        score = sum(centred[i] * centred[i + lag] for i in range(n - lag))
        if score > best_score:
            best_lag, best_score = lag, score
    strength = best_score / energy
    if best_lag and strength >= 0.3:
        period_s = best_lag * block * step / 1000.0
        if period_s > 0:
            out["impact_period_s"] = period_s
            out["impact_freq_hz"] = 1.0 / period_s
            out["impact_strength"] = strength
    return out


# ---------------------------------------------------------------------------
# Etapy poškození valivého ložiska (metodologie D.9.3)
# ---------------------------------------------------------------------------

STAGE_LABELS = {
    1: "etapa 1 — nejranější, ve spektru vibrací zpravidla nic",
    2: "etapa 2 — buzení vlastních frekvencí komponent ložiska",
    3: "etapa 3 — diskrétní poruchové frekvence a jejich násobky",
    4: "etapa 4 — širokopásmový šum, kritický stav",
}


def bearing_stage(evidence):
    """Odhadne etapu poškození ložiska z několika nezávislých znaků.

    Metodologie váže na 3. etapu přímý pokyn k výměně ložiska bez ohledu na
    amplitudu, proto se etapa přiřazuje KONZERVATIVNĚ: vrací se jen tehdy,
    když ji podpírá konkrétní doložený znak, a spolu s ní vždy i seznam těch
    znaků. Nejde o diagnózu, ale o podklad, který model interpretuje.

    `evidence` očekává klíče: ``defect_matches`` (počet poruchových frekvencí
    nalezených ve zrychlení/obálce), ``defect_harmonics`` (kolik z nich má
    násobek), ``sidebands`` (počet doložených modulací), ``envelope_band`` a
    ``accel_band`` (pásma A–D), ``velocity_band``, ``noise_floor_ratio``
    a ``envelope_rising``.
    """
    if not isinstance(evidence, dict):
        return None
    matches = int(evidence.get("defect_matches") or 0)
    harmonics = int(evidence.get("defect_harmonics") or 0)
    sidebands = int(evidence.get("sidebands") or 0)
    noise = _finite(evidence.get("noise_floor_ratio")) or 0.0
    bands = {"A": 0, "B": 1, "C": 2, "D": 3}
    accel = bands.get(evidence.get("accel_band"), 0)
    envelope = bands.get(evidence.get("envelope_band"), 0)
    velocity = bands.get(evidence.get("velocity_band"), 0)
    reasons = []

    # Etapa 4: diskrétní frekvence mizí v širokopásmovém šumu a roste 1×.
    if noise >= 0.15 and accel >= 2 and matches == 0:
        reasons.append("zvýšený práh šumu bez diskrétních poruchových frekvencí")
        if velocity >= 2:
            reasons.append("zvýšená i celková rychlost vibrací")
        return {"stage": 4, "label": STAGE_LABELS[4], "reasons": reasons}

    # Etapa 3: poruchové frekvence jsou přítomny, ideálně s násobky či pásmy.
    if matches and (harmonics or sidebands):
        reasons.append("%d poruchových frekvencí ve zrychlení/obálce" % matches)
        if harmonics:
            reasons.append("%d z nich má násobek" % harmonics)
        if sidebands:
            reasons.append("%d doložených modulací" % sidebands)
        return {"stage": 3, "label": STAGE_LABELS[3], "reasons": reasons}

    # Etapa 2: zvýšené zrychlení či obálka, ale bez diskrétních frekvencí.
    if not matches and (accel >= 1 or envelope >= 1):
        reasons.append("zvýšené zrychlení nebo obálka bez diskrétních "
                       "poruchových frekvencí")
        return {"stage": 2, "label": STAGE_LABELS[2], "reasons": reasons}

    # Etapa 1: jediným náznakem je rostoucí obálka při jinak čistém obrazu.
    if evidence.get("envelope_rising") and not matches:
        reasons.append("rostoucí trend obálky zrychlení při čistém spektru")
        return {"stage": 1, "label": STAGE_LABELS[1], "reasons": reasons}
    return None


# ---------------------------------------------------------------------------
# Rychlost změny trendu a porovnání s referencí (metodologie E.1)
# ---------------------------------------------------------------------------
#
# Metodologie řadí způsoby hodnocení podle spolehlivosti: trend téhož bodu,
# pak baseline ze známého dobrého stavu, pak shodný stroj za srovnatelných
# podmínek a teprve nakonec norma. Norma je výslovně určena jen pro stroj bez
# historie. HADS proto tyto tři lepší opory počítá a dává je modelu k dispozici
# s uvedením, která z nich je k dispozici.

TREND_MIN_POINTS = 3
TREND_WINDOW_DAYS = 30.0
TREND_NOTABLE_PCT = 10.0       # změna za 30 dní, která už stojí za zmínku

# Rychlost změny se NEEXTRAPOLUJE z krátkého rozpětí. Měření pořízená během
# jediného dne (typicky několik odečtů po sobě) dávají po přepočtu na 30 dní
# hodnoty v tisících procent, které nic neznamenají a model by je vzal vážně.
# Sedm dní je nejkratší rozpětí, ze kterého má měsíční tempo smysl odvozovat.
TREND_MIN_SPAN_DAYS = 7.0
COMPARE_NOTABLE_RATIO = 1.5    # kolikrát nad referencí je hodnota nápadná


def trend_rate(samples):
    """Rychlost změny trendu v procentech za 30 dní.

    `samples` je seznam dvojic ``(dny, hodnota)``, kde dny jsou relativní čas
    měření v dnech. Používá se metoda nejmenších čtverců, takže výsledek
    neurčuje jediný výkyv na kraji řady — metodologie žádá sledovat rychlost
    změny, ne rozdíl krajních hodnot.

    Vrací ``{"pct_per_30d", "per_day", "mean", "points", "span_days"}`` nebo
    None, není-li dost bodů nebo je rozpětí nulové.
    """
    pairs = []
    for item in samples or ():
        try:
            day, value = float(item[0]), float(item[1])
        except (TypeError, ValueError, IndexError):
            continue
        if math.isfinite(day) and math.isfinite(value):
            pairs.append((day, value))
    count = len(pairs)
    if count < TREND_MIN_POINTS:
        return None
    span = max(p[0] for p in pairs) - min(p[0] for p in pairs)
    if span < TREND_MIN_SPAN_DAYS:
        return None
    mean_day = sum(p[0] for p in pairs) / count
    mean_value = sum(p[1] for p in pairs) / count
    variance = sum((p[0] - mean_day) ** 2 for p in pairs)
    if variance <= 0 or mean_value <= 0:
        return None
    covariance = sum((p[0] - mean_day) * (p[1] - mean_value) for p in pairs)
    per_day = covariance / variance
    return {
        "per_day": per_day,
        "pct_per_30d": per_day * TREND_WINDOW_DAYS / mean_value * 100.0,
        "mean": mean_value,
        "points": count,
        "span_days": span,
    }


def compare_to_reference(current, reference):
    """Porovná hodnotu s referencí (baseline nebo sesterský stroj).

    Vrací poměr a slovní znak. Nehodnotí závažnost — ta plyne z pásem a mezí;
    tohle je pouze relativní ukotvení, které metodologie staví NAD normu.
    """
    now = _finite(current)
    base = _finite(reference)
    if now is None or base is None or base <= 0:
        return None
    ratio = now / base
    if ratio >= COMPARE_NOTABLE_RATIO:
        verdict = "výrazně nad referencí"
    elif ratio >= 1.15:
        verdict = "nad referencí"
    elif ratio <= 0.85:
        verdict = "pod referencí"
    else:
        verdict = "na úrovni reference"
    return {"ratio": ratio, "verdict": verdict,
            "pct": (ratio - 1.0) * 100.0}


# Pořadí odpovídá metodologii E.1: čím dřív v seznamu, tím spolehlivější opora.
ASSESSMENT_METHODS = ("trend", "baseline", "sesterský stroj", "norma")


def assessment_basis(has_trend=False, has_baseline=False, has_sister=False,
                     has_norm=False):
    """Které opory hodnocení jsou k dispozici a která je nejsilnější."""
    available = []
    if has_trend:
        available.append("trend")
    if has_baseline:
        available.append("baseline")
    if has_sister:
        available.append("sesterský stroj")
    if has_norm:
        available.append("norma")
    return {"available": available,
            "best": available[0] if available else None,
            "norm_only": available == ["norma"]}


# ---------------------------------------------------------------------------
# Priorita a míra jistoty (metodologie E.6 a G.1)
# ---------------------------------------------------------------------------

PRIORITY_CRITICAL = "KRITICKÁ"
PRIORITY_HIGH = "VYSOKÁ"
PRIORITY_MEDIUM = "STŘEDNÍ"
PRIORITY_LOW = "NÍZKÁ"


def priority(worst_band=None, stage=None, ratio_2x_1x=None, rising=False):
    """Zařadí nález do priority podle tabulky E.6. Vrací (priorita, důvody)."""
    reasons = []
    ratio = _finite(ratio_2x_1x)
    if worst_band == "D":
        reasons.append("pásmo D")
    if stage == 4:
        reasons.append("ložisko v etapě 4")
    if reasons:
        return PRIORITY_CRITICAL, reasons

    if worst_band == "C" and rising:
        reasons.append("pásmo C s rostoucím trendem")
    if stage == 3:
        reasons.append("ložisko v etapě 3")
    if ratio is not None and ratio > 1.5:
        reasons.append("poměr 2×/1× nad 150 %")
    if reasons:
        return PRIORITY_HIGH, reasons

    if worst_band == "C":
        reasons.append("pásmo C bez prokázaného růstu")
    if stage == 2:
        reasons.append("ložisko v etapě 2")
    if ratio is not None and 0.5 <= ratio <= 1.5:
        reasons.append("poměr 2×/1× mezi 50 a 150 %")
    if reasons:
        return PRIORITY_MEDIUM, reasons
    return PRIORITY_LOW, ["pásmo A/B bez dalších nálezů"]


CERTAINTY_HIGH = "VYSOKÁ"
CERTAINTY_MEDIUM = "STŘEDNÍ"
CERTAINTY_LOW = "NÍZKÁ"


def certainty_ceiling(speed_known=False, speed_confirmed=False,
                      directions=0, has_phase=False, range_warnings=0):
    """Nejvyšší přípustná míra jistoty podle pravidel G.1.

    Metodologie váže VYSOKOU jistotu na současné splnění několika podmínek,
    mezi nimi na potvrzení fází nebo jiným nezávislým měřením. HADS fázi
    z databáze přístroje nemá, takže tento strop je pro celou třídu závad
    trvalý — a je správné jej přiznat, ne jej obcházet.
    """
    reasons = []
    if not speed_known:
        return CERTAINTY_LOW, ["otáčky nejsou známy, řády nelze určit"]
    if not speed_confirmed:
        reasons.append("otáčková frekvence není potvrzena harmonickými")
    if directions < 2:
        reasons.append("měření jen v jednom směru")
    if range_warnings:
        reasons.append("upozornění k rozsahu nebo rozlišení měření")
    if reasons:
        return CERTAINTY_LOW, reasons
    if not has_phase:
        return CERTAINTY_MEDIUM, ["fáze není k dispozici; nevývahu a nesouosost "
                                  "nelze prokázat nezávisle"]
    return CERTAINTY_HIGH, []


# ---------------------------------------------------------------------------
# Kinematické frekvence ze zadaných údajů stroje (metodologie C.3, D.11–D.16)
# ---------------------------------------------------------------------------

KINEMATIC_HARMONICS = 3        # BPF, 2× BPF, 3× BPF …


def kinematic_frequencies(kinematics, speed_hz):
    """Frekvence, které ze samotného spektra spočítat nelze.

    Jsou-li na kartě stroje vyplněny počty lopatek, zubů, pólů či rozměry
    řemenového převodu, přestává jít o odhad z dominantního řádu a frekvence
    se počítá přesně. Každá položka nese roli, do kterého spektra patří:
    lopatky jsou nízkofrekvenční jev (rychlost), záběr zubů vysokofrekvenční
    (zrychlení a obálka).

    Vrací seznam ``{"label", "freq", "role", "source"}``; prázdný, není-li
    vyplněno nic použitelného.
    """
    speed = _finite(speed_hz)
    if not isinstance(kinematics, dict) or not speed or speed <= 0:
        return []
    out = []

    blades = kinematics.get("blade_count")
    if blades:
        out.append({"label": "BPF (%d lopatek)" % blades,
                    "freq": blades * speed, "role": ROLE_VELOCITY,
                    "source": "počet lopatek"})

    for key, name in (("gear_teeth_driver", "hnací"),
                      ("gear_teeth_driven", "hnané")):
        teeth = kinematics.get(key)
        if teeth:
            out.append({"label": "GMF (%d zubů, %s kolo)" % (teeth, name),
                        "freq": teeth * speed, "role": ROLE_ACCELERATION,
                        "source": "počet zubů"})

    poles = kinematics.get("pole_count")
    line = _finite(kinematics.get("line_freq_hz")) or LINE_FREQUENCY_HZ
    if poles:
        synchronous = 2.0 * line / poles
        slip = max(synchronous - speed, 0.0)
        slip_pct = (slip / synchronous * 100.0) if synchronous > 0 else 0.0
        out.append({"label": "2F_L", "freq": 2.0 * line,
                    "role": ROLE_VELOCITY, "source": "síťová frekvence"})
        # F_P se odvozuje ze SKLUZU. Vyjde-li skluz mimo obvyklé rozmezí,
        # zadaný počet pólů k naměřeným otáčkám nesedí a odvozená frekvence
        # by byla smyšlená — proto se nenabízí a místo ní jde varování.
        if slip > 0 and PLAUSIBLE_SLIP_PCT[0] <= slip_pct <= PLAUSIBLE_SLIP_PCT[1]:
            out.append({"label": "F_P (průchod pólů)", "freq": slip * poles,
                        "role": ROLE_VELOCITY, "source": "počet pólů a skluz"})
        elif slip > 0:
            out.append({"label": "F_P (nespočteno)", "freq": None,
                        "role": ROLE_VELOCITY, "source": "počet pólů",
                        "warning": (
                            "Zadaný počet pólů %d dává při %s Hz skluz %.1f %%, "
                            "což je mimo obvyklé rozmezí. Zkontrolujte počet "
                            "pólů nebo otáčky; F_P proto nebyla spočtena."
                            % (poles, _fmt_hz(speed), slip_pct))})

    # Řemenová frekvence = π × průměr řemenice × otáčky / délka řemene.
    belt = _finite(kinematics.get("belt_length_mm"))
    pulley = _finite(kinematics.get("pulley_driver_mm"))
    if belt and pulley and belt > 0:
        out.append({"label": "řemenová frekvence",
                    "freq": math.pi * pulley * speed / belt,
                    "role": ROLE_VELOCITY, "source": "rozměry řemenového převodu"})
    return out


def kinematic_rows(values, step, kinematics, speed_hz, role=None,
                   overall=None, tolerance_pct=ORDER_TOLERANCE_PCT):
    """Odečte amplitudy na zadaných kinematických frekvencích a násobcích."""
    entries = [item for item in kinematic_frequencies(kinematics, speed_hz)
               if role is None or item["role"] == role
               or (role == ROLE_ENVELOPE and item["role"] == ROLE_ACCELERATION)]
    if not entries or not values:
        return []
    # Položky bez frekvence nesou jen varování k zadání (např. nesmyslný skluz).
    warnings = [item for item in entries if item.get("warning")]
    entries = [item for item in entries if item.get("freq")]
    step_value = _finite(step) or 1.0
    reference = _finite(overall) or 0.0
    threshold = max(reference * MIN_RELATIVE_AMPLITUDE, MIN_REPORTABLE_AMPLITUDE)
    out = []
    for item in entries:
        for order in range(1, KINEMATIC_HARMONICS + 1):
            target = item["freq"] * order
            found = amplitude_at(values, step_value, target, tolerance_pct)
            if not found:
                continue
            # Základní frekvenci uvádíme vždy, násobky jen když vybočí:
            # metodologie u D.11 i D.12 zdůrazňuje, že samotná přítomnost
            # BPF či GMF je normální a rozhodují až zvýšené harmonické.
            if order > 1 and found["amplitude"] < threshold:
                continue
            if found["amplitude"] < MIN_REPORTABLE_AMPLITUDE:
                continue
            label = item["label"] if order == 1 else "%d× %s" % (order, item["label"])
            out.append({"label": label, "freq": found["freq"],
                        "amplitude": found["amplitude"],
                        "deviation_pct": _deviation_pct(found["freq"], target)})
    for item in warnings:
        out.append({"label": item["label"], "warning": item["warning"]})
    return out


def blade_count_mismatch(families, kinematics):
    """Neshoda mezi zadaným počtem lopatek a dominantním řádem ve spektru.

    Je-li počet lopatek zadán, přestává být dominantní celočíselný řád
    odhadem — a rozpor mezi ním a zadáním je sám o sobě nález: buď je údaj
    na kartě chybný, nebo složka pochází z něčeho jiného.
    """
    blades = (kinematics or {}).get("blade_count")
    if not blades or not families:
        return None
    orders = [item.get("order") for item in families if item.get("order")]
    if not orders or blades in orders:
        return None
    return {"configured": blades, "detected": orders}


def row_count(analysis):
    """Počet řádků, které analýza přidá do promptu (pro strop na stroj)."""
    if not isinstance(analysis, dict):
        return 0
    return (len(analysis.get("peaks") or [])
            + len(analysis.get("harmonics") or [])
            + len(analysis.get("defects") or []))


def apply_machine_budget(analyses, budget=MAX_ROWS_PER_MACHINE):
    """Ořízne nálezy celého stroje na rozpočet řádků.

    Ořezává se od nejméně nosných údajů: nejprve nejvyšší harmonické, pak
    nejslabší vrcholy. Spárované nálezy a otáčková frekvence (1×) se ruší až
    jako poslední — bez nich by podklad ztratil diagnostický smysl. Vrací
    počet zahozených řádků, aby prompt mohl uvést, že je seznam zkrácený.
    """
    total = sum(row_count(item) for item in analyses)
    if total <= budget:
        return 0

    # Priorita ZACHOVÁNÍ řádku (vyšší = důležitější). Otáčková frekvence je
    # základní diagnostický údaj, spárované nálezy nesou konkrétní závadu;
    # nespárovaný slabý vrchol je naopak nejméně nosný.
    rows = []
    for position, analysis in enumerate(analyses):
        for index, row in enumerate(analysis.get("peaks") or []):
            rows.append((3 if row.get("match") else 1, row.get("amplitude") or 0.0,
                         position, "peaks", index))
        for index, row in enumerate(analysis.get("harmonics") or []):
            rows.append((4 if row.get("order") == 1 else 2, row.get("amplitude") or 0.0,
                         position, "harmonics", index))
        for index, row in enumerate(analysis.get("defects") or []):
            rows.append((3, row.get("amplitude") or 0.0, position, "defects", index))

    # Odstraňuje se od nejméně nosných: nejdřív nízká priorita, pak nízká
    # amplituda. Poslední dvě položky klíče zaručují stabilní pořadí, takže
    # stejný vstup dá vždy stejný výsledek.
    rows.sort(key=lambda item: (item[0], item[1], item[2], item[3], item[4]))
    doomed = {}
    dropped = 0
    for _priority, _amplitude, position, key, index in rows:
        if total <= budget:
            break
        doomed.setdefault((position, key), set()).add(index)
        total -= 1
        dropped += 1
    for (position, key), indices in doomed.items():
        collection = analyses[position].get(key) or []
        analyses[position][key] = [row for i, row in enumerate(collection)
                                   if i not in indices]
    return dropped
