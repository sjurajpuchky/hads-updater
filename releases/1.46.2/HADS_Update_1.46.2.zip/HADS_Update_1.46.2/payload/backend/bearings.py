"""Interní databáze defektních ložiskových frekvencí.

Načte kompaktní JSON (bearings_db.json) jednou do paměti a poskytuje
fulltextové vyhledávání podle označení / typu / výrobce.

Formát záznamu (pole `bearings` je pole polí):
    [idx, desig, type, mfg, Z, Bd, Pd, alpha, FTF, BSF, BPFO, BPFI]

Frekvenční koeficienty (FTF/BSF/BPFO/BPFI) jsou BEZROZMĚRNÉ násobky
otáčkové frekvence hřídele n [Hz]. Skutečná frekvence = koeficient × n.

Používá POUZE standardní knihovnu Pythonu.
"""

import json
from pathlib import Path

_DB_PATH = Path(__file__).resolve().parent / "bearings_db.json"

# indexy sloupců v kompaktním poli
_I_IDX, _I_DESIG, _I_TYPE, _I_MFG = 0, 1, 2, 3
_I_Z, _I_BD, _I_PD, _I_ALPHA = 4, 5, 6, 7
_I_FTF, _I_BSF, _I_BPFO, _I_BPFI = 8, 9, 10, 11

_cache = {"loaded": False, "rows": [], "meta": {}, "manufacturers": []}


def _ensure_loaded():
    if _cache["loaded"]:
        return
    try:
        raw = json.loads(_DB_PATH.read_text(encoding="utf-8"))
        _cache["rows"] = raw.get("bearings", [])
        _cache["meta"] = raw.get("meta", {})
        mfgs = {}
        for r in _cache["rows"]:
            m = r[_I_MFG]
            if m:
                mfgs[m] = mfgs.get(m, 0) + 1
        _cache["manufacturers"] = sorted(
            ({"name": k, "count": v} for k, v in mfgs.items()),
            key=lambda x: (-x["count"], x["name"]),
        )
    except Exception:
        _cache["rows"] = []
        _cache["meta"] = {}
        _cache["manufacturers"] = []
    _cache["loaded"] = True


def _row_to_dict(r):
    return {
        "idx": r[_I_IDX],
        "designation": r[_I_DESIG],
        "type": r[_I_TYPE],
        "manufacturer": r[_I_MFG],
        "Z": r[_I_Z],
        "Bd": r[_I_BD],
        "Pd": r[_I_PD],
        "alpha": r[_I_ALPHA],
        "FTF": r[_I_FTF],
        "BSF": r[_I_BSF],
        "BPFO": r[_I_BPFO],
        "BPFI": r[_I_BPFI],
    }


def count():
    _ensure_loaded()
    return len(_cache["rows"])


def manufacturers():
    _ensure_loaded()
    return _cache["manufacturers"]


def meta():
    _ensure_loaded()
    return _cache["meta"]


def search(q="", mfg="", limit=50):
    """Fulltextové vyhledávání ložisek.

    q   – hledaný řetězec (porovnává se s označením, typem a výrobcem)
    mfg – nepovinný filtr na výrobce (přesná shoda, case-insensitive)
    limit – max. počet vrácených záznamů
    """
    _ensure_loaded()
    q = (q or "").strip().lower()
    mfg = (mfg or "").strip().lower()
    try:
        limit = max(1, min(int(limit), 500))
    except (TypeError, ValueError):
        limit = 50

    out = []
    for r in _cache["rows"]:
        if mfg and (r[_I_MFG] or "").lower() != mfg:
            continue
        if q:
            hay = " ".join(
                str(x).lower() for x in (r[_I_DESIG], r[_I_TYPE], r[_I_MFG]) if x
            )
            if q not in hay:
                continue
        out.append(_row_to_dict(r))
        if len(out) >= limit:
            break
    return {
        "results": out,
        "count": len(out),
        "total": len(_cache["rows"]),
        "truncated": len(out) >= limit,
    }


def by_designation(desig):
    """Najde ložisko podle přesného označení (case-insensitive)."""
    _ensure_loaded()
    d = (desig or "").strip().lower()
    if not d:
        return None
    for r in _cache["rows"]:
        if (r[_I_DESIG] or "").lower() == d:
            return _row_to_dict(r)
    return None
