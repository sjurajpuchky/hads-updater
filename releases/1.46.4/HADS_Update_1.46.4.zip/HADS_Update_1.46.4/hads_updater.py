#!/usr/bin/env python3
"""Bezpečný offline aktualizátor HADS.

Balíček aktualizace obsahuje tento soubor, ``manifest.json`` a adresář
``payload``. Nepotřebuje žádné externí knihovny ani připojení k internetu.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import py_compile
import shutil
import socket
import stat
import subprocess
import sys
import time
import traceback
import uuid


PRODUCT = "HADS"
BACKUP_KEEP = 3
RETENTION_REMOVE_ATTEMPTS = 3
RETENTION_RETRY_SECONDS = 0.20
CONFIG_BACKUP_MAX_BYTES = 10 * 1024 * 1024
_CREDENTIAL_PAIR = ("ai_credentials.bin", "ai_credentials.machinekey")
CONTROLLED_ROOTS = ("backend", "frontend", "tests", "assets", "launcher", "tools")
CONTROLLED_FILES = ("README.md", "README_AKTUALIZACE.txt", "spustit.bat", "spustit.sh", "HADS.exe")
LOCK_RELATIVE = Path("updates") / "update.lock"
_LOG_PATH: Path | None = None


def _data_guard(update_root: Path | None = None, installation: Path | None = None):
    """Loads the versioned data inventory implementation without importing app state."""
    candidates = []
    if update_root is not None:
        candidates.append(update_root / "payload" / "backend" / "data_protection.py")
    if installation is not None:
        candidates.append(Path(installation) / "backend" / "data_protection.py")
    candidates.append(Path(__file__).resolve().parents[1] / "backend" / "data_protection.py")
    for source in candidates:
        if not source.is_file():
            continue
        spec = importlib.util.spec_from_file_location("_hads_data_protection_" + uuid.uuid4().hex, source)
        if spec is not None and spec.loader is not None:
            module = importlib.util.module_from_spec(spec)
            # Bytekód se k modulu nezapisuje: u zdroje v payloadu by vytvořil
            # `__pycache__`, který do ověřovaného obsahu balíčku nepatří.
            previous = sys.dont_write_bytecode
            sys.dont_write_bytecode = True
            try:
                spec.loader.exec_module(module)
            finally:
                sys.dont_write_bytecode = previous
            return module
    raise UpdateError("Balíček aktualizace neobsahuje kontrolu ochrany uživatelských dat.")


class UpdateError(RuntimeError):
    """Chyba, která se má zobrazit zákazníkovi bez tracebacku."""


class SelectionCancelled(UpdateError):
    """Uživatel zrušil interaktivní výběr ještě před změnou instalace."""


def _message(level: str, text: str) -> None:
    line = f"[{level}] {text}"
    print(line, flush=True)
    if _LOG_PATH is not None:
        try:
            with _LOG_PATH.open("a", encoding="utf-8") as log:
                log.write(_dt.datetime.now().astimezone().isoformat(timespec="seconds") + " " + line + "\n")
        except OSError:
            # Neschopnost zapsat diagnostický log nesmí skrýt skutečný výsledek
            # ani znemožnit automatický rollback.
            pass


def _start_log(installation: Path, operation: str) -> Path:
    """Otevře neměnný auditní log mimo nahrazované programové složky."""
    global _LOG_PATH
    logs = installation / "updates" / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    _LOG_PATH = logs / f"{operation}_{_timestamp()}.log"
    _message("INFO", f"Zahájena operace {operation}; log: {_LOG_PATH}")
    return _LOG_PATH


def _safe_rel(value: str) -> Path:
    """Převede relativní POSIX cestu a odmítne traversal i zvláštní cesty."""
    if not isinstance(value, str) or not value or "\x00" in value:
        raise UpdateError("Manifest obsahuje neplatnou cestu.")
    p = PurePosixPath(value)
    if p.is_absolute() or ".." in p.parts or "." in p.parts or not p.parts:
        raise UpdateError(f"Manifest obsahuje nepovolenou cestu: {value!r}.")
    if any(part in ("", ".", "..") for part in p.parts):
        raise UpdateError(f"Manifest obsahuje nepovolenou cestu: {value!r}.")
    return Path(*p.parts)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _version_tuple(version: str) -> tuple[int, int, int]:
    if not isinstance(version, str):
        raise UpdateError("Číslo verze není text.")
    parts = version.split(".")
    if len(parts) != 3 or any(not item.isdigit() for item in parts):
        raise UpdateError(f"Neplatné číslo verze: {version!r}.")
    nums = tuple(int(item) for item in parts)
    if any(item > 999999 for item in nums):
        raise UpdateError(f"Neplatné číslo verze: {version!r}.")
    return nums  # type: ignore[return-value]


def _read_json(path: Path, what: str) -> dict:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise UpdateError(f"Nelze načíst {what}: {exc}") from exc
    if not isinstance(raw, dict):
        raise UpdateError(f"{what} musí být JSON objekt.")
    return raw


def _under(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _assert_no_symlinks(root: Path, label: str, required: bool = True) -> None:
    if not root.exists():
        if required:
            raise UpdateError(f"Chybí {label}: {root}.")
        return
    if root.is_symlink():
        raise UpdateError(f"{label} nesmí být symbolický odkaz: {root}.")
    if root.is_file():
        return
    for item in root.rglob("*"):
        if item.is_symlink():
            raise UpdateError(f"{label} obsahuje symbolický odkaz: {item}.")


def _load_installed_version(installation: Path) -> str:
    version_path = installation / "backend" / "version.py"
    if not version_path.is_file() or version_path.is_symlink():
        raise UpdateError("Instalace neobsahuje bezpečný soubor backend/version.py.")
    namespace: dict[str, object] = {}
    try:
        code = compile(version_path.read_text(encoding="utf-8"), str(version_path), "exec")
        exec(code, {"__builtins__": {}}, namespace)
    except Exception as exc:
        raise UpdateError(f"Nelze ověřit verzi nainstalovaného HADS: {exc}") from exc
    version = namespace.get("APP_VERSION")
    if not isinstance(version, str):
        raise UpdateError("backend/version.py neobsahuje APP_VERSION.")
    _version_tuple(version)
    return version


def normalize_installation_target(candidate: str | os.PathLike[str] | Path) -> Path:
    """Normalizuje volbu uživatele na kořen HADS bez prohledávání disku.

    Přímo vybraný kořen vrací beze změny. Pokud uživatel vybere jen jeho
    nadřazenou složku, přijme její jediný strukturálně platný podadresář.
    Díky tomu funguje aktualizace starší instalace bez ukládání historického
    názvu složky v balíčku. Funkce neprovádí GUI a je proto snadno
    testovatelná.
    """
    raw = Path(candidate).expanduser()
    try:
        selected = raw.resolve(strict=False)
    except OSError as exc:
        raise UpdateError(f"Vybranou cestu nelze zpracovat: {exc}") from exc
    if _has_installation_layout(selected):
        return selected
    if selected.is_dir() and not selected.is_symlink():
        children = [
            child.resolve()
            for child in selected.iterdir()
            if child.is_dir() and not child.is_symlink() and _has_installation_layout(child)
        ]
        if len(children) == 1:
            return children[0]
    raise UpdateError(
        "Vybraná složka není instalace HADS. Vyberte kořen obsahující backend/, frontend/ a data/, "
        "nebo nadřazenou složku s jedinou platnou instalací."
    )


def _has_installation_layout(path: Path) -> bool:
    return (
        path.is_dir()
        and not path.is_symlink()
        and (path / "backend").is_dir()
        and (path / "frontend").is_dir()
        and (path / "data").is_dir()
    )


def _powershell_dialog(script: str, environment: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    """Spustí malý Windows dialog bez vkládání uživatelské cesty do příkazu."""
    env = os.environ.copy()
    if environment:
        env.update(environment)
    return subprocess.run(
        ["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, check=False,
    )


def _windows_choose_folder() -> str | None:
    """Vrátí složku z nativního dialogu Windows nebo ``None`` při Storno."""
    script = r'''
Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Vyberte kořen složky instalace HADS (obsahuje backend, frontend a data). Lze vybrat i její nadřazenou složku.'
$dialog.ShowNewFolderButton = $false
if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
  [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($dialog.SelectedPath))
  exit 0
}
exit 10
'''
    result = _powershell_dialog(script)
    if result.returncode == 10:
        return None
    if result.returncode != 0:
        raise UpdateError("Nelze otevřít dialog pro výběr složky HADS: " + result.stderr.strip())
    try:
        return __import__("base64").b64decode(result.stdout.strip(), validate=True).decode("utf-8")
    except Exception as exc:
        raise UpdateError("Dialog pro výběr složky nevrátil platnou cestu.") from exc


def _windows_message(text: str, title: str = "HADS – aktualizace", error: bool = True) -> None:
    icon = "Error" if error else "Information"
    script = f"""
Add-Type -AssemblyName System.Windows.Forms
[void][System.Windows.Forms.MessageBox]::Show($env:HADS_DIALOG_TEXT, '{title}', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::{icon})
"""
    _powershell_dialog(script, {"HADS_DIALOG_TEXT": text})


def _windows_confirm(text: str) -> bool:
    script = r'''
Add-Type -AssemblyName System.Windows.Forms
$result = [System.Windows.Forms.MessageBox]::Show($env:HADS_DIALOG_TEXT, 'HADS – potvrzení', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
if ($result -eq [System.Windows.Forms.DialogResult]::Yes) { 'YES' } else { 'NO' }
'''
    result = _powershell_dialog(script, {"HADS_DIALOG_TEXT": text})
    if result.returncode != 0:
        raise UpdateError("Nelze zobrazit potvrzení aktualizace: " + result.stderr.strip())
    return result.stdout.strip().upper() == "YES"


def _text_choose_folder() -> str | None:
    try:
        answer = input("Zadejte cestu ke kořeni HADS (prázdné = zrušit): ").strip()
    except EOFError:
        return None
    return answer or None


def _console_error(text: str) -> None:
    _message("CHYBA", text)


def choose_installation_interactively(chooser=None, error_reporter=None) -> tuple[Path, str]:
    """Opakuje výběr dokud není zvolen platný kořen, nebo uživatel nestiskne Storno.

    Parametry jsou injekční body pro testy; produkce používá FolderBrowserDialog
    ve Windows a český textový prompt na ostatních platformách.
    """
    if chooser is None:
        chooser = _windows_choose_folder if os.name == "nt" else _text_choose_folder
    if error_reporter is None:
        error_reporter = _windows_message if os.name == "nt" else _console_error
    while True:
        selected = chooser()
        if selected is None:
            raise SelectionCancelled("Výběr instalační složky byl zrušen. Nebyly provedeny žádné změny.")
        try:
            installation = normalize_installation_target(selected)
            version = _validate_installation(installation)
            return installation, version
        except UpdateError as exc:
            error_reporter(str(exc))


def _confirm_interactive_operation(installation: Path, version: str, rollback_mode: bool) -> bool:
    if rollback_mode:
        backups = _successful_backups(installation)
        if not backups:
            raise UpdateError("Nebyla nalezena úspěšná záloha pro obnovení.")
        backup_meta = _read_json(backups[0] / "backup.json", "metadata poslední zálohy")
        target = str(backup_meta.get("from_version", "neznámá verze"))
        action = "Obnovit předchozí verzi"
        detail = f"Nalezená poslední záloha: {backups[0].name} (verze {target})."
    else:
        manifest, _ = _validate_manifest(Path(__file__).resolve().parent)
        target = str(manifest["version"])
        action = "Aktualizovat HADS"
        detail = f"Cílová verze: {target}."
    text = f"{action}?\n\nVybraná instalace:\n{installation}\n\nNalezená verze: {version}\n{detail}\n\nPokračovat?"
    if os.name == "nt":
        return _windows_confirm(text)
    try:
        answer = input(text + " [a/N]: ").strip().casefold()
    except EOFError:
        return False
    return answer in {"a", "ano", "y", "yes"}


def _validate_installation(installation: Path) -> str:
    if not installation.exists() or not installation.is_dir():
        raise UpdateError("Zadaná cesta není složka existující instalace HADS.")
    if installation.is_symlink():
        raise UpdateError("Instalace nesmí být symbolický odkaz.")
    installation = installation.resolve()
    for part in ("backend", "frontend", "tests"):
        directory = installation / part
        if not directory.is_dir():
            raise UpdateError(f"Instalace nemá očekávanou složku {part}/.")
        _assert_no_symlinks(directory, f"instalace ({part})")
    # Novější volitelné složky mohou v historické instalaci chybět; pokud už
    # existují, stále nesmějí obsahovat odkazy mimo instalační kořen.
    for part in ("assets", "launcher"):
        _assert_no_symlinks(installation / part, f"instalace ({part})", required=False)
    if not (installation / "data").is_dir():
        raise UpdateError("Instalace nemá očekávanou složku data/.")
    _assert_no_symlinks(installation / "data", "uživatelská data")
    if not (installation / "frontend" / "index.html").is_file():
        raise UpdateError("Instalace nemá očekávaný soubor frontend/index.html.")
    if not (installation / "backend" / "server.py").is_file():
        raise UpdateError("Instalace nemá očekávaný soubor backend/server.py.")
    return _load_installed_version(installation)


def _migration_destination(installation: Path) -> Path | None:
    """Vrátí bezpečný cílový kořen HADS pro platnou starší instalaci.

    Historické jméno se nikde nevyjmenovává: stačí ověřená struktura instalace.
    Kolize se odmítá před vytvořením zálohy nebo změnou programu.
    """
    if installation.name == PRODUCT:
        return None
    target = installation.parent / PRODUCT
    if target.exists() or target.is_symlink():
        raise UpdateError(
            f"Nelze přejmenovat instalační složku na {PRODUCT}: sourozenec {target} již existuje."
        )
    return target


def _move_installation_root(source: Path, destination: Path) -> Path:
    if destination.exists() or destination.is_symlink():
        raise UpdateError(f"Cílová instalační složka již existuje: {destination}.")
    try:
        os.replace(source, destination)
    except OSError as exc:
        raise UpdateError(f"Nelze bezpečně přejmenovat instalační složku: {exc}") from exc
    return destination


def _relocate_log(old_root: Path, new_root: Path) -> None:
    global _LOG_PATH
    if _LOG_PATH is None:
        return
    try:
        _LOG_PATH = new_root / _LOG_PATH.relative_to(old_root)
    except ValueError:
        _LOG_PATH = None


def _validate_manifest(update_root: Path) -> tuple[dict, list[dict]]:
    manifest_path = update_root / "manifest.json"
    if manifest_path.is_symlink():
        raise UpdateError("manifest.json nesmí být symbolický odkaz.")
    manifest = _read_json(manifest_path, "manifest.json")
    required = ("product", "version", "minimum_version", "files", "preserve", "release_notes")
    missing = [key for key in required if key not in manifest]
    if missing:
        raise UpdateError("V manifestu chybí: " + ", ".join(missing) + ".")
    if manifest["product"] != PRODUCT:
        raise UpdateError("Aktualizační balíček není určen pro HADS.")
    _version_tuple(manifest["version"])
    _version_tuple(manifest["minimum_version"])
    files = manifest["files"]
    if not isinstance(files, list) or not files:
        raise UpdateError("Manifest neobsahuje seznam souborů payloadu.")
    if not isinstance(manifest["preserve"], list) or not all(isinstance(x, str) for x in manifest["preserve"]):
        raise UpdateError("Položka preserve v manifestu není platná.")

    payload = update_root / "payload"
    _assert_no_symlinks(payload, "payload")
    seen: set[str] = set()
    declared: set[Path] = set()
    validated: list[dict] = []
    for item in files:
        if not isinstance(item, dict):
            raise UpdateError("Manifest obsahuje neplatnou položku souboru.")
        rel = _safe_rel(item.get("path"))
        rel_text = rel.as_posix()
        if rel_text in seen:
            raise UpdateError(f"Manifest obsahuje soubor vícekrát: {rel_text}.")
        seen.add(rel_text)
        if not rel.parts or rel.parts[0] not in {*CONTROLLED_ROOTS, *CONTROLLED_FILES}:
            raise UpdateError(f"Payload smí měnit jen programové soubory: {rel_text}.")
        if rel.parts[0] == "data":
            raise UpdateError("Payload aktualizace nesmí obsahovat data/.")
        sha = item.get("sha256")
        size = item.get("size")
        if not isinstance(sha, str) or len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha.lower()):
            raise UpdateError(f"Manifest má neplatný SHA-256 pro {rel_text}.")
        if not isinstance(size, int) or size < 0:
            raise UpdateError(f"Manifest má neplatnou velikost pro {rel_text}.")
        source = payload / rel
        if not _under(source, payload) or not source.is_file() or source.is_symlink():
            raise UpdateError(f"V payloadu chybí bezpečný soubor {rel_text}.")
        if source.stat().st_size != size:
            raise UpdateError(f"Nesouhlasí velikost payloadu: {rel_text}.")
        if _sha256(source).lower() != sha.lower():
            raise UpdateError(f"Nesouhlasí SHA-256 payloadu: {rel_text}.")
        declared.add(rel)
        validated.append({"path": rel, "sha256": sha, "size": size})

    # `__pycache__` do payloadu nepatří, ale může v něm vzniknout: aktualizátor
    # sám importuje payload/backend/data_protection.py, a Python k němu zapíše
    # bytekód. Bez této výjimky by DRUHÝ pokus o aktualizaci ze stejné rozbalené
    # složky selhal na kontrole integrity — typicky když první pokus skončil
    # proto, že běžel HADS, uživatel jej zavřel a spustil aktualizaci znovu.
    actual = {p.relative_to(payload) for p in payload.rglob("*")
              if p.is_file() and "__pycache__" not in p.parts}
    if actual != declared:
        extras = sorted(p.as_posix() for p in actual - declared)
        absent = sorted(p.as_posix() for p in declared - actual)
        detail = ((" navíc: " + ", ".join(extras[:3])) if extras else "") + (
            (" chybí: " + ", ".join(absent[:3])) if absent else ""
        )
        raise UpdateError("Obsah payloadu přesně neodpovídá manifestu." + detail)
    return manifest, validated


def _pid_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        completed = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", check=False,
        )
        return str(pid) in completed.stdout
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _lock_process_identity_matches(pid: int, identity: object) -> bool:
    """Ověří startovní identitu procesu z locku, aby PID reuse neblokoval update."""
    if not isinstance(identity, str) or pid <= 0:
        return False
    try:
        if os.name == "nt" and identity.startswith("win-create:"):
            import ctypes
            from ctypes import wintypes
            process = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if not process:
                return False
            try:
                created = wintypes.FILETIME(); exited = wintypes.FILETIME()
                kernel = wintypes.FILETIME(); user = wintypes.FILETIME()
                if not ctypes.windll.kernel32.GetProcessTimes(process, ctypes.byref(created), ctypes.byref(exited), ctypes.byref(kernel), ctypes.byref(user)):
                    return False
                value = (created.dwHighDateTime << 32) | created.dwLowDateTime
                return identity == f"win-create:{value}"
            finally:
                ctypes.windll.kernel32.CloseHandle(process)
        if identity.startswith("proc-start:"):
            fields = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8").split()
            return identity == f"proc-start:{fields[21]}"
    except (OSError, ValueError, IndexError):
        return False
    return False


def _server_appears_running(installation: Path) -> bool:
    """Detekce běžícího HADS bez HTTP požadavku; stale lock se bezpečně odstraní."""
    lock = installation / "data" / "hads_server.lock"
    if lock.exists():
        if lock.is_symlink():
            raise UpdateError("Nalezen nebezpečný symbolický odkaz hads_server.lock.")
        try:
            rec = _read_json(lock, "zámek serveru")
            pid = int(rec.get("pid", 0))
            root_value = str(rec.get("installation_root", ""))
            root_hash = str(rec.get("installation_fingerprint", ""))
            expected_hash = hashlib.sha256(str(installation.resolve()).casefold().encode("utf-8")).hexdigest()
            valid_format = (root_value and root_hash == expected_hash and int(rec.get("port", 0)) in range(1, 65536))
        except (ValueError, TypeError, UpdateError):
            pid, valid_format = 0, False
        # Starší format se zachovává: běžící PID stále konzervativně blokuje update.
        if _pid_is_running(pid):
            if valid_format:
                if _lock_process_identity_matches(pid, rec.get("process_identity")):
                    return True
            elif "installation_root" not in rec:
                # Původní lock nemá startovní identitu; zachovává se konzervativní
                # chování pro kompatibilitu se staršími instalacemi.
                return True
        try:
            lock.unlink()
        except OSError as exc:
            raise UpdateError(f"Nelze odstranit starý zámek serveru: {exc}") from exc

    target = str(installation.resolve()).casefold()
    try:
        if os.name == "nt":
            command = [
                "powershell", "-NoProfile", "-Command",
                "Get-CimInstance Win32_Process | Select-Object -ExpandProperty CommandLine",
            ]
        else:
            command = ["ps", "-eo", "args="]
        completed = subprocess.run(command, capture_output=True, text=True, encoding="utf-8",
                                   errors="replace", timeout=5, check=False)
        for line in completed.stdout.splitlines():
            normalized = line.casefold().replace("/", "\\") if os.name == "nt" else line.casefold()
            expected = target.replace("/", "\\") if os.name == "nt" else target
            if expected in normalized and ("server.py" in normalized or "backend.server" in normalized):
                return True
    except (OSError, subprocess.SubprocessError):
        # Zámek je primární mechanismus; chyba pomocné kontroly nesmí povolit
        # update, pokud lokální port 8000 už přijímá spojení.
        pass
    # Port bez ověřené identity instalace není důvod k blokování aktualizace:
    # mohl by patřit zcela jiné lokální aplikaci.
    return False


def _timestamp() -> str:
    return _dt.datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")


def _write_json(path: Path, data: dict) -> None:
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def _copy_persistent_small_files(installation: Path, backup: Path) -> list[str]:
    """Back up every small persistent data file, never NDBs or their sidecars.

    This includes credentials, local fallback key, legacy root JSONs, current
    selection, library, shared-update settings and all per-company JSON data.
    The copy lives under ``updates/backups`` and is not used to overwrite a
    present divergent user file during recovery.
    """
    data_dir = installation / "data"
    dest_root = backup / "data_files"
    saved: list[str] = []
    for item in data_dir.rglob("*"):
        if item.is_symlink() or not item.is_file() or item.stat().st_size > CONFIG_BACKUP_MAX_BYTES:
            continue
        rel = item.relative_to(data_dir)
        name = rel.name.casefold()
        if name.endswith(".ndb") or ".ndb-" in name or name.endswith(".ndb-journal"):
            continue
        target = dest_root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)
        saved.append(rel.as_posix())
    return saved


def _make_backup(installation: Path, old_version: str, manifest: dict,
                 data_snapshot: dict | None = None) -> Path:
    backup_root = installation / "updates" / "backups"
    backup_root.mkdir(parents=True, exist_ok=True)
    backup = backup_root / f"{_timestamp()}_v{old_version}"
    backup.mkdir()
    metadata = {
        "product": PRODUCT,
        "created_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "from_version": old_version,
        "to_version": manifest["version"],
        "status": "in_progress",
        "program_roots": list(CONTROLLED_ROOTS),
        "program_files": list(CONTROLLED_FILES),
        "persistent_small_files": _copy_persistent_small_files(installation, backup),
        "data_snapshot": data_snapshot or {},
    }
    _write_json(backup / "backup.json", metadata)
    return backup


def _stage_payload(update_root: Path, validated: list[dict], installation: Path) -> Path:
    stage = installation / "updates" / "staging" / f"stage-{_timestamp()}-{uuid.uuid4().hex[:8]}"
    new_root = stage / "new"
    new_root.mkdir(parents=True)
    payload = update_root / "payload"
    for item in validated:
        rel: Path = item["path"]
        out = new_root / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(payload / rel, out)
    return stage


def _move_to_backup(installation: Path, backup: Path) -> list[str]:
    saved: list[str] = []
    program = backup / "program"
    program.mkdir(exist_ok=True)
    for name in (*CONTROLLED_ROOTS, *CONTROLLED_FILES):
        source = installation / name
        if not source.exists():
            continue
        dest = program / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        os.replace(source, dest)
        saved.append(name)
    return saved


def _install_staged(installation: Path, stage: Path) -> None:
    source_root = stage / "new"
    for name in (*CONTROLLED_ROOTS, *CONTROLLED_FILES):
        source = source_root / name
        if source.exists():
            os.replace(source, installation / name)


def _remove_new_program(installation: Path) -> None:
    for name in (*CONTROLLED_ROOTS, *CONTROLLED_FILES):
        path = installation / name
        if not path.exists():
            continue
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()


def _restore_program(installation: Path, backup: Path) -> None:
    _remove_new_program(installation)
    program = backup / "program"
    for name in (*CONTROLLED_ROOTS, *CONTROLLED_FILES):
        source = program / name
        if source.exists():
            os.replace(source, installation / name)


def _smoke_test(installation: Path, expected_version: str) -> None:
    """Ověří import verze a kompilaci backendu bez spuštění HTTP serveru."""
    version_file = installation / "backend" / "version.py"
    module_name = "_hads_update_version_" + uuid.uuid4().hex
    spec = importlib.util.spec_from_file_location(module_name, version_file)
    if spec is None or spec.loader is None:
        raise UpdateError("Nelze připravit import backend/version.py.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    actual = getattr(module, "APP_VERSION", None)
    if actual != expected_version:
        raise UpdateError(f"Smoke test našel verzi {actual!r}, očekává {expected_version!r}.")
    for py_file in (installation / "backend").rglob("*.py"):
        py_compile.compile(str(py_file), doraise=True)


def _mark_backup(backup: Path, **updates: object) -> None:
    meta = _read_json(backup / "backup.json", "metadata zálohy")
    meta.update(updates)
    _write_json(backup / "backup.json", meta)


def _successful_backups(installation: Path) -> list[Path]:
    root = installation / "updates" / "backups"
    if not root.is_dir():
        return []
    found: list[Path] = []
    for item in root.iterdir():
        meta = item / "backup.json"
        if not item.is_dir() or item.is_symlink() or not meta.is_file() or meta.is_symlink():
            continue
        try:
            rec = _read_json(meta, "metadata zálohy")
        except UpdateError:
            continue
        if rec.get("product") == PRODUCT and rec.get("status") == "successful" and (item / "program").is_dir():
            found.append(item)
    return sorted(found, key=lambda p: p.name, reverse=True)


def _clear_readonly_attribute(path: str | os.PathLike[str]) -> None:
    """Odstraní Windows atribut read-only z položky retenční zálohy.

    Používá se pouze při mazání již vyřazené zálohy. ``follow_symlinks=False``
    brání změně atributu cíle případného odkazu z historické zálohy.
    """
    try:
        mode = os.stat(path, follow_symlinks=False).st_mode
        os.chmod(path, mode | stat.S_IWRITE, follow_symlinks=False)
    except (OSError, NotImplementedError, TypeError):
        # Následující pokus o smazání zachová původní konkrétní chybu.
        pass


def _windows_transient_remove_error(exc: OSError) -> bool:
    """Vrátí True pro chyby, které Windows běžně vrátí při krátkém zámku."""
    return isinstance(exc, PermissionError) or getattr(exc, "winerror", None) in {5, 32, 33}


def _rmtree_readonly_handler(func, path: str, exc_info) -> None:
    """Callback shutil.rmtree pro read-only položky uvnitř staré zálohy."""
    exc = exc_info[1]
    if not isinstance(exc, OSError) or not _windows_transient_remove_error(exc):
        raise exc
    _clear_readonly_attribute(path)
    func(path)


def _remove_obsolete_backup(backup: Path) -> None:
    """Smaže jen nepotřebnou dokončenou zálohu s omezeným Windows retry.

    Tato pomocná funkce nesmí být použita při stagingu, výměně programu,
    vytvoření aktuální zálohy ani rollbacku. Konečná chyba se vrací volajícímu,
    který ji u retenční údržby pouze zapíše jako varování.
    """
    last_error: OSError | None = None
    for attempt in range(RETENTION_REMOVE_ATTEMPTS):
        try:
            shutil.rmtree(backup, onerror=_rmtree_readonly_handler)
            return
        except OSError as exc:
            last_error = exc
            if not _windows_transient_remove_error(exc) or attempt + 1 >= RETENTION_REMOVE_ATTEMPTS:
                raise
            # Krátký backoff nechává antiviru/Průzkumníku čas uvolnit handle.
            time.sleep(RETENTION_RETRY_SECONDS * (attempt + 1))
    assert last_error is not None
    raise last_error


def _apply_retention(installation: Path, protected: Path | None = None) -> None:
    root = installation / "updates" / "backups"
    if not root.is_dir():
        return
    completed: list[Path] = []
    for item in root.iterdir():
        meta = item / "backup.json"
        if not item.is_dir() or item.is_symlink() or not meta.is_file() or meta.is_symlink():
            continue
        try:
            status = _read_json(meta, "metadata zálohy").get("status")
        except UpdateError:
            continue
        # Právě zapisovaná záloha se nikdy nemaže. U dokončených (úspěšných
        # i po bezpečném rollbacku) platí jednotná retence posledních tří.
        if status != "in_progress":
            completed.append(item)
    # Záloha právě dokončené operace nesmí být smazána ani při chybném hodinovém
    # údaji nebo při starším ručně obnoveném názvu zálohy.
    protected_resolved = protected.resolve() if protected is not None else None
    removable = [item for item in completed if protected_resolved is None or item.resolve() != protected_resolved]
    keep_removable = max(BACKUP_KEEP - (1 if protected_resolved is not None else 0), 0)
    for old in sorted(removable, key=lambda p: p.name, reverse=True)[keep_removable:]:
        # Odstraňuje se pouze stará záloha programu/konfigurací, nikdy data instalace.
        # Její zámek nesmí změnit výsledek už úspěšně dokončené aktualizace.
        try:
            _remove_obsolete_backup(old)
        except OSError as exc:
            _message(
                "VAROVÁNÍ",
                f"Nepodařilo se odstranit zastaralou zálohu {old}: {exc}. "
                "Aktualizace zůstává úspěšná; záloha bude ponechána pro pozdější úklid.",
            )


def update(update_root: Path, installation: Path, force: bool = False,
           simulate_failure_after_replace: bool = False,
           simulate_failure_after_rename: bool = False) -> int:
    update_root = update_root.resolve()
    installation = installation.resolve()
    running_updater = Path(__file__).resolve()
    if _under(update_root, installation) or _under(running_updater, installation):
        raise UpdateError(
            "Aktualizátor musí být rozbalen a spuštěn mimo aktualizovanou instalaci; "
            "nesmí běžet z nahrazované složky tools/."
        )
    manifest, files = _validate_manifest(update_root)
    installed = _validate_installation(installation)
    guard = _data_guard(update_root)
    before_data = guard.inventory(installation)
    migration_target = _migration_destination(installation)
    _start_log(installation, "update")
    _message("INFO", f"Ověřen manifest HADS {manifest['version']} ({len(files)} souborů); instalace je {installed}.")
    summary = guard.protected_summary(before_data)
    _message("INFO", "Chráněná uživatelská data před aktualizací: "
             f"{summary['files']} souborů, {summary['bytes']} B, {summary['ndb_files']} databází/sidecarů NDB.")
    target = manifest["version"]
    if _version_tuple(installed) < _version_tuple(manifest["minimum_version"]):
        raise UpdateError(
            f"Nainstalovaná verze {installed} je příliš stará; minimální podporovaná je "
            f"{manifest['minimum_version']}."
        )
    relation = (_version_tuple(target) > _version_tuple(installed)) - (
        _version_tuple(target) < _version_tuple(installed)
    )
    if relation <= 0 and not force:
        word = "stejná" if relation == 0 else "nižší"
        raise UpdateError(f"Cílová verze {target} je {word} než nainstalovaná {installed}; použijte --force.")
    if _server_appears_running(installation):
        raise UpdateError("HADS/server v této instalaci běží. Nejprve jej úplně ukončete.")

    lock = installation / LOCK_RELATIVE
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as exc:
        raise UpdateError("Jiná aktualizace již běží (updates/update.lock).") from exc
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"pid": os.getpid(), "started_at": time.time()}, ensure_ascii=False))
        backup = _make_backup(installation, installed, manifest, before_data)
        stage: Path | None = _stage_payload(update_root, files, installation)
        active = installation
        migrated = False
        try:
            saved = _move_to_backup(installation, backup)
            _mark_backup(backup, moved_program=saved)
            _install_staged(installation, stage)
            if simulate_failure_after_replace:
                raise UpdateError("Simulované selhání po nahrazení souborů.")
            _smoke_test(installation, target)
            _mark_backup(
                backup,
                status="successful",
                completed_at=_dt.datetime.now().astimezone().isoformat(timespec="seconds"),
                root_migration=(
                    {"from_name": installation.name, "to_name": PRODUCT}
                    if migration_target is not None else None
                ),
            )
            _apply_retention(installation, protected=backup)
            # Staging neleží v přejmenovaném kořeni; po úspěšném testu je
            # bezpečně odstraněn ještě před atomickým přejmenováním.
            shutil.rmtree(stage, ignore_errors=True)
            stage = None
            if migration_target is not None:
                active = _move_installation_root(installation, migration_target)
                migrated = True
                _relocate_log(installation, active)
                backup = active / "updates" / "backups" / backup.name
                if simulate_failure_after_rename:
                    raise UpdateError("Simulované selhání po přejmenování instalační složky.")
            after_data = guard.inventory(active)
            difference = guard.compare(before_data, after_data)
            if difference["missing"] or difference["changed"]:
                raise UpdateError(
                    "Kontrola ochrany dat zjistila neočekávanou změnu: "
                    f"chybí {len(difference['missing'])}, změněno {len(difference['changed'])}."
                )
            receipt = guard.write_receipt(active, backup.name, before_data, after_data, backup)
            _message("OK", f"HADS byl bezpečně aktualizován z {installed} na {target}.")
            if migrated:
                _message("INFO", f"Instalační složka byla bezpečně přejmenována na {active}.")
            _message("INFO", f"Záloha programu: {backup}")
            _message("INFO", "Chráněná data byla po aktualizaci zachována: "
                     f"{summary['files']} souborů, {summary['bytes']} B. "
                     f"Po startu proběhne nezávislé ověření ({receipt}).")
            return 0
        except Exception as exc:
            _message("CHYBA", f"Aktualizace selhala: {exc}. Obnovuji původní programové soubory…")
            try:
                _restore_program(active, backup)
                if migrated:
                    _move_installation_root(active, installation)
                    _relocate_log(active, installation)
                    active = installation
                    backup = installation / "updates" / "backups" / backup.name
                _mark_backup(
                    backup, status="rollback_after_failed_update",
                    rolled_back_at=_dt.datetime.now().astimezone().isoformat(timespec="seconds"),
                    failure=str(exc),
                )
                _message("OK", "Rollback proběhl úspěšně; původní program a uživatelská data zůstaly zachovány.")
            except Exception as rollback_exc:
                _message("KRITICKÁ CHYBA", f"Automatický rollback selhal: {rollback_exc}")
            return 1
        finally:
            if stage is not None:
                shutil.rmtree(stage, ignore_errors=True)
    finally:
        try:
            current_lock = (
                migration_target / LOCK_RELATIVE
                if migration_target is not None and migration_target.exists()
                else lock
            )
            current_lock.unlink()
        except OSError:
            pass


def rollback(installation: Path, recovery_internal: bool = False) -> int:
    installation = installation.resolve()
    _validate_installation(installation)
    _start_log(installation, "rollback")
    if not recovery_internal and _server_appears_running(installation):
        raise UpdateError("HADS/server v této instalaci běží. Nejprve jej úplně ukončete.")
    candidates = _successful_backups(installation)
    if not candidates:
        raise UpdateError("Nebyla nalezena úspěšná záloha pro obnovení.")
    backup = candidates[0]
    backup_meta = _read_json(backup / "backup.json", "metadata poslední zálohy")
    migration = backup_meta.get("root_migration")
    restore_root: Path | None = None
    if isinstance(migration, dict) and migration.get("to_name") == PRODUCT:
        old_name = migration.get("from_name")
        if not isinstance(old_name, str) or not old_name or Path(old_name).name != old_name:
            raise UpdateError("Metadata zálohy mají neplatný původní název instalační složky.")
        candidate = installation.parent / old_name
        if candidate != installation and (candidate.exists() or candidate.is_symlink()):
            raise UpdateError(f"Nelze obnovit původní instalační cestu: {candidate} již existuje.")
        restore_root = candidate
    lock = installation / LOCK_RELATIVE
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as exc:
        raise UpdateError("Jiná aktualizace již běží (updates/update.lock).") from exc
    try:
        os.close(fd)
        now = _make_backup(installation, _load_installed_version(installation), {
            "version": "manual-rollback",
        })
        active = installation
        root_restored = False
        try:
            _move_to_backup(installation, now)
            _restore_program(installation, backup)
            restored = _load_installed_version(installation)
            _mark_backup(now, status="successful", completed_at=_dt.datetime.now().astimezone().isoformat(timespec="seconds"))
            _mark_backup(backup, manually_restored_at=_dt.datetime.now().astimezone().isoformat(timespec="seconds"))
            _apply_retention(installation, protected=now)
            if restore_root is not None and restore_root != installation:
                active = _move_installation_root(installation, restore_root)
                root_restored = True
                _relocate_log(installation, active)
            _message("OK", f"Obnovena předchozí verze HADS {restored}. Uživatelská data nebyla změněna.")
            if root_restored:
                _message("INFO", f"Obnovena i původní instalační cesta: {active}.")
            return 0
        except Exception as exc:
            _message("CHYBA", f"Obnovení selhalo: {exc}. Obnovuji aktuální program…")
            _restore_program(active, now)
            if root_restored:
                _move_installation_root(active, installation)
                _relocate_log(active, installation)
                now = installation / "updates" / "backups" / now.name
            _mark_backup(now, status="rollback_after_failed_manual_restore", failure=str(exc))
            return 1
    finally:
        try:
            current_lock = (
                restore_root / LOCK_RELATIVE
                if restore_root is not None and restore_root.exists()
                else lock
            )
            current_lock.unlink()
        except OSError:
            pass


def data_recovery_preview(installation: Path) -> dict:
    """Find the newest verified pre-update small-data backup without changing it."""
    installation = installation.resolve()
    guard = _data_guard(installation=installation)
    candidates = _successful_backups(installation)
    if not candidates:
        raise UpdateError("Nebyla nalezena úspěšná záloha dat po aktualizaci.")
    for backup in candidates:
        meta = _read_json(backup / "backup.json", "metadata zálohy")
        expected = meta.get("data_snapshot")
        source = backup / "data_files"
        if not isinstance(expected, dict) or not source.is_dir():
            continue
        recoverable: list[str] = []
        conflicts: list[str] = []
        invalid: list[str] = []
        incomplete_pairs: list[str] = []
        for name, rec in expected.get("files", {}).items():
            if not isinstance(name, str) or not name.startswith("data/") or not isinstance(rec, dict):
                continue
            rel = Path(name).relative_to("data")
            archived = source / rel
            target = installation / name
            # NDB/sidecary ani velké soubory se do malé zálohy nekopírují a
            # tato obnova je záměrně nikdy nenahrazuje.
            if rec.get("kind") != "file":
                continue
            if not archived.is_file() or archived.is_symlink():
                invalid.append(name)
                continue
            if archived.stat().st_size != rec.get("size") or (
                    rec.get("sha256") and _sha256(archived) != rec.get("sha256")):
                invalid.append(name)
                continue
            if not target.exists():
                recoverable.append(name)
            elif _sha256(target) != _sha256(archived):
                conflicts.append(name)
        # Fallback credentials are a cryptographic pair.  Restoring only one
        # half turns a recoverable condition into an undecryptable blob, so a
        # current partial pair is always preserved for manual investigation.
        pair_names = ["data/" + name for name in _CREDENTIAL_PAIR]
        pair_expected = all(name in expected.get("files", {}) for name in pair_names)
        if pair_expected:
            pair_missing = [name for name in pair_names if not (installation / name).exists()]
            pair_present = [name for name in pair_names if (installation / name).exists()]
            if pair_missing and pair_present:
                recoverable = [name for name in recoverable if name not in pair_missing]
                conflicts.extend(name for name in pair_names if name not in conflicts)
                incomplete_pairs.append("credentials")
        return {
            "backup": str(backup), "recoverable_missing": sorted(recoverable),
            "conflicts": sorted(conflicts), "invalid_backup_files": sorted(invalid),
            "incomplete_pairs": incomplete_pairs,
            "current_difference": guard.compare(expected, guard.inventory(installation)),
        }
    raise UpdateError("Záloha nemá ověřitelný inventář malých persistentních souborů.")


def recover_data(installation: Path, confirm_overwrite: bool = False) -> dict:
    """Restore only missing files by default; conflicts need explicit confirmation."""
    installation = installation.resolve()
    if _server_appears_running(installation):
        raise UpdateError("HADS/server v této instalaci běží. Před obnovou dat jej úplně ukončete.")
    preview = data_recovery_preview(installation)
    if preview["invalid_backup_files"]:
        raise UpdateError("Záloha není nezávisle ověřitelná; obnova nebyla provedena.")
    backup = Path(preview["backup"])
    restored: list[str] = []
    skipped = list(preview["conflicts"])
    names = list(preview["recoverable_missing"])
    if confirm_overwrite:
        names += preview["conflicts"]
        skipped = []
    # Stage a wholly missing fallback credential pair together. The server is
    # required to be stopped above, therefore no reader can observe the short
    # replace sequence. A partial current pair is never touched automatically.
    pair_names = ["data/" + name for name in _CREDENTIAL_PAIR]
    pair_to_restore = [name for name in pair_names if name in names]
    if pair_to_restore:
        if set(pair_to_restore) != set(pair_names):
            raise UpdateError("Dvojice uložených přístupových údajů není v ověřené záloze úplná; obnova nebyla provedena.")
        staged: list[tuple[Path, Path]] = []
        try:
            for name in pair_names:
                rel = Path(name).relative_to("data")
                source, target = backup / "data_files" / rel, installation / name
                target.parent.mkdir(parents=True, exist_ok=True)
                temporary = target.with_name(target.name + ".recovery-" + uuid.uuid4().hex)
                shutil.copy2(source, temporary)
                staged.append((temporary, target))
            for temporary, target in staged:
                os.replace(temporary, target)
                restored.append(target.relative_to(installation).as_posix())
            names = [name for name in names if name not in pair_names]
        finally:
            for temporary, _target in staged:
                try:
                    temporary.unlink()
                except OSError:
                    pass
    for name in names:
        rel = Path(name).relative_to("data")
        source, target = backup / "data_files" / rel, installation / name
        if target.is_symlink():
            raise UpdateError(f"Cíl obnovy nesmí být symbolický odkaz: {name}")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        restored.append(name)
    _start_log(installation, "data_recovery")
    _message("OK", f"Obnova dat dokončena: obnoveno {len(restored)}, přeskočeno kvůli novějším souborům {len(skipped)}.")
    return {**preview, "restored": sorted(restored), "skipped": sorted(skipped)}


def _wait_for_pid_exit(pid: int, timeout: float = 90.0) -> None:
    """Počká na backend spuštěný před aktualizací, bez HTTP komunikace."""
    if pid <= 0:
        raise UpdateError("Neplatný PID procesu, na který má aktualizátor čekat.")
    deadline = time.monotonic() + timeout
    while _pid_is_running(pid):
        if time.monotonic() >= deadline:
            raise UpdateError("Původní HADS se neukončil včas; aktualizace nebyla spuštěna.")
        time.sleep(0.15)


def _save_trusted_release_notes(installation: Path, notes_argument: str | None, version: str) -> None:
    """Zapíše pouze po úspěšné výměně programu, nikdy ne do data/."""
    if not notes_argument:
        return
    source = Path(notes_argument)
    if not source.is_file() or source.is_symlink() or source.stat().st_size > 256 * 1024:
        raise UpdateError("Důvěryhodné poznámky k vydání nejsou bezpečný soubor.")
    try:
        notes = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise UpdateError(f"Nelze načíst důvěryhodné poznámky k vydání: {exc}") from exc
    expected_groups = {"new", "improved", "fixed", "security", "important"}
    if not isinstance(notes, dict) or notes.get("version") != version or not isinstance(notes.get("release_notes"), dict) or set(notes["release_notes"]) != expected_groups:
        raise UpdateError("Důvěryhodné poznámky neodpovídají nainstalované verzi.")
    for entries in notes["release_notes"].values():
        if not isinstance(entries, list) or not all(isinstance(x, str) and 0 < len(x) <= 500 for x in entries):
            raise UpdateError("Důvěryhodné poznámky mají neplatný obsah.")
    target = installation / "updates" / "shared_update_notes.json"
    if target.is_symlink():
        raise UpdateError("Cíl poznámek k vydání nesmí být symbolický odkaz.")
    temporary = target.with_name(target.name + ".tmp-" + uuid.uuid4().hex)
    temporary.write_text(json.dumps(notes, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, target)


def _restart_application(installation: Path) -> None:
    """Spustí launcher po úspěchu i po rollbacku; selhání se zapíše do auditního logu."""
    if os.name == "nt":
        launcher = installation / "spustit.bat"
        executable = installation / "HADS.exe"
        if launcher.is_file() and not launcher.is_symlink():
            # Batch se nespouští přes shell=True: přes explicitní cmd.exe se
            # předá bezpečně i instalační cesta s mezerami a českými znaky.
            command = ["cmd.exe", "/d", "/s", "/c", f'""{launcher}" --after-update"']
        elif executable.is_file() and not executable.is_symlink():
            command = [str(executable)]
        else:
            _message("CHYBA", "Novou verzi nelze spustit: chybí spustit.bat i HADS.exe.")
            return
        try:
            flags = (getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                     | getattr(subprocess, "DETACHED_PROCESS", 0))
            subprocess.Popen(command, cwd=str(installation), close_fds=False,
                             creationflags=flags)
            _message("INFO", "Nová verze HADS byla znovu spuštěna přes spustit.bat.")
        except OSError as exc:
            _message("CHYBA", f"Novou verzi HADS se nepodařilo znovu spustit: {exc}")
        return
    launcher = installation / "spustit.sh"
    if launcher.is_file() and os.access(launcher, os.X_OK):
        try:
            subprocess.Popen([str(launcher), "--after-update"], cwd=str(installation),
                             close_fds=True, start_new_session=True)
            _message("INFO", "Nová verze HADS byla znovu spuštěna přes spustit.sh.")
        except OSError as exc:
            _message("CHYBA", f"Novou verzi HADS se nepodařilo znovu spustit: {exc}")
    else:
        _message("CHYBA", "Novou verzi nelze spustit: spustit.sh chybí nebo nemá právo ke spuštění.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Offline bezpečná aktualizace HADS (pouze standardní knihovna Pythonu)."
    )
    parser.add_argument("install_argument", nargs="?", metavar="CESTA", help="volitelná cesta ke kořeni HADS")
    parser.add_argument("--install", metavar="CESTA", help="cesta ke kořeni existující instalace HADS")
    parser.add_argument("--rollback", action="store_true", help="obnoví poslední úspěšnou zálohu programu")
    parser.add_argument("--recover-data", action="store_true",
                        help="zobrazí nebo obnoví data z poslední ověřené předaktualizační zálohy")
    parser.add_argument("--apply-missing", action="store_true",
                        help="u obnovy dat vrátí jen chybějící ověřené soubory; existující nikdy nepřepíše")
    parser.add_argument("--confirm-overwrite", action="store_true",
                        help="u obnovy dat výslovně povolí přepsání existujících odlišných souborů")
    parser.add_argument("--recovery-internal", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--force", action="store_true", help="povolí stejnou nebo nižší cílovou verzi")
    parser.add_argument("--wait-pid", type=int, help="počkej na ukončení backendu s tímto PID")
    parser.add_argument("--wait-timeout", type=float, default=90.0, help=argparse.SUPPRESS)
    parser.add_argument("--restart", action="store_true", help="po dokončení znovu spustí HADS")
    parser.add_argument("--trusted-release-notes", help=argparse.SUPPRESS)
    parser.add_argument("--simulate-failure-after-replace", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--simulate-failure-after-rename", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    if args.install and args.install_argument:
        raise UpdateError("Použijte pouze jednu cestu: buď argument, nebo --install.")
    explicit = args.install or args.install_argument
    if explicit:
        # Výslovná cesta je neinteraktivní rozhraní pro správce a automatizaci.
        installation = normalize_installation_target(explicit)
        _validate_installation(installation)
    else:
        installation, version = choose_installation_interactively()
        if not _confirm_interactive_operation(installation, version, args.rollback):
            _message("INFO", "Operace byla uživatelem potvrzena jako Ne. Nebyly provedeny žádné změny.")
            return 0
    if args.wait_pid is not None:
        _wait_for_pid_exit(args.wait_pid, args.wait_timeout)
    if args.rollback and args.recover_data:
        raise UpdateError("Zvolte buď rollback programu, nebo obnovu dat.")
    if args.apply_missing and not args.recover_data:
        raise UpdateError("--apply-missing lze použít pouze s --recover-data.")
    if args.recover_data:
        preview = data_recovery_preview(installation)
        _message("INFO", "Náhled obnovy dat: "
                 f"obnovitelné chybějící {len(preview['recoverable_missing'])}, "
                 f"odlišné existující {len(preview['conflicts'])}, "
                 f"neověřitelné v záloze {len(preview['invalid_backup_files'])}.")
        if not args.confirm_overwrite and not args.apply_missing:
            _message("INFO", "Nebyly změněny žádné soubory. Pro obnovu chybějících souborů spusťte "
                     "--recover-data --apply-missing. Pro přepsání odlišných souborů je nutné "
                     "--recover-data --confirm-overwrite.")
            return 0
        recover_data(installation, confirm_overwrite=args.confirm_overwrite)
        return 0
    if args.rollback:
        result = rollback(installation, recovery_internal=args.recovery_internal)
    else:
        result = update(
            Path(__file__).resolve().parent,
            installation,
            args.force,
            args.simulate_failure_after_replace,
            args.simulate_failure_after_rename,
        )
        if result == 0:
            _save_trusted_release_notes(installation, args.trusted_release_notes, _load_installed_version(installation))
    if args.restart:
        # Po neúspěšném update update() již provedl rollback; restart obnoví dostupnost původní verze.
        _restart_application(installation)
    return result


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SelectionCancelled as exc:
        _message("INFO", str(exc))
        raise SystemExit(0)
    except UpdateError as exc:
        _message("CHYBA", str(exc))
        raise SystemExit(2)
    except KeyboardInterrupt:
        _message("CHYBA", "Aktualizace byla přerušena; programové soubory nebyly změněny nebo proběhl rollback.")
        raise SystemExit(130)
    except Exception:
        _message("KRITICKÁ CHYBA", "Neočekávaná chyba aktualizátoru:")
        traceback.print_exc()
        raise SystemExit(3)
