#!/usr/bin/env bash
# ============================================================
#  HADS - Správa diagnostických dat (Linux / macOS)
#  Spustí lokální webovou aplikaci a otevře ji v prohlížeči.
#  Používá pouze vestavěný Python - NIC se neinstaluje.
# ============================================================
set -e
ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT_DIR"

AFTER_UPDATE=0
if [ "${1:-}" = "--after-update" ]; then
  AFTER_UPDATE=1
fi

echo
if [ "$AFTER_UPDATE" -eq 1 ]; then
  echo " HADS - aktualizace dokončena, spouštím novou verzi..."
else
  echo " HADS - spouštím aplikaci..."
fi
echo

# Najdi funkční příkaz Pythonu
PYCMD=""
for c in python3 python py; do
  if command -v "$c" >/dev/null 2>&1; then PYCMD="$c"; break; fi
done

if [ -z "$PYCMD" ]; then
  echo "[CHYBA] Python 3 nebyl nalezen."
  echo "Nainstalujte Python 3.8+ (např. 'sudo apt install python3' nebo z python.org)."
  exit 1
fi

echo "Používám: $PYCMD"
"$PYCMD" --version
echo
echo " Aplikace se otevře v prohlížeči na http://127.0.0.1:8000"
echo " Ukončení: stiskněte Ctrl+C"
echo

cd backend
exec "$PYCMD" server.py
