@echo off
REM ============================================================
REM  HADS - Sprava diagnostickych dat (Windows)
REM  Spusti lokalni webovou aplikaci a otevre ji v prohlizeci.
REM  Pouziva pouze vestaveny Python - NIC se neinstaluje.
REM ============================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"

set "AFTER_UPDATE=0"
if /I "%~1"=="--after-update" set "AFTER_UPDATE=1"

echo.
if "%AFTER_UPDATE%"=="1" (
  echo  HADS - aktualizace dokoncena, spoustim novou verzi...
) else (
  echo  HADS - spoustim aplikaci...
)
echo.

REM Po aktualizaci pouzij novy nativni launcher. START oddeli novou verzi
REM od procesu aktualizatoru, takze zustane bezet i po jeho ukonceni.
if "%AFTER_UPDATE%"=="1" if exist "%~dp0HADS.exe" (
  start "" "%~dp0HADS.exe"
  if not errorlevel 1 exit /b 0
  echo [VAROVANI] HADS.exe se nepodarilo spustit, zkousim Python.
)

REM --- Nejprve prenosny runtime, potom systemovy Python ---
set "PYCMD=%~dp0runtime\python.exe"
if not exist "!PYCMD!" set "PYCMD="
for %%P in (py python python3) do (
  if not defined PYCMD (
    %%P --version >nul 2>&1
    if !errorlevel! equ 0 set "PYCMD=%%P"
  )
)

if not defined PYCMD (
  echo [CHYBA] Python nebyl nalezen.
  echo Nainstalujte Python 3.8+ z https://www.python.org/downloads/
  echo Pri instalaci zaskrtnete "Add Python to PATH".
  echo.
  if "%AFTER_UPDATE%"=="0" pause
  exit /b 1
)

echo Pouzivam: %PYCMD%
"%PYCMD%" --version
echo.
echo  Aplikace se otevre v prohlizeci na http://127.0.0.1:8000
echo  Zavrenim tohoto okna aplikaci ukoncite.
echo.

cd backend
"%PYCMD%" server.py
set "HADS_EXIT=%errorlevel%"

if "%AFTER_UPDATE%"=="0" (
  echo.
  pause
)
exit /b %HADS_EXIT%
