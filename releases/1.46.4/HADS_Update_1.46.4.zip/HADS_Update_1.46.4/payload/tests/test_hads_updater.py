"""Regrese bezpečného offline aktualizátoru HADS bez spuštění HTTP serveru."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zipfile


APP_ROOT = Path(__file__).resolve().parents[1]


def _load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


UPDATER = _load_module("hads_updater_test", APP_ROOT / "tools" / "hads_updater.py")
RELEASE = _load_module("hads_release_test", APP_ROOT / "tools" / "build_release.py")
TARGET_VERSION = RELEASE.VERSION
VALIDATOR_PATH = APP_ROOT / "tools" / "validate_release.py"
VALIDATOR = _load_module("hads_validate_release_test", VALIDATOR_PATH) if VALIDATOR_PATH.is_file() else None


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _hash_tree(root: Path) -> dict[str, str]:
    return {
        item.relative_to(root).as_posix(): _sha256(item)
        for item in sorted(root.rglob("*")) if item.is_file()
    }


def _hash_program(installation: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for name in (*UPDATER.CONTROLLED_ROOTS, *UPDATER.CONTROLLED_FILES):
        item = installation / name
        if item.is_dir():
            result.update({sub.relative_to(installation).as_posix(): _sha256(sub)
                           for sub in item.rglob("*") if sub.is_file()})
        elif item.is_file():
            result[name] = _sha256(item)
    return result


def _build_test_update(update_root: Path) -> None:
    payload = update_root / "payload"
    payload.mkdir(parents=True)
    files: list[dict[str, object]] = []
    for name in (*UPDATER.CONTROLLED_ROOTS, *UPDATER.CONTROLLED_FILES):
        source = APP_ROOT / name
        candidates = source.rglob("*") if source.is_dir() else (source,)
        for item in sorted(candidates):
            if not item.is_file() or "__pycache__" in item.parts or ".pytest_cache" in item.parts:
                continue
            rel = item.relative_to(APP_ROOT)
            target = payload / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)
            files.append({"path": rel.as_posix(), "size": target.stat().st_size, "sha256": _sha256(target)})
    shutil.copy2(APP_ROOT / "tools" / "hads_updater.py", update_root / "hads_updater.py")
    (update_root / "manifest.json").write_text(json.dumps({
        "product": "HADS", "version": TARGET_VERSION, "minimum_version": "1.29.0",
        "files": files, "preserve": ["data/**"], "release_notes": "Testovací manifest HADS.",
    }, ensure_ascii=False), encoding="utf-8")


def _assert_clean_tree(test: unittest.TestCase, root: Path,
                       skip_dirs: tuple = ()) -> None:
    token = "".join(("a", "dash"))
    ascii_token = b"".join((b"a", b"dash")).lower()
    utf16_le = token.encode("utf-16le").lower()
    utf16_be = token.encode("utf-16be").lower()
    for item in root.rglob("*"):
        if "__pycache__" in item.parts or ".pytest_cache" in item.parts:
            continue
        if any(part in skip_dirs for part in item.relative_to(root).parts):
            continue
        test.assertNotIn(token, str(item).casefold(), str(item))
        if item.is_file():
            raw = item.read_bytes().lower()
            test.assertNotIn(ascii_token, raw, str(item))
            test.assertNotIn(utf16_le, raw, str(item))
            test.assertNotIn(utf16_be, raw, str(item))


class HadsUpdaterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads updater test ")
        self.root = Path(self.temp.name)
        self.update_root = self.root / f"HADS_Update_{TARGET_VERSION}"
        _build_test_update(self.update_root)

    def tearDown(self):
        self.temp.cleanup()

    def installation(self, folder_name: str = "HADS", parent: Path | None = None) -> Path:
        install = (parent or self.root) / folder_name
        (install / "backend").mkdir(parents=True)
        (install / "frontend").mkdir()
        (install / "tests").mkdir()
        (install / "data" / "podniky" / "zákazník").mkdir(parents=True)
        (install / "backend" / "version.py").write_text('APP_VERSION = "1.32.2"\n', encoding="utf-8")
        (install / "backend" / "server.py").write_text("VALUE = 'old server'\n", encoding="utf-8")
        (install / "backend" / "legacy.py").write_text("LEGACY = True\n", encoding="utf-8")
        (install / "frontend" / "index.html").write_text("<h1>stará aplikace</h1>", encoding="utf-8")
        (install / "tests" / "test_legacy.py").write_text("assert True\n", encoding="utf-8")
        (install / "README.md").write_text("Stará dokumentace\n", encoding="utf-8")
        (install / "spustit.bat").write_text("@echo old\n", encoding="utf-8")
        (install / "spustit.sh").write_text("#!/bin/sh\necho old\n", encoding="utf-8")
        (install / "data" / "měření.ndb").write_bytes(b"NDB marker must survive")
        (install / "data" / "ai_config.json").write_text('{"test_marker":"zachovat"}', encoding="utf-8")
        (install / "data" / "podniky" / "zákazník" / "report_history.json").write_text(
            '{"history":"marker"}', encoding="utf-8")
        return install

    def test_direct_hads_install_updates_and_preserves_data(self):
        install = self.installation()
        before_data = _hash_tree(install / "data")
        self.assertEqual(UPDATER.update(self.update_root, install), 0)
        self.assertEqual(UPDATER._load_installed_version(install), TARGET_VERSION)
        self.assertEqual(_hash_tree(install / "data"), before_data)
        self.assertTrue(list((install / "updates" / "backups").glob("*/backup.json")))

    def test_linux_post_update_restart_uses_detached_shell_launcher(self):
        install = self.installation()
        launcher = install / "spustit.sh"
        launcher.chmod(0o755)
        with mock.patch.object(UPDATER.subprocess, "Popen") as popen:
            UPDATER._restart_application(install)
        command, = popen.call_args.args
        self.assertEqual(command, [str(launcher), "--after-update"])
        self.assertTrue(popen.call_args.kwargs["start_new_session"])

    def test_windows_post_update_restart_uses_batch_launcher(self):
        install = self.installation()
        launcher = install / "spustit.bat"
        with mock.patch.object(UPDATER.os, "name", "nt"), \
             mock.patch.object(UPDATER.subprocess, "Popen") as popen:
            UPDATER._restart_application(install)
        command, = popen.call_args.args
        self.assertEqual(command[:4], ["cmd.exe", "/d", "/s", "/c"])
        self.assertIn(str(launcher), command[4])
        self.assertIn("--after-update", command[4])

    def test_launchers_support_post_update_mode(self):
        shell = (APP_ROOT / "spustit.sh").read_text(encoding="utf-8")
        batch = (APP_ROOT / "spustit.bat").read_text(encoding="utf-8")
        self.assertIn("--after-update", shell)
        self.assertIn("--after-update", batch)
        self.assertIn("start \"\" \"%~dp0HADS.exe\"", batch)

    def test_structural_legacy_migration_renames_root_and_manual_rollback_restores_it(self):
        legacy = self.installation("Původní instalace")
        before_program = _hash_program(legacy)
        before_data = _hash_tree(legacy / "data")
        self.assertEqual(UPDATER.normalize_installation_target(legacy.parent), legacy.resolve())
        self.assertEqual(UPDATER.update(self.update_root, legacy), 0)
        renamed = self.root / "HADS"
        self.assertFalse(legacy.exists())
        self.assertEqual(UPDATER._load_installed_version(renamed), TARGET_VERSION)
        self.assertEqual(_hash_tree(renamed / "data"), before_data)
        self.assertEqual(UPDATER.rollback(renamed), 0)
        self.assertTrue(legacy.is_dir())
        self.assertFalse(renamed.exists())
        self.assertEqual(UPDATER._load_installed_version(legacy), "1.32.2")
        self.assertEqual(_hash_program(legacy), before_program)
        self.assertEqual(_hash_tree(legacy / "data"), before_data)

    def test_collision_with_hads_sibling_blocks_before_changes(self):
        legacy = self.installation("Původní instalace")
        (self.root / "HADS").mkdir()
        before = _hash_tree(legacy)
        with self.assertRaises(UPDATER.UpdateError):
            UPDATER.update(self.update_root, legacy)
        self.assertEqual(_hash_tree(legacy), before)

    def test_failure_after_replace_rolls_back_program_and_path(self):
        legacy = self.installation("Původní instalace")
        before_program = _hash_program(legacy)
        before_data = _hash_tree(legacy / "data")
        self.assertEqual(UPDATER.update(self.update_root, legacy, simulate_failure_after_replace=True), 1)
        self.assertTrue(legacy.is_dir())
        self.assertFalse((self.root / "HADS").exists())
        self.assertEqual(_hash_program(legacy), before_program)
        self.assertEqual(_hash_tree(legacy / "data"), before_data)

    def test_failure_after_root_rename_restores_program_and_path(self):
        legacy = self.installation("Původní instalace")
        before_program = _hash_program(legacy)
        before_data = _hash_tree(legacy / "data")
        self.assertEqual(UPDATER.update(self.update_root, legacy, simulate_failure_after_rename=True), 1)
        self.assertTrue(legacy.is_dir())
        self.assertFalse((self.root / "HADS").exists())
        self.assertEqual(UPDATER._load_installed_version(legacy), "1.32.2")
        self.assertEqual(_hash_program(legacy), before_program)
        self.assertEqual(_hash_tree(legacy / "data"), before_data)

    def test_damaged_hash_is_rejected_before_any_change(self):
        install = self.installation()
        before = _hash_tree(install)
        payload_file = self.update_root / "payload" / "backend" / "version.py"
        payload_file.write_text('APP_VERSION = "9.9.9"\n', encoding="utf-8")
        with self.assertRaises(UPDATER.UpdateError):
            UPDATER.update(self.update_root, install)
        self.assertEqual(_hash_tree(install), before)

    def test_picker_detects_only_one_structural_child_and_retries(self):
        legacy = self.installation("Původní instalace")
        choices = iter([str(self.root / "neplatna"), str(legacy.parent)])
        errors: list[str] = []
        selected, version = UPDATER.choose_installation_interactively(lambda: next(choices), errors.append)
        self.assertEqual(selected, legacy.resolve())
        self.assertEqual(version, "1.32.2")
        self.assertEqual(len(errors), 1)
        self.assertIn("není instalace HADS", errors[0])

    def test_ambiguous_parent_is_rejected(self):
        self.installation("První")
        self.installation("Druhá")
        with self.assertRaises(UPDATER.UpdateError):
            UPDATER.normalize_installation_target(self.root)

    def test_real_cli_update_and_rollback_in_czech_special_path(self):
        parent = self.root / "Česká cesta & (ověření)"
        install = self.installation("HADS", parent)
        before_data = _hash_tree(install / "data")
        updated = subprocess.run(
            [sys.executable, str(self.update_root / "hads_updater.py"), "--install", str(parent)],
            text=True, encoding="utf-8", capture_output=True, check=False,
        )
        self.assertEqual(updated.returncode, 0, updated.stdout + updated.stderr)
        self.assertEqual(UPDATER._load_installed_version(install), TARGET_VERSION)
        restored = subprocess.run(
            [sys.executable, str(self.update_root / "hads_updater.py"), "--rollback", "--install", str(install)],
            text=True, encoding="utf-8", capture_output=True, check=False,
        )
        self.assertEqual(restored.returncode, 0, restored.stdout + restored.stderr)
        self.assertEqual(UPDATER._load_installed_version(install), "1.32.2")
        self.assertEqual(_hash_tree(install / "data"), before_data)

    def test_release_archives_have_hads_root_and_no_forbidden_sequence(self):
        app_zip = self.root / f"HADS_aplikace_v{TARGET_VERSION}.zip"
        update_zip = self.root / f"HADS_Update_{TARGET_VERSION}.zip"
        RELEASE.build_clean_application(app_zip)
        RELEASE.build_update(update_zip)
        for archive_path, root_name in (
            (app_zip, f"HADS_aplikace_v{TARGET_VERSION}"),
            (update_zip, f"HADS_Update_{TARGET_VERSION}"),
        ):
            with zipfile.ZipFile(archive_path) as archive:
                roots = {Path(name).parts[0] for name in archive.namelist() if name}
                self.assertEqual(roots, {root_name})
                token = "".join(("a", "dash"))
                self.assertTrue(all(token not in name.casefold() for name in archive.namelist()))
                extracted = self.root / (root_name + "_extracted")
                archive.extractall(extracted)
            _assert_clean_tree(self, extracted)
        with zipfile.ZipFile(update_zip) as archive:
            self.assertTrue(all("/data/" not in ("/" + name) for name in archive.namelist()))
            manifest = json.loads(archive.read(f"HADS_Update_{TARGET_VERSION}/manifest.json"))
            self.assertTrue(all("data" not in row["path"].split("/") for row in manifest["files"]))
        with zipfile.ZipFile(app_zip) as archive:
            names = archive.namelist()
            self.assertTrue(all(not name.startswith("HADS/data/") for name in names))
            self.assertIn(f"HADS_aplikace_v{TARGET_VERSION}/clean_seed/HADS/data/ai_config.json", names)
            self.assertIn(f"HADS_aplikace_v{TARGET_VERSION}/Instalovat HADS.bat", names)

    def test_new_lock_pid_reuse_is_treated_as_verified_stale_but_matching_identity_blocks(self):
        install = self.installation()
        lock = install / "data" / "hads_server.lock"
        record = {
            "format": 2, "pid": 4242, "port": 8000,
            "installation_root": str(install.resolve()),
            "installation_fingerprint": hashlib.sha256(str(install.resolve()).casefold().encode("utf-8")).hexdigest(),
            "process_identity": "proc-start:old",
        }
        lock.write_text(json.dumps(record), encoding="utf-8")
        with mock.patch.object(UPDATER, "_pid_is_running", return_value=True), \
             mock.patch.object(UPDATER, "_lock_process_identity_matches", return_value=False):
            self.assertFalse(UPDATER._server_appears_running(install))
        self.assertFalse(lock.exists(), "PID reuse nesmí držet falešný zámek")
        lock.write_text(json.dumps(record), encoding="utf-8")
        with mock.patch.object(UPDATER, "_pid_is_running", return_value=True), \
             mock.patch.object(UPDATER, "_lock_process_identity_matches", return_value=True):
            self.assertTrue(UPDATER._server_appears_running(install))

    def test_retained_backup_access_denied_warns_but_keeps_successful_update(self):
        install = self.installation()
        (install / "backend" / "version.py").write_text('APP_VERSION = "1.34.5"\n', encoding="utf-8")
        backups = install / "updates" / "backups"
        denied_name = "20260819-112444-756641_v1.34.2"
        for name in (denied_name, "20260819-112500-000000_v1.34.3", "20260819-112600-000000_v1.34.4", "20260819-112700-000000_v1.34.5"):
            backup = backups / name
            (backup / "program" / "tools").mkdir(parents=True)
            (backup / "program" / "tools" / "held.py").write_text("# historical backup\n", encoding="utf-8")
            (backup / "backup.json").write_text(json.dumps({
                "product": "HADS", "status": "successful", "from_version": "1.34.2", "to_version": "1.34.3",
            }), encoding="utf-8")

        real_rmtree = UPDATER.shutil.rmtree
        def deny_old_tools(path, *args, **kwargs):
            if Path(path).name == denied_name:
                error = PermissionError(13, "Přístup byl odepřen", str(path))
                error.winerror = 5
                raise error
            return real_rmtree(path, *args, **kwargs)

        with mock.patch.object(UPDATER.shutil, "rmtree", side_effect=deny_old_tools), \
             mock.patch.object(UPDATER.time, "sleep") as retry_sleep:
            self.assertEqual(UPDATER.update(self.update_root, install), 0)
        self.assertEqual(UPDATER._load_installed_version(install), TARGET_VERSION)
        self.assertTrue((backups / denied_name / "program" / "tools").is_dir())
        self.assertGreaterEqual(retry_sleep.call_count, UPDATER.RETENTION_REMOVE_ATTEMPTS - 1)
        successful = [
            (item, json.loads((item / "backup.json").read_text(encoding="utf-8")))
            for item in UPDATER._successful_backups(install)
        ]
        latest = next(meta for item, meta in successful if meta.get("from_version") == "1.34.5")
        self.assertEqual(latest.get("status"), "successful")
        self.assertTrue((next(item for item, meta in successful if meta is latest) / "program").is_dir())
        logs = "\n".join(log.read_text(encoding="utf-8") for log in (install / "updates" / "logs").glob("update_*.log"))
        self.assertIn("[VAROVÁNÍ] Nepodařilo se odstranit zastaralou zálohu", logs)
        self.assertIn(denied_name, logs)
        self.assertIn("Aktualizace zůstává úspěšná", logs)

    def test_readonly_retention_cleanup_retries_windows_access_errors(self):
        backup = self.root / "old-backup"
        readonly_dir = backup / "program" / "tools"
        readonly_file = readonly_dir / "held.py"
        readonly_dir.mkdir(parents=True)
        readonly_file.write_text("# read only\n", encoding="utf-8")
        # The fake Windows onerror calls below represent FILE_ATTRIBUTE_READONLY
        # on both a file and its directory without relying on POSIX deletion rules.
        real_rmtree = UPDATER.shutil.rmtree
        calls = 0

        def win_error(code: int) -> PermissionError:
            error = PermissionError(13, "Windows access denied", str(backup))
            error.winerror = code
            return error

        def rmtree_with_windows_lock(path, *, onerror=None, **kwargs):
            nonlocal calls
            calls += 1
            if calls == 1:
                assert onerror is not None
                onerror(os.unlink, str(readonly_file), (PermissionError, win_error(5), None))
                onerror(os.rmdir, str(readonly_dir), (PermissionError, win_error(5), None))
                raise win_error(32)
            return real_rmtree(path, onerror=onerror, **kwargs)

        with mock.patch.object(UPDATER.shutil, "rmtree", side_effect=rmtree_with_windows_lock), \
             mock.patch.object(UPDATER.os, "chmod") as chmod, \
             mock.patch.object(UPDATER.time, "sleep") as retry_sleep:
            UPDATER._remove_obsolete_backup(backup)
        self.assertFalse(backup.exists())
        self.assertEqual(calls, 2)
        self.assertEqual(retry_sleep.call_args_list, [mock.call(UPDATER.RETENTION_RETRY_SECONDS)])
        cleared = {Path(call.args[0]) for call in chmod.call_args_list}
        self.assertTrue({readonly_file, readonly_dir}.issubset(cleared))

    def test_update_refuses_updater_loaded_from_replaced_tools_directory(self):
        install = self.installation()
        embedded_path = install / "tools" / "hads_updater.py"
        embedded_path.parent.mkdir()
        shutil.copy2(APP_ROOT / "tools" / "hads_updater.py", embedded_path)
        embedded = _load_module("hads_updater_embedded_test", embedded_path)
        before_program = _hash_program(install)
        with self.assertRaises(embedded.UpdateError) as raised:
            embedded.update(self.update_root, install)
        self.assertIn("nesmí běžet z nahrazované složky tools/", str(raised.exception))
        self.assertEqual(_hash_program(install), before_program)

    def test_source_tree_has_no_forbidden_sequence(self):
        # `data/` jsou uživatelské měřicí databáze; do balíčku nikdy nejdou
        # a jejich obsah HADS neurčuje. Balíčky se kontrolují celé (výše).
        _assert_clean_tree(self, APP_ROOT, skip_dirs=("data", "updates"))


@unittest.skipUnless(VALIDATOR is not None, "Nástroj validačního release není součástí distribučního ZIPu.")
class ReleaseValidationPredecessorTests(unittest.TestCase):
    """Validátor smí přijmout jen skutečný clean-seed 1.37.0 předchůdce."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="hads predecessor validation ")
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def _predecessor_zip(self, filename: str, declared_version: str) -> Path:
        archive = self.root / filename
        root = f"HADS_aplikace_v{VALIDATOR.PREVIOUS_VERSION}/clean_seed/HADS"
        with zipfile.ZipFile(archive, "w") as z:
            z.writestr(root + "/backend/version.py", f'APP_VERSION = "{declared_version}"\n')
            z.writestr(root + "/frontend/index.html", "<title>HADS</title>")
        return archive

    def test_constructor_requires_real_declared_previous_predecessor(self):
        predecessor = self._predecessor_zip(
            f"HADS_aplikace_v{VALIDATOR.PREVIOUS_VERSION}.zip",
            VALIDATOR.PREVIOUS_VERSION)
        with mock.patch.object(VALIDATOR, "PREVIOUS_APP_ZIP", predecessor):
            installation, evidence = VALIDATOR._construct_predecessor(self.root / "valid")
        self.assertEqual(VALIDATOR._installed_version(installation), VALIDATOR.PREVIOUS_VERSION)
        self.assertEqual(evidence["predecessor_observed_version"], VALIDATOR.PREVIOUS_VERSION)
        self.assertEqual(evidence["predecessor_archive_sha256"], _sha256(predecessor))

    def test_constructor_rejects_only_renamed_current_package(self):
        renamed_current = self._predecessor_zip(
            f"HADS_aplikace_v{VALIDATOR.PREVIOUS_VERSION}.zip",
            VALIDATOR.VERSION)
        with mock.patch.object(VALIDATOR, "PREVIOUS_APP_ZIP", renamed_current):
            with self.assertRaisesRegex(
                    RuntimeError, f"očekává se skutečné {re.escape(VALIDATOR.PREVIOUS_VERSION)}"):
                VALIDATOR._construct_predecessor(self.root / "invalid")


if __name__ == "__main__":
    unittest.main()
