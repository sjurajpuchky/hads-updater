#!/usr/bin/env python3
"""Sestaví ověřené distribuční ZIPy HADS 1.46.5 pouze pomocí stdlib."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import zipfile


APP_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = APP_ROOT.parent
VERSION = "1.46.5"
PRODUCT = "HADS"
PROGRAM_ROOTS = ("backend", "frontend", "tests", "assets", "launcher")
PROGRAM_FILES = (
    "README.md", "README_AKTUALIZACE.txt", "spustit.bat", "spustit.sh", "HADS.exe",
    "tools/build_release.py", "tools/hads_database_replacer.py",
    "tools/hads_updater.py", "tools/publish_shared_release.py",
)
EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".git"}
FORBIDDEN_CREDENTIAL_NAMES = {"ai_credentials.bin", "ai_credentials.machinekey"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def allowed_program_files(root: Path):
    for top in PROGRAM_ROOTS:
        folder = root / top
        for item in sorted(folder.rglob("*")):
            if not item.is_file() or item.is_symlink() or any(part in EXCLUDED_PARTS for part in item.relative_to(root).parts):
                continue
            yield item
    for name in PROGRAM_FILES:
        item = root / name
        if not item.is_file() or item.is_symlink():
            raise RuntimeError(f"Chybí distribuční soubor {item}")
        yield item


def copy_program(source: Path, destination: Path) -> list[dict]:
    manifest_files: list[dict] = []
    for item in allowed_program_files(source):
        rel = item.relative_to(source)
        target = destination / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)
        manifest_files.append({
            "path": rel.as_posix(),
            "size": target.stat().st_size,
            "sha256": sha256(target),
        })
    return manifest_files


def zip_tree(source: Path, destination: Path, prefix: str = "") -> None:
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for item in sorted(source.rglob("*")):
            if item.is_dir() or item.is_symlink():
                continue
            arcname = (PurePosixPath(prefix) / item.relative_to(source)).as_posix() if prefix else item.relative_to(source).as_posix()
            if item.suffix.lower() == ".sh":
                original_mode = item.stat().st_mode
                try:
                    item.chmod(0o755)
                    archive.write(item, arcname)
                finally:
                    item.chmod(original_mode)
            else:
                archive.write(item, arcname)


def _retired_brand_tokens():
    text_token = "".join(("a", "dash"))
    return (b"".join((b"a", b"dash")), text_token.encode("utf-16le"),
            text_token.encode("utf-16be"))


def _check_retired_brand(item: Path) -> None:
    token, utf16_le, utf16_be = _retired_brand_tokens()
    if token in item.name.encode("utf-8", "ignore").lower():
        raise RuntimeError(f"Název obsahuje nepovolené historické označení: {item}")
    raw = item.read_bytes().lower()
    if token in raw or utf16_le in raw or utf16_be in raw:
        raise RuntimeError(f"Obsah obsahuje nepovolené historické označení: {item}")


def assert_no_retired_brand(root: Path) -> None:
    """Ověří názvy i binární obsah celého stromu (rozbalený balíček)."""
    for item in root.rglob("*"):
        if item.is_file():
            _check_retired_brand(item)
        elif b"".join((b"a", b"dash")) in item.name.encode("utf-8", "ignore").lower():
            raise RuntimeError(f"Název obsahuje nepovolené historické označení: {item}")


def assert_source_has_no_retired_brand(root: Path) -> None:
    """Totéž pro zdrojový strom, ale jen nad distribuovanými soubory.

    `data/` obsahuje uživatelské měřicí databáze — ty se nedistribuují
    a jejich obsah HADS neurčuje, takže by kontrola hlásila poplach nad
    cizím textem. Balíček se níže kontroluje celý.
    """
    for item in allowed_program_files(root):
        _check_retired_brand(item)


def write_text(path: Path, content: str) -> None:
    path.write_text(content.replace("\n", "\r\n") if path.suffix == ".bat" else content, encoding="utf-8", newline="")


def update_launchers(update_root: Path) -> None:
    # UTF-8 bez BOM + chcp/PYTHONUTF8 opraví české znaky v tradičním CMD.
    # %* ponechá správné quoting cest s mezerami, &, závorkami a diakritikou.
    write_text(update_root / "Aktualizovat HADS.bat", r"""@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PYCMD="
for %%P in (py python python3) do (
  if not defined PYCMD (
    %%P --version >nul 2>&1 && set "PYCMD=%%P"
  )
)
if not defined PYCMD (
  echo [CHYBA] Python 3.8+ nebyl nalezen. Nainstalujte jej z https://www.python.org/downloads/
  pause
  exit /b 1
)
if "%~1"=="" (
  REM Bez argumentu Python otevře standardní dialog pro výběr složky HADS.
  "%PYCMD%" "%~dp0hads_updater.py"
) else (
  REM Explicitní cesta nebo --install zůstává neinteraktivní pro správce a automatizaci.
  "%PYCMD%" "%~dp0hads_updater.py" %*
)
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Aktualizace nebyla provedena. Podrobnosti jsou ve výpisu výše.
pause
exit /b %RC%
""")
    write_text(update_root / "Obnovit předchozí verzi.bat", r"""@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PYCMD="
for %%P in (py python python3) do (
  if not defined PYCMD (
    %%P --version >nul 2>&1 && set "PYCMD=%%P"
  )
)
if not defined PYCMD (
  echo [CHYBA] Python 3.8+ nebyl nalezen.
  pause
  exit /b 1
)
if "%~1"=="" (
  REM Bez argumentu Python otevře standardní dialog a ukáže poslední zálohu.
  "%PYCMD%" "%~dp0hads_updater.py" --rollback
) else (
  "%PYCMD%" "%~dp0hads_updater.py" --rollback %*
)
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Obnovení nebylo provedeno. Podrobnosti jsou ve výpisu výše.
pause
exit /b %RC%
""")
    write_text(update_root / "Obnovit data po aktualizaci.bat", r"""@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
set "PYCMD="
for %%P in (py python python3) do (
  if not defined PYCMD (
    %%P --version >nul 2>&1 && set "PYCMD=%%P"
  )
)
if not defined PYCMD (
  echo [CHYBA] Python 3.8+ nebyl nalezen.
  pause
  exit /b 1
)
echo Zobrazí se náhled a obnoví se jen chybějící ověřené soubory.
echo Existující odlišné soubory se nikdy nepřepisují bez parametru --confirm-overwrite.
"%PYCMD%" "%~dp0hads_updater.py" --recover-data --apply-missing %*
pause
""")
    write_text(update_root / "aktualizovat_hads.sh", """#!/usr/bin/env sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PYTHON=""
for candidate in python3 python py; do
  if command -v "$candidate" >/dev/null 2>&1; then PYTHON="$candidate"; break; fi
done
if [ -z "$PYTHON" ]; then
  echo "[CHYBA] Python 3.8+ nebyl nalezen." >&2
  exit 1
fi
# Bez argumentu updater nabídne český interaktivní textový výběr a potvrzení.
exec "$PYTHON" "$HERE/hads_updater.py" "$@"
""")
    write_text(update_root / "obnovit_predchozi_verzi.sh", """#!/usr/bin/env sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PYTHON=""
for candidate in python3 python py; do
  if command -v "$candidate" >/dev/null 2>&1; then PYTHON="$candidate"; break; fi
done
if [ -z "$PYTHON" ]; then
  echo "[CHYBA] Python 3.8+ nebyl nalezen." >&2
  exit 1
fi
exec "$PYTHON" "$HERE/hads_updater.py" --rollback "$@"
""")
    write_text(update_root / "obnovit_data_po_aktualizaci.sh", """#!/usr/bin/env sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec python3 "$HERE/hads_updater.py" --recover-data --apply-missing "$@"
""")
    for name in ("aktualizovat_hads.sh", "obnovit_predchozi_verzi.sh", "obnovit_data_po_aktualizaci.sh"):
        (update_root / name).chmod(0o755)


def build_update(output: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="hads-release-") as temp:
        work = Path(temp) / f"HADS_Update_{VERSION}"
        payload = work / "payload"
        payload.mkdir(parents=True)
        files = copy_program(APP_ROOT, payload)
        shutil.copy2(APP_ROOT / "tools" / "hads_updater.py", work / "hads_updater.py")
        update_launchers(work)
        manifest = {
            "product": PRODUCT,
            "version": VERSION,
            "minimum_version": "1.34.4",
            "files": files,
            "preserve": [
                "data/**/*.ndb",
                "data/podniky/**",
                "data/ai_config.json",
                "data/ai_credentials.bin",
                "data/ai_credentials.machinekey",
                "data/ai_examples.json",
                "data/ai_prompts.json",
                "data/custom_norms.json",
                "data/report_drafts.json",
                "data/report_history.json",
                "data/report_settings.json",
                "data/machine_config.json",
                "data/company.json",
                "data/branding/settings.json",
                "data/branding/logo.jpg",
                "data/fft_settings.json",
                "data/** (všechna další uživatelská data)",
                "runtime/** (neměnný přenosný Python runtime)",
            ],
            "release_notes": (
                "Verze 1.46.0 přidává na kartu Protokol zaškrtávátko „Vždy plné FFT "
                "podklady“. U stroje celého v pásmu A se dosud spektrální nálezy "
                "vůbec nepočítaly (úspora tokenů), takže je nešlo vyžádat ani "
                "Doplňujícími pokyny — AI spektra prostě nedostala. Nově lze úsporu "
                "vypnout a detailní FFT rozbor si vynutit i u zdravého stroje. "
                "Verze 1.45.0 zrušila falešné výtky k rozsahu měření. Kontrola vhodnosti "
                "F_max se nově řídí rolí spektra: pásmo vlastních frekvencí ložisek "
                "(do 2000 Hz) se vyžaduje jen u nedemodulovaného spektra zrychlení, "
                "protože obálka je z principu nese už přepočtené dolů na poruchové "
                "frekvence a spektrum rychlosti ložiska neřeší vůbec. Dřív padala "
                "výtka na každé spektrum a AI pak psala o nedostatečném rozsahu "
                "i tam, kde tři harmonické BPFI ležely hluboko uvnitř rozsahu. "
                "Podklady pro AI navíc počítaly pásmo A–D jinak než tabulka protokolu: "
                "odhad hranice A/B se nyní na obou místech dělá jen u mezí z normy. "
                "Verze 1.44.0 dala strukturu závěru do rukou zákazníka. Počet a pořadí "
                "bodů závěru i to, co se má vůbec hodnotit, určuje nově výhradně "
                "editovatelná šablona v Nastavení → AI prompty. Dřív ji přebíjel "
                "pevný odstavec v kódu, takže upravená šablona neměla na výstup "
                "vliv. Doplňující pokyny pro AI u konkrétního protokolu mají "
                "přednost před šablonou, takže lze pro jedno měření změnit "
                "i rozsah hodnocení (např. „jde o třídič, rychlost dle normy "
                "nehodnoť\"). Neměnný zůstává pouze JSON obal odpovědi, aby šel "
                "výsledek načíst do editoru protokolu. Výchozí šablony popisují "
                "totéž co dosud, takže beze změny nastavení se výstupy nemění. "
                "Verze 1.43.0 opravila hodnocení valivých ložisek. Zrychlení a obálka "
                "zrychlení se v protokolu berou VÝHRADNĚ z horizontálního směru "
                "(statické hodnoty i FFT spektra); dřív se bral maximum z H/V/A, "
                "takže se do stavu jednoho ložiska mísily tři různé body. U těchto "
                "dvou veličin se navíc už NEODHADUJE hranice A/B jako polovina meze "
                "výstrahy — mají jen dvě skutečné meze, a odhad vyráběl pásmo B "
                "u hodnot hluboko pod limitem. Je-li v podkladech pro AI otáčková "
                "frekvence pouze detekovaná a neuložená na kartě stroje, podklady "
                "to výslovně řeknou i s návodem, jak to napravit. "
                "Verze 1.42.0 přidala opory hodnocení, které metodologie řadí nad "
                "normu: baseline ze známého dobrého stavu (ukládá se jen datum), "
                "ručně vybraný sesterský stroj a rychlost změny trendu v % za 30 "
                "dní. Podklady uvádějí, které opory jsou k dispozici, a chybí-li "
                "všechny, řeknou to. Balíček je kumulativní — z verzí starších než "
                "1.42.0 přináší i vše z 1.42.0, 1.41.0 a 1.40.0. "
                "Verze 1.41.0 dala AI skutečný obsah FFT spekter: aplikace sama "
                "deterministicky spočítá vrcholy, řády otáčkové frekvence a amplitudy "
                "na harmonických i poruchových frekvencích ložisek a předá je jako "
                "hotové nálezy; model už nic nepřepočítává. Hodnoty se porovnávají "
                "proti platné mezi včetně jejího původu (norma má přednost před "
                "databází přístroje). Odborný postup je v jedné editovatelné "
                "metodologii v Nastavení → AI prompty. Karta stroje má volitelnou "
                "kinematiku (lopatky, póly, zuby, řemenový převod), která mění "
                "odhad ze spektra na přesný výpočet. Navazuje na 1.40.0 "
                "(personalizace loga a údajů firmy), která zůstává beze změny."
            ),
        }
        (work / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        shutil.copy2(APP_ROOT / "README_AKTUALIZACE.txt", work / "README_AKTUALIZACE.txt")
        zip_tree(work, output, prefix=work.name)


def build_clean_application(output: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="hads-clean-") as temp:
        # Deliberately do not expose a top-level HADS/ tree in the full archive:
        # common archive tools otherwise merge it over an existing installation
        # and replace seed configuration files.  The guarded installer is the
        # supported one-click fresh-install/merge path.
        package = Path(temp) / f"HADS_aplikace_v{VERSION}"
        root = package / "clean_seed" / "HADS"
        root.mkdir(parents=True)
        copy_program(APP_ROOT, root)
        runtime_source = APP_ROOT / "runtime"
        if not (runtime_source / "pythonw.exe").is_file():
            raise RuntimeError("Chybí ověřený přenosný runtime/pythonw.exe pro Windows.")
        shutil.copytree(runtime_source, root / "runtime")
        # Plný balíček obsahuje updater i jeho stdlib release nástroj, takže lze
        # kompletní regresní sadu spustit přímo po rozbalení. Neobsahuje payload,
        # uživatelská data ani klíče.
        tools = root / "tools"
        tools.mkdir(exist_ok=True)
        data = root / "data"
        data.mkdir()
        # Pouze neosobní ukázková databáze a čisté výchozí konfigurace.
        shutil.copy2(
            APP_ROOT / "data" / "HADS_ukazkova_databaze.ndb",
            data / "HADS_ukazkova_databaze.ndb",
        )
        (data / "ai_config.json").write_text(
            json.dumps({"schema": 2, "model": "gpt-4o"}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        (data / "ai_examples.json").write_text('{"examples": []}\n', encoding="utf-8")
        (data / "ai_prompts.json").write_text(
            json.dumps({
                "format": 1, "defaults_revision": VERSION, "revision": 0,
                "updated_at": None, "overrides": {},
            }, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        (data / "report_drafts.json").write_text("{}\n", encoding="utf-8")
        write_text(package / "INSTALACE_BEZPECNE.txt", (
            "HADS " + VERSION + " – bezpečná nová instalace\n\n"
            "Tento plný balíček je pouze čisté osivo pro novou instalaci. "
            "NIKDY nekopírujte clean_seed/HADS přes existující HADS.\n"
            "Použijte Aktualizovat HADS z balíčku aktualizace, nebo spusťte "
            "Instalovat HADS.bat a vyberte novou prázdnou cílovou složku. "
            "Instalátor odmítne existující HADS/data.\n"
        ))
        write_text(package / "Instalovat HADS.bat", r"""@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
if "%~1"=="" (
  echo Pouziti: Instalovat HADS.bat "C:\cilova_slozka"
  echo Cíl musí být nová nebo prázdná složka. Existující HADS/data nebude přepsáno.
  pause
  exit /b 2
)
set "DEST=%~1\HADS"
if exist "%DEST%\data\" (
  echo [CHYBA] V cíli již existují data HADS. Pro aktualizaci použijte HADS_Update_""" + VERSION + r""".zip.
  pause
  exit /b 3
)
if exist "%DEST%\" (
  echo [CHYBA] Cílová složka HADS již existuje. Instalace ji z bezpečnostních důvodů nesloučí.
  pause
  exit /b 3
)
robocopy "%~dp0clean_seed\HADS" "%DEST%" /E /COPY:DAT /DCOPY:DAT /R:0 /W:0 >nul
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo [CHYBA] Novou instalaci se nepodařilo zkopírovat. Kód %RC%.
  pause
  exit /b %RC%
)
echo [OK] Nová čistá instalace byla vytvořena v "%DEST%".
pause
exit /b 0
""")
        write_text(package / "instalovat_hads.sh", """#!/usr/bin/env sh
set -eu
if [ "$#" -ne 1 ]; then
  echo 'Použití: instalovat_hads.sh /cesta/k/nove_slozce' >&2
  exit 2
fi
dest=$1/HADS
if [ -e "$dest" ]; then
  echo 'CHYBA: Cílová složka HADS již existuje; čistý balíček ji nikdy nesloučí.' >&2
  exit 3
fi
mkdir -p "$dest"
cp -R "$(dirname "$0")/clean_seed/HADS/." "$dest/"
echo "OK: Nová čistá instalace je v $dest"
""")
        (package / "instalovat_hads.sh").chmod(0o755)
        zip_tree(package, output, prefix=package.name)


def verify_zip(path: Path, require_update: bool) -> None:
    with tempfile.TemporaryDirectory(prefix="hads-verify-") as temp:
        with zipfile.ZipFile(path) as archive:
            bad_shell_modes = [
                info.filename for info in archive.infolist()
                if info.filename.lower().endswith(".sh")
                and ((info.external_attr >> 16) & 0o777) != 0o755
            ]
            if bad_shell_modes:
                raise RuntimeError("Shell skripty v ZIP nemají oprávnění 755: " + ", ".join(bad_shell_modes[:3]))
            names = archive.namelist()
            token = "".join(("a", "dash"))
            if any(token in name.casefold() for name in names):
                raise RuntimeError(f"ZIP obsahuje nepovolené historické označení v cestě: {path}")
            if any(name.startswith("/") or ".." in PurePosixPath(name).parts for name in names):
                raise RuntimeError(f"ZIP obsahuje nebezpečnou cestu: {path}")
            if any(PurePosixPath(name).name.casefold() in FORBIDDEN_CREDENTIAL_NAMES for name in names):
                raise RuntimeError(f"ZIP obsahuje zakázaný artefakt přístupových údajů: {path}")
            archive.extractall(temp)
        assert_no_retired_brand(Path(temp))
        if require_update:
            root = Path(temp) / f"HADS_Update_{VERSION}"
            if not (root / "manifest.json").is_file() or not (root / "hads_updater.py").is_file():
                raise RuntimeError("Aktualizační ZIP nemá očekávanou strukturu.")
            if any("/data/" in ("/" + n) or n.startswith("data/") for n in names):
                raise RuntimeError("Aktualizační ZIP nesmí obsahovat data.")
        else:
            package = Path(temp) / f"HADS_aplikace_v{VERSION}"
            root = package / "clean_seed" / "HADS"
            if not (root / "backend" / "version.py").is_file() or not (root / "HADS.exe").is_file():
                raise RuntimeError("Aplikační ZIP nemá očekávaný kořen HADS nebo HADS.exe.")
            if not (package / "Instalovat HADS.bat").is_file():
                raise RuntimeError("Plný ZIP nemá bezpečný instalační launcher.")
            if not (root / "runtime" / "pythonw.exe").is_file():
                raise RuntimeError("Aplikační ZIP neobsahuje přenosný runtime/pythonw.exe.")
            if any("__pycache__" in n or ".pytest_cache" in n or "/updates/" in ("/" + n) for n in names):
                raise RuntimeError("Čistý aplikační ZIP obsahuje cache nebo zálohy.")
            config = json.loads((root / "data" / "ai_config.json").read_text(encoding="utf-8"))
            if set(config).intersection({"openai_api_key", "anthropic_api_key", "api_key"}):
                raise RuntimeError("Čistý aplikační ZIP obsahuje API klíč nebo historické pole klíče.")
            tool_files = sorted(
                p.relative_to(root).as_posix()
                for p in (root / "tools").rglob("*") if p.is_file()
            ) if (root / "tools").is_dir() else []
            if tool_files != ["tools/build_release.py", "tools/hads_database_replacer.py", "tools/hads_updater.py", "tools/publish_shared_release.py"]:
                raise RuntimeError("Čistý aplikační ZIP má obsahovat jen bezpečné stdlib nástroje updateru, release a publikace.")


def build_shared_repository(output: Path, update_zip: Path, private_key: Path) -> None:
    """Sestaví ready-to-copy HADS_aktualizace/1.46.0 bez dat, runtime a tajemství."""
    import publish_shared_release as publisher
    notes = {
        "new": [
            "AI dostává skutečné nálezy z FFT spekter: vrcholy s řádem otáčkové frekvence, amplitudy na harmonických a na poruchových frekvencích ložiska (FTF/BSF/BPFO/BPFI).",
            "Jedna společná editovatelná metodologie diagnostiky v Nastavení → AI prompty; používá ji protokol i poradce u měřicího bodu.",
            "Nastavitelné toleranční pásmo shody frekvencí: zvlášť pro otáčkové řády (výchozí 1 %) a pro poruchové frekvence ložisek (výchozí 2 %); u každé shody se vypisuje skutečná odchylka.",
            "Postranní pásma s identifikací modulujícího prvku, vzorec spektra (harmonická řada, subharmonické, zlomkové řády, poměr 2×/1×, práh šumu) a rozbor směrovosti H/V/A na každém ložisku.",
            "Odhad počtu lopatek a zubů ze silného celočíselného řádu, rozpoznání řemenového převodu a dopočet pólů, skluzu a F_P u asynchronních motorů — vše bez nutnosti zadávat kinematiku.",
            "Kontrola vhodnosti F_max a rozlišení spektra a ověření, že zadaná otáčková frekvence má ve spektrech harmonické.",
            "Rozdělení rolí spekter: rychlost pro nízkofrekvenční dynamiku v řádech otáčky, zrychlení a obálka pro poškození ložisek, ozubení, přidírání a kavitaci.",
            "Volitelná kinematika na kartě stroje (lopatky, póly, zuby, řemenový převod) mění odhad ze spektra na přesný výpočet BPF, GMF, 2F_L, F_P a řemenové frekvence.",
            "Opory hodnocení nad rámec normy: baseline ze známého dobrého stavu (ukládá se jen datum) a ručně vybraný sesterský stroj; podklady uvádějí, které opory jsou k dispozici.",
            "Rychlost změny trendu v % za 30 dní metodou nejmenších čtverců; z rozpětí kratšího než sedm dní se neextrapoluje.",
            "Odhad etapy poškození ložiska 1–4 s výpisem důvodů, vyhodnocení časové vlny (činitel výkmitu, ořezání, periodicita rázů) a výpočet navržené priority i stropu míry jistoty.",
            "Nastavení → Firma a logo: vlastní logo do hlavičky protokolu a vlastní název firmy, adresa, web, značka a výchozí schvalovatel do patičky.",
        ],
        "improved": [
            "Podklady uvádějí meze A/B, B/C i C/D včetně jejich původu; je-li platná mez z normy, vypíší se i nepoužité meze z .ndb.",
            "Rozsah spektrálních podkladů se řídí nejhorším pásmem stroje, takže se neplýtvá u strojů v pásmu A.",
            "PDF, DOCX i protokol znovu vygenerovaný z historie berou aktuální personalizaci.",
        ],
        "fixed": [
            "Detailní protokol už nenutí model komentovat FFT spektra, ze kterých dosud dostával jen jedinou celkovou hodnotu.",
            "Potlačení okolí vrcholu se už neodvíjí od tolerance shody, takže se ve vysokých frekvencích neztrácejí samostatné složky spektra.",
            "Toleranční okno se nerozšiřuje zaokrouhlením na celé čáry; u nízkých frekvencí tak nevznikají shody s odchylkou mnohonásobně přes zadaná procenta.",
            "Opakovaná aktualizace ze stejné rozbalené složky už neselže na kontrole integrity payloadu; aktualizátor si do něj nezapisuje bytekód a případný __pycache__ ignoruje.",
            "Údaje vydavatele už nejsou natvrdo v programu, takže je aktualizace nemůže vrátit na hodnoty dodavatele.",
        ],
        "security": [
            "Veškerá aritmetika spekter probíhá v aplikaci a je pokrytá testy; model nic nepřepočítává. Jedna čára spektra nikdy nenese dva popisky, takže se do protokolu nedostane nedoložená závada.",
            "Bez zadaných otáček se řády ani poruchové frekvence neurčují a prompt to výslovně uvádí.",
            "Personalizace je uložena výhradně v data/branding/, kterou aktualizace nikdy nemění; nahrané logo se přijme jen jako skutečný JPEG do 2 MB.",
        ],
        "important": [
            "Vyplňte na kartě stroje OTÁČKY — bez nich zůstane spektrální analýza omezená jen na frekvence vrcholů bez jejich významu.",
            "Logo NIKDY neukládejte do backend/assets — tuto složku aktualizace nahrazuje. Použijte výhradně Nastavení → Firma a logo.",
        ],
    }
    with tempfile.TemporaryDirectory(prefix="hads-shared-repository-") as temp:
        root = Path(temp) / "HADS_aktualizace"
        publisher.publish(VERSION, update_zip, root, private_key, "2026-08-26", "1.34.4", False,
                         "Opory hodnocení: baseline a sesterský stroj",
                         "Aktualizace HADS 1.46.0 z ověřené sdílené složky.", notes)
        zip_tree(root.parent, output)
    with zipfile.ZipFile(output) as archive:
        expected = f"HADS_aktualizace/{VERSION}/"
        names = archive.namelist()
        if not any(name == expected + "release.json" for name in names) or not any(name == expected + "release.json.sig" for name in names):
            raise RuntimeError("Repozitářový ZIP nemá podepsané metadata.")
        if any("private" in name.casefold() or "/data/" in ("/" + name) or "/runtime/" in ("/" + name) for name in names):
            raise RuntimeError("Repozitářový ZIP obsahuje zakázaný obsah.")
    verify_zip(output, require_update=False) if False else None


def build_artifact_manifest(output: Path, private_key: Path,
                            artifacts: tuple[Path, ...]) -> tuple[Path, Path]:
    """Create a detached RSA-signed checksum manifest for every release file.

    The release metadata signature remains what the in-app shared updater
    verifies.  This companion manifest also gives administrators a signature
    over the HADS.exe, full ZIP, update ZIP and shared repository as delivered.
    The private key is only passed to ``publish_shared_release.sign`` and is
    never copied to a distribution tree.
    """
    import publish_shared_release as publisher
    record = {
        "format": 1,
        "product": PRODUCT,
        "version": VERSION,
        "algorithm": "RSASSA-PKCS1-v1_5/SHA-256",
        "artifacts": [
            {"filename": path.name, "byte_size": path.stat().st_size, "sha256": sha256(path)}
            for path in artifacts
        ],
    }
    raw = json.dumps(record, ensure_ascii=False, sort_keys=True,
                     separators=(",", ":")).encode("utf-8")
    # Signature is over the exact file bytes so administrators can verify it
    # directly with OpenSSL without a JSON re-serialization step.
    output.write_bytes(raw)
    signature = output.with_suffix(output.suffix + ".sig")
    signature.write_text(base64.b64encode(publisher.sign(raw, private_key)).decode("ascii") + "\n",
                         encoding="ascii")
    return output, signature


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Sestaví distribuční ZIPy HADS.")
    parser.add_argument("--private-key", help="explicitní offline klíč jen pro sestavení sdíleného repozitáře")
    args = parser.parse_args(argv)
    update_zip = OUTPUT_ROOT / f"HADS_Update_{VERSION}.zip"
    app_zip = OUTPUT_ROOT / f"HADS_aplikace_v{VERSION}.zip"
    assert_source_has_no_retired_brand(APP_ROOT)
    build_update(update_zip)
    build_clean_application(app_zip)
    verify_zip(update_zip, require_update=True)
    verify_zip(app_zip, require_update=False)
    print(f"Vytvořeno a ověřeno: {update_zip}")
    print(f"Vytvořeno a ověřeno: {app_zip}")
    if args.private_key:
        repo_zip = OUTPUT_ROOT / f"HADS_sdilene_aktualizace_v{VERSION}.zip"
        build_shared_repository(repo_zip, update_zip, Path(args.private_key))
        print(f"Vytvořeno a ověřeno: {repo_zip}")
        manifest, signature = build_artifact_manifest(
            OUTPUT_ROOT / f"HADS_{VERSION}_artifact_manifest.json",
            Path(args.private_key),
            (APP_ROOT / "HADS.exe", app_zip, update_zip, repo_zip),
        )
        print(f"Vytvořen oddělený podpis artefaktů: {manifest} + {signature}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
