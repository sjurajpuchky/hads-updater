/* HADS – Heistech AI Diagnostic Software — frontend logika (vanilla JS) */

const API = "";
// SJEDNOCENÉ STAVY STROJŮ (napříč dashboardem, stromem, protokolem i normami):
//   pásmo A a B  -> OK          (zelená)   – severity id 1
//   pásmo C      -> Upozornění  (žlutá)    – severity id 3
//   pásmo D      -> Výstraha    (červená)  – severity id 4
// Syrové ID 2 (staré "Varování") se sjednocuje na 3 (Upozornění).
const SEV_VARS = { 1: "--sev-ok", 2: "--sev-warn", 3: "--sev-warn", 4: "--sev-danger" };
// Jednotné popisky stavů (přebíjí názvy z .ndb databáze přístroje).
const SEV_LABELS_UI = { 0: "Neměřeno", 1: "OK", 2: "Upozornění", 3: "Upozornění", 4: "Výstraha" };
function sevLabelUI(id) { return SEV_LABELS_UI[id] || "—"; }
// Popisky stavového modelu protokolu (klíče shodné s backendem report.py).
const SEV_MODEL_LABELS = { ok: "OK", alarm: "Upozornění", warn: "Výstraha", none: "Neměřeno" };
// Pásmo (A–D) -> stav protokolu (shodně s backend band_severity).
function _autoSeverityFromBand(band) {
  if (band === "A" || band === "B") return "ok";
  if (band === "C") return "alarm";
  if (band === "D") return "warn";
  return "none";
}
function sevColor(id) {
  const v = SEV_VARS[id];
  if (!v) return getCss("--sev-none");
  return getCss(v);
}
function getCss(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

// Vyhodnotí stav poslední naměřené hodnoty vůči platným limitům veličiny.
// Vrací { color, title, level } nebo null (není hodnota / limity / klasifikace
// je vypnutá). level: "ok" | "warn" | "alarm".
function lastValueStatus(value, warning, alarm, classify) {
  if (classify === false) return null;
  const v = (value != null && isFinite(value)) ? value : null;
  if (v == null) return null;
  const w = (warning != null && isFinite(warning)) ? warning : null;
  const a = (alarm != null && isFinite(alarm)) ? alarm : null;
  if (w == null && a == null) return null;
  if (a != null && v >= a) {
    return { level: "alarm", color: getCss("--sev-danger"),
             title: `Výstraha – nad alarmem (≥ ${fmtNum(a, 4)})` };
  }
  if (w != null && v >= w) {
    return { level: "warn", color: getCss("--sev-warn"),
             title: `Upozornění – nad varováním (≥ ${fmtNum(w, 4)})` };
  }
  return { level: "ok", color: getCss("--sev-ok"),
           title: "Pod limity (v pořádku)" };
}

let STATE = {
  nodes: [],
  byId: {},
  children: {},
  severities: [],
  sevById: {},
  pointSeverity: {},
  activePoint: null,
  activeCell: null,
  databases: [],
  compareMode: false,
  compareSel: [],      // pořadí vybraných ID měřicích bodů
  compareData: null,   // odpověď z /api/compare
  wfData: null,        // odpověď z /api/point/{id}/waterfall
  wfMode: "3d",        // "3d" | "2d"
  wfSel: 0,            // index vybraného spektra (pro detail)
};

// stav dashboardu (filtr podle data posledního měření)
let DASH = {
  overview: null,      // poslední odpověď z /api/overview
  sevById: {},
  recencyDays: 0,      // 0 = bez omezení; jinak max. stáří posledního měření ve dnech
};

// ---------- utils ----------
async function api(path, opts) {
  const r = await fetch(API + path, opts);
  if (!r.ok) {
    let msg = "Chyba " + r.status;
    try { const j = await r.json(); if (j.detail) msg = j.detail; } catch (e) {}
    throw new Error(msg);
  }
  return r.json();
}
function toast(msg, isErr) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = "toast show" + (isErr ? " err" : "");
  setTimeout(() => { t.className = "toast"; }, 3200);
}
function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return iso;
  return d.toLocaleString("cs-CZ", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
function fmtNum(v, dec = 4) {
  if (v === null || v === undefined || isNaN(v)) return "—";
  return Number(v).toLocaleString("cs-CZ", { maximumFractionDigits: dec, minimumFractionDigits: 0 });
}

// --- pamatování pozice skrolování stránky per záložka ---
// Při přepínání záložek (karta stroje, karta bodu, protokol) se poloha
// posuvníku hlavního obsahu (.content) ukládá pod klíčem `scopeKey:tabKey`
// a při návratu na danou záložku se obnoví – uživatel se tak nemusí
// znovu posouvat na místo, kde přepínání přerušil.
const TAB_SCROLL_MEMORY = new Map();
function saveTabScroll(scopeKey, tabKey) {
  const content = document.querySelector(".content");
  if (!content || !scopeKey || !tabKey) return;
  TAB_SCROLL_MEMORY.set(scopeKey + ":" + tabKey, content.scrollTop);
}
function restoreTabScroll(scopeKey, tabKey) {
  const content = document.querySelector(".content");
  if (!content) return;
  const saved = TAB_SCROLL_MEMORY.get(scopeKey + ":" + tabKey) || 0;
  // nastavíme hned i po překreslení layoutu – obsah nově aktivní záložky
  // se někdy dopočítá (výška) až po tomto volání, jinak by scroll „ujel“
  content.scrollTop = saved;
  requestAnimationFrame(() => { content.scrollTop = saved; });
}

// ---------- icons ----------
const ICONS = {
  plant: '<svg class="ticon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 21h18M5 21V7l5-3v17M14 21V11l5-3v13M9 9v0M9 13v0M9 17v0"/></svg>',
  machine: '<svg class="ticon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3.2"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M17.7 6.3l-1.4 1.4M7.7 16.3l-1.4 1.4"/></svg>',
  point: '<svg class="ticon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 12h3l2-7 4 14 2-7h3"/><circle cx="20" cy="12" r="1.4" fill="currentColor"/></svg>',
  caret: '<svg class="tcaret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M9 6l6 6-6 6"/></svg>',
};

// ---------- init ----------
async function init() {
  document.getElementById("file-input").addEventListener("change", onUpload);
  document.getElementById("file-input-2").addEventListener("change", onUpload);
  document.getElementById("update-db-btn").addEventListener("click", chooseDatabaseUpdate);
  document.getElementById("update-db-input").addEventListener("change", onDatabaseUpdateFile);
  document.getElementById("update-db-confirm").addEventListener("click", confirmDatabaseUpdate);
  document.getElementById("update-db-cancel").addEventListener("click", closeDatabaseUpdateModal);
  document.getElementById("update-db-close").addEventListener("click", closeDatabaseUpdateModal);
  document.getElementById("update-db-modal").addEventListener("click", (e) => {
    if (e.target.id === "update-db-modal") closeDatabaseUpdateModal();
  });
  document.getElementById("tree-search").addEventListener("input", onSearch);
  const collapseAllBtn = document.getElementById("tree-collapse-all");
  if (collapseAllBtn) collapseAllBtn.addEventListener("click", toggleCollapseAllTree);
  document.getElementById("db-select").addEventListener("change", onDbSelect);
  document.getElementById("manage-btn").addEventListener("click", openManageModal);
  document.getElementById("home-btn").addEventListener("click", goHome);
  document.getElementById("compare-toggle").addEventListener("click", toggleCompareMode);
  document.getElementById("compare-clear").addEventListener("click", clearCompareSelection);
  document.getElementById("compare-run").addEventListener("click", runCompare);
  document.getElementById("compare-quantity").addEventListener("change", drawCompare);
  document.getElementById("compare-normalize").addEventListener("change", drawCompare);
  document.getElementById("compare-markers").addEventListener("change", drawCompare);
  updateCompareCount();
  // --- vodopád spekter ---
  document.getElementById("wf-back").addEventListener("click", () => showView("point"));
  document.getElementById("wf-mode-3d").addEventListener("click", () => setWaterfallMode("3d"));
  document.getElementById("wf-mode-2d").addEventListener("click", () => setWaterfallMode("2d"));
  document.getElementById("wf-cell").addEventListener("change", loadWaterfall);
  document.getElementById("wf-limit").addEventListener("change", loadWaterfall);
  document.getElementById("wf-log").addEventListener("change", () => { drawWaterfall(); drawWaterfallDetail(); });
  document.getElementById("wf-slider").addEventListener("input", (e) => selectWaterfallSpectrum(parseInt(e.target.value, 10)));
  document.getElementById("modal-close").addEventListener("click", closeManageModal);
  document.getElementById("manage-modal").addEventListener("click", (e) => {
    if (e.target.id === "manage-modal") closeManageModal();
  });
  // --- karta stroje + vyhledání ložiska ---
  document.getElementById("machine-save").addEventListener("click", saveMachineConfig);
  document.getElementById("bearing-modal-close").addEventListener("click", closeBearingModal);
  document.getElementById("bearing-modal").addEventListener("click", (e) => {
    if (e.target.id === "bearing-modal") closeBearingModal();
  });
  document.getElementById("bearing-search").addEventListener("input", () => {
    clearTimeout(_bearingSearchTimer);
    _bearingSearchTimer = setTimeout(runBearingSearch, 280);
  });
  document.getElementById("bearing-mfg").addEventListener("change", runBearingSearch);
  // --- údaje o podniku ---
  document.getElementById("company-btn").addEventListener("click", openCompanyModal);
  document.getElementById("company-modal-close").addEventListener("click", closeCompanyModal);
  document.getElementById("company-modal").addEventListener("click", (e) => {
    if (e.target.id === "company-modal") closeCompanyModal();
  });
  document.getElementById("company-save").addEventListener("click", saveCompany);
  // --- nastavení (samostatná záložka na hlavní stránce) ---
  document.getElementById("settings-btn").addEventListener("click", openSettingsView);
  document.getElementById("settings-save").addEventListener("click", saveSettings);
  var _aiexSave = document.getElementById("aiex-save");
  if (_aiexSave) _aiexSave.addEventListener("click", onAiExampleSave);
  var _aiexCancel = document.getElementById("aiex-cancel");
  if (_aiexCancel) _aiexCancel.addEventListener("click", resetAiExampleForm);
  ["openai", "anthropic"].forEach((provider) => {
    const save = document.getElementById(`ai-${provider}-save`);
    const del = document.getElementById(`ai-${provider}-delete`);
    if (save) save.addEventListener("click", () => saveAiProviderKey(provider));
    if (del) del.addEventListener("click", () => deleteAiProviderKey(provider));
  });
  const modelSelect = document.getElementById("ai-default-model");
  if (modelSelect) modelSelect.addEventListener("change", saveAiDefaultModel);
  const aiConfigRetry = document.getElementById("ai-config-retry");
  if (aiConfigRetry) aiConfigRetry.addEventListener("click", loadAiAgentsSettings);
  const aiPromptsRetry = document.getElementById("ai-prompts-retry");
  if (aiPromptsRetry) aiPromptsRetry.addEventListener("click", async () => {
    try { await loadAiPrompts(); } catch (_error) { /* Stav chyby už je viditelný. */ }
  });
  const aiPromptsList = document.getElementById("ai-prompts-list");
  if (aiPromptsList) aiPromptsList.addEventListener("click", onAiPromptListClick);
  document.getElementById("set-tech-add").addEventListener("click", onSettingsTechAdd);
  document.getElementById("set-tech-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); onSettingsTechAdd(); }
  });
  // --- tolerance shody frekvencí ve spektru ---
  const fftSave = document.getElementById("fft-tol-save");
  if (fftSave) fftSave.addEventListener("click", saveFftSettings);
  const fftReset = document.getElementById("fft-tol-reset");
  if (fftReset) fftReset.addEventListener("click", resetFftSettings);
  // --- personalizace: firma vydavatele + logo do protokolů ---
  const brandSave = document.getElementById("brand-save");
  if (brandSave) brandSave.addEventListener("click", saveBranding);
  const brandReset = document.getElementById("brand-reset");
  if (brandReset) brandReset.addEventListener("click", resetBranding);
  const brandPick = document.getElementById("brand-logo-pick");
  const brandFile = document.getElementById("brand-logo-file");
  if (brandPick && brandFile) brandPick.addEventListener("click", () => brandFile.click());
  if (brandFile) brandFile.addEventListener("change", onBrandingLogoChosen);
  const brandLogoDel = document.getElementById("brand-logo-delete");
  if (brandLogoDel) brandLogoDel.addEventListener("click", deleteBrandingLogo);
  // podzáložky nastavení
  document.querySelectorAll("#settings-tabbar .mc-tab").forEach((tab) => {
    tab.addEventListener("click", () => switchSettingsTab(tab.dataset.settingsTab));
  });
  // sekce Normy
  document.getElementById("set-norm-add").addEventListener("click", onNormSave);
  document.getElementById("set-norm-cancel").addEventListener("click", resetNormForm);
  document.getElementById("set-norm-row-add").addEventListener("click", () => addNormRow());
  // zkratky do správy databází / podniku ze záložky nastavení
  document.getElementById("set-open-manage").addEventListener("click", openManageModal);
  document.getElementById("set-open-company").addEventListener("click", openCompanyModal);
  const persistenceCheck = document.getElementById("persistence-check");
  if (persistenceCheck) persistenceCheck.addEventListener("click", () => loadPersistenceStatus(true));
  // --- sdílené aktualizace ---
  document.getElementById("updates-pick").addEventListener("click", chooseSharedUpdateFolder);
  document.getElementById("updates-save").addEventListener("click", saveSharedUpdateSettings);
  document.getElementById("updates-check").addEventListener("click", checkSharedUpdates);
  document.getElementById("updates-whats-new").addEventListener("click", openWhatsNew);
  document.getElementById("shared-update-close").addEventListener("click", closeSharedUpdateModal);
  document.getElementById("shared-update-later").addEventListener("click", closeSharedUpdateModal);
  document.getElementById("shared-update-whats-new").addEventListener("click", showCandidateWhatsNew);
  document.getElementById("shared-update-install").addEventListener("click", installSharedUpdate);
  document.getElementById("shared-update-modal").addEventListener("click", (e) => { if (e.target.id === "shared-update-modal") closeSharedUpdateModal(); });
  document.getElementById("app-shutdown-open").addEventListener("click", openAppShutdownModal);
  document.getElementById("app-shutdown-cancel").addEventListener("click", closeAppShutdownModal);
  document.getElementById("app-shutdown-confirm").addEventListener("click", confirmAppShutdown);
  document.getElementById("app-shutdown-modal").addEventListener("click", (e) => { if (e.target.id === "app-shutdown-modal") closeAppShutdownModal(); });
  refreshSharedUpdateStatus();
  // protokol z měření (PDF)
  document.getElementById("report-btn").addEventListener("click", openReport);
  document.getElementById("report-scope-mode").addEventListener("change", onReportScopeChange);
  document.getElementById("report-scope-days").addEventListener("change", refreshReportScopeMachines);
  document.getElementById("report-scope-date").addEventListener("change", () => {
    REPORT_SCOPE_MACHINES.checkedIds = null;
    refreshReportScopeMachines();
  });
  document.getElementById("report-scope-machines-all").addEventListener("click", () => setAllReportScopeMachines(true));
  document.getElementById("report-scope-machines-none").addEventListener("click", () => setAllReportScopeMachines(false));
  document.getElementById("report-generate-btn").addEventListener("click", generateReportDraft);
  document.getElementById("report-pdf-btn").addEventListener("click", downloadReportPdf);
  const docxBtn = document.getElementById("report-docx-btn");
  if (docxBtn) docxBtn.addEventListener("click", downloadReportDocx);
  const docxImportBtn = document.getElementById("report-docx-import-btn");
  const docxImportInput = document.getElementById("report-docx-import-input");
  if (docxImportBtn && docxImportInput) {
    docxImportBtn.addEventListener("click", () => {
      docxImportInput.value = "";
      docxImportInput.click();
    });
    docxImportInput.addEventListener("change", (e) => {
      const f = e.target.files && e.target.files[0];
      if (f) startDocxImportPreview(f);
    });
  }
  const docxImClose = document.getElementById("docx-import-close");
  if (docxImClose) docxImClose.addEventListener("click", _closeDocxImportModal);
  const docxImCancel = document.getElementById("docx-import-cancel");
  if (docxImCancel) docxImCancel.addEventListener("click", _closeDocxImportModal);
  const docxImOverlay = document.getElementById("docx-import-modal");
  if (docxImOverlay) docxImOverlay.addEventListener("click", (e) => {
    if (e.target === docxImOverlay) _closeDocxImportModal();
  });
  const docxImSelChanged = document.getElementById("docx-import-select-changed");
  if (docxImSelChanged) docxImSelChanged.addEventListener("click", _selectChangedDocxImportItems);
  const docxImApply = document.getElementById("docx-import-apply");
  if (docxImApply) docxImApply.addEventListener("click", applyDocxImportSelection);
  const refreshBtn = document.getElementById("report-refresh-btn");
  if (refreshBtn) refreshBtn.addEventListener("click", refreshReportLimits);
  // uložení do historie protokolů + obnovení seznamu historie
  const saveHistBtn = document.getElementById("report-save-history-btn");
  if (saveHistBtn) saveHistBtn.addEventListener("click", () => saveReportToHistory());
  const histRefresh = document.getElementById("report-history-refresh");
  if (histRefresh) histRefresh.addEventListener("click", loadReportHistory);
  // náhled celého PDF protokolu před vygenerováním
  document.getElementById("report-preview-btn").addEventListener("click", previewReportPdf);
  const pdfPvClose = document.getElementById("pdf-preview-close");
  if (pdfPvClose) pdfPvClose.addEventListener("click", _closePdfPreview);
  const pdfPvCancel = document.getElementById("pdf-preview-cancel");
  if (pdfPvCancel) pdfPvCancel.addEventListener("click", _closePdfPreview);
  const pdfPvDl = document.getElementById("pdf-preview-download");
  if (pdfPvDl) pdfPvDl.addEventListener("click", () => {
    if (PDF_PREVIEW.blob) _downloadBlob(PDF_PREVIEW.blob, PDF_PREVIEW.fname);
  });
  const pdfPvOverlay = document.getElementById("pdf-preview-modal");
  if (pdfPvOverlay) pdfPvOverlay.addEventListener("click", (e) => {
    if (e.target === pdfPvOverlay) _closePdfPreview();
  });
  // název PDF souboru: automatický výchozí název z čísla zakázky / zákazníka /
  // názvu protokolu, dokud jej uživatel neupravil ručně
  ["rep-order_number", "rep-company_name", "rep-report_title"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("input", _syncDefaultPdfFilename);
  });
  const fnameEl = document.getElementById("rep-pdf_filename");
  if (fnameEl) fnameEl.addEventListener("input", () => { PDF_FNAME_EDITED = true; });
  const fnameReset = document.getElementById("rep-pdf_filename-reset");
  if (fnameReset) fnameReset.addEventListener("click", () => {
    PDF_FNAME_EDITED = false;
    _syncDefaultPdfFilename();
  });
  // náhled grafu do protokolu (modalní okno)
  const gpClose = document.getElementById("gp-preview-close");
  if (gpClose) gpClose.addEventListener("click", closeGraphPreview);
  const gpSave = document.getElementById("gp-preview-save");
  if (gpSave) gpSave.addEventListener("click", saveGraphPreview);
  const gpClear = document.getElementById("gp-preview-clear-markers");
  if (gpClear) gpClear.addEventListener("click", () => {
    if (GP_PREVIEW) { GP_PREVIEW.userMarkers = []; _refreshPreviewMarkers(); }
  });
  const gpModal = document.getElementById("gp-preview-modal");
  if (gpModal) gpModal.addEventListener("click", (e) => {
    if (e.target === gpModal) closeGraphPreview();
  });
  document.querySelectorAll("#report-tabbar .mc-tab").forEach(btn => {
    // preventDefault na mousedown zabrání focusu tlačítka, který by prohlížeč
    // automaticky doprovodil scrollnutím .content (scroll-into-view) ještě
    // před spuštěním click handleru – tím by se ztratila pamatovaná pozice.
    btn.addEventListener("mousedown", (e) => e.preventDefault());
    btn.addEventListener("click", () => switchReportTab(btn.dataset.reportTab));
  });
  initPanelHotkeys();  // Ctrl+Tab / Ctrl+Shift+Tab / Ctrl+1..9 mezi panely
  await refreshDbSelect();
  await loadAiConf();
  await loadNormsCatalog();
  const st = await api("/api/status");
  if (st.version) {
    const vEl = document.getElementById("app-version");
    if (vEl) vEl.textContent = "v" + st.version;
  }
  if (st.loaded) {
    await loadAll();
  } else {
    showEmpty("Nahrajte databázi .ndb z měřicího přístroje.");
  }
  await showExternalDatabaseUpdateResult();
}

// ---------- KNIHOVNA DATABÁZÍ ----------
async function refreshDbSelect() {
  const { databases } = await api("/api/databases");
  STATE.databases = databases;
  const sel = document.getElementById("db-select");
  sel.innerHTML = "";
  if (!databases.length) {
    const o = document.createElement("option");
    o.textContent = "Žádná databáze";
    o.value = "";
    sel.appendChild(o);
    sel.disabled = true;
    setDatabaseUpdateEnabled(false);
    return;
  }
  sel.disabled = false;
  databases.forEach(db => {
    const o = document.createElement("option");
    o.value = db.filename;
    o.textContent = db.display_name;
    if (db.active) o.selected = true;
    sel.appendChild(o);
  });
  setDatabaseUpdateEnabled(databases.some(db => db.active));
}

function setDatabaseUpdateEnabled(enabled) {
  const btn = document.getElementById("update-db-btn");
  if (btn) btn.disabled = !enabled;
}

async function onDbSelect(e) {
  const fn = e.target.value;
  if (!fn) return;
  await switchDatabase(fn);
}

async function switchDatabase(filename) {
  // Přepnutí aktivní .ndb mění serverový kontext. Zápis proto dokonči ještě
  // před aktivací nové databáze; jinak by asynchronní autosave mohl skončit
  // pod cizím podnikem/databází.
  await flushReportDraft();
  toast("Přepínám databázi…");
  try {
    await api("/api/databases/activate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename }),
    });
    await refreshDbSelect();
    await loadAll();
    const db = (STATE.databases || []).find(d => d.filename === filename);
    toast("Načteno: " + (db ? db.display_name : filename));
  } catch (err) {
    toast(err.message, true);
  }
}

// ---------- MODAL SPRÁVY ----------
async function openManageModal() {
  await refreshDbSelect();
  renderDbList();
  document.getElementById("manage-modal").classList.remove("hidden");
}
function closeManageModal() {
  document.getElementById("manage-modal").classList.add("hidden");
}

// ---------- ÚDAJE O PODNIKU ----------
async function openCompanyModal() {
  const modal = document.getElementById("company-modal");
  const statusEl = document.getElementById("company-status");
  if (statusEl) { statusEl.textContent = ""; statusEl.className = "company-status"; }
  // vyplnění aktuálními údaji
  try {
    const r = await api("/api/company");
    const c = (r && r.company) || { name: "", address: "", contact: "" };
    document.getElementById("company-name").value = c.name || "";
    document.getElementById("company-address").value = c.address || "";
    document.getElementById("company-contact").value = c.contact || "";
  } catch (e) {
    if (statusEl) { statusEl.textContent = e.message || "Načtení se nezdařilo."; statusEl.className = "company-status err"; }
  }
  modal.classList.remove("hidden");
}
function closeCompanyModal() {
  document.getElementById("company-modal").classList.add("hidden");
}
async function saveCompany() {
  const btn = document.getElementById("company-save");
  const statusEl = document.getElementById("company-status");
  const payload = {
    name: document.getElementById("company-name").value.trim(),
    address: document.getElementById("company-address").value.trim(),
    contact: document.getElementById("company-contact").value.trim(),
  };
  if (btn) btn.disabled = true;
  if (statusEl) { statusEl.textContent = "Ukládám…"; statusEl.className = "company-status"; }
  try {
    await api("/api/company", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (statusEl) { statusEl.textContent = "Údaje uloženy."; statusEl.className = "company-status ok"; }
    toast("Údaje o podniku uloženy.");
    setTimeout(closeCompanyModal, 600);
  } catch (e) {
    if (statusEl) { statusEl.textContent = e.message || "Uložení selhalo."; statusEl.className = "company-status err"; }
    toast(e.message || "Uložení selhalo.", true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ---------- SDÍLENÉ AKTUALIZACE ----------
let SHARED_UPDATE = null;
let APP_SHUTDOWN_BUSY = false;
function _setAppShutdownStatus(text, kind) {
  const el = document.getElementById("app-shutdown-status");
  if (!el) return;
  el.textContent = text || "";
  el.className = "updates-status" + (kind ? " " + kind : "");
}
function openAppShutdownModal() {
  if (APP_SHUTDOWN_BUSY) return;
  const modal = document.getElementById("app-shutdown-modal");
  modal.classList.remove("hidden");
  document.getElementById("app-shutdown-confirm").focus();
}
function closeAppShutdownModal() {
  if (APP_SHUTDOWN_BUSY) return;
  document.getElementById("app-shutdown-modal").classList.add("hidden");
  document.getElementById("app-shutdown-open").focus();
}
async function confirmAppShutdown() {
  if (APP_SHUTDOWN_BUSY) return;
  const confirmButton = document.getElementById("app-shutdown-confirm");
  APP_SHUTDOWN_BUSY = true;
  confirmButton.disabled = true;
  _setAppShutdownStatus("Připravuji bezpečné ukončení…");
  try {
    // Nonce existuje pouze v této stránce, je svázán s aktuálním originem a použije se jednou.
    const session = await api("/api/ui/shutdown-session", {
      method: "POST",
      cache: "no-store",
      headers: { "Content-Type": "application/json", "X-HADS-UI-Session": "request" },
      body: JSON.stringify({ purpose: "shutdown" }),
    });
    const nonce = session && session.nonce;
    if (!nonce) throw new Error("Bezpečné potvrzení ukončení se nepodařilo připravit.");
    await api("/api/ui/shutdown", {
      method: "POST",
      cache: "no-store",
      headers: { "Content-Type": "application/json", "X-HADS-UI-Shutdown-Nonce": nonce },
      body: JSON.stringify({ nonce }),
    });
    document.getElementById("app-shutdown-modal").classList.add("hidden");
    document.getElementById("app").classList.add("hidden");
    document.getElementById("app-shutdown-screen").classList.remove("hidden");
    _setAppShutdownStatus("HADS byl bezpečně ukončen.", "ok");
    // Prohlížeč smí okno zavřít jen v některých kontextech; text zůstává spolehlivou informací.
    window.setTimeout(() => { try { window.close(); } catch (e) {} }, 900);
  } catch (e) {
    _setAppShutdownStatus(e.message || "Ukončení HADS se nepodařilo připravit.", "err");
    APP_SHUTDOWN_BUSY = false;
    confirmButton.disabled = false;
  }
}
function _updateStatus(text, kind) {
  const el = document.getElementById("updates-status");
  if (!el) return;
  el.textContent = text || "";
  el.className = "updates-status" + (kind ? " " + kind : "");
}
function _formatReleaseNotes(notes) {
  const labels = { new: "Nové funkce", improved: "Vylepšení", fixed: "Opravy", security: "Zabezpečení", important: "Důležitá upozornění" };
  return ["new", "improved", "fixed", "security", "important"].map((key) => {
    const rows = notes && Array.isArray(notes[key]) ? notes[key] : [];
    return `<section class="release-note-group"><h3>${labels[key]}</h3>${rows.length ? `<ul>${rows.map((x) => `<li>${escapeHtml(x)}</li>`).join("")}</ul>` : "<p>Bez položek.</p>"}</section>`;
  }).join("");
}
function _setUpdateBadge(value) {
  const badge = document.getElementById("updates-badge");
  if (badge) badge.classList.toggle("hidden", !value);
}
function _renderSharedUpdateState(data) {
  const source = document.getElementById("updates-source-path");
  const automatic = document.getElementById("updates-startup-check");
  const current = document.getElementById("updates-current-version");
  const sourceDisplay = document.getElementById("updates-source-display");
  const last = document.getElementById("updates-last-check");
  if (!data) return;
  if (source) source.value = data.source_path || "";
  if (automatic) automatic.checked = data.automatic_startup_check !== false;
  if (current) current.textContent = data.current_version || "—";
  if (sourceDisplay) sourceDisplay.textContent = data.source_path || "Nenastaveno";
  if (last) last.textContent = fmtDate(data.last_check);
  _setUpdateBadge(data.update || data.startup_badge);
  if (data.update) SHARED_UPDATE = data.update;
  if (data.message || data.last_status) _updateStatus(data.message || data.last_status, data.update ? "ok" : "");
}
async function refreshSharedUpdateStatus() {
  try {
    const data = await api("/api/updates/status");
    _renderSharedUpdateState(data);
    if (data.post_update_notes && data.post_update_notes.unseen) setTimeout(openWhatsNew, 0);
    return data;
  } catch (e) { _updateStatus("Stav aktualizací se nepodařilo načíst.", "err"); return null; }
}
async function chooseSharedUpdateFolder() {
  try {
    const result = await api("/api/updates/source/pick", { method: "POST" });
    if (result.path) { document.getElementById("updates-source-path").value = result.path; _updateStatus("Složka byla vybrána. Uložte cestu."); }
    else if (!result.supported) _updateStatus("Na tomto systému zadejte cestu ručně.");
  } catch (e) { _updateStatus(e.message || "Výběr složky selhal.", "err"); }
}
async function saveSharedUpdateSettings() {
  const button = document.getElementById("updates-save");
  const payload = { source_path: document.getElementById("updates-source-path").value, automatic_startup_check: document.getElementById("updates-startup-check").checked };
  button.disabled = true; _updateStatus("Ukládám nastavení…");
  try {
    const result = await api("/api/updates/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    _renderSharedUpdateState({ ...result.settings, current_version: document.getElementById("updates-current-version").textContent, last_check: null, last_status: "Složka aktualizací je nastavena." });
    _updateStatus("Složka aktualizací je nastavena.", "ok");
  } catch (e) { _updateStatus(e.message || "Uložení cesty selhalo.", "err"); }
  finally { button.disabled = false; }
}
async function checkSharedUpdates() {
  const button = document.getElementById("updates-check");
  button.disabled = true; _updateStatus("Kontroluji podepsaná vydání ve sdílené složce…");
  try {
    const data = await api("/api/updates/check", { method: "POST" });
    _renderSharedUpdateState(data);
    if (data.update) openSharedUpdateModal(data.update);
    else _updateStatus("Nainstalovaná verze je aktuální.", "ok");
  } catch (e) { _updateStatus(e.message || "Kontrola aktualizací selhala.", "err"); }
  finally { button.disabled = false; }
}
function openSharedUpdateModal(update) {
  SHARED_UPDATE = update || SHARED_UPDATE;
  if (!SHARED_UPDATE) { _updateStatus("Nejprve zkontrolujte aktualizace."); return; }
  const item = SHARED_UPDATE;
  const size = formatFileBytes(item.byte_size || 0);
  document.getElementById("shared-update-title").textContent = `Aktualizace HADS ${item.version}`;
  document.getElementById("shared-update-install").style.display = "";
  document.getElementById("shared-update-content").innerHTML = `<p class="release-summary"><strong>${escapeHtml(item.title)}</strong><br>${escapeHtml(item.summary)}</p><dl class="updates-meta"><div><dt>Aktuální verze</dt><dd>${escapeHtml(document.getElementById("updates-current-version").textContent)}</dd></div><div><dt>Nová verze</dt><dd>${escapeHtml(item.version)}</dd></div><div><dt>Datum vydání</dt><dd>${escapeHtml(item.release_date)}</dd></div><div><dt>Velikost balíčku</dt><dd>${escapeHtml(size)}</dd></div><div><dt>Minimální verze</dt><dd>${escapeHtml(item.minimum_version)}</dd></div></dl>${item.mandatory ? '<p class="update-mandatory">Důležité: tato aktualizace je označena jako povinná.</p>' : ""}<div class="release-notes">${_formatReleaseNotes(item.release_notes)}</div>`;
  document.getElementById("shared-update-install").disabled = false;
  document.getElementById("shared-update-modal").classList.remove("hidden");
  document.getElementById("shared-update-install").focus();
}
function closeSharedUpdateModal() { document.getElementById("shared-update-modal").classList.add("hidden"); }
function showCandidateWhatsNew() {
  if (!SHARED_UPDATE) return;
  const item = SHARED_UPDATE;
  document.getElementById("shared-update-title").textContent = `Co je nového ve verzi ${item.version}`;
  document.getElementById("shared-update-content").innerHTML = `<p class="release-summary"><strong>${escapeHtml(item.title)}</strong><br>${escapeHtml(item.summary)}</p><div class="release-notes">${_formatReleaseNotes(item.release_notes)}</div>`;
}
async function installSharedUpdate() {
  const button = document.getElementById("shared-update-install");
  if (!SHARED_UPDATE || !confirm(`Opravdu chcete nainstalovat aktualizaci HADS ${SHARED_UPDATE.version}? Aplikace se poté restartuje.`)) return;
  button.disabled = true; _updateStatus("Ověřuji a připravuji aktualizaci…");
  try {
    const result = await api("/api/updates/install", { method: "POST" });
    _updateStatus(result.status || "Aktualizace byla připravena.", "ok");
    closeSharedUpdateModal();
  } catch (e) { _updateStatus(e.message || "Aktualizaci nelze připravit.", "err"); button.disabled = false; }
}
async function openWhatsNew() {
  try {
    const data = await api("/api/updates/notes");
    const note = data.notes;
    if (!note) { _updateStatus("Pro tuto nainstalovanou verzi nejsou k dispozici důvěryhodné poznámky k vydání."); return; }
    document.getElementById("shared-update-title").textContent = `Co je nového ve verzi ${note.version}`;
    document.getElementById("shared-update-content").innerHTML = `<p class="release-summary"><strong>${escapeHtml(note.title || "HADS")}</strong><br>${escapeHtml(note.summary || "")}</p><div class="release-notes">${_formatReleaseNotes(note.release_notes)}</div>`;
    document.getElementById("shared-update-install").style.display = "none";
    document.getElementById("shared-update-modal").classList.remove("hidden");
    if (note.unseen) await api("/api/updates/notes/shown", { method: "POST" });
  } catch (e) { _updateStatus(e.message || "Poznámky k vydání nelze načíst.", "err"); }
}

// ---------- NASTAVENÍ DATABÁZE (veličiny protokolu + jména techniků) ----------
// Per-databáze (podnik) uložené nastavení: které měřené veličiny se v protokolu
// berou jako rychlost / zrychlení / obálka, a seznam techniků pro pole
// Vypracoval / Měřil / Schválil.
let SETTINGS_TECHS = [];        // pracovní seznam techniků v modalu
let SETTINGS_QUANTITIES = [];   // dostupné veličiny z aktuální DB
let SETTINGS_DEFAULTS = {};     // výchozí veličiny {velocity, accel, env}

// Naplní jeden <select> veličin: první položka = "(výchozí)" (prázdná hodnota),
// pak všechny dostupné veličiny. Označí uloženou hodnotu.
function _fillQuantitySelect(id, selected, defLabel) {
  const sel = document.getElementById(id);
  if (!sel) return;
  const opts = [];
  const defName = (defLabel || "").trim();
  const defTxt = defName ? `(výchozí – ${defName})` : "(výchozí)";
  opts.push(`<option value="">${escapeHtml(defTxt)}</option>`);
  (SETTINGS_QUANTITIES || []).forEach((q) => {
    const isSel = (q === selected) ? " selected" : "";
    opts.push(`<option value="${escapeHtml(q)}"${isSel}>${escapeHtml(q)}</option>`);
  });
  sel.innerHTML = opts.join("");
  // pokud uložená hodnota není v seznamu (např. jiná DB), zůstane "(výchozí)"
  sel.value = (selected && SETTINGS_QUANTITIES.includes(selected)) ? selected : "";
}

// Vykreslí seznam techniků v modalu (s tlačítkem smazat u každého).
function _renderSettingsTechList() {
  const ul = document.getElementById("set-tech-list");
  if (!ul) return;
  if (!SETTINGS_TECHS.length) {
    ul.innerHTML = '<li class="tech-list-empty">Zatím žádní technici. Přidejte jméno výše.</li>';
    return;
  }
  ul.innerHTML = SETTINGS_TECHS.map((name, i) =>
    `<li><span class="tech-name" title="${escapeHtml(name)}">${escapeHtml(name)}</span>` +
    `<button type="button" class="tech-del" data-idx="${i}" title="Odebrat">×</button></li>`
  ).join("");
  ul.querySelectorAll(".tech-del").forEach((btn) => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.dataset.idx, 10);
      if (idx >= 0) { SETTINGS_TECHS.splice(idx, 1); _renderSettingsTechList(); }
    });
  });
}

function onSettingsTechAdd() {
  const inp = document.getElementById("set-tech-input");
  if (!inp) return;
  const name = (inp.value || "").trim();
  if (!name) return;
  // deduplikace bez ohledu na velikost písmen
  const exists = SETTINGS_TECHS.some((t) => t.toLowerCase() === name.toLowerCase());
  if (!exists) SETTINGS_TECHS.push(name);
  inp.value = "";
  inp.focus();
  _renderSettingsTechList();
}

// Přepínání podzáložek nastavení včetně oddělených lokálních AI klíčů.
function switchSettingsTab(name) {
  document.querySelectorAll("#settings-tabbar .mc-tab").forEach((t) => {
    t.classList.toggle("active", t.dataset.settingsTab === name);
  });
  document.querySelectorAll("#view-settings .mc-tabpane").forEach((p) => {
    p.classList.toggle("active", p.dataset.settingsTab === name);
  });
}

async function openSettingsView() {
  const statusEl = document.getElementById("settings-status");
  if (statusEl) { statusEl.textContent = ""; statusEl.className = "company-status"; }
  SETTINGS_TECHS = [];
  SETTINGS_QUANTITIES = [];
  SETTINGS_DEFAULTS = {};
  showView("settings");
  switchSettingsTab("quantities");
  try {
    // 1) dostupné veličiny + výchozí
    const rq = await api("/api/report/quantities");
    SETTINGS_QUANTITIES = (rq && rq.quantities) || [];
    SETTINGS_DEFAULTS = (rq && rq.defaults) || {};
    // 2) uložené nastavení této DB
    const rs = await api("/api/report/settings");
    const s = (rs && rs.settings) || {};
    const q = s.quantities || {};
    _fillQuantitySelect("set-q-velocity", q.velocity || "", SETTINGS_DEFAULTS.velocity);
    _fillQuantitySelect("set-q-accel", q.accel || "", SETTINGS_DEFAULTS.accel);
    _fillQuantitySelect("set-q-env", q.env || "", SETTINGS_DEFAULTS.env);
    SETTINGS_TECHS = Array.isArray(s.technicians) ? s.technicians.slice() : [];
    _renderSettingsTechList();
  } catch (e) {
    if (statusEl) { statusEl.textContent = e.message || "Načtení se nezdařilo."; statusEl.className = "company-status err"; }
  }
  // 3) načti katalog norem (včetně vlastních) a vykresli seznam
  resetNormForm();
  try { await loadNormsCatalog(); } catch (e) { /* ponecháme stávající */ }
  await loadCustomNorms();
  try { resetAiExampleForm(); await loadAiExamples(); } catch (e) { /* ponecháme */ }
  // loadAiPrompts již rozlišuje bezpečnou kategorii chyby a nabídne opakování;
  // nepřepisujeme ji zde obecnou hláškou.
  try { await loadAiPrompts(); } catch (e) { /* stav je zobrazen v kartě */ }
  try { await loadAiAgentsSettings(); } catch (e) { /* chyba je zobrazena v kartě */ }
  try { await loadFftSettings(); } catch (e) { /* stav je zobrazen v kartě */ }
  try { await loadBranding(); } catch (e) { /* stav je zobrazen v kartě */ }
  try { await loadPersistenceStatus(false); } catch (e) { /* stav je v kartě */ }
  const inp = document.getElementById("set-tech-input");
  if (inp) inp.value = "";
}

// ====== Tolerance shody frekvencí ve spektru (globální nastavení) ======

function _fftStatus(msg, kind) {
  const el = document.getElementById("fft-tol-status");
  if (!el) return;
  el.textContent = msg || "";
  el.className = "company-status" + (kind ? " " + kind : "");
}

function _renderFftSettings(payload) {
  const rec = (payload && payload.settings) || {};
  const tol = rec.tolerances || {};
  const def = rec.defaults || {};
  const fill = (id, key) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.value = tol[key] != null ? tol[key] : "";
    if (def[key] != null) el.placeholder = String(def[key]);
    if (rec.min_pct != null) el.min = rec.min_pct;
    if (rec.max_pct != null) el.max = rec.max_pct;
  };
  fill("fft-tol-order", "order_tolerance_pct");
  fill("fft-tol-bearing", "bearing_tolerance_pct");
}

async function loadFftSettings() {
  try {
    _renderFftSettings(await api("/api/fft/settings"));
  } catch (e) {
    _fftStatus(e.message || "Tolerance se nepodařilo načíst.", "err");
    throw e;
  }
}

async function saveFftSettings() {
  const btn = document.getElementById("fft-tol-save");
  const num = (id) => {
    const el = document.getElementById(id);
    const v = parseFloat((el && el.value) || "");
    return Number.isFinite(v) ? v : null;
  };
  if (btn) btn.disabled = true;
  _fftStatus("Ukládám…");
  try {
    _renderFftSettings(await api("/api/fft/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tolerances: {
          order_tolerance_pct: num("fft-tol-order"),
          bearing_tolerance_pct: num("fft-tol-bearing"),
        },
      }),
    }));
    _fftStatus("Tolerance uloženy. Projeví se u nově generovaných podkladů.", "ok");
    toast("Tolerance shody frekvencí uloženy.");
  } catch (e) {
    _fftStatus(e.message || "Uložení selhalo.", "err");
    toast(e.message || "Tolerance se nepodařilo uložit.", true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function resetFftSettings() {
  const btn = document.getElementById("fft-tol-reset");
  if (btn) btn.disabled = true;
  try {
    _renderFftSettings(await api("/api/fft/settings/reset", { method: "POST" }));
    _fftStatus("Obnoveny výchozí tolerance.", "ok");
  } catch (e) {
    _fftStatus(e.message || "Obnovení selhalo.", "err");
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ============ Personalizace: firma vydavatele protokolů + logo ============
// Globální pro celou instalaci HADS (ne per podnik). Ukládá se do data/,
// takže to aktualizace programu nikdy nepřepíše.

const BRANDING_FIELDS = {
  company: "brand-company",
  web: "brand-web",
  address: "brand-address",
  brand: "brand-brand",
  approved_by: "brand-approved",
};

function _brandStatus(msg, kind) {
  const el = document.getElementById("brand-status");
  if (!el) return;
  el.textContent = msg || "";
  el.className = "company-status" + (kind ? " " + kind : "");
}

function _renderBranding(payload) {
  const rec = (payload && payload.branding) || {};
  const issuer = rec.issuer || {};
  const defaults = rec.defaults || {};
  Object.entries(BRANDING_FIELDS).forEach(([key, id]) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.value = issuer[key] || "";
    // Výchozí hodnota jako našeptávaný placeholder – prázdné pole ji použije.
    if (defaults[key]) el.placeholder = defaults[key];
  });

  const preview = (payload && payload.logo_preview) || "";
  const img = document.getElementById("brand-logo-img");
  const empty = document.getElementById("brand-logo-empty");
  if (img) {
    if (preview) { img.src = preview; img.classList.add("visible"); }
    else { img.removeAttribute("src"); img.classList.remove("visible"); }
  }
  if (empty) empty.classList.toggle("hidden", !!preview);

  const logo = rec.logo || {};
  const info = document.getElementById("brand-logo-info");
  const del = document.getElementById("brand-logo-delete");
  const custom = logo.source === "custom" || logo.source === "invalid";
  if (info) {
    if (logo.source === "custom") {
      const dims = (logo.width && logo.height) ? ` (${logo.width}×${logo.height} px)` : "";
      // Math.max(1, …): drobné logo nesmí hlásit „0 kB“, což vypadá jako chyba.
      const kb = logo.bytes ? `, ${Math.max(1, Math.round(logo.bytes / 1024))} kB` : "";
      info.textContent = `Používá se vlastní logo${dims}${kb}.`;
      info.className = "updates-status";
    } else if (logo.source === "invalid") {
      info.textContent = "Uložené vlastní logo se nepodařilo přečíst; protokol zatím používá vestavěné logo. Nahrajte logo znovu.";
      info.className = "updates-status err";
    } else if (logo.source === "builtin") {
      info.textContent = "Používá se vestavěné logo dodané s programem.";
      info.className = "updates-status";
    } else {
      info.textContent = "Žádné logo není k dispozici; v hlavičce se vysází textová značka.";
      info.className = "updates-status";
    }
  }
  if (del) del.classList.toggle("hidden", !custom);
}

async function loadBranding() {
  try {
    _renderBranding(await api("/api/branding"));
  } catch (e) {
    _brandStatus(e.message || "Nastavení firmy se nepodařilo načíst.", "err");
    throw e;
  }
}

async function saveBranding() {
  const btn = document.getElementById("brand-save");
  const issuer = {};
  Object.entries(BRANDING_FIELDS).forEach(([key, id]) => {
    const el = document.getElementById(id);
    issuer[key] = el ? (el.value || "") : "";
  });
  if (btn) btn.disabled = true;
  _brandStatus("Ukládám…");
  try {
    _renderBranding(await api("/api/branding", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ issuer }),
    }));
    _brandStatus("Údaje firmy uloženy.", "ok");
    toast("Údaje firmy pro protokoly uloženy.");
  } catch (e) {
    _brandStatus(e.message || "Uložení selhalo.", "err");
    toast(e.message || "Uložení údajů firmy selhalo.", true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function resetBranding() {
  if (!confirm("Obnovit výchozí údaje firmy v patičce protokolu? Vaše texty budou nahrazeny hodnotami dodanými s programem. Logo zůstane zachováno.")) return;
  const btn = document.getElementById("brand-reset");
  if (btn) btn.disabled = true;
  try {
    _renderBranding(await api("/api/branding/reset", { method: "POST" }));
    _brandStatus("Obnoveny výchozí údaje.", "ok");
  } catch (e) {
    _brandStatus(e.message || "Obnovení selhalo.", "err");
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function onBrandingLogoChosen(event) {
  const input = event && event.target;
  const file = input && input.files && input.files[0];
  if (!file) return;
  const btn = document.getElementById("brand-logo-pick");
  if (btn) btn.disabled = true;
  _brandStatus("Zpracovávám logo…");
  try {
    // PDF generátor umí vložit pouze JPEG, proto se i PNG převede na canvasu
    // na JPEG s bílým pozadím – stejně jako obrázek stroje.
    const dataUrl = await imageFileToJpegDataUrl(file, 1400, 0.92);
    _renderBranding(await api("/api/branding/logo", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image: dataUrl }),
    }));
    _brandStatus("Logo uloženo.", "ok");
    toast("Logo pro protokoly bylo uloženo.");
  } catch (e) {
    _brandStatus(e.message || "Logo se nepodařilo uložit.", "err");
    toast(e.message || "Logo se nepodařilo uložit.", true);
  } finally {
    if (btn) btn.disabled = false;
    // Umožní znovu vybrat tentýž soubor po opravě.
    if (input) input.value = "";
  }
}

async function deleteBrandingLogo() {
  if (!confirm("Opravdu odstranit vlastní logo? Protokoly se vrátí k vestavěnému logu.")) return;
  const btn = document.getElementById("brand-logo-delete");
  if (btn) btn.disabled = true;
  try {
    _renderBranding(await api("/api/branding/logo", { method: "DELETE" }));
    _brandStatus("Vlastní logo odstraněno.", "ok");
  } catch (e) {
    _brandStatus(e.message || "Logo se nepodařilo odstranit.", "err");
  } finally {
    if (btn) btn.disabled = false;
  }
}

let PERSISTENCE_NOTICE_KEY = "";

function _persistenceLabel(item) {
  const labels = {
    technicians: "Technici", company: "Údaje o podniku",
    machine_config: "Karty strojů", report_history: "Historie",
    report_drafts: "Koncepty", company_attachments: "Přílohy a poznámky",
    custom_norms: "Vlastní normy", ai_examples: "AI vzory",
    ai_prompts: "AI prompty", ai_credentials: "AI klíče",
    ai_config: "Nastavení AI", branding: "Firma a logo",
    shared_updates: "Nastavení aktualizací",
    database_library: "Knihovna databází", active_selection: "Aktivní databáze",
    ndb_and_sidecars: "NDB a doprovodné soubory",
  };
  const name = labels[item.id] || item.id;
  if (item.id === "ai_credentials") {
    const value = item.state === "configured" ? "nastaveno"
      : item.state === "stored_unavailable" ? "uloženo, nedostupné"
      : "nenastaveno";
    return `${name}: ${value}`;
  }
  if (item.id === "ai_prompts") return `${name}: ${item.state === "custom" ? "vlastní" : "výchozí"}`;
  if (item.id === "branding") return `${name}: ${item.state === "custom" ? "vlastní" : "výchozí"}`;
  if (item.state === "unavailable") return `${name}: nedostupné`;
  return `${name}: ${Number.isFinite(item.count) ? `${item.count} položek` : "dostupné"}`;
}

async function loadPersistenceStatus(showToast) {
  const target = document.getElementById("persistence-status");
  if (!target) return;
  try {
    const result = await api("/api/persistence/status");
    const rows = Array.isArray(result.categories) ? result.categories : [];
    target.textContent = rows.map(_persistenceLabel).join(" · ") || "Nejsou k dispozici žádná data.";
    const context = result.context || {};
    target.className = `updates-status${["ambiguous", "conflict"].includes(context.state) ? " err" : ""}`;
    if (result.notice) {
      const key = `${context.code || ""}:${context.folder_hash || ""}`;
      if (showToast || (key && key !== PERSISTENCE_NOTICE_KEY)) {
        toast(result.notice, ["ambiguous", "conflict"].includes(context.state));
        PERSISTENCE_NOTICE_KEY = key;
      }
    }
  } catch (e) {
    target.textContent = "Kontrolu uložených dat se nepodařilo načíst.";
    target.className = "updates-status err";
    if (showToast) toast(e.message || "Kontrola uložených dat selhala.", true);
  }
}

// ================= Bezpečná konfigurace AI agentů =================
// Nikdy nečteme ani nevypisujeme hodnotu uloženého klíče. Pro každou mutaci
// si vyžádáme jednorázový serverový nonce, svázaný se stejným loopback origin.
async function aiConfigNonce() {
  const session = await api("/api/ai/config/session", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-HADS-AI-Config-Session": "request" },
    body: JSON.stringify({ purpose: "ai-config" }),
  });
  return session.nonce;
}

async function aiConfigMutation(path, payload) {
  const nonce = await aiConfigNonce();
  return api(path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-HADS-AI-Config-Nonce": nonce,
    },
    body: JSON.stringify(Object.assign({}, payload, { nonce })),
  });
}

function _aiConfigMessage(text, isErr) {
  const el = document.getElementById("ai-config-status");
  const retry = document.getElementById("ai-config-retry");
  if (!el) return;
  el.textContent = text || "";
  el.className = "updates-status" + (isErr ? " err" : (text ? " ok" : ""));
  if (retry) retry.classList.toggle("hidden", !isErr);
}

function renderAiAgentsSettings(st) {
  st = st || {};
  AI_CONF = {
    models: st.models || [],
    model: st.model || "",
    has_openai_key: !!st.has_openai_key,
    has_anthropic_key: !!st.has_anthropic_key,
  };
  ["openai", "anthropic"].forEach((provider) => {
    const has = provider === "openai" ? AI_CONF.has_openai_key : AI_CONF.has_anthropic_key;
    const providerState = (st.providers || {})[provider] || (has ? "configured" : "not_configured");
    const status = document.getElementById(`ai-${provider}-status`);
    const input = document.getElementById(`ai-${provider}-key`);
    if (status) {
      status.textContent = providerState === "stored_unavailable"
        ? "Klíč je uložen, ale nelze jej na tomto počítači načíst"
        : (has ? "Klíč je nastaven" : "Klíč není nastaven");
      status.className = "ai-provider-status " + (providerState === "stored_unavailable" ? "err" : (has ? "ok" : "empty"));
    }
    // Zásadně nepředvyplňovat ani náhradou maskovaných znaků.
    if (input) input.value = "";
  });
  const select = document.getElementById("ai-default-model");
  if (select) {
    select.textContent = "";
    (AI_CONF.models || []).forEach((model) => {
      const option = document.createElement("option");
      option.value = model.id;
      option.textContent = model.label;
      option.selected = model.id === AI_CONF.model;
      select.appendChild(option);
    });
  }
}

async function loadAiAgentsSettings() {
  const configStatus = document.getElementById("ai-config-status");
  try {
    const st = await api("/api/ai/status");
    renderAiAgentsSettings(st);
    if (configStatus && !configStatus.textContent) _aiConfigMessage("");
  } catch (e) {
    _aiConfigMessage("Stav AI agentů se nepodařilo načíst (spojení s místní službou). Klíče ani nastavení nebyly změněny.", true);
  }
}

async function saveAiProviderKey(provider) {
  const input = document.getElementById(`ai-${provider}-key`);
  const value = input ? (input.value || "").trim() : "";
  if (!value) {
    _aiConfigMessage("Prázdné pole klíč nemění.", false);
    return;
  }
  const btn = document.getElementById(`ai-${provider}-save`);
  if (btn) btn.disabled = true;
  try {
    const st = await aiConfigMutation("/api/ai/config", { provider, api_key: value });
    // Hodnota existuje pouze v proměnné požadavku a hned se vymaže z DOM.
    if (input) input.value = "";
    renderAiAgentsSettings(st);
    _aiConfigMessage(provider === "openai" ? "Klíč OpenAI byl lokálně uložen." : "Klíč Anthropic byl lokálně uložen.", false);
  } catch (e) {
    if (input) input.value = "";
    _aiConfigMessage("Klíč nelze bezpečně uložit. Zkuste akci znovu.", true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function saveAiDefaultModel() {
  const select = document.getElementById("ai-default-model");
  if (!select || !select.value) return;
  try {
    const st = await aiConfigMutation("/api/ai/config", { model: select.value });
    renderAiAgentsSettings(st);
    _aiConfigMessage("Výchozí model AI byl uložen.", false);
  } catch (e) {
    _aiConfigMessage("Výchozí model AI nelze uložit.", true);
  }
}

async function deleteAiProviderKey(provider) {
  const label = provider === "openai" ? "OpenAI" : "Anthropic";
  if (!window.confirm(`Opravdu chcete odstranit lokálně uložený API klíč ${label}? Tuto akci nelze vrátit zpět.`)) return;
  const btn = document.getElementById(`ai-${provider}-delete`);
  if (btn) btn.disabled = true;
  try {
    const st = await aiConfigMutation("/api/ai/config/delete", { provider });
    renderAiAgentsSettings(st);
    _aiConfigMessage(`Klíč ${label} byl odstraněn.`, false);
  } catch (e) {
    _aiConfigMessage(`Klíč ${label} nelze bezpečně odstranit.`, true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ================= Editovatelné AI prompty protokolů =================
// Stav obsahuje pouze texty šablon, nikdy API klíče. Počítadlo brání tomu,
// aby opožděná GET odpověď přepsala novější save/reset z téže obrazovky.
let AI_PROMPTS = { revision: 0, templates: [] };
let AI_PROMPTS_REQUEST = 0;

function _aiPromptsMessage(text, isErr) {
  const el = document.getElementById("ai-prompts-status");
  const retry = document.getElementById("ai-prompts-retry");
  if (!el) return;
  el.textContent = text || "";
  el.className = "updates-status" + (isErr ? " err" : (text ? " ok" : ""));
  if (retry) retry.classList.toggle("hidden", !isErr);
}

async function aiPromptsNonce() {
  const session = await api("/api/ai/prompts/session", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-HADS-AI-Prompts-Session": "request" },
    body: JSON.stringify({ purpose: "ai-prompts" }),
  });
  return session.nonce;
}

async function aiPromptsMutation(path, payload) {
  const nonce = await aiPromptsNonce();
  return api(path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-HADS-AI-Prompts-Nonce": nonce,
    },
    body: JSON.stringify(Object.assign({}, payload, { nonce })),
  });
}

function _renderAiPromptCard(template) {
  const card = document.createElement("section");
  card.className = "ai-prompt-card";
  card.dataset.promptId = template.id;
  const head = document.createElement("div");
  head.className = "ai-prompt-card-head";
  const title = document.createElement("div");
  const h = document.createElement("h3");
  h.textContent = template.label || template.id;
  const purpose = document.createElement("p");
  purpose.textContent = template.purpose || "";
  title.append(h, purpose);
  const state = document.createElement("span");
  state.className = "ai-prompt-state " + (template.is_modified ? "modified" : "default");
  state.textContent = template.is_modified ? "Upraveno" : "Výchozí";
  head.append(title, state);
  card.append(head);

  const meta = document.createElement("p");
  meta.className = "ai-prompt-meta";
  meta.textContent = template.is_modified && template.saved_at
    ? "Naposledy uloženo: " + fmtDate(template.saved_at)
    : "Používá se vestavěná verze aplikace.";
  card.append(meta);

  const label = document.createElement("label");
  label.htmlFor = "ai-prompt-" + template.id;
  label.textContent = "Upravitelná část instrukce";
  const area = document.createElement("textarea");
  area.id = "ai-prompt-" + template.id;
  area.className = "brg-in ai-prompt-editor";
  area.rows = 13;
  area.spellcheck = false;
  area.value = template.text || "";
  area.setAttribute("data-testid", "textarea-ai-prompt-" + template.id);
  card.append(label, area);

  const placeholders = document.createElement("p");
  placeholders.className = "ai-prompt-placeholders";
  placeholders.textContent = "Povinný placeholder: {report_contract} (právě jednou). "
    + "Doslovné závorky: {{ a }}.";
  card.append(placeholders);

  const actions = document.createElement("div");
  actions.className = "norm-form-actions ai-prompt-actions";
  const preview = document.createElement("button");
  preview.type = "button"; preview.className = "cb-btn";
  preview.dataset.action = "preview"; preview.dataset.promptId = template.id;
  preview.textContent = "Testovat náhled";
  const save = document.createElement("button");
  save.type = "button"; save.className = "cb-btn cb-primary";
  save.dataset.action = "save"; save.dataset.promptId = template.id;
  save.textContent = "Uložit";
  const reset = document.createElement("button");
  reset.type = "button"; reset.className = "cb-btn cb-danger";
  reset.dataset.action = "reset"; reset.dataset.promptId = template.id;
  reset.textContent = "Obnovit výchozí…";
  reset.disabled = !template.is_modified;
  actions.append(preview, save, reset);
  card.append(actions);

  const previewBox = document.createElement("pre");
  previewBox.className = "ai-prompt-preview hidden";
  previewBox.id = "ai-prompt-preview-" + template.id;
  previewBox.setAttribute("aria-live", "polite");
  card.append(previewBox);
  return card;
}

function renderAiPrompts(config) {
  AI_PROMPTS = {
    revision: Number(config && config.revision) || 0,
    templates: (config && config.templates) || [],
  };
  const list = document.getElementById("ai-prompts-list");
  if (!list) return;
  list.textContent = "";
  AI_PROMPTS.templates.forEach((template) => list.append(_renderAiPromptCard(template)));
  const warnings = (config && config.warnings) || [];
  if (warnings.length) _aiPromptsMessage(warnings.join(" ") + " Úpravu můžete obnovit nebo znovu uložit.", true);
  else {
    const status = document.getElementById("ai-prompts-status");
    if (status && !status.textContent) _aiPromptsMessage("", false);
  }
}

async function loadAiPrompts() {
  const request = ++AI_PROMPTS_REQUEST;
  try {
    const config = await api("/api/ai/prompts");
    if (request !== AI_PROMPTS_REQUEST) return;
    renderAiPrompts(config);
  } catch (error) {
    if (request !== AI_PROMPTS_REQUEST) return;
    _aiPromptsMessage("AI prompty se nepodařilo načíst (spojení s místní službou). Uložené prompty nebyly změněny.", true);
    throw error;
  }
}

async function onAiPromptListClick(event) {
  const button = event.target.closest("button[data-action][data-prompt-id]");
  if (!button) return;
  const id = button.dataset.promptId;
  const template = AI_PROMPTS.templates.find((item) => item.id === id);
  const area = document.getElementById("ai-prompt-" + id);
  if (!template || !area) return;
  const action = button.dataset.action;
  if (action === "preview") {
    button.disabled = true;
    _aiPromptsMessage("Připravuji lokální náhled…", false);
    try {
      const result = await api("/api/ai/prompts/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, text: area.value }),
      });
      const box = document.getElementById("ai-prompt-preview-" + id);
      if (box) {
        box.textContent = "NÁHLED SYSTEM INSTRUKCE\n\n" + result.system_prompt
          + "\n\nANONYMIZOVANÝ UKÁZKOVÝ KONTEXT\n\n" + result.sample_context;
        box.classList.remove("hidden");
      }
      _aiPromptsMessage("Náhled je připraven lokálně; AI nebyla volána.", false);
    } catch (e) {
      _aiPromptsMessage(e.message || "Náhled nelze připravit.", true);
    } finally {
      button.disabled = false;
    }
    return;
  }
  if (action === "reset") {
    if (!window.confirm("Obnovit výchozí prompt „" + template.label + "“? Vaše úprava této šablony bude odstraněna.")) return;
    button.disabled = true;
    try {
      const config = await aiPromptsMutation("/api/ai/prompts/" + encodeURIComponent(id) + "/reset", {
        revision: AI_PROMPTS.revision,
      });
      renderAiPrompts(config);
      _aiPromptsMessage("Výchozí prompt byl obnoven.", false);
    } catch (e) {
      _aiPromptsMessage(e.message || "Obnovení výchozího promptu se nezdařilo.", true);
    } finally {
      button.disabled = false;
    }
    return;
  }
  if (action === "save") {
    button.disabled = true;
    try {
      const config = await aiPromptsMutation("/api/ai/prompts", {
        id,
        text: area.value,
        revision: AI_PROMPTS.revision,
      });
      renderAiPrompts(config);
      _aiPromptsMessage("AI prompt byl uložen.", false);
    } catch (e) {
      _aiPromptsMessage(e.message || "AI prompt se nepodařilo uložit.", true);
    } finally {
      button.disabled = false;
    }
  }
}

async function saveSettings() {
  const btn = document.getElementById("settings-save");
  const statusEl = document.getElementById("settings-status");
  const gv = (id) => { const e = document.getElementById(id); return e ? (e.value || "") : ""; };
  const payload = {
    quantities: {
      velocity: gv("set-q-velocity"),
      accel: gv("set-q-accel"),
      env: gv("set-q-env"),
    },
    technicians: SETTINGS_TECHS.slice(),
  };
  if (btn) btn.disabled = true;
  if (statusEl) { statusEl.textContent = "Ukládám…"; statusEl.className = "company-status"; }
  try {
    await api("/api/report/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (statusEl) { statusEl.textContent = "Nastavení uloženo."; statusEl.className = "company-status ok"; }
    toast("Nastavení databáze uloženo.");
    // aktualizuj datalist techniků pro editor protokolu
    _populateTechDatalist(SETTINGS_TECHS);
  } catch (e) {
    if (statusEl) { statusEl.textContent = e.message || "Uložení selhalo."; statusEl.className = "company-status err"; }
    toast(e.message || "Uložení selhalo.", true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ---------- Vlastní normy (globální, se třemi mezemi A/B, B/C, C/D) ----------
let CUSTOM_NORMS = [];
let NORM_EDITING = null; // {standard, machine_class} když upravujeme

function _normStatus(msg, kind) {
  const el = document.getElementById("set-norm-status");
  if (!el) return;
  el.textContent = msg || "";
  el.className = "company-status" + (kind ? " " + kind : "");
}

// Vykreslí jeden řádek třídy do formuláře. `data` = {machine_class, ab, warning, alarm}.
// `lockName` zamkne pole názvu třídy (používá se při úpravě jedné třídy).
function addNormRow(data, lockName) {
  const wrap = document.getElementById("set-norm-rows");
  if (!wrap) return;
  const d = data || {};
  const fmt = (v) => (v === null || v === undefined || v === "") ? "" : String(v).replace(".", ",");
  const row = document.createElement("div");
  row.className = "norm-row";
  row.innerHTML =
    `<div class="brg-field norm-row-class">` +
      `<label>Třída / kategorie stroje</label>` +
      `<input class="brg-in nr-class" type="text" placeholder="Např. VR8 / BV-3 tuhé" />` +
    `</div>` +
    `<div class="brg-field">` +
      `<label><span class="norm-dot norm-dot-ab"></span> A/B [mm/s] <span class="norm-opt">(volitelné)</span></label>` +
      `<input class="brg-in nr-ab" type="text" inputmode="decimal" placeholder="Např. 5" />` +
    `</div>` +
    `<div class="brg-field">` +
      `<label><span class="norm-dot norm-dot-c"></span> B/C – varování [mm/s]</label>` +
      `<input class="brg-in nr-warning" type="text" inputmode="decimal" placeholder="Např. 8" />` +
    `</div>` +
    `<div class="brg-field">` +
      `<label><span class="norm-dot norm-dot-d"></span> C/D – alarm [mm/s] <span class="norm-opt">(volitelné)</span></label>` +
      `<input class="brg-in nr-alarm" type="text" inputmode="decimal" placeholder="Např. 12,5" />` +
    `</div>` +
    `<button type="button" class="norm-row-del" title="Odebrat třídu">×</button>`;
  row.querySelector(".nr-class").value = d.machine_class || "";
  row.querySelector(".nr-ab").value = fmt(d.ab);
  row.querySelector(".nr-warning").value = fmt(d.warning);
  row.querySelector(".nr-alarm").value = fmt(d.alarm);
  if (lockName) row.querySelector(".nr-class").disabled = true;
  row.querySelector(".norm-row-del").addEventListener("click", () => {
    const rows = wrap.querySelectorAll(".norm-row");
    if (rows.length <= 1) { // poslední řádek jen vyprázdni
      row.querySelectorAll("input").forEach((i) => { i.value = ""; });
    } else {
      row.remove();
    }
  });
  wrap.appendChild(row);
  return row;
}

// Posbírá všechny řádky tříd z formuláře do pole objektů (jen neprázdné).
function collectNormRows() {
  const wrap = document.getElementById("set-norm-rows");
  const out = [];
  if (!wrap) return out;
  wrap.querySelectorAll(".norm-row").forEach((row) => {
    const cls = (row.querySelector(".nr-class").value || "").trim();
    const ab = (row.querySelector(".nr-ab").value || "").trim();
    const warning = (row.querySelector(".nr-warning").value || "").trim();
    const alarm = (row.querySelector(".nr-alarm").value || "").trim();
    // řádek je „prázdný“ (přeskoč), když nemá vyplněno vůbec nic
    if (!cls && !ab && !warning && !alarm) return;
    const c = { machine_class: cls, warning: warning };
    if (ab) c.ab = ab;
    if (alarm) c.alarm = alarm;
    out.push(c);
  });
  return out;
}

function resetNormForm() {
  NORM_EDITING = null;
  const std = document.getElementById("set-norm-standard");
  if (std) { std.value = ""; std.disabled = false; }
  const wrap = document.getElementById("set-norm-rows");
  if (wrap) wrap.innerHTML = "";
  addNormRow(); // jeden prázdný řádek
  const t = document.getElementById("set-norm-form-title");
  if (t) t.textContent = "Přidat normu";
  const add = document.getElementById("set-norm-add");
  if (add) add.textContent = "Přidat normu";
  const cancel = document.getElementById("set-norm-cancel");
  if (cancel) cancel.classList.add("hidden");
  const rowAdd = document.getElementById("set-norm-row-add");
  if (rowAdd) rowAdd.classList.remove("hidden");
  _normStatus("");
}

async function loadCustomNorms() {
  try {
    const r = await api("/api/norms/custom");
    CUSTOM_NORMS = (r && r.norms) || [];
  } catch (e) {
    CUSTOM_NORMS = [];
  }
  renderNormsList();
}


// ================= AI vzory (znalostní báze – varianta B) =================
var AIEX_LIST = [];
var AIEX_KINDS = [];
var AIEX_SEVERITIES = [];
var AIEX_EDITING = null; // id upravovaného vzoru

var AIEX_KIND_LABELS = {
  "obecne": "Obecný stroj",
  "ventilator": "Ventilátor",
  "cerpadlo": "Čerpadlo",
  "motor": "Elektromotor",
  "prevodovka": "Převodovka",
  "kompresor": "Kompresor",
  "loziskovy_uzel": "Ložiskový uzel",
};
var AIEX_SEV_LABELS = {
  "": "– neurčeno –",
  "ok": "OK (pásmo A/B)",
  "warn": "Upozornění (pásmo C)",
  "alarm": "Výstraha (pásmo D)",
};

function aiexKindLabel(k) { return AIEX_KIND_LABELS[k] || k || "–"; }
function aiexSevLabel(s) { return AIEX_SEV_LABELS[s] !== undefined ? AIEX_SEV_LABELS[s] : (s || "–"); }

function _aiexFillSelect(id, values, labelFn, current) {
  var el = document.getElementById(id);
  if (!el) return;
  var html = "";
  (values || []).forEach(function (v) {
    var sel = (v === current) ? " selected" : "";
    html += '<option value="' + escapeHtml(v) + '"' + sel + '>' + escapeHtml(labelFn(v)) + '</option>';
  });
  el.innerHTML = html;
}

async function loadAiExamples() {
  try {
    var r = await api("/api/ai/examples");
    AIEX_LIST = (r && r.examples) || [];
    AIEX_KINDS = (r && r.machine_kinds) || [];
    AIEX_SEVERITIES = (r && r.severities) || [];
  } catch (e) {
    AIEX_LIST = []; AIEX_KINDS = []; AIEX_SEVERITIES = [];
  }
  // naplň číselníky formuláře (typ + stav)
  _aiexFillSelect("aiex-kind", AIEX_KINDS, aiexKindLabel,
    (AIEX_EDITING ? null : (AIEX_KINDS[0] || "obecne")));
  _aiexFillSelect("aiex-severity", AIEX_SEVERITIES, aiexSevLabel, null);
  renderAiExamplesList();
}

function renderAiExamplesList() {
  var ul = document.getElementById("aiex-list");
  if (!ul) return;
  if (!AIEX_LIST.length) {
    ul.innerHTML = '<li class="tech-list-empty">Zatím žádné vzory. Přidejte první vzor výše, nebo jej povyšte z hotového protokolu tlačítkem „Povýšit na vzor“.</li>';
    return;
  }
  var html = "";
  AIEX_LIST.forEach(function (e) {
    var off = e.enabled === false;
    var faults = Array.isArray(e.fault) ? e.fault.join(", ") : "";
    var badge = off
      ? '<span class="norm-badge norm-badge-builtin">vypnuto</span>'
      : '<span class="norm-badge norm-badge-custom">aktivní</span>';
    html += '<li class="norm-group"><div class="norm-group-head">' +
      '<span class="norm-std">' + escapeHtml(aiexKindLabel(e.machine_kind)) +
      ' · v' + escapeHtml(String(e.report_version || "?")) +
      ' · ' + escapeHtml(aiexSevLabel(e.severity || "")) + '</span> ' + badge +
      '<span class="norm-class-actions" style="margin-left:auto">' +
      '<button type="button" class="norm-edit" data-id="' + escapeHtml(e.id) + '">Upravit</button>' +
      '<button type="button" class="aiex-toggle norm-edit" data-id="' + escapeHtml(e.id) + '">' + (off ? "Zapnout" : "Vypnout") + '</button>' +
      '<button type="button" class="norm-del" data-id="' + escapeHtml(e.id) + '" title="Smazat vzor">×</button>' +
      '</span></div>';
    if (faults) {
      html += '<div class="norm-class-row"><span class="norm-class-name">Závady: ' + escapeHtml(faults) + '</span></div>';
    }
    if (e.situation) {
      html += '<div class="norm-class-row"><span class="norm-class-name" style="white-space:normal"><strong>Situace:</strong> ' + escapeHtml(e.situation) + '</span></div>';
    }
    html += '<div class="norm-class-row"><span class="norm-class-name" style="white-space:normal"><strong>Závěr:</strong> ' + escapeHtml(e.zaver || "") + '</span></div>';
    if (e.doporuceni) {
      html += '<div class="norm-class-row"><span class="norm-class-name" style="white-space:normal"><strong>Doporučení:</strong> ' + escapeHtml(e.doporuceni) + '</span></div>';
    }
    html += '</li>';
  });
  ul.innerHTML = html;
  ul.querySelectorAll(".aiex-toggle").forEach(function (b) {
    b.addEventListener("click", function () { onAiExampleToggle(b.dataset.id); });
  });
  ul.querySelectorAll(".norm-edit:not(.aiex-toggle)").forEach(function (b) {
    b.addEventListener("click", function () { startEditAiExample(b.dataset.id); });
  });
  ul.querySelectorAll(".norm-del").forEach(function (b) {
    b.addEventListener("click", function () { onAiExampleDelete(b.dataset.id); });
  });
}

function _aiexReadForm() {
  var gv = function (id) { var el = document.getElementById(id); return el ? (el.value || "") : ""; };
  var faults = gv("aiex-fault").split(",").map(function (s) { return s.trim(); }).filter(Boolean);
  return {
    machine_kind: gv("aiex-kind"),
    report_version: parseInt(gv("aiex-version"), 10) || 2,
    severity: gv("aiex-severity"),
    fault: faults,
    situation: gv("aiex-situation").trim(),
    zaver: gv("aiex-zaver").trim(),
    doporuceni: gv("aiex-doporuceni").trim(),
  };
}

function resetAiExampleForm() {
  AIEX_EDITING = null;
  var ids = ["aiex-fault", "aiex-situation", "aiex-zaver", "aiex-doporuceni"];
  ids.forEach(function (id) { var el = document.getElementById(id); if (el) el.value = ""; });
  var kind = document.getElementById("aiex-kind"); if (kind && kind.options.length) kind.selectedIndex = 0;
  var ver = document.getElementById("aiex-version"); if (ver) ver.value = "2";
  var sev = document.getElementById("aiex-severity"); if (sev && sev.options.length) sev.selectedIndex = 0;
  var title = document.getElementById("aiex-form-title"); if (title) title.textContent = "Přidat vzor závěru";
  var cancel = document.getElementById("aiex-cancel"); if (cancel) cancel.style.display = "none";
  var st = document.getElementById("aiex-status"); if (st) { st.textContent = ""; st.className = "company-status"; }
}

function startEditAiExample(id) {
  var e = (AIEX_LIST || []).find(function (x) { return x.id === id; });
  if (!e) return;
  AIEX_EDITING = id;
  var sv = function (fid, val) { var el = document.getElementById(fid); if (el) el.value = val; };
  sv("aiex-kind", e.machine_kind || "");
  sv("aiex-version", String(e.report_version || 2));
  sv("aiex-severity", e.severity || "");
  sv("aiex-fault", Array.isArray(e.fault) ? e.fault.join(", ") : "");
  sv("aiex-situation", e.situation || "");
  sv("aiex-zaver", e.zaver || "");
  sv("aiex-doporuceni", e.doporuceni || "");
  var title = document.getElementById("aiex-form-title"); if (title) title.textContent = "Upravit vzor závěru";
  var cancel = document.getElementById("aiex-cancel"); if (cancel) cancel.style.display = "";
  switchSettingsTab("aiexamples");
  var pane = document.getElementById("settings-pane-aiexamples");
  if (pane && pane.scrollIntoView) pane.scrollIntoView({ behavior: "smooth", block: "start" });
}

async function onAiExampleSave() {
  var payload = _aiexReadForm();
  var st = document.getElementById("aiex-status");
  if (!payload.situation || !payload.zaver) {
    if (st) { st.textContent = "Vyplňte aspoň pole „Situace“ a „Závěr“."; st.className = "company-status err"; }
    return;
  }
  var btn = document.getElementById("aiex-save");
  if (btn) btn.disabled = true;
  if (st) { st.textContent = "Ukládám…"; st.className = "company-status"; }
  try {
    var url = AIEX_EDITING ? ("/api/ai/examples/" + encodeURIComponent(AIEX_EDITING)) : "/api/ai/examples";
    await api(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    resetAiExampleForm();
    await loadAiExamples();
    if (st) { st.textContent = "Vzor uložen."; st.className = "company-status ok"; }
  } catch (e) {
    if (st) { st.textContent = e.message || "Uložení se nezdařilo."; st.className = "company-status err"; }
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function onAiExampleToggle(id) {
  var e = (AIEX_LIST || []).find(function (x) { return x.id === id; });
  if (!e) return;
  try {
    await api("/api/ai/examples/" + encodeURIComponent(id), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled: e.enabled === false }),
    });
    await loadAiExamples();
  } catch (err) { toast(err.message || "Změna se nezdařila.", true); }
}

async function onAiExampleDelete(id) {
  if (!confirm("Opravdu smazat tento vzor ze znalostní báze?")) return;
  try {
    await api("/api/ai/examples/" + encodeURIComponent(id), { method: "DELETE" });
    if (AIEX_EDITING === id) resetAiExampleForm();
    await loadAiExamples();
  } catch (err) { toast(err.message || "Smazání se nezdařilo.", true); }
}

// Povýšení hotového per-stroj závěru z protokolu na vzor do znalostní báze.
// Předvyplní formulář AI vzorů a přepne na záložku nastavení.
function promoteToAiExample(prefill) {
  prefill = prefill || {};
  showView("settings");
  switchSettingsTab("aiexamples");
  // číselníky musí existovat (naplní se při načtení); dolaď po malé prodlevě
  var apply = function () {
    resetAiExampleForm();
    var sv = function (fid, val) { var el = document.getElementById(fid); if (el && val != null) el.value = val; };
    if (prefill.machine_kind) sv("aiex-kind", prefill.machine_kind);
    if (prefill.report_version) sv("aiex-version", String(prefill.report_version));
    if (prefill.severity) sv("aiex-severity", prefill.severity);
    if (prefill.fault) sv("aiex-fault", Array.isArray(prefill.fault) ? prefill.fault.join(", ") : prefill.fault);
    sv("aiex-situation", prefill.situation || prefill.problem || "");
    sv("aiex-zaver", prefill.zaver || "");
    sv("aiex-doporuceni", prefill.doporuceni || "");
    var st = document.getElementById("aiex-status");
    if (st) { st.textContent = "Předvyplněno z protokolu – zkontrolujte a uložte."; st.className = "company-status"; }
    var pane = document.getElementById("settings-pane-aiexamples");
    if (pane && pane.scrollIntoView) pane.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  loadAiExamples().then(apply, apply);
}

function renderNormsList() {
  const ul = document.getElementById("set-norm-list");
  if (!ul) return;
  const cat = Array.isArray(NORMS_CATALOG) ? NORMS_CATALOG : [];
  if (!cat.length) {
    ul.innerHTML = '<li class="tech-list-empty">Katalog norem se načítá…</li>';
    return;
  }
  const fmt = (v) => (v === null || v === undefined || v === "") ? "–" : String(v).replace(".", ",");
  let html = "";
  cat.forEach((norm) => {
    const builtin = norm.builtin !== false; // undefined => vestavěná
    const badge = builtin
      ? '<span class="norm-badge norm-badge-builtin">vestavěná</span>'
      : '<span class="norm-badge norm-badge-custom">vlastní</span>';
    html += `<li class="norm-group"><div class="norm-group-head">` +
      `<span class="norm-std">${escapeHtml(norm.standard)}</span> ${badge}` +
      (builtin ? "" :
        `<button type="button" class="norm-del-all" data-std="${escapeHtml(norm.standard)}" title="Smazat celou normu">Smazat normu</button>`) +
      `</div>`;
    (norm.classes || []).forEach((c) => {
      html += `<div class="norm-class-row">` +
        `<span class="norm-class-name" title="${escapeHtml(c.machine_class)}">${escapeHtml(c.machine_class)}</span>` +
        `<span class="norm-limits">` +
          `<span class="norm-chip norm-chip-ab" title="Hranice A/B">A/B ${fmt(c.ab)}</span>` +
          `<span class="norm-chip norm-chip-c" title="Varování (B/C)">B/C ${fmt(c.warning)}</span>` +
          `<span class="norm-chip norm-chip-d" title="Alarm (C/D)">C/D ${fmt(c.alarm)}</span>` +
        `</span>`;
      if (!builtin) {
        html += `<span class="norm-class-actions">` +
          `<button type="button" class="norm-edit" data-std="${escapeHtml(norm.standard)}" data-cls="${escapeHtml(c.machine_class)}" title="Upravit">Upravit</button>` +
          `<button type="button" class="norm-del" data-std="${escapeHtml(norm.standard)}" data-cls="${escapeHtml(c.machine_class)}" title="Smazat třídu">×</button>` +
          `</span>`;
      }
      html += `</div>`;
    });
    html += `</li>`;
  });
  ul.innerHTML = html;
  ul.querySelectorAll(".norm-edit").forEach((b) => b.addEventListener("click", () =>
    startEditNorm(b.dataset.std, b.dataset.cls)));
  ul.querySelectorAll(".norm-del").forEach((b) => b.addEventListener("click", () =>
    onNormDelete(b.dataset.std, b.dataset.cls)));
  ul.querySelectorAll(".norm-del-all").forEach((b) => b.addEventListener("click", () =>
    onNormDelete(b.dataset.std, null)));
}

function startEditNorm(standard, machineClass) {
  const norm = (CUSTOM_NORMS || []).find((n) => n.standard === standard);
  const cls = norm && (norm.classes || []).find((c) => c.machine_class === machineClass);
  if (!cls) { toast("Normu nelze upravit (není vlastní).", true); return; }
  NORM_EDITING = { standard: standard, machine_class: machineClass };
  const std = document.getElementById("set-norm-standard");
  std.value = standard;
  std.disabled = true; // název normy je klíč – při úpravě zamknut
  const wrap = document.getElementById("set-norm-rows");
  if (wrap) wrap.innerHTML = "";
  // upravujeme jen jednu třídu; její název je zamčený (klíč záznamu)
  addNormRow(cls, true);
  // při úpravě jedné třídy nepovolujeme přidávání dalších řádků
  const rowAdd = document.getElementById("set-norm-row-add");
  if (rowAdd) rowAdd.classList.add("hidden");
  document.getElementById("set-norm-form-title").textContent = "Upravit normu";
  document.getElementById("set-norm-add").textContent = "Uložit změny";
  document.getElementById("set-norm-cancel").classList.remove("hidden");
  _normStatus("");
  switchSettingsTab("norms");
  const first = wrap && wrap.querySelector(".nr-ab");
  if (first) first.focus();
}

async function onNormSave() {
  const standard = (document.getElementById("set-norm-standard").value || "").trim();
  if (!standard) { _normStatus("Vyplňte název normy.", "err"); return; }
  const rows = collectNormRows();
  if (!rows.length) { _normStatus("Přidejte alespoň jednu třídu.", "err"); return; }
  // validace řádků: název + mez B/C povinné; A/B < B/C; C/D > B/C
  for (const c of rows) {
    if (!c.machine_class) { _normStatus("U každé třídy vyplňte její název.", "err"); return; }
    if (!c.warning) { _normStatus(`U třídy „${c.machine_class}“ vyplňte mez B/C (varování).`, "err"); return; }
    const w = parseFloat(String(c.warning).replace(",", "."));
    const a = c.alarm ? parseFloat(String(c.alarm).replace(",", ".")) : null;
    const ab = c.ab ? parseFloat(String(c.ab).replace(",", ".")) : null;
    if (!isFinite(w)) { _normStatus(`U třídy „${c.machine_class}“ je mez B/C nečíselná.`, "err"); return; }
    if (a !== null && !(a > w)) { _normStatus(`U třídy „${c.machine_class}“ musí být C/D (alarm) větší než B/C.`, "err"); return; }
    if (ab !== null && !(ab < w)) { _normStatus(`U třídy „${c.machine_class}“ musí být A/B menší než B/C.`, "err"); return; }
  }
  // duplicitní názvy tříd v rámci jednoho odeslání
  const names = rows.map((c) => c.machine_class);
  if (new Set(names).size !== names.length) { _normStatus("Názvy tříd se nesmí opakovat.", "err"); return; }
  const payload = { standard, classes: rows };
  const btn = document.getElementById("set-norm-add");
  if (btn) btn.disabled = true;
  _normStatus("Ukládám…");
  try {
    const r = await api("/api/norms/custom", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    CUSTOM_NORMS = (r && r.norms) || [];
    if (r && r.catalog) NORMS_CATALOG = r.catalog;
    const msg = NORM_EDITING ? "Norma upravena."
      : (rows.length > 1 ? `Norma přidána (${rows.length} tříd).` : "Norma přidána.");
    _normStatus(msg, "ok");
    toast(msg);
    resetNormForm();
    renderNormsList();
  } catch (e) {
    _normStatus(e.message || "Uložení selhalo.", "err");
    toast(e.message || "Uložení normy selhalo.", true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function onNormDelete(standard, machineClass) {
  const msg = machineClass
    ? `Smazat třídu „${machineClass}“ z normy „${standard}“?`
    : `Smazat celou normu „${standard}“ včetně všech tříd?`;
  if (!confirm(msg)) return;
  try {
    const r = await api("/api/norms/custom/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ standard, machine_class: machineClass || null }),
    });
    CUSTOM_NORMS = (r && r.norms) || [];
    if (r && r.catalog) NORMS_CATALOG = r.catalog;
    toast("Norma smazána.");
    if (NORM_EDITING && NORM_EDITING.standard === standard &&
        (!machineClass || NORM_EDITING.machine_class === machineClass)) {
      resetNormForm();
    }
    renderNormsList();
  } catch (e) {
    toast(e.message || "Smazání selhalo.", true);
  }
}

// Naplní <datalist id="tech-datalist"> jmény techniků pro auto-doplňování
// v polích Vypracoval / Měřil / Schválil.
function _populateTechDatalist(techs) {
  const dl = document.getElementById("tech-datalist");
  if (!dl) return;
  const list = Array.isArray(techs) ? techs : [];
  dl.innerHTML = list.map((t) => `<option value="${escapeHtml(t)}"></option>`).join("");
}

// Načte techniků z API a naplní datalist (volá se při otevření editoru protokolu).
async function loadTechDatalist() {
  try {
    const rs = await api("/api/report/settings");
    const s = (rs && rs.settings) || {};
    _populateTechDatalist(Array.isArray(s.technicians) ? s.technicians : []);
  } catch (e) { /* ticho – datalist zůstane prázdný */ }
}

function fmtSize(mb) {
  if (mb === null || mb === undefined) return "";
  return mb >= 1 ? `${fmtNum(mb, 1)} MB` : `${fmtNum(mb * 1024, 0)} kB`;
}

function renderDbList() {
  const ul = document.getElementById("db-list");
  ul.innerHTML = "";
  const dbs = STATE.databases || [];
  if (!dbs.length) {
    ul.innerHTML = '<li class="empty">Knihovna je prázdná. Přidejte databázi tlačítkem níže.</li>';
    return;
  }
  dbs.forEach(db => {
    const li = document.createElement("li");
    li.className = "db-item" + (db.active ? " active" : "");
    const sub = [db.filename, fmtSize(db.size_mb), db.modified ? fmtDate(db.modified) : ""]
      .filter(Boolean).join("  ·  ");
    li.innerHTML = `
      <div class="db-meta">
        <div class="db-title">${escapeHtml(db.display_name)}</div>
        <div class="db-sub">${escapeHtml(sub)}</div>
      </div>
      ${db.active ? '<span class="badge-active">AKTIVNÍ</span>' : ""}
      <div class="db-actions">
        ${db.active ? "" : `<button class="act-open" title="Otevřít"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>`}
        <button class="act-rename" title="Přejmenovat"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9M16.5 3.5a2.12 2.12 0 013 3L7 19l-4 1 1-4 12.5-12.5z"/></svg></button>
        <button class="act-del" title="Smazat"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/></svg></button>
      </div>`;
    const openBtn = li.querySelector(".act-open");
    if (openBtn) openBtn.addEventListener("click", async () => {
      await switchDatabase(db.filename); renderDbList();
    });
    li.querySelector(".act-rename").addEventListener("click", () => renameDatabase(db));
    li.querySelector(".act-del").addEventListener("click", () => deleteDatabase(db));
    ul.appendChild(li);
  });
}

async function renameDatabase(db) {
  const name = prompt("Zadejte název databáze:", db.display_name);
  if (name === null) return;
  try {
    await api("/api/databases/rename", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: db.filename, display_name: name }),
    });
    await refreshDbSelect();
    renderDbList();
    toast("Název uložen.");
  } catch (err) {
    toast(err.message, true);
  }
}

async function deleteDatabase(db) {
  if (!confirm(`Opravdu smazat databázi "${db.display_name}"?\nSoubor bude trvale odstraněn z disku.`)) return;
  try {
    const r = await api("/api/databases/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: db.filename }),
    });
    await refreshDbSelect();
    renderDbList();
    toast("Databáze smazána.");
    if (r.active) {
      await loadAll();
    } else if (!(STATE.databases || []).length) {
      STATE.nodes = []; renderTree();
      showEmpty("Nahrajte databázi .ndb z měřicího přístroje.");
    }
  } catch (err) {
    toast(err.message, true);
  }
}


async function loadAll() {
  // při načtení (jiné) databáze zavřít všechny otevřené panely – patří k předchozím datům
  PANELS.list = [];
  PANELS.active = null;
  renderPanelTabbar();
  const tree = await api("/api/tree");
  STATE.nodes = tree.nodes;
  STATE.severities = tree.severities;
  STATE.sevById = {};
  tree.severities.forEach(s => STATE.sevById[s.id] = s);
  STATE.pointSeverity = tree.point_severity || {};
  STATE.byId = {}; STATE.children = {};
  tree.nodes.forEach(n => {
    STATE.byId[n.id] = n;
    (STATE.children[n.parent] = STATE.children[n.parent] || []).push(n);
  });
  renderTree();
  await renderDashboard();
}

// ---------- TREE ----------
function renderTree() {
  const root = document.getElementById("tree");
  root.innerHTML = "";
  const roots = STATE.children[0] || STATE.nodes.filter(n => !STATE.byId[n.parent]);
  roots.forEach(n => root.appendChild(buildNode(n, 0)));
  // otevři první úroveň
  root.querySelectorAll(".tnode[data-type='1'] > .tchildren").forEach(c => c.classList.add("open"));
  root.querySelectorAll(".tnode[data-type='1'] > .trow .tcaret").forEach(c => c.classList.add("open"));
  _syncCollapseAllLabel();
}

// Vrátí true, pokud je aktuálně ve stromu rozbalen alespoň jeden uzel.
function _treeHasOpenNode() {
  const root = document.getElementById("tree");
  if (!root) return false;
  return !!root.querySelector(".tchildren.open");
}

// Aktualizuje popisek tlačítka podle stavu stromu (Sbalit vše / Rozbalit vše).
function _syncCollapseAllLabel() {
  const label = document.getElementById("tree-collapse-all-label");
  if (!label) return;
  label.textContent = _treeHasOpenNode() ? "Sbalit vše" : "Rozbalit vše";
}

// Sbalí celý strom (všechny uzly), nebo – pokud už je vše sbalené – rozbalí
// všechny uzly. Tlačítko u vyhledávání nad stromem.
function toggleCollapseAllTree() {
  const root = document.getElementById("tree");
  if (!root) return;
  const expand = !_treeHasOpenNode();  // nic není otevřeno => rozbalíme vše
  root.querySelectorAll(".tchildren").forEach(c => {
    // listové uzly (měřicí body) nemají děti – těch se to netýká
    c.classList.toggle("open", expand);
  });
  root.querySelectorAll(".trow .tcaret").forEach(c => {
    if (c.classList.contains("leaf")) return;
    c.classList.toggle("open", expand);
  });
  _syncCollapseAllLabel();
}

// nejhorší závažnost ze všech měřicích bodů (type 3) pod daným uzlem stromu
// (rekurzivně — pro stroj to jsou přímé potomci, ale funguje i pro hlubší strukturu)
function worstPointSeverity(nodeId) {
  const kids = STATE.children[nodeId] || [];
  let worst = 0;
  kids.forEach(k => {
    if (k.type === 3) {
      const sev = STATE.pointSeverity[k.id];
      if (sev && sev > worst) worst = sev;
    } else {
      const sub = worstPointSeverity(k.id);
      if (sub > worst) worst = sub;
    }
  });
  return worst;
}

function buildNode(node, depth) {
  const wrap = document.createElement("div");
  wrap.className = "tnode";
  wrap.dataset.type = node.type;
  wrap.dataset.id = node.id;

  const kids = STATE.children[node.id] || [];
  const isLeaf = node.type === 3 || kids.length === 0;

  const row = document.createElement("div");
  row.className = "trow";
  row.style.paddingLeft = (12 + depth * 14) + "px";
  row.dataset.id = node.id;

  const icon = node.type === 1 ? ICONS.plant : node.type === 2 ? ICONS.machine : ICONS.point;
  row.innerHTML = ICONS.caret + icon + `<span class="tname">${escapeHtml(node.name)}</span>`;
  const caret = row.querySelector(".tcaret");
  if (isLeaf) caret.classList.add("leaf");

  // zaškrtávací políčko pro režim porovnání (jen u měřicích bodů)
  if (node.type === 3) {
    const cb = document.createElement("span");
    cb.className = "tcheck";
    if (STATE.compareSel.includes(node.id)) cb.classList.add("on");
    cb.innerHTML = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 12l5 5L20 6"/></svg>';
    row.insertBefore(cb, row.firstChild.nextSibling);
  }

  // dot for severity on points
  if (node.type === 3) {
    const sev = STATE.pointSeverity[node.id];
    const dot = document.createElement("span");
    dot.className = "tdot";
    dot.style.background = (sev && sev > 0) ? sevColor(sev) : getCss("--sev-none");
    row.appendChild(dot);
  }

  // dot for severity on machines (nejhorší stav ze všech jeho bodů)
  if (node.type === 2) {
    const sev = worstPointSeverity(node.id);
    const dot = document.createElement("span");
    dot.className = "tdot";
    dot.style.background = (sev && sev > 0) ? sevColor(sev) : getCss("--sev-none");
    row.appendChild(dot);
  }

  wrap.appendChild(row);

  const childWrap = document.createElement("div");
  childWrap.className = "tchildren";
  kids.forEach(k => childWrap.appendChild(buildNode(k, depth + 1)));
  wrap.appendChild(childWrap);

  row.addEventListener("click", (e) => {
    e.stopPropagation();
    if (node.type === 3 && STATE.compareMode) {
      togglePointSelection(node.id, row);
      return;
    }
    if (!isLeaf) {
      caret.classList.toggle("open");
      childWrap.classList.toggle("open");
      _syncCollapseAllLabel();
    }
    if (node.type === 3) {
      selectPoint(node.id, row);
    } else if (node.type === 2) {
      // klik na stroj (uzel s měřenými body) zobrazí kartu příslušného stroje
      openMachine(node.id);
    }
  });

  return wrap;
}

function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function onSearch(e) {
  const q = e.target.value.trim().toLowerCase();
  const nodes = document.querySelectorAll(".tnode");
  if (!q) { nodes.forEach(n => n.style.display = ""); return; }
  nodes.forEach(n => {
    const name = STATE.byId[n.dataset.id]?.name?.toLowerCase() || "";
    const match = name.includes(q);
    n.style.display = match ? "" : "none";
    if (match) { // show ancestors
      let p = n.parentElement.closest(".tnode");
      while (p) {
        p.style.display = "";
        const cw = p.querySelector(".tchildren");
        if (cw) cw.classList.add("open");
        p = p.parentElement.closest(".tnode");
      }
    }
  });
}

// ---------- DASHBOARD (karty strojů) ----------
function goHome() {
  renderDashboard();
}

async function renderDashboard() {
  showView("dashboard");
  const ov = await api("/api/overview");
  DASH.overview = ov;  // ulož pro použití při změně filtru
  const sevById = {};
  ov.severities.forEach(s => sevById[s.id] = s);
  DASH.sevById = sevById;

  // napoj filtr (jen jednou)
  const sel = document.getElementById("dash-recency");
  if (sel && !sel._bound) {
    sel._bound = true;
    sel.addEventListener("change", () => { DASH.recencyDays = parseInt(sel.value, 10) || 0; paintDashboard(); });
  }
  paintDashboard();
}

// Vykreslí KPI + mřížku strojů podle aktuálního filtru DASH.recencyDays.
// Stroje bez jakéhokoli měření se nezobrazují vůbec.
function paintDashboard() {
  const ov = DASH.overview;
  if (!ov) return;
  const sevById = DASH.sevById || {};
  const order = [4, 3, 2, 1];

  // seskup body podle stroje (rodič typu 2)
  const machines = {};
  ov.points.forEach(p => {
    const mid = p.parent;
    if (!machines[mid]) {
      machines[mid] = { id: mid, node: STATE.byId[mid] || null, points: [],
                        counts: {}, worst: 0, lastMs: 0, measuredPoints: 0 };
    }
    const m = machines[mid];
    m.points.push(p);
    const sid = p.severity_id || 1;
    m.counts[sid] = (m.counts[sid] || 0) + 1;
    if (sid > m.worst) m.worst = sid;
    if (p.last_measured_ms) {
      m.measuredPoints++;
      if (p.last_measured_ms > m.lastMs) m.lastMs = p.last_measured_ms;
    }
  });
  let machineList = Object.values(machines);

  // 1) stroje BEZ jakéhokoli měření vůbec nezobrazovat
  const allMachines = machineList.length;
  machineList = machineList.filter(m => m.measuredPoints > 0);
  const measuredMachines = machineList.length;
  const hiddenNever = allMachines - measuredMachines;

  // 2) filtr podle data posledního měření (0 = bez omezení)
  const days = DASH.recencyDays || 0;
  let hiddenOld = 0;
  if (days > 0) {
    // časy v DB jsou v ms od 1. 1. 2000; použijeme stejnou referenci.
    const EPOCH2000 = Date.UTC(2000, 0, 1);
    const nowMs2000 = Date.now() - EPOCH2000;
    const cutoff = nowMs2000 - days * 86400000;
    const before = machineList.length;
    machineList = machineList.filter(m => m.lastMs >= cutoff);
    hiddenOld = before - machineList.length;
  }

  // KPI řádek (počítá z odfiltrovaných strojů)
  const shownPoints = machineList.reduce((s, m) => s + m.points.length, 0);
  const shownCounts = {};
  machineList.forEach(m => order.forEach(sid => { shownCounts[sid] = (shownCounts[sid]||0) + (m.counts[sid]||0); }));
  const kpiRow = document.getElementById("kpi-row");
  kpiRow.innerHTML = "";
  kpiRow.appendChild(kpiCard(machineList.length, "Strojů", "--accent"));
  kpiRow.appendChild(kpiCard(shownPoints, "Měřicích bodů", "--accent"));
  order.forEach(sid => {
    if (!sevById[sid]) return;
    kpiRow.appendChild(kpiCard(shownCounts[sid] || 0, sevLabelUI(sid), SEV_VARS[sid]));
  });

  // poznámka o filtrování
  const note = document.getElementById("dash-note");
  if (note) {
    const parts = [];
    if (hiddenNever > 0) parts.push(`skryto ${hiddenNever} strojů bez naměřených hodnot`);
    if (days > 0 && hiddenOld > 0) parts.push(`skryto ${hiddenOld} strojů s posledním měřením starším než ${days} dní`);
    note.textContent = parts.length ? "Filtr: " + parts.join("; ") + "." : "";
    note.style.display = parts.length ? "" : "none";
  }

  // mřížka karet strojů — nejzávažnější první
  const grid = document.getElementById("machine-grid");
  grid.innerHTML = "";
  if (!machineList.length) {
    const msg = days > 0
      ? "Žádný stroj neodpovídá zvolenému filtru. Zkuste delší období."
      : "Žádné stroje s naměřenými hodnotami.";
    grid.innerHTML = `<div class="empty-state"><p>${msg}</p></div>`;
    return;
  }
  machineList.sort((a, b) =>
    (b.worst - a.worst) ||
    ((b.counts[4]||0)-(a.counts[4]||0)) ||
    ((b.counts[3]||0)-(a.counts[3]||0)) ||
    (b.lastMs - a.lastMs) ||
    (a.node?.name||"").localeCompare(b.node?.name||"", "cs")
  );
  machineList.forEach(m => grid.appendChild(machineCard(m, sevById, order)));
}

function machineCard(m, sevById, order) {
  const card = document.createElement("div");
  card.className = "machine-card sev-border-" + m.worst;
  const worstName = m.worst > 0 ? sevLabelUI(m.worst) : "—";
  const worstCol = m.worst > 0 ? sevColor(m.worst) : getCss("--sev-none");
  const plant = STATE.byId[m.node?.parent];

  const badges = order.map(sid => {
    const cnt = m.counts[sid] || 0;
    if (!cnt) return "";
    return `<span class="mc-badge" style="--b:${sevColor(sid)}" title="${escapeHtml(sevLabelUI(sid))}"><span class="mc-dot"></span>${cnt}</span>`;
  }).join("");

  card.innerHTML = `
    <div class="mc-head">
      <span class="mc-status-dot" style="background:${worstCol}"></span>
      <div class="mc-title-wrap">
        <div class="mc-title" title="${escapeHtml(m.node?.name||'')}">${escapeHtml(m.node?.name || "Stroj")}</div>
        ${plant ? `<div class="mc-plant">${escapeHtml(plant.name)}</div>` : ""}
      </div>
      <span class="mc-worst" style="color:${worstCol}">${escapeHtml(worstName)}</span>
    </div>
    <div class="mc-stats">
      <div class="mc-total"><strong>${m.points.length}</strong> měřicích bodů</div>
      <div class="mc-badges">${badges || '<span class="mc-muted">—</span>'}</div>
    </div>
    <div class="mc-points"></div>
    <button class="mc-card-btn" title="Otevřít kartu stroje (limity a ložiska)">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.9" style="vertical-align:-3px;margin-right:5px"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 14h8M8 17h5"/></svg>
      Karta stroje — limity a ložiska
    </button>`;

  const pl = card.querySelector(".mc-points");
  const sorted = m.points.slice().sort((a, b) => (b.severity_id||0)-(a.severity_id||0));
  sorted.slice(0, 6).forEach(p => {
    const row = document.createElement("button");
    row.className = "mc-point";
    const col = p.severity_id > 0 ? sevColor(p.severity_id) : getCss("--sev-none");
    row.innerHTML = `<span class="dot" style="background:${col}"></span><span class="nm">${escapeHtml(p.name)}</span>`;
    row.addEventListener("click", (e) => { e.stopPropagation(); selectPoint(p.id); });
    pl.appendChild(row);
  });
  if (sorted.length > 6) {
    const more = document.createElement("div");
    more.className = "mc-more";
    more.textContent = `+ dalších ${sorted.length - 6}…`;
    pl.appendChild(more);
  }
  const cardBtn = card.querySelector(".mc-card-btn");
  if (cardBtn) cardBtn.addEventListener("click", (e) => { e.stopPropagation(); openMachine(m.id); });
  return card;
}

function kpiCard(val, label, cssVar) {
  const d = document.createElement("div");
  d.className = "kpi";
  d.style.setProperty("--kpi-c", getCss(cssVar));
  d.innerHTML = `<div class="kpi-val" style="color:${getCss(cssVar)}">${val}</div><div class="kpi-label">${escapeHtml(label)}</div>`;
  return d;
}

// ---------- POINT DETAIL ----------
async function selectPoint(treeId, rowEl) {
  STATE.activePoint = treeId;
  // highlight in tree
  document.querySelectorAll(".trow.active").forEach(r => r.classList.remove("active"));
  const row = rowEl || document.querySelector(`.trow[data-id='${treeId}']`);
  if (row) {
    row.classList.add("active");
    // expand ancestors
    let p = row.closest(".tnode")?.parentElement.closest(".tnode");
    while (p) {
      p.querySelector(".tchildren")?.classList.add("open");
      p.querySelector(".trow .tcaret")?.classList.add("open");
      p = p.parentElement.closest(".tnode");
    }
  }

  showView("point");
  const node = STATE.byId[treeId];
  const machine = STATE.byId[node.parent];
  const plant = STATE.byId[machine?.parent];
  document.getElementById("point-title").textContent = node.name;
  // zaevidovat jako panel (pro přepínání Ctrl+Tab)
  openPanel("point", treeId, `Bod: ${node.name}`, () => selectPoint(treeId));
  document.getElementById("point-breadcrumb").textContent =
    [plant?.name, machine?.name].filter(Boolean).join("  ›  ");

  const sev = STATE.pointSeverity[treeId];
  const badge = document.getElementById("point-badge");
  if (sev && sev > 0) {
    badge.textContent = STATE.sevById[sev]?.name || "—";
    badge.style.background = sevColor(sev);
    badge.style.display = "";
  } else {
    badge.style.display = "none";
  }

  // načti přiřazené ložisko z karty stroje — vede se na Úrovni LOŽISKA
  // (skupina směrů L1H/L1V/L1A -> ložisko L1), proto najdeme skupinu,
  // jejíž součástí je tento měřicí bod.
  DYN.assignedBearing = null;
  DYN.assignedBearingName = null;
  try {
    if (machine && machine.id != null) {
      // Rychlé načtení jen tohoto stroje (ne celé databáze).
      const resp = await api(`/api/machine/${machine.id}`);
      const mm = resp.machine || null;
      if (mm) {
        // výchozí otáčky stroje (platí pro všechna měřicí místa) – použij jako
        // základní frekvenci, dokud ložisko nemá vlastní rpm
        if (mm.speed_hz != null && isFinite(mm.speed_hz) && mm.speed_hz > 0) {
          DYN.baseFreq = mm.speed_hz;
        }
        if (mm.bearings) {
          const grp = mm.bearings.find(b =>
            (b.points || []).some(p => p.id === treeId));
          if (grp && grp.bearing) {
            DYN.assignedBearing = grp.bearing;
            DYN.assignedBearingName =
              (grp.bearing.designation || "ložisko") + " · " + grp.label;
            if (DYN.assignedBearing.rpm_hz) DYN.baseFreq = DYN.assignedBearing.rpm_hz;
            DYN.markers = "assigned";
          }
        }
      }
    }
  } catch (e) { /* konfigurace není kritická */ }

  const { cells } = await api(`/api/point/${treeId}/cells`);
  renderTabs(cells);
  if (cells.length) selectCell(cells[0]);
  else {
    document.getElementById("chart").innerHTML = "<div class='empty-state'>Žádná měření.</div>";
  }

  // AI poradce pro diagnostiky (pod grafy) – otáčky, ložisko, AI vyhodnocení
  renderPointAdvisor(treeId);
}

function renderTabs(cells) {
  const tabs = document.getElementById("cell-tabs");
  tabs.innerHTML = "";
  STATE.pointCells = cells;
  const kindLabel = { trend: "Trend", spectrum: "Spektrum", time: "Čas. signál", other: "Data" };

  // rozdělení buněk: STATICKÁ (trend) vs DYNAMICKÁ (spektrum / časový signál)
  const staticCells = cells.filter(c => c.kind === "trend");
  const dynamicCells = cells.filter(c => c.kind === "spectrum" || c.kind === "time");
  const otherCells = cells.filter(c => c.kind === "other");

  // pomocná funkce pro tlačítko záložky
  const mkTab = (c) => {
    const t = document.createElement("button");
    t.className = "tab";
    t.dataset.cell = c.id;
    // podbarvení statických záložek dle překročeného limitu (ok/varování/alarm)
    if (c.kind === "trend" && c.lim_state) t.classList.add("tab-lim-" + c.lim_state);
    t.innerHTML = `<span class="kind">${kindLabel[c.kind] || c.kind}</span> ${escapeHtml(c.name)}`;
    t.addEventListener("click", () => selectCell(c));
    return t;
  };

  // ŘÁDEK 1 — statická data (trendy) + tlačítko „Vykreslit všechny grafy“
  const rowStatic = document.createElement("div");
  rowStatic.className = "tab-row";
  const lblS = document.createElement("span");
  lblS.className = "tab-row-label";
  lblS.textContent = "Statická data";
  rowStatic.appendChild(lblS);
  staticCells.forEach(c => rowStatic.appendChild(mkTab(c)));
  otherCells.forEach(c => rowStatic.appendChild(mkTab(c)));
  tabs.appendChild(rowStatic);

  // ŘÁDEK 2 — dynamická data (spektra / časový signál) + vodopád
  const rowDyn = document.createElement("div");
  rowDyn.className = "tab-row";
  const lblD = document.createElement("span");
  lblD.className = "tab-row-label";
  lblD.textContent = "Dynamická data";
  rowDyn.appendChild(lblD);
  dynamicCells.forEach(c => rowDyn.appendChild(mkTab(c)));
  // tlačítko vodopádu — jen pokud má bod spektrální měření
  const hasSpectrum = cells.some(c => c.kind === "spectrum");
  if (hasSpectrum) {
    const wf = document.createElement("button");
    wf.className = "tab tab-waterfall";
    wf.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.9" style="vertical-align:-2px;margin-right:4px"><path d="M3 17l4-6 4 3 4-8 6 7"/><path d="M3 21h18"/></svg>Vodopád spekter';
    wf.title = "Vodopádový graf vývoje FFT spekter v čase";
    wf.addEventListener("click", () => openWaterfall());
    rowDyn.appendChild(wf);
  }
  tabs.appendChild(rowDyn);

  // ŘÁDEK 3 — tlačítko „Vykreslit všechny grafy“ (statické i dynamické najednou)
  const rowAll = document.createElement("div");
  rowAll.className = "tab-row tab-row-actions";
  const allBtn = document.createElement("button");
  allBtn.id = "btn-show-all-graphs";
  allBtn.className = "tab tab-allgraphs";
  allBtn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.9" style="vertical-align:-2px;margin-right:5px"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>Vykreslit všechny grafy';
  allBtn.title = "Zobrazí všechny grafy (statické i dynamické) najednou v přehledu";
  allBtn.addEventListener("click", () => showAllGraphs(cells));
  rowAll.appendChild(allBtn);
  tabs.appendChild(rowAll);
}

// ====================================================================
//  PŘEHLED VŠECH GRAFŮ — vykreslí statické (trendy) i dynamické
//  (spektra / časové signály) grafy najednou do mřížky mini-panelů.
//  V tomto režimu se skryje samostatný graf i AI poradce; do běžného
//  zobrazení se vrátíme kliknutím na libovolnou záložku.
// ====================================================================

// ====================================================================
//  JEDNODUCHÝ KURZOR (spike) + odečet hodnoty vpravo nahoře
//  Použito ve statických (trend) i dynamických (spektrum / čas. signál)
//  grafech – jak v samostatném zobrazení, tak v přehledu všech grafů.
// ====================================================================

// přidá do rozvržení svislý jednoduchý kurzor (spike) sledující myš
function applySpikeCursor(layout, color) {
  const c = color || getCss("--accent");
  layout.hovermode = "x";
  layout.xaxis = layout.xaxis || {};
  layout.xaxis.showspikes = true;
  layout.xaxis.spikemode = "across";
  layout.xaxis.spikesnap = "cursor";
  layout.xaxis.spikethickness = 1.2;
  layout.xaxis.spikedash = "solid";
  layout.xaxis.spikecolor = c;
  // svislý kurzor stačí – vodorovnou čáru nezobrazujeme
  layout.yaxis = layout.yaxis || {};
  layout.yaxis.showspikes = false;
  return layout;
}

// připojí k vykreslenému grafu odečet hodnoty kurzoru vpravo nahoře.
//   plotEl    – element s grafem (Plotly)
//   readoutEl – HTML element pro zobrazení hodnoty (overlay vpravo nahoře)
//   fmt(pt)   – funkce vracející text z bodu pod kurzorem
function attachCursorReadout(plotEl, readoutEl, fmt) {
  if (!plotEl || !readoutEl) return;
  readoutEl.classList.remove("active");
  readoutEl.textContent = "";
  plotEl.on("plotly_hover", (ev) => {
    const pt = ev && ev.points && ev.points[0];
    if (!pt) return;
    readoutEl.textContent = fmt(pt);
    readoutEl.classList.add("active");
  });
  plotEl.on("plotly_unhover", () => {
    readoutEl.classList.remove("active");
    readoutEl.textContent = "";
  });
}

// formátovač pro trend (datum + hodnota)
function cursorFmtTrend(pt) {
  const v = (typeof pt.y === "number") ? fmtNum(pt.y) : pt.y;
  return `${pt.x} · ${v}`;
}
// formátovač pro spektrum (frekvence v Hz + amplituda)
function cursorFmtSpectrum(pt) {
  return `${fmtNum(pt.x)} Hz · ${fmtNum(pt.y)}`;
}
// formátovač pro časový signál (čas + amplituda)
function cursorFmtTime(pt) {
  return `${fmtNum(pt.x)} s · ${fmtNum(pt.y)}`;
}

// odlehčené rozvržení pro mini-grafy v přehledu (bez interaktivních prvků)
const ALLGRAPH_CONFIG = { responsive: true, displayModeBar: false, staticPlot: false };

// opustí režim „všechny grafy“ a vrátí běžné zobrazení jednoho grafu
function exitAllGraphs() {
  const grid = document.getElementById("all-graphs");
  if (!grid || grid.classList.contains("hidden")) return;
  // odstraň vykreslené grafy (uvolni Plotly instance)
  grid.querySelectorAll(".ag-chart").forEach(el => { try { Plotly.purge(el); } catch (e) {} });
  grid.innerHTML = "";
  grid.classList.add("hidden");
  // vrať samostatný graf + AI poradce
  const panel = document.querySelector("#view-point .chart-panel");
  if (panel) panel.classList.remove("hidden");
  const adv = document.getElementById("point-advisor");
  if (adv) adv.classList.remove("hidden");
  document.getElementById("btn-show-all-graphs")?.classList.remove("active");
}

// vykreslí všechny grafy bodu (statické i dynamické) najednou v přehledu
async function showAllGraphs(cells) {
  // přepni do režimu přehledu: skryj samostatný graf i AI poradce
  document.querySelectorAll(".tab.active").forEach(t => t.classList.remove("active"));
  document.getElementById("btn-show-all-graphs")?.classList.add("active");
  const panel = document.querySelector("#view-point .chart-panel");
  if (panel) panel.classList.add("hidden");
  const adv = document.getElementById("point-advisor");
  if (adv) adv.classList.add("hidden");

  const grid = document.getElementById("all-graphs");
  grid.classList.remove("hidden");
  grid.innerHTML = '<div class="spinner"></div>';

  // posuň obsah nahoru, ať přehled začíná od shora
  const content = document.querySelector(".content");
  if (content) content.scrollTop = 0;

  // pořadí: nejdřív statická (trendy), pak dynamická (spektra/čas), pak ostatní
  const order = { trend: 0, spectrum: 1, time: 2, other: 3 };
  const list = (cells || STATE.pointCells || []).slice().sort(
    (a, b) => (order[a.kind] ?? 9) - (order[b.kind] ?? 9));

  grid.innerHTML = "";
  const kindLabel = { trend: "Trend", spectrum: "Spektrum", time: "Čas. signál", other: "Data" };

  // vytvoř panely a vykresli každý graf nezávisle (sekvenčně kvůli single-thread serveru)
  for (const c of list) {
    const card = document.createElement("div");
    card.className = "ag-card";
    if (c.kind === "trend" && c.lim_state) card.classList.add("ag-lim-" + c.lim_state);

    const head = document.createElement("div");
    head.className = "ag-head";
    head.innerHTML = `<span class="ag-kind">${kindLabel[c.kind] || c.kind}</span>` +
      `<span class="ag-name">${escapeHtml(c.name)}</span>`;
    // tlačítko pro otevření tohoto grafu v detailu (interaktivní režim)
    const open = document.createElement("button");
    open.className = "ag-open";
    open.textContent = "Detail";
    open.title = "Otevřít tento graf v interaktivním zobrazení";
    open.addEventListener("click", () => selectCell(c));
    head.appendChild(open);
    card.appendChild(head);

    // obal grafu, aby šel umístit odečet hodnoty kurzoru vpravo nahoře
    const wrap = document.createElement("div");
    wrap.className = "ag-chart-wrap";
    const readout = document.createElement("div");
    readout.className = "cursor-readout";
    const chart = document.createElement("div");
    chart.className = "ag-chart";
    chart.id = "ag-chart-" + c.id;
    wrap.appendChild(readout);
    wrap.appendChild(chart);
    card.appendChild(wrap);

    grid.appendChild(card);

    // asynchronně načti a vykresli (chyby nezastaví ostatní grafy)
    try {
      if (c.kind === "trend") {
        const { points, limits } = await api(`/api/cell/${c.id}/trend`);
        plotMiniTrend(chart, c, points, limits, readout);
      } else {
        const { records } = await api(`/api/cell/${c.id}/dynamic`);
        if (!records || !records.length) {
          chart.innerHTML = "<div class='empty-state'>Žádná data.</div>";
        } else {
          const last = records[records.length - 1];
          const d = await api(`/api/dynamic/${last.id}`);
          plotMiniDynamic(chart, c, d, readout);
        }
      }
    } catch (e) {
      chart.innerHTML = `<div class='empty-state'>${escapeHtml(e.message || "Chyba")}</div>`;
    }
  }
}

// odlehčené vykreslení trendu do mini-panelu (s limity, bez statistik/toolbaru)
function plotMiniTrend(el, cell, points, limits, readoutEl) {
  const x = points.map(p => p.t);
  const y = points.map(p => p.value);
  const lim = limits || {};
  const warn = (lim.warning != null && isFinite(lim.warning)) ? lim.warning : null;
  const alarm = (lim.alarm != null && isFinite(lim.alarm)) ? lim.alarm : null;

  const okCol = getCss("--sev-ok");
  const warnCol = getCss("--sev-alert");
  const alarmCol = getCss("--sev-danger");
  const accent = getCss("--accent");
  const stateColor = (v) => {
    if (alarm != null && v >= alarm) return alarmCol;
    if (warn != null && v >= warn) return warnCol;
    return (warn != null || alarm != null) ? okCol : accent;
  };
  const trace = {
    x, y, type: "scatter", mode: "lines+markers",
    line: { color: accent, width: 1.8 },
    marker: { size: 5, color: y.map(stateColor), line: { width: 1, color: "#11161d" } },
    hovertemplate: "%{y:.4f}<extra></extra>",
  };
  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.margin = { l: 48, r: 40, t: 8, b: 32 };
  layout.font = { color: "#9aa6b2", family: "Inter, sans-serif", size: 10 };
  layout.xaxis.type = "date";
  layout.xaxis.automargin = true;
  layout.showlegend = false;
  applySpikeCursor(layout, accent);
  const shapes = [], annotations = [];
  const hline = (val, color, label) => {
    shapes.push({ type: "line", xref: "paper", x0: 0, x1: 1, y0: val, y1: val,
      line: { color, width: 1.2, dash: "dash" } });
    annotations.push({ xref: "paper", x: 0.985, y: val, xanchor: "right", yanchor: "bottom",
      text: label, showarrow: false, font: { size: 9, color },
      bgcolor: "rgba(15,20,26,0.7)" });
  };
  if (warn != null) hline(warn, warnCol, `V: ${fmtNum(warn)}`);
  if (alarm != null) hline(alarm, alarmCol, `A: ${fmtNum(alarm)}`);
  layout.shapes = shapes;
  layout.annotations = annotations;
  Plotly.newPlot(el, [trace], layout, ALLGRAPH_CONFIG);
  attachCursorReadout(el, readoutEl, cursorFmtTrend);
}

// odlehčené vykreslení dynamického záznamu (spektrum / čas. signál) do mini-panelu
function plotMiniDynamic(el, cell, d, readoutEl) {
  const x = d.x, y = d.y;
  const isSpectrum = d.kind === "spectrum";
  const accent = getCss("--accent");
  const trace = isSpectrum
    ? { x, y, type: "scatter", mode: "lines", line: { color: accent, width: 1.2 },
        fill: "tozeroy", fillcolor: "rgba(47,155,214,0.12)",
        hovertemplate: "%{x:.1f} Hz · %{y:.4f}<extra></extra>" }
    : { x, y, type: "scatter", mode: "lines", line: { color: accent, width: 1 },
        hovertemplate: "%{x:.4f} · %{y:.4f}<extra></extra>" };
  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.margin = { l: 48, r: 24, t: 8, b: 32 };
  layout.font = { color: "#9aa6b2", family: "Inter, sans-serif", size: 10 };
  layout.showlegend = false;
  layout.xaxis.title = isSpectrum ? (d.x_unit || "Hz") : (d.x_unit || "s");
  applySpikeCursor(layout, accent);
  Plotly.newPlot(el, [trace], layout, ALLGRAPH_CONFIG);
  attachCursorReadout(el, readoutEl, isSpectrum ? cursorFmtSpectrum : cursorFmtTime);
}

async function selectCell(cell) {
  exitAllGraphs(); // opustí přehled všech grafů, pokud je aktivní
  STATE.activeCell = cell;
  document.querySelectorAll(".tab.active").forEach(t => t.classList.remove("active"));
  document.querySelector(`.tab[data-cell='${cell.id}']`)?.classList.add("active");
  document.getElementById("chart-title").textContent = cell.name;
  document.getElementById("record-picker").innerHTML = "";
  document.getElementById("chart-stats").innerHTML = "";
  document.getElementById("chart").innerHTML = '<div class="spinner"></div>';

  try {
    if (cell.kind === "trend") {
      const { points, limits } = await api(`/api/cell/${cell.id}/trend`);
      plotTrend(cell, points, limits);
    } else {
      const { records } = await api(`/api/cell/${cell.id}/dynamic`);
      if (!records.length) { document.getElementById("chart").innerHTML = "<div class='empty-state'>Žádná data.</div>"; return; }
      buildRecordPicker(cell, records);
      await showDynamic(records[records.length - 1].id, cell);
    }
  } catch (e) {
    document.getElementById("chart").innerHTML = `<div class='empty-state'>${escapeHtml(e.message)}</div>`;
  }
}

function buildRecordPicker(cell, records) {
  const picker = document.getElementById("record-picker");
  picker.innerHTML = `<label>Měření:</label>`;
  const sel = document.createElement("select");
  records.forEach(r => {
    const o = document.createElement("option");
    o.value = r.id;
    o.textContent = fmtDate(r.time);
    sel.appendChild(o);
  });
  sel.value = records[records.length - 1].id;
  sel.addEventListener("change", () => showDynamic(parseInt(sel.value), cell));
  picker.appendChild(sel);
}

// ====================================================================
//  DYNAMICKÉ GRAFY — funkce inspirované softwarem DDS
//  (kurzory, hledání vrcholu, typy os, značky poruchových frekvencí,
//   lokální maxima, mřížka)
// ====================================================================

// stav aktuálně zobrazeného dynamického grafu
let DYN = {
  data: null,          // {x, y, kind, x_unit, speed_hz, ...}
  cell: null,
  cursor: "off",       // off | single | harmonic | sideband
  cursorX: null,       // poloha hlavního kurzoru (jednotka osy X)
  harmonics: 8,        // počet harmonických / postranních pásem
  sideStep: null,      // krok postranních pásem (Hz)
  baseFreq: null,      // základní frekvence (otáčky) pro značky/harmonické
  yType: "linear",     // linear | log | db
  xType: "linear",     // linear | log
  grid: true,
  markers: "none",     // none | assigned | bearing | gear | motor
  showMaxima: false,
  maximaN: 8,
  assignedBearing: null,     // přiřazené ložisko bodu {designation, FTF, BSF, BPFO, BPFI, rpm_hz}
  assignedBearingName: null,
};

const PLOT_LAYOUT_BASE = {
  paper_bgcolor: "rgba(0,0,0,0)",
  plot_bgcolor: "rgba(0,0,0,0)",
  font: { color: "#9aa6b2", family: "Inter, sans-serif", size: 12 },
  margin: { l: 64, r: 24, t: 16, b: 48 },
  xaxis: { gridcolor: "#222831", zerolinecolor: "#2a313c", linecolor: "#2a313c" },
  yaxis: { gridcolor: "#222831", zerolinecolor: "#2a313c", linecolor: "#2a313c" },
  hovermode: "x unified",
};
const PLOT_CONFIG = { responsive: true, displaylogo: false, modeBarButtonsToRemove: ["lasso2d", "select2d"], displayModeBar: true };

function plotTrend(cell, points, limits) {
  document.getElementById("chart-toolbar").classList.add("hidden");
  document.getElementById("local-maxima").classList.add("hidden");
  const x = points.map(p => p.t);
  const y = points.map(p => p.value);

  // Platné limity pro tuto veličinu přimímo z backendu (výchozí z DB,
  // případně přepsané na kartě stroje). Jednotný zdroj jako barvy teček.
  const lim = limits || {};
  const warn = (lim.warning != null && isFinite(lim.warning)) ? lim.warning : null;
  const alarm = (lim.alarm != null && isFinite(lim.alarm)) ? lim.alarm : null;
  const overridden = !!lim.overridden;

  // obarvení bodů podle stavu vůči limitům
  const okCol = getCss("--sev-ok");
  const warnCol = getCss("--sev-alert");
  const alarmCol = getCss("--sev-danger");
  const accent = getCss("--accent");
  function stateColor(v) {
    if (alarm != null && v >= alarm) return alarmCol;
    if (warn != null && v >= warn) return warnCol;
    return (warn != null || alarm != null) ? okCol : accent;
  }
  const markerColors = y.map(stateColor);

  const trace = {
    x, y, type: "scatter", mode: "lines+markers",
    line: { color: accent, width: 2, shape: "linear" },
    marker: { size: 7, color: markerColors, line: { width: 1, color: "#11161d" } },
    name: cell.name,
    hovertemplate: "%{y:.4f}<extra></extra>",
  };
  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.xaxis.title = "Čas měření";
  layout.yaxis.title = "Hodnota";
  layout.xaxis.type = "date";
  // jednoduchý svislý kurzor + odečet hodnoty vpravo nahoře
  applySpikeCursor(layout, accent);

  // vodorovné čáry limitů + popisky
  const shapes = [];
  const annotations = [];
  function hline(val, color, label) {
    shapes.push({ type: "line", xref: "paper", x0: 0, x1: 1, y0: val, y1: val,
      line: { color, width: 1.4, dash: "dash" } });
    annotations.push({ xref: "paper", x: 1, y: val, xanchor: "right", yanchor: "bottom",
      text: label, showarrow: false, font: { size: 10, color },
      bgcolor: "rgba(15,20,26,0.7)" });
  }
  if (warn != null) hline(warn, warnCol, `Varování: ${fmtNum(warn)}`);
  if (alarm != null) hline(alarm, alarmCol, `Alarm: ${fmtNum(alarm)}`);
  layout.shapes = shapes;
  layout.annotations = annotations;

  Plotly.newPlot("chart", [trace], layout, PLOT_CONFIG);
  attachCursorReadout(document.getElementById("chart"), document.getElementById("chart-readout"), cursorFmtTrend);

  if (y.length) {
    const last = y[y.length - 1];
    const stats = [
      ["Poslední", fmtNum(last)],
      ["Maximum", fmtNum(Math.max(...y))],
      ["Minimum", fmtNum(Math.min(...y))],
      ["Průměr", fmtNum(y.reduce((a, b) => a + b, 0) / y.length)],
      ["Počet", y.length],
    ];
    const limSrc = overridden ? " (vlastní)" : " (z DB)";
    if (warn != null) stats.push(["Limit varování" + limSrc, fmtNum(warn)]);
    if (alarm != null) stats.push(["Limit alarm" + limSrc, fmtNum(alarm)]);
    if (warn != null || alarm != null) {
      let stName = "V pořádku", stCol = okCol;
      if (alarm != null && last >= alarm) { stName = "Alarm"; stCol = alarmCol; }
      else if (warn != null && last >= warn) { stName = "Varování"; stCol = warnCol; }
      stats.push(["Stav (poslední)", `<span style="color:${stCol};font-weight:600">${stName}</span>`]);
    }
    renderStats(stats);
  }
}

async function showDynamic(dynId, cell) {
  document.getElementById("chart").innerHTML = '<div class="spinner"></div>';
  const d = await api(`/api/dynamic/${dynId}`);
  DYN.data = d;
  DYN.cell = cell;
  // resetuj odvozené hodnoty pro nový záznam
  DYN.cursorX = null;
  DYN.baseFreq = (d.kind === "spectrum" && d.speed_hz) ? d.speed_hz : DYN.baseFreq;
  if (DYN.sideStep === null && d.speed_hz) DYN.sideStep = d.speed_hz;
  buildToolbar();
  redrawDynamic();
}

// ---------- pomocné výpočty ----------
function nearestIndex(x, val) {
  let lo = 0, hi = x.length - 1;
  if (val <= x[0]) return 0;
  if (val >= x[hi]) return hi;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (x[mid] < val) lo = mid; else hi = mid;
  }
  return (val - x[lo] <= x[hi] - val) ? lo : hi;
}

// vrchol nejblíže k zadané X pozici (lokální maximum v okolí)
function snapToPeak(x, y, val) {
  let i = nearestIndex(x, val);
  // posun do lokálního maxima
  let guard = 0;
  while (guard++ < x.length) {
    const l = i > 0 ? y[i - 1] : -Infinity;
    const r = i < y.length - 1 ? y[i + 1] : -Infinity;
    if (l > y[i]) i = i - 1;
    else if (r > y[i]) i = i + 1;
    else break;
  }
  return i;
}

// N nejvyšších lokálních maxim, seřazeno sestupně dle amplitudy
function findLocalMaxima(x, y, n) {
  const peaks = [];
  for (let i = 1; i < y.length - 1; i++) {
    if (y[i] > y[i - 1] && y[i] >= y[i + 1]) peaks.push({ x: x[i], y: y[i], i });
  }
  peaks.sort((a, b) => b.y - a.y);
  return peaks.slice(0, n);
}

function rmsOf(y) {
  return Math.sqrt(y.reduce((a, b) => a + b * b, 0) / y.length);
}

// poruchové frekvence ložisek / převodů / asynchronního motoru
// (orientační koeficienty × otáčková frekvence — pro vizuální vodítka)
function faultMarkers(type, base) {
  if (!base || base <= 0) return [];
  const out = [];
  if (type === "bearing") {
    // typické násobky pro běžné ložisko (orientační hodnoty)
    [["BPFO", 3.05], ["BPFI", 4.95], ["BSF", 1.99], ["FTF", 0.38]].forEach(([lbl, k]) => {
      for (let h = 1; h <= 3; h++) out.push({ f: base * k * h, label: h === 1 ? lbl : `${lbl}·${h}` });
    });
  } else if (type === "gear") {
    // ozubení: násobky otáček (orientační GMF řada)
    [1, 2, 3, 4, 5].forEach(h => out.push({ f: base * h * 10, label: `GMF·${h}` }));
  } else if (type === "motor") {
    // asynchronní motor: otáčková frekvence + 2× síťový kmitočet (50 Hz)
    out.push({ f: base, label: "1X" });
    out.push({ f: 2 * base, label: "2X" });
    out.push({ f: 100, label: "2×LF (100 Hz)" });
  }
  return out;
}

// ---------- vykreslení ----------
function redrawDynamic() {
  const d = DYN.data;
  if (!d) return;
  const x = d.x, y = d.y;
  const isSpectrum = d.kind === "spectrum";
  const accent = getCss("--accent");

  // transformace Y pro dB
  let yPlot = y, yTitle = "Amplituda";
  if (DYN.yType === "db" && isSpectrum) {
    const ref = Math.max(1e-12, Math.max.apply(null, y) * 1e-3) || 1e-9;
    yPlot = y.map(v => 20 * Math.log10(Math.max(v, 1e-12) / ref));
    yTitle = "Amplituda [dB]";
  }

  const traces = [{
    x, y: yPlot, type: "scatter", mode: "lines",
    line: { color: accent, width: 1.3 },
    fill: (isSpectrum && DYN.yType !== "db") ? "tozeroy" : "none",
    fillcolor: "rgba(47,155,214,0.12)",
    name: d.name,
    hovertemplate: `%{x} ${d.x_unit} · %{y:.5f}<extra></extra>`,
  }];

  const shapes = [];
  const annotations = [];

  // --- KURZORY ---
  const yMaxPlot = Math.max.apply(null, yPlot);
  function vline(fx, color, label, dash) {
    shapes.push({ type: "line", x0: fx, x1: fx, yref: "paper", y0: 0, y1: 1,
      line: { color, width: 1, dash: dash || "solid" } });
    if (label) annotations.push({ x: fx, y: 1, yref: "paper", text: label,
      showarrow: false, font: { size: 10, color }, yanchor: "bottom", bgcolor: "rgba(15,20,26,0.7)" });
  }

  if (DYN.cursor !== "off" && DYN.cursorX != null) {
    const ci = isSpectrum ? snapToPeak(x, y, DYN.cursorX) : nearestIndex(x, DYN.cursorX);
    const cx = x[ci];
    DYN.cursorX = cx;
    const cCol = "#ff5d5d";
    vline(cx, cCol, null);

    if (DYN.cursor === "harmonic") {
      const baseH = cx;
      for (let h = 1; h <= DYN.harmonics; h++) {
        const fx = baseH * h;
        if (fx > x[x.length - 1]) break;
        vline(fx, h === 1 ? cCol : "rgba(255,93,93,0.55)", `${h}X`, h === 1 ? "solid" : "dot");
      }
    } else if (DYN.cursor === "sideband") {
      const step = DYN.sideStep || (DYN.data.speed_hz) || (x[1] - x[0]);
      vline(cx, cCol, "C");
      for (let k = 1; k <= DYN.harmonics; k++) {
        if (cx - step * k >= x[0]) vline(cx - step * k, "rgba(120,200,255,0.6)", `-${k}`, "dot");
        if (cx + step * k <= x[x.length - 1]) vline(cx + step * k, "rgba(120,200,255,0.6)", `+${k}`, "dot");
      }
    } else {
      vline(cx, cCol, "•");
    }
  }

  // --- ZNAČKY PORUCHOVÝCH FREKVENCÍ ---
  if (isSpectrum && DYN.markers !== "none") {
    const xmax = x[x.length - 1];
    let ms;
    if (DYN.markers === "assigned") {
      ms = assignedBearingMarkers(DYN.assignedBearing, DYN.baseFreq, xmax);
    } else {
      ms = faultMarkers(DYN.markers, DYN.baseFreq);
    }
    const mcol = "#ffb454";
    ms.forEach(mk => {
      if (mk.f <= xmax) vline(mk.f, mcol, mk.label, "dashdot");
    });
  }

  // --- LOKÁLNÍ MAXIMA ---
  let maxima = [];
  if (isSpectrum && DYN.showMaxima) {
    maxima = findLocalMaxima(x, y, DYN.maximaN);
    traces.push({
      x: maxima.map(p => p.x),
      y: maxima.map(p => DYN.yType === "db" ? yPlot[p.i] : p.y),
      type: "scatter", mode: "markers",
      marker: { color: "#ffe08a", size: 9, symbol: "triangle-down", line: { color: "#1a1f26", width: 1 } },
      name: "Lokální maxima",
      hovertemplate: `%{x} ${d.x_unit} · %{y:.5f}<extra>max</extra>`,
    });
  }

  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.xaxis.title = `${d.x_label} [${d.x_unit}]`;
  layout.yaxis.title = yTitle;
  layout.shapes = shapes;
  layout.annotations = annotations;
  layout.xaxis.showgrid = DYN.grid;
  layout.yaxis.showgrid = DYN.grid;
  if (DYN.xType === "log" && isSpectrum) { layout.xaxis.type = "log"; }
  if (DYN.yType === "log" && isSpectrum) { layout.yaxis.type = "log"; }
  // jednoduchý svislý kurzor (výchozí) + odečet hodnoty vpravo nahoře
  applySpikeCursor(layout, getCss("--accent"));

  Plotly.newPlot("chart", traces, layout, PLOT_CONFIG);
  attachCursorReadout(document.getElementById("chart"), document.getElementById("chart-readout"), isSpectrum ? cursorFmtSpectrum : cursorFmtTime);

  // klik do grafu = umísti kurzor
  const chartEl = document.getElementById("chart");
  chartEl.removeAllListeners && chartEl.removeAllListeners("plotly_click");
  chartEl.on("plotly_click", (ev) => {
    if (DYN.cursor === "off" || !ev.points || !ev.points.length) return;
    DYN.cursorX = ev.points[0].x;
    redrawDynamic();
  });

  // --- STATISTIKA + tabulka maxim ---
  let peakIdx = 0;
  for (let i = 1; i < y.length; i++) if (y[i] > y[peakIdx]) peakIdx = i;
  const stats = [
    ["Datum", fmtDate(d.time)],
    ["Bodů", y.length],
    [isSpectrum ? "Špička" : "Max", fmtNum(y[peakIdx], 4)],
    [isSpectrum ? "Frekvence špičky" : "Čas max", `${fmtNum(x[peakIdx], 2)} ${d.x_unit}`],
    ["RMS", fmtNum(rmsOf(y), 4)],
  ];
  if (isSpectrum && d.overall != null) {
    const cut = d.hp_cutoff != null ? d.hp_cutoff : 1;
    stats.push([`Celková hodnota (overall, HP ${fmtNum(cut, 0)} Hz)`, fmtNum(d.overall, 4)]);
  }
  if (DYN.cursor !== "off" && DYN.cursorX != null) {
    const ci = nearestIndex(x, DYN.cursorX);
    stats.push(["Kurzor", `${fmtNum(x[ci], 3)} ${d.x_unit}`]);
    stats.push(["Ampl. kurzoru", fmtNum(y[ci], 5)]);
    if (DYN.cursor === "harmonic" && DYN.cursorX > 0) {
      stats.push(["Otáčky (1X)", `${fmtNum(x[ci] * 60, 0)} ot/min`]);
    }
  }
  renderStats(stats);

  // tabulka lokálních maxim
  const lm = document.getElementById("local-maxima");
  if (isSpectrum && DYN.showMaxima && maxima.length) {
    lm.classList.remove("hidden");
    lm.innerHTML =
      `<div class="lm-head">Lokální maxima (${maxima.length})</div>` +
      `<table class="lm-table"><thead><tr><th>#</th><th>Frekvence</th><th>Amplituda</th></tr></thead><tbody>` +
      maxima.map((p, i) =>
        `<tr><td>${i + 1}</td><td>${fmtNum(p.x, 2)} ${d.x_unit}</td><td>${fmtNum(p.y, 5)}</td></tr>`
      ).join("") + `</tbody></table>`;
  } else {
    lm.classList.add("hidden");
    lm.innerHTML = "";
  }
}

// ---------- ovládací lišta grafu ----------
function buildToolbar() {
  const tb = document.getElementById("chart-toolbar");
  const d = DYN.data;
  if (!d) { tb.classList.add("hidden"); return; }
  const isSpectrum = d.kind === "spectrum";
  tb.classList.remove("hidden");

  // pro časový signál nabízíme jen jednoduchý kurzor + mřížku
  const cursorOpts = isSpectrum
    ? [["off", "Vypnutý"], ["single", "Jednoduchý"], ["harmonic", "Harmonický"], ["sideband", "Postr. pásma"]]
    : [["off", "Vypnutý"], ["single", "Jednoduchý"]];

  let html = `
    <div class="ctl">
      <label>Kurzor</label>
      <select id="dyn-cursor">${cursorOpts.map(([v, l]) =>
        `<option value="${v}" ${DYN.cursor === v ? "selected" : ""}>${l}</option>`).join("")}</select>
    </div>
    <button id="dyn-findpeak" class="ctl-btn" title="Najít nejbližší vrchol">⌖ Najít vrchol</button>`;

  if (isSpectrum) {
    html += `
    <div class="ctl">
      <label>Osa Y</label>
      <select id="dyn-ytype">
        <option value="linear" ${DYN.yType==="linear"?"selected":""}>Lineární</option>
        <option value="log" ${DYN.yType==="log"?"selected":""}>Logaritmická</option>
        <option value="db" ${DYN.yType==="db"?"selected":""}>Decibely (dB)</option>
      </select>
    </div>
    <div class="ctl">
      <label>Osa X</label>
      <select id="dyn-xtype">
        <option value="linear" ${DYN.xType==="linear"?"selected":""}>Lineární</option>
        <option value="log" ${DYN.xType==="log"?"selected":""}>Logaritmická</option>
      </select>
    </div>
    <div class="ctl">
      <label>Značky</label>
      <select id="dyn-markers">
        <option value="none" ${DYN.markers==="none"?"selected":""}>Žádné</option>
        ${DYN.assignedBearing ? `<option value="assigned" ${DYN.markers==="assigned"?"selected":""}>Přiřazené ložisko (${escapeHtml(DYN.assignedBearingName||"")})</option>` : ""}
        <option value="bearing" ${DYN.markers==="bearing"?"selected":""}>Ložiska (orientační)</option>
        <option value="gear" ${DYN.markers==="gear"?"selected":""}>Převod</option>
        <option value="motor" ${DYN.markers==="motor"?"selected":""}>Asynch. motor</option>
      </select>
    </div>
    <div class="ctl">
      <label>Otáčky [Hz]</label>
      <input id="dyn-base" type="number" step="0.1" min="0" style="width:74px"
        value="${DYN.baseFreq != null ? Number(DYN.baseFreq).toFixed(2) : ""}" placeholder="—" />
    </div>
    <div class="ctl">
      <label>Počet harm./pásem</label>
      <input id="dyn-harm" type="number" step="1" min="1" max="40" style="width:56px" value="${DYN.harmonics}" />
    </div>
    <label class="ctl-check"><input id="dyn-maxima" type="checkbox" ${DYN.showMaxima?"checked":""}/> Lokální maxima</label>
    <div class="ctl">
      <label>N maxim</label>
      <input id="dyn-maxn" type="number" step="1" min="1" max="50" style="width:52px" value="${DYN.maximaN}" />
    </div>`;
  }

  html += `<label class="ctl-check"><input id="dyn-grid" type="checkbox" ${DYN.grid?"checked":""}/> Mřížka</label>`;
  tb.innerHTML = html;

  // navázání ovladačů
  const on = (id, ev, fn) => { const el = document.getElementById(id); if (el) el.addEventListener(ev, fn); };
  on("dyn-cursor", "change", e => { DYN.cursor = e.target.value; if (DYN.cursorX == null && DYN.cursor !== "off") doFindPeak(false); else redrawDynamic(); });
  on("dyn-findpeak", "click", () => doFindPeak(true));
  on("dyn-ytype", "change", e => { DYN.yType = e.target.value; redrawDynamic(); });
  on("dyn-xtype", "change", e => { DYN.xType = e.target.value; redrawDynamic(); });
  on("dyn-markers", "change", e => { DYN.markers = e.target.value; redrawDynamic(); });
  on("dyn-base", "change", e => { const v = parseFloat(e.target.value); DYN.baseFreq = isFinite(v) && v > 0 ? v : null; DYN.sideStep = DYN.baseFreq; redrawDynamic(); });
  on("dyn-harm", "change", e => { const v = parseInt(e.target.value); DYN.harmonics = Math.max(1, Math.min(40, v || 8)); redrawDynamic(); });
  on("dyn-maxima", "change", e => { DYN.showMaxima = e.target.checked; redrawDynamic(); });
  on("dyn-maxn", "change", e => { const v = parseInt(e.target.value); DYN.maximaN = Math.max(1, Math.min(50, v || 8)); redrawDynamic(); });
  on("dyn-grid", "change", e => { DYN.grid = e.target.checked; redrawDynamic(); });
}

function doFindPeak(global) {
  const d = DYN.data;
  if (!d) return;
  const x = d.x, y = d.y;
  if (DYN.cursor === "off") { DYN.cursor = "single"; }
  if (global || DYN.cursorX == null) {
    // globální vrchol
    let pi = 0;
    for (let i = 1; i < y.length; i++) if (y[i] > y[pi]) pi = i;
    DYN.cursorX = x[pi];
  } else {
    const pi = snapToPeak(x, y, DYN.cursorX);
    DYN.cursorX = x[pi];
  }
  buildToolbar();
  redrawDynamic();
}

function renderStats(arr) {
  const el = document.getElementById("chart-stats");
  el.innerHTML = arr.map(([l, v]) => `<div class="st"><span class="l">${escapeHtml(l)}</span><span class="v">${v}</span></div>`).join("");
}


// ====================================================================
//  KARTA STROJE — limity a ložiska per měřicí místo
// ====================================================================

// stav aktuálně otevřené karty stroje
let MACHINE = {
  id: null,
  data: null,        // jeden stroj z /api/machine/{id} (vč. .bearings[] se sloučenými limity)
  overrides: null,   // pouze uživatelské přepisy: { <bearing_key>: { limits:{...}, bearing:{...} } }
  // dočasné pole pro vyhledávání ložiska – kam uložit výsledek (klíč ložiska)
  bearingTargetKey: null,
  // aktivní záložka karty stroje (info / bearings / ai / chat)
  activeTab: "info",
  // aktivní podzáložka ložiska v rámci záložky "Ložiska a limity" (bearing_key)
  activeBearingTab: null,
  // historie chatu s AI diagnostikem: [{role:"user"|"assistant", content}]
  chatHistory: [],
};

// Konfigurace AI (modely + výchozí model) – načte se ze serveru při startu.
let AI_CONF = { models: [], model: "", has_openai_key: false, has_anthropic_key: false };

// Katalog norem se dynamicky načítá ze serveru při startu (/api/norms/catalog).
// Fallback drží vestavěné ČSN ISO 20816-3 a ČSN ISO 20816-9 Převodovky, aby
// výběr normy nezmizel ani při dočasně nedostupném katalogu API.
let NORMS_CATALOG = [
  {
    standard: "ČSN ISO 20816-3",
    label: "ČSN ISO 20816-3 (novější)",
    classes: [
      { machine_class: "Skupina 1 (velké stroje, tuhý základ)",   label: "Skupina 1 (velké stroje, tuhý základ)",   warning: 4.5,  alarm: 7.1,  band: "" },
      { machine_class: "Skupina 1 (velké stroje, pružný základ)", label: "Skupina 1 (velké stroje, pružný základ)", warning: 7.1,  alarm: 11.0, band: "" },
      { machine_class: "Skupina 2 (střední stroje, tuhý základ)", label: "Skupina 2 (střední stroje, tuhý základ)", warning: 2.8,  alarm: 4.5,  band: "" },
      { machine_class: "Skupina 2 (střední stroje, pružný základ)", label: "Skupina 2 (střední stroje, pružný základ)", warning: 4.5, alarm: 7.1, band: "" },
    ],
  },
  {
    standard: "ČSN ISO 20816-9 Převodovky",
    label: "ČSN ISO 20816-9 Převodovky",
    classes: [
      { machine_class: "VR 3,15", label: "VR 3,15", ab: 2.0, warning: 3.15, alarm: 5.0, band: "A/B 2,0; B/C 3,15; C/D 5,0 mm/s RMS" },
      { machine_class: "VR 5", label: "VR 5", ab: 3.15, warning: 5.0, alarm: 8.0, band: "A/B 3,15; B/C 5,0; C/D 8,0 mm/s RMS" },
      { machine_class: "VR 8", label: "VR 8", ab: 5.0, warning: 8.0, alarm: 12.5, band: "A/B 5,0; B/C 8,0; C/D 12,5 mm/s RMS" },
      { machine_class: "VR 12,5", label: "VR 12,5", ab: 8.0, warning: 12.5, alarm: 20.0, band: "A/B 8,0; B/C 12,5; C/D 20,0 mm/s RMS" },
      { machine_class: "VR 20", label: "VR 20", ab: 12.5, warning: 20.0, alarm: 31.5, band: "A/B 12,5; B/C 20,0; C/D 31,5 mm/s RMS" },
    ],
  },
];

// Katalog z API je již deduplikovaný backendem. Tato pojistka navíc chrání
// UI při ručně poškozené odpovědi/starší instalaci: pro stejný standard vyhraje
// vestavěná definice nad vlastní a v rámci standardu zůstane jedna třída.
function normalizeNormsCatalog(catalog) {
  const byStandard = new Map();
  (Array.isArray(catalog) ? catalog : []).forEach((raw) => {
    const standard = String((raw && raw.standard) || "").trim();
    if (!standard) return;
    const candidate = Object.assign({}, raw, {
      standard,
      label: (raw && raw.label) || standard,
      builtin: !raw || raw.builtin !== false,
      classes: [],
    });
    const current = byStandard.get(standard);
    // Vestavěná definice je vždy autoritativní. Při stejné prioritě vyhraje
    // první položka — pořadí odpovědi API je deterministické.
    if (!current || (candidate.builtin && !current.builtin)) {
      byStandard.set(standard, candidate);
    }
  });
  (Array.isArray(catalog) ? catalog : []).forEach((raw) => {
    const standard = String((raw && raw.standard) || "").trim();
    const target = byStandard.get(standard);
    if (!target) return;
    const sourceBuiltin = !raw || raw.builtin !== false;
    // Třídy bereme jen z vybrané (autoritativní) definice standardu.
    if (sourceBuiltin !== target.builtin) return;
    const seen = new Set(target.classes.map((c) => c.machine_class));
    (Array.isArray(raw && raw.classes) ? raw.classes : []).forEach((cls) => {
      const machineClass = String((cls && cls.machine_class) || "").trim();
      if (!machineClass || seen.has(machineClass)) return;
      seen.add(machineClass);
      target.classes.push(Object.assign({}, cls, {
        machine_class: machineClass,
        label: (cls && cls.label) || machineClass,
      }));
    });
  });
  return Array.from(byStandard.values());
}

NORMS_CATALOG = normalizeNormsCatalog(NORMS_CATALOG);

// Najde záznam normy podle klíče (iso_norm.standard).
function findNorm(standard) {
  const key = (standard || "").trim();
  return NORMS_CATALOG.find(n => n.standard === key) || null;
}

// Najde záznam třídy v katalogu (bere v úvahu norm; s fallbackem hledání
// napříč všemi normami pro zpětnou kompatibilitu se starším uložením).
function findNormClass(standard, machineClass) {
  const cls = (machineClass || "").trim();
  if (!cls) return null;
  const std = findNorm(standard);
  if (std) {
    const rec = (std.classes || []).find(c => c.machine_class === cls);
    if (rec) return rec;
  }
  for (const n of NORMS_CATALOG) {
    const rec = (n.classes || []).find(c => c.machine_class === cls);
    if (rec) return rec;
  }
  return null;
}

// Vrátí limity {warning, alarm} pro danou normu + třídu z katalogu, nebo null.
function normLimitsFor(standard, machineClass) {
  const rec = findNormClass(standard, machineClass);
  if (!rec) return null;
  if (rec.warning == null || rec.alarm == null) return null;
  return { warning: rec.warning, alarm: rec.alarm };
}

async function loadNormsCatalog() {
  try {
    const r = await api("/api/norms/catalog");
    if (r && Array.isArray(r.catalog) && r.catalog.length) {
      NORMS_CATALOG = normalizeNormsCatalog(r.catalog);
    }
  } catch (e) { /* fallback zůstává v platnosti */ }
}

async function loadAiConf() {
  try {
    const st = await api("/api/ai/status");
    AI_CONF = {
      models: st.models || [],
      model: st.model || "",
      has_openai_key: !!st.has_openai_key,
      has_anthropic_key: !!st.has_anthropic_key,
    };
  } catch (e) { /* AI konfigurace není kritická pro běh aplikace */ }
}

async function ensureBearingManufacturers() {
  if (MACHINE._mfgLoaded) return;
  try {
    const r = await api("/api/bearings/manufacturers");
    const sel = document.getElementById("bearing-mfg");
    if (sel) {
      sel.innerHTML = '<option value="">Všichni výrobci</option>';
      (r.manufacturers || []).forEach(m => {
        const o = document.createElement("option");
        o.value = m.name;
        o.textContent = `${m.name} (${m.count})`;
        sel.appendChild(o);
      });
    }
    MACHINE._mfgLoaded = true;
  } catch (e) { /* tichá chyba – filtr výrobce není kritický */ }
}

async function openMachine(machineId) {
  showView("machine");
  document.getElementById("machine-title").textContent = "Načítám…";
  document.getElementById("machine-points").innerHTML = '<div class="spinner"></div>';
  try {
    // Rychlé načtení: /api/machine/{id} spočítá jen tento stroj, ne celou DB.
    const [machineResp, cfgResp] = await Promise.all([
      api(`/api/machine/${machineId}`),
      api(`/api/machine/${machineId}/config`),
    ]);
    const machine = machineResp.machine || null;
    if (!machine) {
      document.getElementById("machine-points").innerHTML =
        '<div class="empty-state"><p>Stroj nenalezen.</p></div>';
      return;
    }
    // při otevření jiného stroje začni vždy na záložce se základními informacemi
    // a vymaž historii chatu (chat je vázaný na konkrétní stroj)
    if (MACHINE.id !== machineId) { MACHINE.activeTab = "info"; MACHINE.activeBearingTab = null; MACHINE.chatHistory = []; }
    MACHINE.id = machineId;
    MACHINE.data = machine;            // obsahuje .bearings[] s platnými (sloučenými) limity
    MACHINE.overrides = cfgResp.overrides || {};  // pouze uživatelské přepisy
    renderMachineCard();
    // zaevidovat jako panel (pro přepínání Ctrl+Tab)
    openPanel("machine", machineId, `Stroj: ${machine.name || "—"}`, () => openMachine(machineId));
  } catch (e) {
    document.getElementById("machine-points").innerHTML =
      `<div class="empty-state"><p>${escapeHtml(e.message)}</p></div>`;
  }
}

function renderMachineCard() {
  const m = MACHINE.data;
  document.getElementById("machine-title").textContent = m.name || "Stroj";
  document.getElementById("machine-breadcrumb").textContent =
    [m.parent_name, "Karta stroje"].filter(Boolean).join("  ›  ");

  const wrap = document.getElementById("machine-points");
  wrap.innerHTML = "";
  const bearings = m.bearings || [];
  if (!bearings.length) {
    wrap.innerHTML = '<div class="empty-state"><p>Stroj nemá měřicí body.</p></div>';
    return;
  }

  // --- ZÁLOŽKY (taby) karty stroje ---
  // Dlouhá karta je rozdělena do tří přehledných záložek. Všechny vstupy
  // zůstávají v DOM (neaktivní záložky jsou jen skryté přes CSS), takže
  // collectMachineConfig() ukládá hodnoty bez ohledu na zobrazenou záložku.
  const TABS = [
    { key: "info", label: "Základní informace o stroji" },
    { key: "bearings", label: "Ložiska a limity" },
    { key: "ai", label: "Vyhodnocení pomocí AI" },
    { key: "chat", label: "Chat s diagnostikem" },
  ];
  if (!TABS.some(t => t.key === MACHINE.activeTab)) MACHINE.activeTab = "info";

  // záložky (taby) se vykreslují do fixní hlavičky (mimo skrolovaný obsah)
  const tabBar = document.getElementById("machine-tabbar");
  tabBar.innerHTML = "";
  tabBar.className = "mc-tabbar-mount mc-tabs";
  tabBar.setAttribute("role", "tablist");
  TABS.forEach(t => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "mc-tab" + (t.key === MACHINE.activeTab ? " active" : "");
    btn.dataset.tab = t.key;
    btn.textContent = t.label;
    // preventDefault na mousedown zabrání focusu tlačítka, který by (pokud
    // by tabbar byl uvnitř skrolovaného obsahu) vyvolal scroll-into-view
    // ještě před click handlerem a smazal tak pamatovanou pozici.
    btn.addEventListener("mousedown", (e) => e.preventDefault());
    btn.addEventListener("click", () => switchMachineTab(t.key));
    tabBar.appendChild(btn);
  });

  // kontejnery jednotlivých záložek
  const paneInfo = document.createElement("div");
  paneInfo.className = "mc-tabpane" + (MACHINE.activeTab === "info" ? " active" : "");
  paneInfo.dataset.tab = "info";
  const paneBearings = document.createElement("div");
  paneBearings.className = "mc-tabpane" + (MACHINE.activeTab === "bearings" ? " active" : "");
  paneBearings.dataset.tab = "bearings";
  const paneAi = document.createElement("div");
  paneAi.className = "mc-tabpane" + (MACHINE.activeTab === "ai" ? " active" : "");
  paneAi.dataset.tab = "ai";
  const paneChat = document.createElement("div");
  paneChat.className = "mc-tabpane" + (MACHINE.activeTab === "chat" ? " active" : "");
  paneChat.dataset.tab = "chat";

  // --- ZÁLOŽKA: ZÁKLADNÍ INFORMACE O STROJI + OTÁČKY ---
  paneInfo.appendChild(renderCardInfoPanel(m));
  paneInfo.appendChild(renderSpeedPanel(m));

  // --- ZÁLOŽKA: LOŽISKA A LIMITY ---
  // vysvětlující poznámka – limity se vedou na ložisko, sdíleně přes směry
  const note = document.createElement("div");
  note.className = "mc-note";
  note.innerHTML =
    "Limity i ložisko se zadávají <strong>na ložisko</strong> (např. L1) a platí " +
    "sdíleně pro všechny jeho směry (H/V/A). Výchozí limity se načítají z databáze " +
    "(<em>z DB</em>); je možné je přepsat (<em>vlastní</em>). Barvy teček u bodů " +
    "vycházejí ze stavu vyhodnoceného v databázi.";
  paneBearings.appendChild(note);
  // panel s parametry adaptivních limitů EWMA (společný pro celý stroj)
  paneBearings.appendChild(renderEwmaPanel(m));
  // jednotlivá ložiska jsou dále rozdělena do podzáložek (místo dlouhého
  // seznamu karet pod sebou) — sníží to nutnost neustále skrolovat.
  paneBearings.appendChild(renderBearingTabs(bearings));

  // --- ZÁLOŽKA: VYHODNOCENÍ POMOCÍ AI ---
  paneAi.appendChild(renderAiPanel(m));

  // --- ZÁLOŽKA: CHAT S DIAGNOSTIKEM ---
  paneChat.appendChild(renderChatPanel(m));

  wrap.appendChild(paneInfo);
  wrap.appendChild(paneBearings);
  wrap.appendChild(paneAi);
  wrap.appendChild(paneChat);
}

// Přepnutí záložky na kartě stroje (bez překreslení – jen viditelnost).
// Pozice skrolování se pamatuje zvlášť pro každou záložku (a stroj), aby se
// při návratu na záložku obnovilo místo, kde uživatel skončil.
function switchMachineTab(key) {
  const scopeKey = "machine:" + (MACHINE.id == null ? "_" : MACHINE.id);
  if (MACHINE.activeTab !== key) saveTabScroll(scopeKey, MACHINE.activeTab);
  MACHINE.activeTab = key;
  document.querySelectorAll("#machine-tabbar .mc-tab").forEach(b => {
    b.classList.toggle("active", b.dataset.tab === key);
  });
  document.querySelectorAll("#machine-points .mc-tabpane").forEach(p => {
    p.classList.toggle("active", p.dataset.tab === key);
  });
  restoreTabScroll(scopeKey, key);
}

// Vykreslí ložiska záložky "Ložiska a limity" jako podzáložky (jedno ložisko
// = jedna podzáložka) namísto dlouhého seznamu karet pod sebou. Panely
// zůstávají v DOM (jen skryté přes CSS), takže collectMachineConfig() je
// stále najde přes document.querySelectorAll(".mp-panel") bez ohledu na to,
// která podzáložka je právě aktivní.
function renderBearingTabs(bearings) {
  const wrap = document.createElement("div");
  wrap.className = "mc-bearing-tabs";

  if (!bearings.length) {
    wrap.innerHTML = '<div class="mp-empty">Stroj nemá žádná ložiska.</div>';
    return wrap;
  }

  if (!bearings.some(b => String(b.bearing_key) === MACHINE.activeBearingTab)) {
    MACHINE.activeBearingTab = String(bearings[0].bearing_key);
  }

  const tabBar = document.createElement("div");
  tabBar.className = "mc-tabs mc-bearing-tabbar";
  tabBar.setAttribute("role", "tablist");
  bearings.forEach(b => {
    const bkey = String(b.bearing_key);
    const sevCol = b.severity_id > 0 ? sevColor(b.severity_id) : getCss("--sev-none");
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "mc-tab mc-bearing-tab" + (bkey === MACHINE.activeBearingTab ? " active" : "");
    btn.dataset.bkey = bkey;
    btn.innerHTML = `<span class="mp-dot sm" style="background:${sevCol}"></span> Ložisko ${escapeHtml(b.label)}`;
    // preventDefault na mousedown zabrání focusu tlačítka, který by vyvolal
    // scroll-into-view ještě před click handlerem a smazal pamatovanou pozici.
    btn.addEventListener("mousedown", (e) => e.preventDefault());
    btn.addEventListener("click", () => switchBearingTab(bkey));
    tabBar.appendChild(btn);
  });
  wrap.appendChild(tabBar);

  const paneHost = document.createElement("div");
  paneHost.className = "mc-bearing-panes";
  bearings.forEach(b => {
    const bkey = String(b.bearing_key);
    const pane = document.createElement("div");
    pane.className = "mc-bearing-pane" + (bkey === MACHINE.activeBearingTab ? " active" : "");
    pane.dataset.bkey = bkey;
    pane.appendChild(renderBearingPanel(b));
    paneHost.appendChild(pane);
  });
  wrap.appendChild(paneHost);

  return wrap;
}

// Přepnutí podzáložky ložiska (bez překreslení – jen viditelnost). Pozice
// skrolování se pamatuje zvlášť pro každé ložisko (a stroj).
function switchBearingTab(bkey) {
  const scopeKey = "bearings:" + (MACHINE.id == null ? "_" : MACHINE.id);
  if (MACHINE.activeBearingTab !== bkey) saveTabScroll(scopeKey, MACHINE.activeBearingTab);
  MACHINE.activeBearingTab = bkey;
  document.querySelectorAll("#machine-points .mc-bearing-tab").forEach(b => {
    b.classList.toggle("active", b.dataset.bkey === bkey);
  });
  document.querySelectorAll("#machine-points .mc-bearing-pane").forEach(p => {
    p.classList.toggle("active", p.dataset.bkey === bkey);
  });
  restoreTabScroll(scopeKey, bkey);
}



// Kinematické údaje stroje. Odemykají výpočet frekvencí, které ze samotného
// spektra spočítat nelze: BPF z počtu lopatek, GMF z počtu zubů, 2F_L a F_P
// z počtu pólů a řemenové frekvence z rozměrů převodu. Vše je volitelné —
// bez vyplnění zůstane HADS u odhadu z dominantního řádu ve spektru.
function renderKinematicsSection() {
  const kin = (MACHINE.overrides && MACHINE.overrides.kinematics) || {};
  const v = (k) => (kin[k] === null || kin[k] === undefined ? "" : escapeHtml(String(kin[k])));
  const wrap = document.createElement("div");
  wrap.className = "mp-section mc-kinematics";
  wrap.innerHTML = `
    <div class="mp-subhead">Kinematika stroje <span class="mp-src mp-src-own">volitelné</span></div>
    <p class="brg-hint">Vyplněné údaje změní odhad ze spektra na přesný výpočet. Prázdné pole nevadí — HADS pak nabídne odhad z dominantního řádu a vyzve k ověření.</p>
    <div class="mc-card-grid">
      <div class="brg-field"><label for="mc-kin-blade_count">Počet lopatek (ventilátor, čerpadlo)</label>
        <input id="mc-kin-blade_count" class="brg-in" type="number" min="2" max="60" step="1" value="${v('blade_count')}" placeholder="např. 12" /></div>
      <div class="brg-field"><label for="mc-kin-pole_count">Počet pólů motoru</label>
        <input id="mc-kin-pole_count" class="brg-in" type="number" min="2" max="24" step="2" value="${v('pole_count')}" placeholder="např. 4" /></div>
      <div class="brg-field"><label for="mc-kin-line_freq_hz">Síťová frekvence [Hz]</label>
        <input id="mc-kin-line_freq_hz" class="brg-in" type="number" min="40" max="70" step="1" value="${v('line_freq_hz')}" placeholder="50" /></div>
      <div class="brg-field"><label for="mc-kin-drive_type">Typ pohonu</label>
        <select id="mc-kin-drive_type" class="brg-in">
          <option value="">neurčeno</option>
          <option value="spojka">spojka</option>
          <option value="řemen">řemen</option>
          <option value="ozubení">ozubení</option>
          <option value="přímé">přímé</option>
        </select></div>
      <div class="brg-field"><label for="mc-kin-gear_teeth_driver">Počet zubů hnacího kola</label>
        <input id="mc-kin-gear_teeth_driver" class="brg-in" type="number" min="5" max="400" step="1" value="${v('gear_teeth_driver')}" placeholder="často neznámé" /></div>
      <div class="brg-field"><label for="mc-kin-gear_teeth_driven">Počet zubů hnaného kola</label>
        <input id="mc-kin-gear_teeth_driven" class="brg-in" type="number" min="5" max="400" step="1" value="${v('gear_teeth_driven')}" placeholder="často neznámé" /></div>
      <div class="brg-field"><label for="mc-kin-belt_length_mm">Délka řemene [mm]</label>
        <input id="mc-kin-belt_length_mm" class="brg-in" type="number" min="1" step="1" value="${v('belt_length_mm')}" placeholder="např. 1250" /></div>
      <div class="brg-field"><label for="mc-kin-pulley_driver_mm">Průměr hnací řemenice [mm]</label>
        <input id="mc-kin-pulley_driver_mm" class="brg-in" type="number" min="1" step="1" value="${v('pulley_driver_mm')}" placeholder="např. 200" /></div>
      <div class="brg-field"><label for="mc-kin-pulley_driven_mm">Průměr hnané řemenice [mm]</label>
        <input id="mc-kin-pulley_driven_mm" class="brg-in" type="number" min="1" step="1" value="${v('pulley_driven_mm')}" placeholder="např. 400" /></div>
    </div>
  `;
  const drive = wrap.querySelector("#mc-kin-drive_type");
  if (drive && kin.drive_type) drive.value = kin.drive_type;
  return wrap;
}

// Přečte kinematiku z formuláře karty stroje. Prázdné pole = neznámý údaj.
function collectKinematics() {
  const num = (id) => {
    const el = document.getElementById(id);
    if (!el || !el.value.trim()) return null;
    const parsed = parseFloat(el.value.replace(",", "."));
    return Number.isFinite(parsed) ? parsed : null;
  };
  const out = {};
  ["blade_count", "pole_count", "line_freq_hz", "gear_teeth_driver",
   "gear_teeth_driven", "belt_length_mm", "pulley_driver_mm",
   "pulley_driven_mm"].forEach((key) => {
    const value = num("mc-kin-" + key);
    if (value !== null) out[key] = value;
  });
  const drive = document.getElementById("mc-kin-drive_type");
  if (drive && drive.value) out.drive_type = drive.value;
  return Object.keys(out).length ? out : null;
}

// Opory hodnocení, které metodologie řadí NAD normu: baseline ze známého
// dobrého stavu a shodný (sesterský) stroj za srovnatelných podmínek.
// Sesterský stroj nelze odvodit z dat — vybírá jej diagnostik, protože jen
// on ví, že jde o shodné provedení ve shodném provozu.
function renderReferenceSection() {
  const over = (MACHINE.overrides || {});
  const base = over.baseline || {};
  const wrap = document.createElement("div");
  wrap.className = "mp-section mc-reference";

  const machines = (STATE.nodes || [])
    .filter((n) => Number(n.type) === 2 && n.id !== MACHINE.id)
    .sort((a, b) => (a.name || "").localeCompare(b.name || "", "cs"));
  const options = ['<option value="">nevybrán</option>'].concat(
    machines.map((n) =>
      `<option value="${n.id}">${escapeHtml(n.name || ("Stroj #" + n.id))}</option>`)
  ).join("");

  wrap.innerHTML = `
    <div class="mp-subhead">Opory hodnocení <span class="mp-src mp-src-own">volitelné</span></div>
    <p class="brg-hint">Metodologie řadí spolehlivost takto: <strong>trend</strong> téhož bodu, <strong>baseline</strong>, <strong>sesterský stroj</strong> a teprve pak <strong>norma</strong> — ta je jen hrubé vodítko pro stroj bez historie. Vyplněné položky se použijí přednostně.</p>
    <div class="mc-card-grid">
      <div class="brg-field"><label for="mc-ref-baseline-time">Baseline – datum známého dobrého stavu</label>
        <input id="mc-ref-baseline-time" class="brg-in" type="date" value="${escapeHtml((base.time || "").slice(0, 10))}" />
        <span class="brg-hint">Ukládá se jen datum; hodnoty se čtou z databáze, takže se reference nikdy nerozejde s měřením.</span></div>
      <div class="brg-field"><label for="mc-ref-baseline-note">Baseline – poznámka</label>
        <input id="mc-ref-baseline-note" class="brg-in" type="text" maxlength="200" value="${escapeHtml(base.note || "")}" placeholder="např. po generální opravě" /></div>
      <div class="brg-field"><label for="mc-ref-sister">Sesterský stroj (shodné provedení)</label>
        <select id="mc-ref-sister" class="brg-in">${options}</select>
        <span class="brg-hint">Porovnává se podle dvojice ložisko + veličina. Platí jen za srovnatelného zatížení a otáček.</span></div>
    </div>
  `;
  const sel = wrap.querySelector("#mc-ref-sister");
  if (sel && over.sister_machine_id != null) sel.value = String(over.sister_machine_id);
  return wrap;
}

// Přečte opory hodnocení z formuláře karty stroje.
function collectReference() {
  const timeEl = document.getElementById("mc-ref-baseline-time");
  const noteEl = document.getElementById("mc-ref-baseline-note");
  const sisterEl = document.getElementById("mc-ref-sister");
  const time = timeEl ? (timeEl.value || "").trim() : "";
  const note = noteEl ? (noteEl.value || "").trim() : "";
  const sister = sisterEl && sisterEl.value ? parseInt(sisterEl.value, 10) : null;
  return {
    baseline: time ? { time, note } : null,
    sister_machine_id: Number.isFinite(sister) ? sister : null,
  };
}

// Panel se základními informacemi o stroji („karta stroje“).
// Tyto údaje se používají na stránce stroje v PDF protokolu.
function renderCardInfoPanel(m) {
  const card = (MACHINE.overrides && MACHINE.overrides.card) || {};
  const v = (k) => escapeHtml(card[k] || "");
  const panel = document.createElement("div");
  panel.className = "mp-panel mc-cardinfo";
  panel.id = "mc-cardinfo-panel";

  const head = document.createElement("div");
  head.className = "mp-head";
  head.innerHTML = `<span class="mp-name">Základní informace o stroji</span>` +
    `<span class="mp-src mp-src-own">pro protokol</span>`;
  panel.appendChild(head);

  const body = document.createElement("div");
  body.className = "mp-section mc-card-grid";
  body.innerHTML = `
    <div class="brg-field"><label>Číslo pohonu</label>
      <input id="mc-card-drive_no" class="brg-in" type="text" value="${v('drive_no')}" placeholder="např. P-102" /></div>
    <div class="brg-field"><label>Technické místo</label>
      <input id="mc-card-tech_location" class="brg-in" type="text" value="${v('tech_location')}" placeholder="např. Hala 2 / linka A" /></div>
    <div class="brg-field"><label>Výkon [kW]</label>
      <input id="mc-card-power_kw" class="brg-in" type="text" value="${v('power_kw')}" placeholder="např. 75" /></div>
    <div class="brg-field"><label>Otáčky [ot/min]</label>
      <input id="mc-card-rpm" class="brg-in" type="text" value="${v('rpm')}" placeholder="např. 1480" /></div>
    <div class="brg-field"><label>Průměr oběžného kola [mm]</label>
      <input id="mc-card-impeller_diameter" class="brg-in" type="text" value="${v('impeller_diameter')}" placeholder="např. 630" /></div>
  `;
  panel.appendChild(body);

  const descWrap = document.createElement("div");
  descWrap.className = "mp-section";
  descWrap.innerHTML = `
    <div class="brg-field brg-field-wide"><label>Popis stroje</label>
      <textarea id="mc-card-description" class="brg-in mc-card-desc" rows="3" placeholder="Stručný popis stroje, funkce, umístění…">${v('description')}</textarea></div>
  `;
  panel.appendChild(descWrap);

  // --- kinematika stroje (odemyká výpočet BPF, GMF, F_P a řemenových frekvencí) ---
  panel.appendChild(renderKinematicsSection());

  // --- opory hodnocení: baseline a sesterský stroj (metodologie E.1) ---
  panel.appendChild(renderReferenceSection());

  // --- norma pro hodnocení (dříve v panelu AI, nyní jediné místo pro nastavení) ---
  panel.appendChild(renderNormSection(m));

  // obrázek stroje
  const imgWrap = document.createElement("div");
  imgWrap.className = "mp-section mc-card-image";
  const hasImg = !!(card.image && card.image.startsWith("data:image/"));
  imgWrap.innerHTML = `
    <label class="mc-img-label">Obrázek stroje (pro protokol)</label>
    <div class="mc-img-row">
      <div class="mc-img-preview" id="mc-card-img-preview">
        ${hasImg ? `<img src="${card.image}" alt="Obrázek stroje" />` : '<span class="mc-img-empty">Bez obrázku</span>'}
      </div>
      <div class="mc-img-btns">
        <button type="button" id="mc-card-img-btn" class="brg-search-btn">Nahrát obrázek…</button>
        <button type="button" id="mc-card-img-clear" class="brg-search-btn ${hasImg ? '' : 'hidden'}">Odebrat obrázek</button>
        <input type="file" id="mc-card-img-file" accept="image/*" class="hidden" />
      </div>
    </div>
    <div class="mp-lim-hint">Obrázek se převede do JPEG a vloží na stránku stroje v PDF. Maximální velikost cca 4 MB.</div>
  `;
  panel.appendChild(imgWrap);

  // uchování aktuálního obrázku (data URL JPEG) na panelu
  panel.dataset.image = hasImg ? card.image : "";

  // wiring tlačítek
  setTimeout(() => {
    const btn = document.getElementById("mc-card-img-btn");
    const file = document.getElementById("mc-card-img-file");
    const clr = document.getElementById("mc-card-img-clear");
    const prev = document.getElementById("mc-card-img-preview");
    if (btn && file) btn.addEventListener("click", () => file.click());
    if (file) file.addEventListener("change", async (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      try {
        const jpeg = await imageFileToJpegDataUrl(f, 1200, 0.82);
        panel.dataset.image = jpeg;
        prev.innerHTML = `<img src="${jpeg}" alt="Obrázek stroje" />`;
        if (clr) clr.classList.remove("hidden");
      } catch (err) {
        toast("Obrázek se nepodařilo načíst: " + err.message, true);
      }
      file.value = "";
    });
    if (clr) clr.addEventListener("click", () => {
      panel.dataset.image = "";
      prev.innerHTML = '<span class="mc-img-empty">Bez obrázku</span>';
      clr.classList.add("hidden");
    });
  }, 0);

  return panel;
}

// Převede obrázkový soubor na JPEG datovou URL přes <canvas>.
// PDF generator přijímá pouze JPEG – proto vždy převedeme i PNG.
function imageFileToJpegDataUrl(file, maxDim, quality) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("čtení souboru selhalo"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("neplatný obrázek"));
      img.onload = () => {
        let w = img.naturalWidth || img.width;
        let h = img.naturalHeight || img.height;
        if (!w || !h) { reject(new Error("nulové rozměry")); return; }
        const md = maxDim || 1200;
        if (w > md || h > md) {
          const r = Math.min(md / w, md / h);
          w = Math.round(w * r); h = Math.round(h * r);
        }
        const cv = document.createElement("canvas");
        cv.width = w; cv.height = h;
        const ctx = cv.getContext("2d");
        // bílé pozadí (JPEG nemá průhlednost)
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        try {
          resolve(cv.toDataURL("image/jpeg", quality || 0.82));
        } catch (err) { reject(err); }
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

// Panel pro otáčky celého stroje. Hodnota se použije jako výchozí
// otáčková frekvence ve spektrech (násobky pro ložiskové frekvence).
function renderSpeedPanel(m) {
  const panel = document.createElement("div");
  panel.className = "mp-panel mc-speed";

  const eff = m.speed_hz != null ? m.speed_hz : null;       // platná hodnota (přepis nebo DB)
  const dbVal = m.db_speed_hz != null ? m.db_speed_hz : null;
  const overridden = !!m.speed_overridden;
  const inputVal = (overridden && eff != null) ? eff : "";  // v poli jen vlastní přepis
  const ph = dbVal != null ? fmtNum(dbVal, 2) : "—";
  const srcLabel = overridden ? "vlastní" : (dbVal != null ? "z DB" : "nezadáno");
  const srcCls = overridden ? "mp-src-own" : "mp-src-db";

  const head = document.createElement("div");
  head.className = "mp-head";
  head.innerHTML =
    `<span class="mp-name">Otáčky stroje</span>` +
    `<span class="mp-src ${srcCls}" id="mc-speed-src">${srcLabel}</span>`;
  panel.appendChild(head);

  const body = document.createElement("div");
  body.className = "mp-section mc-speed-row";
  body.innerHTML = `
    <div class="brg-field">
      <label>Otáčky [Hz]</label>
      <input id="mc-speed-input" class="brg-in" type="number" step="any" min="0"
             value="${inputVal}" placeholder="${ph}" title="Výchozí z DB: ${ph}" />
    </div>
    <button id="mc-speed-detect" class="brg-search-btn" title="Automaticky detekovat otáčky z maxima spektra rychlosti (5–70 Hz)">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.9" style="vertical-align:-3px;margin-right:5px"><path d="M3 12h4l3 8 4-16 3 8h4"/></svg>
      Detekovat ze spektra
    </button>`;
  panel.appendChild(body);

  const hint = document.createElement("div");
  hint.className = "mp-lim-hint";
  hint.innerHTML =
    "Otáčky platí pro <strong>celý stroj</strong> (všechna měřicí místa) a používají se jako " +
    "výchozí otáčková frekvence ve spektrech. Prázdné pole = použije se hodnota z databáze " +
    "(zobrazena šedě). Tlačítko <em>Detekovat ze spektra</em> najde maximální amplitudu " +
    "spektra rychlosti vibrací v rozsahu 5–70 Hz.";
  panel.appendChild(hint);

  // Detekce se do historie zapíše hned, ale platnými otáčkami se stane až
  // po uložení karty. Bez tohoto upozornění vypadá stroj jako by otáčky měl
  // (jsou v historii), a přitom je AI ani spektra nepoužijí.
  const detected = (m.speed_history || []).find(
    (h) => h && Number.isFinite(Number(h.value)) && Number(h.value) > 0);
  if (detected && !inputVal) {
    const warn = document.createElement("div");
    warn.className = "mp-lim-hint mc-speed-unsaved";
    warn.innerHTML =
      `<strong>Otáčky nejsou uloženy.</strong> Naposledy bylo detekováno ` +
      `<strong>${escapeHtml(String(detected.value))} Hz</strong>, ale dokud hodnotu ` +
      `nevyplníte do pole výše a neuložíte kartu, HADS ji nepoužije — spektra ` +
      `zůstanou bez řádů (× ot) a bez poruchových frekvencí ložisek.`;
    panel.appendChild(warn);
  }

  // --- HISTORIE DETEKCÍ OTÁČEK (posledních 5) ---
  const histSection = document.createElement("div");
  histSection.className = "mp-section mc-speed-hist";
  histSection.innerHTML = `<div class="mp-section-title">Historie detekcí otáček</div>
    <div id="mc-speed-hist-body"></div>`;
  panel.appendChild(histSection);

  body.querySelector("#mc-speed-detect").addEventListener("click", detectMachineSpeed);
  // vykresli historii z aktuálních dat stroje (přímo do prvku sekce, panel zatím není v DOM)
  renderSpeedHistory(m.speed_history || [], histSection.querySelector("#mc-speed-hist-body"));
  return panel;
}

// Vykreslí seznam posledních detekcí otáček (datum + hodnota) s tlačítkem Obnovit.
// `history` = [{time, value}, ...] (nejnovější první).
function renderSpeedHistory(history, boxEl) {
  const box = boxEl || document.getElementById("mc-speed-hist-body");
  if (!box) return;
  box.innerHTML = "";
  if (!history || !history.length) {
    box.innerHTML = `<div class="mp-empty">Zatím žádné detekce. Použijte tlačítko „Detekovat ze spektra“.</div>`;
    return;
  }
  const table = document.createElement("table");
  table.className = "mc-hist-table";
  table.innerHTML = `<thead><tr>
      <th>Datum a čas detekce</th>
      <th>Otáčky [Hz]</th>
      <th></th>
    </tr></thead>`;
  const tbody = document.createElement("tbody");
  history.forEach((rec, i) => {
    const tr = document.createElement("tr");
    if (i === 0) tr.className = "mc-hist-latest";
    const dateCell = document.createElement("td");
    dateCell.className = "mc-hist-date";
    dateCell.textContent = fmtDate(rec.time);
    const valCell = document.createElement("td");
    valCell.className = "mc-hist-val";
    valCell.textContent = fmtNum(rec.value, 2);
    const actCell = document.createElement("td");
    actCell.className = "mc-hist-act";
    const btn = document.createElement("button");
    btn.className = "mc-hist-restore";
    btn.type = "button";
    btn.title = "Obnovit tuto hodnotu jako aktuální otáčky stroje";
    btn.textContent = "Obnovit";
    btn.addEventListener("click", () => applyDetectedSpeed(rec.value));
    actCell.appendChild(btn);
    tr.appendChild(dateCell);
    tr.appendChild(valCell);
    tr.appendChild(actCell);
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  box.appendChild(table);
}

// Vloží zvolenou (dříve detekovanou) hodnotu do pole aktuálních otáček.
function applyDetectedSpeed(value) {
  const inp = document.getElementById("mc-speed-input");
  if (inp) {
    inp.value = fmtNum(value, 2);
    inp.focus();
  }
  toast(`Otáčky nastaveny na ${fmtNum(value, 2)} Hz. Nezapomeňte uložit.`);
}

// Zavolá backend pro autodetekci otáček a vyplní pole.
async function detectMachineSpeed() {
  if (MACHINE.id == null) return;
  const btn = document.getElementById("mc-speed-detect");
  const inp = document.getElementById("mc-speed-input");
  if (btn) { btn.disabled = true; }
  try {
    const r = await api(`/api/machine/${MACHINE.id}/detect-speed`);
    if (r && r.speed_hz != null) {
      if (inp) inp.value = fmtNum(r.speed_hz, 2);
      const amp = r.amplitude != null ? fmtNum(r.amplitude, 3) : "—";
      // aktualizuj historii detekcí (backend ji vrátí včetně nového záznamu)
      if (r.speed_history) {
        if (MACHINE.data) MACHINE.data.speed_history = r.speed_history;
        renderSpeedHistory(r.speed_history);
      }
      toast(`Detekováno ${fmtNum(r.speed_hz, 2)} Hz (bod ${r.point_name || "?"}, amplituda ${amp}). Nezapomeňte uložit.`);
    } else {
      toast("Otáčky se nepodařilo detekovat – stroj nemá vhodné spektrum rychlosti.", true);
    }
  } catch (e) {
    const msg = (e && e.message && /404/.test(e.message))
      ? "Otáčky se nepodařilo detekovat – stroj nemá naměřené spektrum rychlosti (5–70 Hz)."
      : (e.message || "Detekce otáček selhala.");
    toast(msg, true);
  } finally {
    if (btn) { btn.disabled = false; }
  }
}

// jeden panel = jedno ložisko (L1, L2…) se všemi svými směry

// ============== ADAPTIVNÍ LIMITY EWMA – panel parametrů ==============
// Parametry jsou společné pro celý stroj. Po změně a uložení karty stroje
// se adaptivní limity přepočítají na backendu z trendů jednotlivých bodů.

function renderEwmaPanel(m) {
  const cfg = (m && m.ewma) || {};
  const enabled = cfg.enabled !== false;
  const lam = cfg.lambda != null ? cfg.lambda : 0.2;
  const lwarn = cfg.l_warn != null ? cfg.l_warn : 3;
  const lalarm = cfg.l_alarm != null ? cfg.l_alarm : 4;
  const minn = cfg.min_n != null ? cfg.min_n : 8;

  const panel = document.createElement("div");
  panel.className = "mp-panel mc-ewma";
  panel.id = "mc-ewma-panel";

  const head = document.createElement("div");
  head.className = "mp-head";
  head.innerHTML =
    `<span class="mp-name">Adaptivní limity (EWMA)</span>` +
    `<label class="mp-classify-toggle" title="Zapnout výpočet adaptivních limitů z historie trendu (mimo rychlost vibrací).">` +
    `<input type="checkbox" id="ewma-enabled" ${enabled ? "checked" : ""} />` +
    `<span>Počítat adaptivní limity</span></label>`;
  panel.appendChild(head);

  const hint = document.createElement("div");
  hint.className = "mp-lim-hint";
  hint.innerHTML =
    "Adaptivní limity se počítají metodou <strong>EWMA</strong> (exponenciálně vážený " +
    "klouzavý průměr) z historie trendu každého směru/bodu jako " +
    "<em>průměr + L × směrodatná odchylka</em>. Počítají se pro <strong>všechny statické " +
    "veličiny mimo rychlost vibrací</strong> (tu řeší norma ČSN ISO 20816). Slouží jako " +
    "<strong>orientační návrh</strong> – zobrazují se vedle naměřené hodnoty a tlačítkem " +
    "„Převzít“ je lze zkopírovat do ručního limitu. Klasifikaci stavu nadále řídí ruční limity. " +
    "Parametry se uloží spolu s kartou stroje (tlačítko „Uložit kartu stroje“).";
  panel.appendChild(hint);

  const grid = document.createElement("div");
  grid.className = "mc-ewma-grid";
  grid.innerHTML = `
    <div class="mc-ewma-field">
      <label for="ewma-lambda" title="Rychlost adaptace (0–1). Nižší hodnota = pomalejší přizpůsobení, hladší limit.">λ (rychlost adaptace)</label>
      <input id="ewma-lambda" class="cb-input" type="number" step="0.05" min="0.01" max="1" value="${lam}" />
    </div>
    <div class="mc-ewma-field">
      <label for="ewma-lwarn" title="Násobitel směrodatné odchylky pro úroveň Varování.">L pro Varování</label>
      <input id="ewma-lwarn" class="cb-input" type="number" step="0.5" min="0.1" value="${lwarn}" />
    </div>
    <div class="mc-ewma-field">
      <label for="ewma-lalarm" title="Násobitel směrodatné odchylky pro úroveň Alarm.">L pro Alarm</label>
      <input id="ewma-lalarm" class="cb-input" type="number" step="0.5" min="0.1" value="${lalarm}" />
    </div>
    <div class="mc-ewma-field">
      <label for="ewma-minn" title="Minimální počet měření v trendu, jinak se limit nepočítá.">Min. počet měření</label>
      <input id="ewma-minn" class="cb-input" type="number" step="1" min="2" value="${minn}" />
    </div>`;
  panel.appendChild(grid);

  const noteEl = document.createElement("div");
  noteEl.className = "mc-ewma-note";
  noteEl.textContent =
    "Po změně parametrů uložte kartu stroje – adaptivní limity se poté přepočítají.";
  panel.appendChild(noteEl);

  return panel;
}

// Sebere parametry EWMA z panelu (pro uložení konfigurace stroje).
function collectEwmaConfig() {
  const enEl = document.getElementById("ewma-enabled");
  if (!enEl) return null;  // panel není vykreslen
  const numOr = (id, def) => {
    const e = document.getElementById(id);
    if (!e || e.value === "") return def;
    const v = parseFloat(e.value);
    return isFinite(v) ? v : def;
  };
  return {
    enabled: enEl.checked,
    lambda: numOr("ewma-lambda", 0.2),
    l_warn: numOr("ewma-lwarn", 3),
    l_alarm: numOr("ewma-lalarm", 4),
    min_n: Math.round(numOr("ewma-minn", 8)),
  };
}
// ============ KONEC ADAPTIVNÍ LIMITY EWMA – panel parametrů ============

function renderBearingPanel(b) {
  const bkey = String(b.bearing_key);
  const panel = document.createElement("div");
  panel.className = "mp-panel";
  panel.dataset.bkey = bkey;

  const sevCol = b.severity_id > 0 ? sevColor(b.severity_id) : getCss("--sev-none");

  // hlavička ložiska (+ přepínač klasifikace celého ložiska dle limitů)
  const bClassify = b.classify !== false;
  const head = document.createElement("div");
  head.className = "mp-head";
  head.innerHTML = `
    <span class="mp-dot" style="background:${sevCol}"></span>
    <span class="mp-name">Ložisko ${escapeHtml(b.label)}</span>
    ${b.severity_name ? `<span class="mp-sev" style="color:${sevCol}">${escapeHtml(b.severity_name)}</span>` : ""}
    <label class="mp-classify-toggle" title="Klasifikovat stav tohoto ložiska dle limitů (pásma A–D). Při vypnutí se ložisko nehodnotí a nezapočítává do celkového stavu.">
      <input type="checkbox" class="mp-classify-bearing" ${bClassify ? "checked" : ""} />
      <span>Klasifikovat dle limitů</span>
    </label>`;
  panel.appendChild(head);

  // --- SMĚRY (měřicí body tohoto ložiska) ---
  const dirWrap = document.createElement("div");
  dirWrap.className = "mp-section";
  dirWrap.innerHTML = `<div class="mp-section-title">Směry / měřicí body</div>`;
  const dirRow = document.createElement("div");
  dirRow.className = "mp-dirs";
  (b.points || []).forEach(p => {
    const pCol = p.severity_id > 0 ? sevColor(p.severity_id) : getCss("--sev-none");
    const chip = document.createElement("button");
    chip.className = "mp-dir";
    chip.title = "Otevřít detail a spektra bodu";
    chip.innerHTML =
      `<span class="mp-dot sm" style="background:${pCol}"></span>` +
      `<span class="mp-dir-name">${escapeHtml(p.name)}</span>` +
      `<span class="mp-dir-arrow">→</span>`;
    chip.addEventListener("click", () => selectPoint(p.id));
    dirRow.appendChild(chip);
  });
  dirWrap.appendChild(dirRow);
  panel.appendChild(dirWrap);

  // --- LIMITY (Varování / Alarm pro více veličin) – sdíleno přes směry ---
  const limWrap = document.createElement("div");
  limWrap.className = "mp-section";
  limWrap.innerHTML = `<div class="mp-section-title">Limity měřených veličin</div>`;
  const quantities = b.quantities || [];
  if (!quantities.length) {
    limWrap.innerHTML += `<div class="mp-empty">Ložisko nemá trendové (skalární) veličiny.</div>`;
  } else {
    const table = document.createElement("table");
    table.className = "mp-lim-table";
    table.innerHTML = `<thead><tr>
        <th>Veličina</th>
        <th>Varování</th>
        <th>Alarm</th>
        <th class="mp-ewma-head" title="Adaptivní limity vypočtené algoritmem EWMA z historie trendu (max přes směry). Informativní – klasifikaci určují ruční limity.">Adaptivní (EWMA)</th>
        <th class="mp-lim-classify" title="Klasifikovat stav této veličiny dle limitů (pásma A–D)">Klasifikovat</th>
        <th class="mp-lim-src"></th>
      </tr></thead>`;
    const tbody = document.createElement("tbody");
    quantities.forEach(q => {
      const tr = document.createElement("tr");
      // hodnota v políčku = jen vlastní přepis; výchozí (z DB) je placeholder
      const ovw = q.overridden && q.warning != null ? q.warning : "";
      const ova = q.overridden && q.alarm != null ? q.alarm : "";
      const phw = q.db_warning != null ? fmtNum(q.db_warning, 4) : "—";
      const pha = q.db_alarm != null ? fmtNum(q.db_alarm, 4) : "—";
      const srcLabel = q.overridden ? "vlastní" : "z DB";
      const srcCls = q.overridden ? "mp-src-own" : "mp-src-db";
      const qClassify = q.classify !== false;
      tr.dataset.q = q.name;
      tr.dataset.dbWarning = q.db_warning != null ? q.db_warning : "";
      tr.dataset.dbAlarm = q.db_alarm != null ? q.db_alarm : "";

      // --- buňka Adaptivní (EWMA) ---
      let ewmaCell;
      if (q.is_velocity) {
        ewmaCell = `<span class="mp-ewma-na" title="Rychlost vibrací hodnotí norma ČSN ISO 20816, adaptivní limity se zde nepočítají.">řeší norma</span>`;
      } else if (q.ewma_warning_max != null || q.ewma_alarm_max != null) {
        const ew = q.ewma_warning_max != null ? fmtNum(q.ewma_warning_max, 4) : "—";
        const ea = q.ewma_alarm_max != null ? fmtNum(q.ewma_alarm_max, 4) : "—";
        ewmaCell =
          `<span class="mp-ewma-val" title="Adaptivní Varování / Alarm (max přes směry)">${ew} / ${ea}</span>` +
          ` <button type="button" class="mp-ewma-apply" title="Převzít adaptivní hodnoty do ručních limitů tohoto ložiska"` +
          ` data-q="${escapeHtml(q.name)}"` +
          ` data-warn="${q.ewma_warning_max != null ? q.ewma_warning_max : ""}"` +
          ` data-alarm="${q.ewma_alarm_max != null ? q.ewma_alarm_max : ""}">Převzít</button>`;
      } else {
        ewmaCell = `<span class="mp-ewma-na" title="Pro výpočet adaptivních limitů je potřeba více měření v trendu.">málo dat</span>`;
      }

      tr.innerHTML = `
        <td class="mp-q">${escapeHtml(q.name)}</td>
        <td><input class="mp-lim mp-warn" data-q="${escapeHtml(q.name)}" type="number" step="any" min="0"
              value="${ovw}" placeholder="${phw}" title="Výchozí z DB: ${phw}" /></td>
        <td><input class="mp-lim mp-alarm" data-q="${escapeHtml(q.name)}" type="number" step="any" min="0"
              value="${ova}" placeholder="${pha}" title="Výchozí z DB: ${pha}" /></td>
        <td class="mp-ewma-col">${ewmaCell}</td>
        <td class="mp-lim-classify"><label class="mp-classify-cell" title="Klasifikovat stav této veličiny dle limitů">
          <input type="checkbox" class="mp-classify-q" data-q="${escapeHtml(q.name)}" ${qClassify ? "checked" : ""} /></label></td>
        <td class="mp-lim-src"><span class="mp-src ${srcCls}">${srcLabel}</span></td>`;
      tbody.appendChild(tr);

      // --- detailní řádky per směr/bod (poslední hodnota + EWMA per směr) ---
      // POZOR: tyto řádky NESMÍ obsahovat .mp-warn/.mp-alarm (jinak by je
      // collectMachineConfig() chybně načetl jako limity).
      // platné limity veličiny (sdílené přes směry) – pro klasifikaci poslední
      // hodnoty. Používají se ISO/EWMA/ruční limity už sloučené backendem
      // do q.warning / q.alarm.
      const effWarn = (q.warning != null && isFinite(q.warning)) ? q.warning : null;
      const effAlarm = (q.alarm != null && isFinite(q.alarm)) ? q.alarm : null;
      (q.cells || []).forEach(cc => {
        const drow = document.createElement("tr");
        drow.className = "mp-ewma-detail";
        const dirName = cc.direction || cc.point_name || "—";
        const lastVal = cc.last_value != null ? fmtNum(cc.last_value, 4) : "—";
        // stavový puntík: porovnání poslední hodnoty s platnými limity
        const st = lastValueStatus(cc.last_value, effWarn, effAlarm, q.classify);
        const dotHtml = st
          ? `<span class="mp-last-dot" style="background:${st.color}" title="${escapeHtml(st.title)}"></span>`
          : "";
        let ewDetail;
        if (q.is_velocity) {
          ewDetail = `<span class="mp-ewma-na">řeší norma</span>`;
        } else if (cc.ewma_warning != null || cc.ewma_alarm != null) {
          const w = cc.ewma_warning != null ? fmtNum(cc.ewma_warning, 4) : "—";
          const a = cc.ewma_alarm != null ? fmtNum(cc.ewma_alarm, 4) : "—";
          ewDetail = `<span class="mp-ewma-val">${w} / ${a}</span>`;
        } else {
          ewDetail = `<span class="mp-ewma-na">málo dat (n=${cc.n_trend != null ? cc.n_trend : 0})</span>`;
        }
        drow.innerHTML = `
          <td class="mp-ewma-dir">${escapeHtml(dirName)}</td>
          <td class="mp-ewma-last" colspan="2">poslední: ${dotHtml}${lastVal}</td>
          <td class="mp-ewma-sub">${ewDetail}</td>
          <td></td>
          <td></td>`;
        tbody.appendChild(drow);
      });
    });
    table.appendChild(tbody);
    limWrap.appendChild(table);

    // tlačítka „Převzít“ – zkopírují adaptivní hodnoty do ručních limitů
    // Zaokrouhlí převzatou adaptivní hodnotu na 2 desetinná místa.
    // Týká se POUZE hodnot vložených tlačítkem „Převzít“ – ručně napsaná
    // čísla se nemění. Vrací řetězec vhodný do <input type=number>.
    const round2 = (raw) => {
      const n = parseFloat(raw);
      if (!isFinite(n)) return "";
      return String(Math.round(n * 100) / 100);
    };
    table.querySelectorAll(".mp-ewma-apply").forEach(btn => {
      btn.addEventListener("click", () => {
        const qn = btn.dataset.q;
        // převzaté adaptivní limity se zaokrouhlují na 2 desetinná místa
        const wv = round2(btn.dataset.warn);
        const av = round2(btn.dataset.alarm);
        // najdeme řádek dané veličiny a jeho ruční vstupy
        let warnEl = null, alarmEl = null;
        table.querySelectorAll("tbody tr").forEach(tr => {
          if (tr.classList.contains("mp-ewma-detail")) return;
          const we = tr.querySelector(".mp-warn");
          if (we && we.dataset.q === qn) {
            warnEl = we;
            alarmEl = tr.querySelector(".mp-alarm");
          }
        });
        if (warnEl && wv !== "") {
          warnEl.value = wv;
          warnEl.classList.add("mp-lim-flash");
          setTimeout(() => warnEl.classList.remove("mp-lim-flash"), 900);
        }
        if (alarmEl && av !== "") {
          alarmEl.value = av;
          alarmEl.classList.add("mp-lim-flash");
          setTimeout(() => alarmEl.classList.remove("mp-lim-flash"), 900);
        }
        toast(`Adaptivní limity převzaty do ručních limitů (${qn}), zaokrouhleno na 2 des. místa.`);
      });
    });

    const hint = document.createElement("div");
    hint.className = "mp-lim-hint";
    hint.innerHTML =
      "Prázdné políčko = použije se výchozí limit z databáze (zobrazen šedě). " +
      "Vyplněním pole limit přepíšete pro celé ložisko (všechny směry). " +
      "Sloupec „Adaptivní (EWMA)“ je informativní – tlačítkem „Převzít“ zkopírujete hodnoty do ručních limitů " +
      "(zaokrouhlené na 2 desetinná místa). Uloží se do konfigurace tlačítkem „Uložit kartu stroje“ – originální databáze .ndb se nemění.";
    limWrap.appendChild(hint);
  }
  panel.appendChild(limWrap);

  // --- LOŽISKO (defektní frekvence) – sdíleno přes směry ---
  const brgWrap = document.createElement("div");
  brgWrap.className = "mp-section mp-bearing";
  brgWrap.innerHTML = `<div class="mp-section-title">Ložisko (defektní frekvence)</div>`;
  brgWrap.appendChild(renderBearingEditor(bkey, b.bearing));
  panel.appendChild(brgWrap);

  return panel;
}

function renderBearingEditor(bkey, bearing) {
  bearing = bearing || {};
  const box = document.createElement("div");
  box.className = "brg-editor";
  box.dataset.bkey = bkey;
  box.innerHTML = `
    <div class="brg-row brg-top">
      <button class="brg-search-btn" data-bkey="${bkey}" title="Vyhledat ložisko v interní databázi">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.9" style="vertical-align:-3px;margin-right:5px"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
        Vyhledat v databázi
      </button>
      <div class="brg-field brg-desig-wrap">
        <label>Označení</label>
        <input class="brg-in brg-desig" type="text" value="${escapeHtml(bearing.designation || "")}" placeholder="např. 6205-SKF" />
      </div>
      <button class="brg-clear" data-bkey="${bkey}" title="Odebrat přiřazené ložisko">Vymazat</button>
    </div>
    <div class="brg-row brg-coefs">
      <div class="brg-field"><label title="Frekvence klece (Fundamental Train Frequency)">FTF ×</label>
        <input class="brg-in brg-ftf" type="number" step="any" min="0" value="${bearing.FTF != null ? bearing.FTF : ""}" placeholder="—" /></div>
      <div class="brg-field"><label title="Frekvence valivého tělíska (Ball Spin Frequency)">BSF ×</label>
        <input class="brg-in brg-bsf" type="number" step="any" min="0" value="${bearing.BSF != null ? bearing.BSF : ""}" placeholder="—" /></div>
      <div class="brg-field"><label title="Frekvence vnějšího kroužku (Ball Pass Freq. Outer)">BPFO ×</label>
        <input class="brg-in brg-bpfo" type="number" step="any" min="0" value="${bearing.BPFO != null ? bearing.BPFO : ""}" placeholder="—" /></div>
      <div class="brg-field"><label title="Frekvence vnitřního kroužku (Ball Pass Freq. Inner)">BPFI ×</label>
        <input class="brg-in brg-bpfi" type="number" step="any" min="0" value="${bearing.BPFI != null ? bearing.BPFI : ""}" placeholder="—" /></div>
    </div>
    <div class="brg-note">Koeficienty jsou bezrozměrné násobky otáčkové frekvence hřídele. Skutečná frekvence = koeficient × otáčky [Hz]. Otáčky se zadávají ve spektru. Ložisko platí pro všechny směry (H/V/A) tohoto ložiska.</div>`;

  box.querySelector(".brg-search-btn").addEventListener("click", () => openBearingModal(bkey));
  box.querySelector(".brg-clear").addEventListener("click", () => {
    box.querySelectorAll(".brg-in").forEach(i => { i.value = ""; });
  });
  return box;
}

// ---- načtení konfigurace z DOM (před uložením) – jen PŘEPISY ----
function collectMachineConfig() {
  const bearings = {};
  document.querySelectorAll(".mp-panel").forEach(panel => {
    const bkey = panel.dataset.bkey;
    if (!bkey) return;
    // příznak klasifikace celého ložiska (výchozí zapnuto)
    const bClassifyEl = panel.querySelector(".mp-classify-bearing");
    const bearingClassify = bClassifyEl ? bClassifyEl.checked : true;
    // limity – ukládáme hodnoty vyplněné uživatelem (přepis) + příznak klasifikace
    const limits = {};
    panel.querySelectorAll(".mp-lim-table tbody tr").forEach(tr => {
      const warnEl = tr.querySelector(".mp-warn");
      const alarmEl = tr.querySelector(".mp-alarm");
      if (!warnEl) return;
      const q = warnEl.dataset.q;
      const warning = warnEl.value !== "" ? parseFloat(warnEl.value) : null;
      const alarm = alarmEl.value !== "" ? parseFloat(alarmEl.value) : null;
      const w = (warning != null && isFinite(warning)) ? warning : null;
      const a = (alarm != null && isFinite(alarm)) ? alarm : null;
      const qcEl = tr.querySelector(".mp-classify-q");
      const qClassify = qcEl ? qcEl.checked : true;
      // ulož, pokud je vyplněn limit NEBO je vypnuta klasifikace veličiny
      if (w != null || a != null || !qClassify) {
        const entry = { warning: w, alarm: a };
        if (!qClassify) entry.classify = false;
        limits[q] = entry;
      }
    });
    // ložisko – jen pokud je něco vyplněno
    let bearing = null;
    const box = panel.querySelector(".brg-editor");
    if (box) {
      const val = (sel) => { const e = box.querySelector(sel); return e ? e.value.trim() : ""; };
      const num = (sel) => { const v = parseFloat(val(sel)); return isFinite(v) ? v : null; };
      const desig = val(".brg-desig");
      const ftf = num(".brg-ftf"), bsf = num(".brg-bsf"), bpfo = num(".brg-bpfo"), bpfi = num(".brg-bpfi");
      if (desig || ftf != null || bsf != null || bpfo != null || bpfi != null) {
        bearing = { designation: desig, manufacturer: "", type: "", FTF: ftf, BSF: bsf, BPFO: bpfo, BPFI: bpfi, rpm_hz: null };
      }
    }
    if (Object.keys(limits).length || bearing || !bearingClassify) {
      const entry = { limits, bearing };
      if (!bearingClassify) entry.classify = false;
      bearings[bkey] = entry;
    }
  });
  // otáčky stroje (na celý stroj) – jen pokud uživatel vyplnil pole
  let speed_hz = null;
  const spInp = document.getElementById("mc-speed-input");
  if (spInp && spInp.value !== "") {
    const v = parseFloat(spInp.value);
    if (isFinite(v) && v > 0) speed_hz = v;
  }
  // norma ISO 20816 (na celý stroj) – sebráno z výběru v AI panelu
  const iso_norm = collectIsoNorm();
  // karta stroje (základní informace + obrázek) pro PDF protokol
  const card = collectMachineCard();
  // parametry adaptivních limitů EWMA (na celý stroj)
  const ewma = collectEwmaConfig();
  // kinematika (lopatky, zuby, póly, řemenový převod) pro výpočet frekvencí
  const kinematics = collectKinematics();
  // opory hodnocení nad rámec normy: baseline a sesterský stroj
  const reference = collectReference();
  return { bearings, speed_hz, iso_norm, card, ewma, kinematics,
           baseline: reference.baseline,
           sister_machine_id: reference.sister_machine_id };
}

// Sebere údaje z karty stroje (panel se základními informacemi).
function collectMachineCard() {
  const panel = document.getElementById("mc-cardinfo-panel");
  if (!panel) return null;
  const val = (id) => {
    const e = document.getElementById(id);
    return e ? (e.value || "").trim() : "";
  };
  return {
    drive_no: val("mc-card-drive_no"),
    tech_location: val("mc-card-tech_location"),
    power_kw: val("mc-card-power_kw"),
    rpm: val("mc-card-rpm"),
    impeller_diameter: val("mc-card-impeller_diameter"),
    description: val("mc-card-description"),
    image: panel.dataset.image || "",
  };
}

// Po uložení karty stroje aktualizuje závažnosti bodů daného stroje v datech,
// z nichž se skládá levý strom (STATE.pointSeverity) a dashboard s kartami
// strojů (DASH.overview). Backend `POST /api/machine/{id}/config` vrací
// sloučená (merged) data stroje s přepočítanými `severity_id` u každého bodu,
// takže nemusíme re-fetchnout /api/overview ani /api/tree – stačí lokálně
// promítnout jen body TOHOTO stroje.
function _applyMachineSeverityToViews(machine) {
  if (!machine) return;
  // 1) sesbírat mapu {point_id: severity_id} z bearings[].points[]
  const sevByPoint = {};
  (machine.bearings || []).forEach(b => {
    (b.points || []).forEach(p => {
      if (p && p.id != null) sevByPoint[p.id] = p.severity_id || null;
    });
  });
  if (!Object.keys(sevByPoint).length) return;

  // 2) přepiš STATE.pointSeverity (barvy puntíků v levém stromu)
  if (STATE.pointSeverity) {
    Object.entries(sevByPoint).forEach(([pid, sev]) => {
      STATE.pointSeverity[pid] = sev;
    });
    // překreslit strom, aby se barvy okamžitě promítly
    try { renderTree(); } catch (e) {}
  }

  // 3) přepiš DASH.overview.points[] pro tento stroj (barvy karet strojů)
  const ov = DASH.overview;
  if (ov && Array.isArray(ov.points)) {
    const sevById = DASH.sevById || {};
    ov.points.forEach(p => {
      if (!(p.id in sevByPoint)) return;
      const sev = sevByPoint[p.id] || 1;   // bez limitů/hodnoty počítáme jako Ok
      p.severity_id = sev;
      p.severity_name = sevById[sev]?.name || null;
      p.color = sevById[sev]?.color || null;
    });
  }
}

async function saveMachineConfig() {
  if (MACHINE.id == null) return;
  const cfg = collectMachineConfig();
  try {
    const r = await api(`/api/machine/${MACHINE.id}/config`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cfg),
    });
    MACHINE.overrides = r.overrides || {};
    if (r.machine) {
      MACHINE.data = r.machine;   // sloučená data (platné limity) z backendu
      // aktualizuj barvy puntíků ve stromě i na kartách dashboardu podle
      // nově přepočítaných severity_id u bodů tohoto stroje
      _applyMachineSeverityToViews(r.machine);
    }
    renderMachineCard();                        // překreslit – aktualizuje příznaky z DB/vlastní
    toast("Karta stroje uložena.");
  } catch (e) {
    toast(e.message, true);
  }
}

// ---- modal vyhledání ložiska ----
let _bearingSearchTimer = null;
function openBearingModal(bkey) {
  MACHINE.bearingTargetKey = bkey;
  const modal = document.getElementById("bearing-modal");
  modal.classList.remove("hidden");
  const inp = document.getElementById("bearing-search");
  inp.value = "";
  document.getElementById("bearing-mfg").value = "";
  document.getElementById("bearing-results").innerHTML =
    '<div class="brg-hint">Zadejte označení nebo typ ložiska pro vyhledání (např. 6205, 22310, NU310).</div>';
  ensureBearingManufacturers();
  setTimeout(() => inp.focus(), 50);
}

function closeBearingModal() {
  document.getElementById("bearing-modal").classList.add("hidden");
  MACHINE.bearingTargetKey = null;
}

async function runBearingSearch() {
  const q = document.getElementById("bearing-search").value.trim();
  const mfg = document.getElementById("bearing-mfg").value;
  const box = document.getElementById("bearing-results");
  if (!q && !mfg) {
    box.innerHTML = '<div class="brg-hint">Zadejte označení nebo typ ložiska pro vyhledání.</div>';
    return;
  }
  box.innerHTML = '<div class="spinner"></div>';
  try {
    const r = await api(`/api/bearings/search?q=${encodeURIComponent(q)}&mfg=${encodeURIComponent(mfg)}&limit=60`);
    if (!r.results.length) {
      box.innerHTML = '<div class="brg-hint">Žádné ložisko nenalezeno. Můžete zadat koeficienty ručně.</div>';
      return;
    }
    const rows = r.results.map(b => `
      <tr class="brg-res-row" data-b='${escapeHtml(JSON.stringify(b))}'>
        <td class="brg-res-desig">${escapeHtml(b.designation || "—")}</td>
        <td>${escapeHtml(b.manufacturer || "—")}</td>
        <td class="brg-res-num">${b.FTF != null ? fmtNum(b.FTF, 4) : "—"}</td>
        <td class="brg-res-num">${b.BSF != null ? fmtNum(b.BSF, 4) : "—"}</td>
        <td class="brg-res-num">${b.BPFO != null ? fmtNum(b.BPFO, 4) : "—"}</td>
        <td class="brg-res-num">${b.BPFI != null ? fmtNum(b.BPFI, 4) : "—"}</td>
      </tr>`).join("");
    box.innerHTML = `
      <div class="brg-res-info">Nalezeno ${r.results.length}${r.truncated ? "+ (zobrazeno prvních " + r.results.length + ")" : ""} z ${fmtNum(r.total, 0)} ložisek</div>
      <table class="brg-res-table">
        <thead><tr><th>Označení</th><th>Výrobce</th><th>FTF</th><th>BSF</th><th>BPFO</th><th>BPFI</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
    box.querySelectorAll(".brg-res-row").forEach(tr => {
      tr.addEventListener("click", () => {
        try { applyBearingToBearing(JSON.parse(tr.dataset.b)); } catch (e) {}
      });
    });
  } catch (e) {
    box.innerHTML = `<div class="brg-hint">${escapeHtml(e.message)}</div>`;
  }
}

function applyBearingToBearing(b) {
  const bkey = MACHINE.bearingTargetKey;
  if (bkey == null) return;
  const box = document.querySelector(`.brg-editor[data-bkey="${bkey}"]`);
  if (box) {
    const set = (sel, v) => { const e = box.querySelector(sel); if (e) e.value = (v != null ? v : ""); };
    set(".brg-desig", b.designation || "");
    set(".brg-ftf", b.FTF);
    set(".brg-bsf", b.BSF);
    set(".brg-bpfo", b.BPFO);
    set(".brg-bpfi", b.BPFI);
  }
  closeBearingModal();
  toast("Ložisko přiřazeno: " + (b.designation || ""));
}

// ============================================================
//  VYHODNOCENÍ STROJE POMOCÍ AI (OpenAI)
// ============================================================

// Sestaví <option> pro select norem z katalogu; označí aktuálně vybranou.
function buildNormStdOptions(selStd) {
  const key = (selStd || "").trim();
  const options = NORMS_CATALOG.map(n => {
    const sel = n.standard === key ? " selected" : "";
    const label = n.label || n.standard;
    return `<option value="${escapeHtml(n.standard)}"${sel}>${escapeHtml(label)}</option>`;
  });
  // pokud uživatel má uloženou normu, která v katalogu není, přidej ji jako
  // fallback – ať se staré záznamy nezahodí při prvním otevření karty
  if (key && !NORMS_CATALOG.some(n => n.standard === key)) {
    options.unshift(`<option value="${escapeHtml(key)}" selected>${escapeHtml(key)}</option>`);
  }
  return options.join("");
}

// Sestaví <option> pro select tříd v rámci vybrané normy; zachová uloženou
// třídu, i kdyby ji vybraná norma v katalogu neměla (staré hodnoty).
function buildNormClsOptions(selStd, selCls) {
  const norm = findNorm(selStd);
  const clsKey = (selCls || "").trim();
  const items = (norm && norm.classes) ? norm.classes.slice() : [];
  const opts = items.map(c => {
    const sel = c.machine_class === clsKey ? " selected" : "";
    return `<option value="${escapeHtml(c.machine_class)}"${sel}>${escapeHtml(c.label || c.machine_class)}</option>`;
  });
  if (clsKey && !items.some(c => c.machine_class === clsKey)) {
    opts.unshift(`<option value="${escapeHtml(clsKey)}" selected>${escapeHtml(clsKey)}</option>`);
  }
  return opts.join("");
}

// Sekce "Norma pro hodnocení" na kartě stroje (Základní informace). Uživatel
// zde vybírá normu a třídu stroje, kterou se pak řídí klasifikace rychlosti
// vibrací (ISO RMS) napříč celou aplikací (strom, dashboard, karta stroje,
// AI vyhodnocení). Panel AI vyhodnocení normu jen zobrazuje (read-only) —
// jediné místo úpravy je zde. Seznam norem se čte z NORMS_CATALOG.
function renderNormSection(m) {
  const iso = m.iso_norm || {};
  const mode = (iso.mode === "multi") ? "multi" : "single";
  const selStd = iso.standard || (NORMS_CATALOG[0] && NORMS_CATALOG[0].standard) || "ČSN ISO 20816-3";
  const selCls = iso.machine_class || "";
  const selCustom = iso.custom || "";
  const bearingKeys = (m.bearings || []).map(b => String(b.bearing_key));

  const normSec = document.createElement("div");
  normSec.className = "mp-section";
  const stdOptions = buildNormStdOptions(selStd);
  const clsOptions = buildNormClsOptions(selStd, selCls);
  normSec.innerHTML = `
    <div class="mp-section-title">Norma pro hodnocení rychlosti vibrací</div>
    <div class="mc-norm-mode">
      <label class="ctl-check"><input type="radio" name="mc-norm-mode" value="single"${mode === "single" ? " checked" : ""}/> Jedna norma pro celý stroj</label>
      <label class="ctl-check"><input type="radio" name="mc-norm-mode" value="multi"${mode === "multi" ? " checked" : ""}/> Více norem dle ložisek</label>
    </div>
    <div id="mc-norm-single" class="mc-norm-single${mode === "multi" ? " hidden" : ""}">
      <div class="mc-ai-norm">
        <div class="brg-field">
          <label>Norma</label>
          <select id="mc-ai-std" class="brg-in">${stdOptions}</select>
        </div>
        <div class="brg-field mc-ai-cls">
          <label>Třída stroje</label>
          <select id="mc-ai-cls" class="brg-in">
            <option value="">— vyberte třídu —</option>
            ${clsOptions}
          </select>
        </div>
      </div>
      <div id="mc-ai-limits" class="mc-ai-limits"></div>
    </div>
    <div id="mc-norm-multi" class="mc-norm-multi${mode === "single" ? " hidden" : ""}">
      <div class="mp-lim-hint">Vyberte normu a třídu a zaškrtněte ložiska, která pod ni spadají. Tlačítkem „+ Přidat přiřazení“ lze pod stroj přiřadit více norem.</div>
      <div id="mc-norm-assigns" class="mc-norm-assigns"></div>
      <div class="norm-form-actions">
        <button type="button" id="mc-norm-assign-add" class="cb-btn">+ Přidat přiřazení</button>
      </div>
    </div>
    <div class="brg-field mc-ai-custom-field">
      <label>Vlastní poznámka k normě / dodatečný kontext (nepovinné)</label>
      <input id="mc-ai-custom" class="brg-in" type="text"
             value="${escapeHtml(selCustom)}"
             placeholder="Např. specifické provozní limity, typ stroje, požadavky zákazníka…" />
    </div>
    <div class="mp-lim-hint">Vybraná norma se automaticky propíše do limitu „ISO RMS“ rychlosti vibrací příslušných měřicích bodů (strom, dashboard, karta stroje i AI vyhodnocení).</div>`;

  const clsSel = normSec.querySelector("#mc-ai-cls");
  const stdSel = normSec.querySelector("#mc-ai-std");
  const custInp = normSec.querySelector("#mc-ai-custom");

  // při změně normy přegeneruj select tříd tak, aby obsahoval jen kategorie
  // dané normy; zvolený stav automaticky vyprazdní, když nová norma neobsahuje
  // předchozí třídu (uživatel si musí vybrat novou)
  if (stdSel) stdSel.addEventListener("change", () => {
    const currentCls = clsSel ? clsSel.value : "";
    const newNorm = findNorm(stdSel.value);
    const stillValid = newNorm && (newNorm.classes || []).some(c => c.machine_class === currentCls);
    if (clsSel) {
      clsSel.innerHTML =
        `<option value="">— vyberte třídu —</option>` +
        buildNormClsOptions(stdSel.value, stillValid ? currentCls : "");
    }
    renderNormLimits(clsSel ? clsSel.value : "", normSec.querySelector("#mc-ai-limits"), stdSel.value);
    syncNormReadonlyView();
  });
  if (clsSel) clsSel.addEventListener("change", () => {
    renderNormLimits(clsSel.value, normSec.querySelector("#mc-ai-limits"), stdSel ? stdSel.value : "");
    syncNormReadonlyView();
  });
  if (custInp) custInp.addEventListener("input", syncNormReadonlyView);
  renderNormLimits(selCls, normSec.querySelector("#mc-ai-limits"), selStd);

  // --- režim VÍCE NOREM ---
  const assignsWrap = normSec.querySelector("#mc-norm-assigns");
  const seedAssigns = (mode === "multi" && Array.isArray(iso.assignments) && iso.assignments.length)
    ? iso.assignments : [{ standard: selStd, machine_class: "", bearings: [] }];
  seedAssigns.forEach(a => addNormAssign(assignsWrap, a, bearingKeys));
  const addBtn = normSec.querySelector("#mc-norm-assign-add");
  if (addBtn) addBtn.addEventListener("click", () => addNormAssign(assignsWrap, null, bearingKeys));

  // --- přepínač režimu ---
  normSec.querySelectorAll('input[name="mc-norm-mode"]').forEach(r => {
    r.addEventListener("change", () => {
      const val = normSec.querySelector('input[name="mc-norm-mode"]:checked').value;
      normSec.querySelector("#mc-norm-single").classList.toggle("hidden", val !== "single");
      normSec.querySelector("#mc-norm-multi").classList.toggle("hidden", val !== "multi");
      syncNormReadonlyView();
    });
  });

  return normSec;
}

// Přidá jeden řádek přiřazení (norma + třída + checkboxy ložisek) do kontejneru.
// `data` = {standard, machine_class, bearings:[...]}; `bearingKeys` = seznam L1…
function addNormAssign(wrap, data, bearingKeys) {
  if (!wrap) return;
  const d = data || { standard: (NORMS_CATALOG[0] && NORMS_CATALOG[0].standard) || "", machine_class: "", bearings: [] };
  const chosen = new Set((d.bearings || []).map(b => String(b).toUpperCase()));
  const row = document.createElement("div");
  row.className = "mc-norm-assign";
  const stdOptions = buildNormStdOptions(d.standard || "");
  const clsOptions = buildNormClsOptions(d.standard || "", d.machine_class || "");
  const brgChecks = (bearingKeys && bearingKeys.length)
    ? bearingKeys.map(bk => {
        const on = chosen.has(String(bk).toUpperCase()) ? " checked" : "";
        return `<label class="ctl-check mc-brg-check"><input type="checkbox" class="na-brg" value="${escapeHtml(bk)}"${on}/> ${escapeHtml(bk)}</label>`;
      }).join("")
    : `<span class="mp-lim-hint">Stroj nemá načtená žádná ložiska.</span>`;
  row.innerHTML =
    `<div class="mc-norm-assign-grid">` +
      `<div class="brg-field"><label>Norma</label>` +
        `<select class="brg-in na-std">${stdOptions}</select></div>` +
      `<div class="brg-field"><label>Třída stroje</label>` +
        `<select class="brg-in na-cls"><option value="">— vyberte třídu —</option>${clsOptions}</select></div>` +
      `<button type="button" class="norm-row-del na-del" title="Odebrat přiřazení">×</button>` +
    `</div>` +
    `<div class="mc-norm-assign-brgs"><span class="na-brgs-title">Ložiska:</span> ${brgChecks}</div>` +
    `<div class="na-limits mc-ai-limits"></div>`;
  wrap.appendChild(row);

  const stdSel = row.querySelector(".na-std");
  const clsSel = row.querySelector(".na-cls");
  const limBox = row.querySelector(".na-limits");
  const refreshLim = () => renderNormLimits(clsSel.value, limBox, stdSel.value);
  stdSel.addEventListener("change", () => {
    const cur = clsSel.value;
    const nn = findNorm(stdSel.value);
    const ok = nn && (nn.classes || []).some(c => c.machine_class === cur);
    clsSel.innerHTML = `<option value="">— vyberte třídu —</option>` + buildNormClsOptions(stdSel.value, ok ? cur : "");
    refreshLim();
  });
  clsSel.addEventListener("change", refreshLim);
  const delBtn = row.querySelector(".na-del");
  if (delBtn) delBtn.addEventListener("click", () => {
    const rows = wrap.querySelectorAll(".mc-norm-assign");
    if (rows.length > 1) row.remove();
    else {
      clsSel.value = "";
      row.querySelectorAll(".na-brg").forEach(cb => { cb.checked = false; });
      refreshLim();
    }
  });
  refreshLim();
}

// Přepíše read-only zobrazení normy v panelu AI aktuálními (i neuloženými)
// hodnotami ze "Základní informace o stroji", aby oba pohledy byly vždy
// synchronní i před uložením karty stroje.
function syncNormReadonlyView() {
  const view = document.querySelector(".mc-ai-norm-view");
  if (!view) return;
  const cust = document.getElementById("mc-ai-custom");
  const customVal = cust ? cust.value.trim() : "";
  const limitsView = document.getElementById("mc-ai-limits-view");

  const modeEl = document.querySelector('input[name="mc-norm-mode"]:checked');
  const mode = modeEl ? modeEl.value : "single";

  if (mode === "multi") {
    // souhrn přiřazení norem k ložiskům
    const rows = Array.from(document.querySelectorAll(".mc-norm-assign"));
    const parts = [];
    rows.forEach(r => {
      const s = r.querySelector(".na-std");
      const c = r.querySelector(".na-cls");
      const std = s ? s.value : "";
      const clsv = c ? c.value : "";
      const bearings = Array.from(r.querySelectorAll(".na-brg"))
        .filter(cb => cb.checked).map(cb => cb.value);
      if (std && clsv && bearings.length) {
        const nr = findNorm(std);
        const nl = (nr && nr.label) ? nr.label : std;
        parts.push(`<div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">${escapeHtml(bearings.join(", "))}:</span> ${escapeHtml(nl)} – tř. ${escapeHtml(clsv)}</div>`);
      }
    });
    view.innerHTML =
      `<div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">Režim:</span> Více norem dle ložisek</div>` +
      (parts.length ? parts.join("") : `<div class="mc-ai-norm-view-row">— zatím bez přiřazení —</div>`) +
      (customVal ? `<div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">Poznámka:</span> ${escapeHtml(customVal)}</div>` : "");
    if (limitsView) limitsView.innerHTML = "";
    return;
  }

  const std = document.getElementById("mc-ai-std");
  const cls = document.getElementById("mc-ai-cls");
  const stdVal = std ? std.value : "";
  const norm = findNorm(stdVal);
  const normLabel = (norm && norm.label) ? norm.label : (stdVal || "—");
  const clsLabel = (cls && cls.value) ? cls.value : "— nevybráno —";
  view.innerHTML = `
      <div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">Norma:</span> ${escapeHtml(normLabel)}</div>
      <div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">Třída stroje:</span> ${escapeHtml(clsLabel)}</div>
      ${customVal ? `<div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">Poznámka:</span> ${escapeHtml(customVal)}</div>` : ""}`;
  if (limitsView) renderNormLimits(cls ? cls.value : "", limitsView, stdVal);
}

// Panel "Vyhodnocení pomocí AI": výběr normy, tlačítko, zobrazení výsledku.
function renderAiPanel(m) {
  const panel = document.createElement("div");
  panel.className = "mp-panel mc-ai";

  const iso = m.iso_norm || {};
  const selStd = iso.standard || (NORMS_CATALOG[0] && NORMS_CATALOG[0].standard) || "ČSN ISO 20816-3";
  const selCls = iso.machine_class || "";
  const selCustom = iso.custom || "";

  const head = document.createElement("div");
  head.className = "mp-head";
  head.innerHTML =
    `<span class="mp-name">Vyhodnocení pomocí AI</span>` +
    `<span class="mp-src mc-ai-badge" id="mc-ai-badge">senior vibrační diagnostik</span>`;
  panel.appendChild(head);

  // --- norma pro hodnocení (read-only zde; úprava jen v "Základní informace o stroji") ---
  const normSec = document.createElement("div");
  normSec.className = "mp-section";
  const normRec = findNorm(selStd);
  const normLabel = (normRec && normRec.label) ? normRec.label : (selStd || "—");
  const clsLabel = selCls || "— nevybráno —";
  normSec.innerHTML = `
    <div class="mp-section-title">Norma pro hodnocení rychlosti vibrací</div>
    <div class="mc-ai-norm-view">
      <div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">Norma:</span> ${escapeHtml(normLabel)}</div>
      <div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">Třída stroje:</span> ${escapeHtml(clsLabel)}</div>
      ${selCustom ? `<div class="mc-ai-norm-view-row"><span class="mc-ai-norm-view-label">Poznámka:</span> ${escapeHtml(selCustom)}</div>` : ""}
    </div>
    <div id="mc-ai-limits-view" class="mc-ai-limits"></div>
    <div class="mp-lim-hint">Norma se nastavuje v záložce „Základní informace o stroji“.</div>`;
  panel.appendChild(normSec);
  renderNormLimits(selCls, normSec.querySelector("#mc-ai-limits-view"), selStd);
  // synchronizuj hned se zivymi (i neulozenymi) hodnotami ze Zakladnich informaci
  syncNormReadonlyView();

  const hint = document.createElement("div");
  hint.className = "mp-lim-hint";
  hint.innerHTML =
    "AI vystupuje jako <strong>senior vibrační diagnostik</strong>. Vyhodnotí poslední měření " +
    "a krátký trend všech bodů, porovná hodnoty s nastavenými limity a rychlost vibrací " +
    "s vybranou normou. Použijí se <strong>aktuální otáčky</strong> z pole výše (nebo z databáze). " +
    "Volání AI využívá zvolený model (OpenAI / Claude) a spotřebovává kredity. Norma se uloží společně s kartou stroje.";
  panel.appendChild(hint);

  // --- výběr modelu + tlačítko spuštění ---
  const actRow = document.createElement("div");
  actRow.className = "mp-section mc-ai-actions";

  // sestav <option> pro dostupné modely; nedostupné (chybí klíč) zakázat
  const modelOpts = (AI_CONF.models || []).map(md => {
    const avail = (md.provider === "anthropic" || md.provider === "anthropic_agent") ? AI_CONF.has_anthropic_key : AI_CONF.has_openai_key;
    const sel = md.id === AI_CONF.model ? " selected" : "";
    const dis = avail ? "" : " disabled";
    const suffix = avail ? "" : " — chybí API klíč";
    return `<option value="${escapeHtml(md.id)}"${sel}${dis}>${escapeHtml(md.label)}${suffix}</option>`;
  }).join("");

  actRow.innerHTML = `
    <div class="mc-ai-model-field">
      <label for="mc-ai-model">Model AI</label>
      <select id="mc-ai-model" class="cb-input">${modelOpts || '<option value="">(žádné modely)</option>'}</select>
    </div>
    <button id="mc-ai-run" class="cb-btn cb-primary">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" style="vertical-align:-3px;margin-right:6px"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15l-1.9-4.1L5.5 9l4.6-1.4z"/><path d="M18 14l.9 2.2L21 17l-2.1.8L18 20l-.9-2.2L15 17l2.1-.8z"/></svg>
      Vyhodnotit pomocí AI
    </button>
    <span id="mc-ai-status" class="mc-ai-status"></span>`;
  panel.appendChild(actRow);

  // --- výsledek ---
  const resBox = document.createElement("div");
  resBox.className = "mc-ai-result";
  resBox.id = "mc-ai-result";
  panel.appendChild(resBox);

  // --- historie vyhodnocení ---
  const histBox = document.createElement("div");
  histBox.className = "mc-ai-history";
  histBox.id = "mc-ai-history";
  panel.appendChild(histBox);

  actRow.querySelector("#mc-ai-run").addEventListener("click", runAiEval);

  // vykresli stávající uložený výsledek a historii (pokud existují)
  renderAiResult(m.ai_eval || null, resBox);
  renderAiHistory(m.ai_eval_history || [], histBox);
  return panel;
}


// ====================== CHAT S AI DIAGNOSTIKEM ======================
// Záložka na kartě stroje, kde uživatel vede dialog s AI agentem, který
// má k dispozici kompletní podklady stroje (poslední měření, trend, FFT,
// ložiska, otáčky, norma a obrázek stroje). Backend přidává tyto podklady
// jako úvodní kontext (bod A – plný kontext předem), frontend posílá pouze
// historii zpráv user/assistant.

function renderChatPanel(m) {
  const panel = document.createElement("div");
  panel.className = "mp-panel mc-chat";

  const head = document.createElement("div");
  head.className = "mp-head";
  head.innerHTML =
    `<span class="mp-name">Chat s diagnostikem</span>` +
    `<span class="mp-src mc-ai-badge">senior vibrační diagnostik</span>`;
  panel.appendChild(head);

  const hint = document.createElement("div");
  hint.className = "mp-lim-hint";
  hint.innerHTML =
    "Veďte dialog s AI, která má k dispozici <strong>kompletní podklady tohoto stroje</strong> " +
    "(poslední měření a trend všech bodů, FFT špičky, ložiska, otáčky, normu i obrázek stroje). " +
    "Ptejte se na pravděpodobné příčiny, doporučení k údržbě, interpretaci spekter apod. " +
    "Použijí se <strong>aktuální otáčky</strong> a <strong>norma</strong> ze záložky " +
    "„Vyhodnocení pomocí AI“. Každý dotaz využívá zvolený model a spotřebovává kredity. " +
    "Historie chatu se neukládá – po opuštění stroje se vymaže.";
  panel.appendChild(hint);

  // výběr modelu (sdílí seznam modelů s vyhodnocením)
  const modelOpts = (AI_CONF.models || []).map(md => {
    const avail = (md.provider === "anthropic" || md.provider === "anthropic_agent") ? AI_CONF.has_anthropic_key : AI_CONF.has_openai_key;
    const sel = md.id === AI_CONF.model ? " selected" : "";
    const dis = avail ? "" : " disabled";
    const suffix = avail ? "" : " — chybí API klíč";
    return `<option value="${escapeHtml(md.id)}"${sel}${dis}>${escapeHtml(md.label)}${suffix}</option>`;
  }).join("");

  const toolbar = document.createElement("div");
  toolbar.className = "mc-chat-toolbar";
  toolbar.innerHTML = `
    <div class="mc-ai-model-field">
      <label for="mc-chat-model">Model AI</label>
      <select id="mc-chat-model" class="cb-input">${modelOpts || '<option value="">(žádné modely)</option>'}</select>
    </div>
    <button id="mc-chat-clear" class="cb-btn cb-ghost" type="button">Vymazat konverzaci</button>`;
  panel.appendChild(toolbar);

  // okno s historií zpráv
  const log = document.createElement("div");
  log.className = "mc-chat-log";
  log.id = "mc-chat-log";
  panel.appendChild(log);

  // vstupní řádek
  const inputRow = document.createElement("div");
  inputRow.className = "mc-chat-inputrow";
  inputRow.innerHTML = `
    <textarea id="mc-chat-input" class="mc-chat-input" rows="2"
      placeholder="Napište dotaz k stavu stroje… (Enter odešle, Shift+Enter nový řádek)"></textarea>
    <button id="mc-chat-send" class="cb-btn cb-primary mc-chat-send" type="button">
      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:-3px"><path d="M4 12l16-8-6 8 6 8z"/></svg>
      Odeslat
    </button>`;
  panel.appendChild(inputRow);

  const status = document.createElement("div");
  status.className = "mc-chat-status";
  status.id = "mc-chat-status";
  panel.appendChild(status);

  // vykresli stávající historii (pokud uživatel přepnul záložku a zpět)
  renderChatLog(log);

  // wiring
  const sendBtn = inputRow.querySelector("#mc-chat-send");
  const inputEl = inputRow.querySelector("#mc-chat-input");
  if (sendBtn) sendBtn.addEventListener("click", sendChatMessage);
  if (inputEl) inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendChatMessage();
    }
  });
  const clearBtn = toolbar.querySelector("#mc-chat-clear");
  if (clearBtn) clearBtn.addEventListener("click", () => {
    MACHINE.chatHistory = [];
    renderChatLog(document.getElementById("mc-chat-log"));
    const st = document.getElementById("mc-chat-status");
    if (st) { st.textContent = ""; st.className = "mc-chat-status"; }
  });

  return panel;
}

// Vykreslí celou historii chatu do okna se zprávami.
function renderChatLog(logEl) {
  const log = logEl || document.getElementById("mc-chat-log");
  if (!log) return;
  log.innerHTML = "";
  const hist = MACHINE.chatHistory || [];
  if (!hist.length) {
    log.innerHTML =
      '<div class="mc-chat-empty">Zatím žádné zprávy. Zeptejte se např.: ' +
      '„Jaký je celkový stav stroje?“ nebo „Co může způsobovat zvýšené hodnoty na ložisku L1?“</div>';
    return;
  }
  hist.forEach(msg => {
    const row = document.createElement("div");
    row.className = "mc-chat-msg " + (msg.role === "user" ? "mc-chat-user" : "mc-chat-assistant");
    const who = document.createElement("div");
    who.className = "mc-chat-who";
    who.textContent = msg.role === "user" ? "Vy" : "Diagnostik (AI)";
    const bubble = document.createElement("div");
    bubble.className = "mc-chat-bubble";
    bubble.textContent = msg.content;
    row.appendChild(who);
    row.appendChild(bubble);
    log.appendChild(row);
  });
  // odroluj na konec
  log.scrollTop = log.scrollHeight;
}

// Odešle dotaz uživatele AI diagnostikovi a zobrazí odpověď.
async function sendChatMessage() {
  if (MACHINE.id == null) return;
  const inputEl = document.getElementById("mc-chat-input");
  const sendBtn = document.getElementById("mc-chat-send");
  const statusEl = document.getElementById("mc-chat-status");
  const log = document.getElementById("mc-chat-log");
  if (!inputEl) return;
  const text = (inputEl.value || "").trim();
  if (!text) return;

  // otáčky + norma ze záložky AI (nebo z DB na backendu)
  let speed_hz = null;
  const spInp = document.getElementById("mc-speed-input");
  if (spInp && spInp.value !== "") {
    const v = parseFloat(spInp.value);
    if (isFinite(v) && v > 0) speed_hz = v;
  }
  const iso_norm = collectIsoNorm();

  // model: z roletky chatu, jinak z roletky AI vyhodnocení, jinak výchozí
  let model = null;
  const mdlSel = document.getElementById("mc-chat-model") || document.getElementById("mc-ai-model");
  if (mdlSel && mdlSel.value) model = mdlSel.value;

  // přidej dotaz do historie a překresli
  MACHINE.chatHistory.push({ role: "user", content: text });
  inputEl.value = "";
  renderChatLog(log);

  if (sendBtn) sendBtn.disabled = true;
  if (statusEl) { statusEl.textContent = "Diagnostik přemýšlí… (může trvat několik sekund)"; statusEl.className = "mc-chat-status busy"; }

  try {
    const r = await api(`/api/machine/${MACHINE.id}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: MACHINE.chatHistory,
        speed_hz, iso_norm, model,
      }),
    });
    const reply = (r && r.reply) ? r.reply : "";
    if (reply) {
      MACHINE.chatHistory.push({ role: "assistant", content: reply });
      renderChatLog(log);
      if (statusEl) {
        statusEl.textContent = r.model ? ("Model: " + r.model) : "";
        statusEl.className = "mc-chat-status ok";
      }
    } else {
      if (statusEl) { statusEl.textContent = "AI nevrátila žádnou odpověď."; statusEl.className = "mc-chat-status err"; }
    }
  } catch (e) {
    const msg = e.message || "Odeslání selhalo.";
    // odeber neúspěšný dotaz z historie, ať jej může uživatel zopakovat
    if (MACHINE.chatHistory.length && MACHINE.chatHistory[MACHINE.chatHistory.length - 1].role === "user") {
      MACHINE.chatHistory.pop();
    }
    renderChatLog(log);
    if (inputEl) inputEl.value = text;
    if (statusEl) { statusEl.textContent = "Chyba: " + msg; statusEl.className = "mc-chat-status err"; }
    toast(msg, true);
  } finally {
    if (sendBtn) sendBtn.disabled = false;
    if (inputEl) inputEl.focus();
  }
}
// ==================== KONEC CHAT S AI DIAGNOSTIKEM ====================

// Vykreslí orientační limity dle zvolené normy a třídy stroje.
// Pokud je třída nastavena, limity se automaticky propíšou do ISO RMS limitu
// každého měřicího bodu (řeší backend při uložení karty / čtení dat).
// Parametr `standard` je nepovinný – když není předán, limity se hledají
// napříč katalogem (pro zpětnou kompatibilitu).
function renderNormLimits(machineClass, boxEl, standard) {
  const box = boxEl || document.getElementById("mc-ai-limits");
  if (!box) return;
  box.innerHTML = "";
  const lim = normLimitsFor(standard, machineClass);
  if (!lim) {
    box.innerHTML =
      '<div class="mc-ai-limits-empty">Vyberte třídu stroje pro zobrazení limitů rychlosti vibrací dle normy.</div>';
    return;
  }
  const norm = findNorm(standard);
  const normName = (norm && norm.label) ? norm.label : (standard || "norma");
  box.innerHTML = `
    <div class="mc-ai-limits-title">Limity rychlosti vibrací dle normy (${escapeHtml(normName)})</div>
    <div class="mc-ai-limits-row">
      <span class="mc-lim-pill mc-lim-warn">Varování: ${fmtNum(lim.warning, 2)} mm/s RMS</span>
      <span class="mc-lim-pill mc-lim-alarm">Alarm: ${fmtNum(lim.alarm, 2)} mm/s RMS</span>
    </div>
    <div class="mc-ai-limits-note">Tyto limity se automaticky propíšou do limitu „ISO RMS“ rychlosti vibrací každého měřicího bodu.</div>`;
}

// Vykreslí historii AI vyhodnocení s možností zpětného vyvolání.
function renderAiHistory(history, boxEl) {
  const box = boxEl || document.getElementById("mc-ai-history");
  if (!box) return;
  box.innerHTML = "";
  const list = Array.isArray(history) ? history : [];
  if (!list.length) {
    return; // bez historie nic nezobrazujeme
  }
  const activeText = (MACHINE.data && MACHINE.data.ai_eval && MACHINE.data.ai_eval.text) || null;

  const head = document.createElement("div");
  head.className = "mc-ai-history-head";
  head.textContent = `Historie vyhodnocení (${list.length})`;
  box.appendChild(head);

  const ul = document.createElement("div");
  ul.className = "mc-ai-history-list";
  list.forEach((ev, idx) => {
    const isActive = activeText != null && ev && ev.text === activeText;
    const item = document.createElement("div");
    item.className = "mc-ai-history-item" + (isActive ? " active" : "");

    const tags = [];
    tags.push(`<span class="mc-ai-hi-meta">${escapeHtml(fmtDate(ev.time))}</span>`);
    if (ev.model) tags.push(`<span class="mc-ai-hi-meta">${escapeHtml(ev.model)}</span>`);
    if (ev.norm) tags.push(`<span class="mc-ai-hi-meta">${escapeHtml(ev.norm)}</span>`);
    if (ev.edited) tags.push(`<span class="mc-ai-hi-meta">ručně upraveno</span>`);

    const preview = (ev.text || "").replace(/\s+/g, " ").trim().slice(0, 90);
    const previewSuffix = (ev.text || "").length > 90 ? "…" : "";

    item.innerHTML = `
      <div class="mc-ai-hi-tags">${tags.join("")}</div>
      <div class="mc-ai-hi-prev">${escapeHtml(preview)}${previewSuffix}</div>
      <button class="cb-btn cb-ghost mc-ai-hi-recall" data-idx="${idx}" ${isActive ? "disabled" : ""}>${isActive ? "Zobrazeno" : "Zobrazit"}</button>`;
    item.querySelector(".mc-ai-hi-recall").addEventListener("click", () => recallAiEval(idx));
    ul.appendChild(item);
  });
  box.appendChild(ul);
}

// Zpětně vyvolá vybrané vyhodnocení z historie a nastaví jej jako aktivní.
async function recallAiEval(index) {
  if (MACHINE.id == null) return;
  try {
    const r = await api(`/api/machine/${MACHINE.id}/ai-eval/recall`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ index }),
    });
    if (r && r.ai_eval) {
      if (MACHINE.data) {
        MACHINE.data.ai_eval = r.ai_eval;
        if (r.ai_eval_history) MACHINE.data.ai_eval_history = r.ai_eval_history;
      }
      renderAiResult(r.ai_eval, document.getElementById("mc-ai-result"));
      renderAiHistory((MACHINE.data && MACHINE.data.ai_eval_history) || [], document.getElementById("mc-ai-history"));
      toast("Vyhodnocení bylo vyvoláno z historie.");
    }
  } catch (e) {
    toast(e.message || "Vyvolání vyhodnocení selhalo.", true);
  }
}

// Sebere zvolenou normu z AI panelu (vrací objekt nebo null).
function collectIsoNorm() {
  const std = document.getElementById("mc-ai-std");
  const cls = document.getElementById("mc-ai-cls");
  const cust = document.getElementById("mc-ai-custom");
  const custom = cust ? cust.value.trim() : "";

  // zjištění režimu (radio přepínač); pokud chybí, ber jako "single"
  const modeEl = document.querySelector('input[name="mc-norm-mode"]:checked');
  const mode = modeEl ? modeEl.value : "single";

  if (mode === "multi") {
    const rows = Array.from(document.querySelectorAll(".mc-norm-assign"));
    const assignments = [];
    rows.forEach(r => {
      const s = r.querySelector(".na-std");
      const c = r.querySelector(".na-cls");
      const bearings = Array.from(r.querySelectorAll(".na-brg"))
        .filter(cb => cb.checked)
        .map(cb => String(cb.value).trim().toUpperCase())
        .filter(Boolean);
      const standard = s ? s.value.trim() : "";
      const machine_class = c ? c.value.trim() : "";
      // řádek má smysl jen když je vybraná třída a alespoň jedno ložisko
      if (standard && machine_class && bearings.length) {
        assignments.push({ standard, machine_class, bearings });
      }
    });
    if (!assignments.length && !custom) return null;
    const obj = { mode: "multi", assignments };
    if (custom) obj.custom = custom;
    return obj;
  }

  // režim JEDNA NORMA (výchozí, zpětně kompatibilní)
  if (!std && !cls && !cust) return null;
  const obj = {
    mode: "single",
    standard: std ? std.value.trim() : "",
    machine_class: cls ? cls.value.trim() : "",
    custom: custom,
  };
  if (!obj.standard && !obj.machine_class && !obj.custom) return null;
  return obj;
}

// Spustí AI vyhodnocení stroje.
async function runAiEval() {
  if (MACHINE.id == null) return;
  const btn = document.getElementById("mc-ai-run");
  const statusEl = document.getElementById("mc-ai-status");
  const resBox = document.getElementById("mc-ai-result");

  // aktuální otáčky z pole (prázdné = backend použije hodnotu z DB)
  let speed_hz = null;
  const spInp = document.getElementById("mc-speed-input");
  if (spInp && spInp.value !== "") {
    const v = parseFloat(spInp.value);
    if (isFinite(v) && v > 0) speed_hz = v;
  }
  const iso_norm = collectIsoNorm();

  // zvolený model AI (z roletky); prázdné = backend použije výchozí model
  let model = null;
  const mdlSel = document.getElementById("mc-ai-model");
  if (mdlSel && mdlSel.value) model = mdlSel.value;

  if (btn) { btn.disabled = true; }
  if (statusEl) { statusEl.textContent = "AI vyhodnocuje data stroje… (může trvat několik sekund)"; statusEl.className = "mc-ai-status busy"; }
  if (resBox) { resBox.innerHTML = '<div class="spinner"></div>'; }

  try {
    const r = await api(`/api/machine/${MACHINE.id}/ai-eval`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ speed_hz, iso_norm, model, save: true }),
    });
    if (r && r.ai_eval) {
      if (MACHINE.data) {
        MACHINE.data.ai_eval = r.ai_eval;
        if (r.ai_eval_history) MACHINE.data.ai_eval_history = r.ai_eval_history;
      }
      renderAiResult(r.ai_eval, resBox);
      renderAiHistory((MACHINE.data && MACHINE.data.ai_eval_history) || [], document.getElementById("mc-ai-history"));
      if (statusEl) { statusEl.textContent = "Vyhodnocení dokončeno a uloženo."; statusEl.className = "mc-ai-status ok"; }
      toast("AI vyhodnocení dokončeno a uloženo na kartu stroje.");
    } else {
      if (statusEl) { statusEl.textContent = "AI nevrátila žádný výsledek."; statusEl.className = "mc-ai-status err"; }
    }
  } catch (e) {
    const msg = e.message || "Vyhodnocení selhalo.";
    if (resBox) resBox.innerHTML = `<div class="mc-ai-error">${escapeHtml(msg)}</div>`;
    if (statusEl) { statusEl.textContent = "Chyba při volání AI."; statusEl.className = "mc-ai-status err"; }
    toast(msg, true);
  } finally {
    if (btn) { btn.disabled = false; }
  }
}

// Vykreslí uložený / vrácený výsledek AI s možností editace.
function renderAiResult(ev, boxEl) {
  const box = boxEl || document.getElementById("mc-ai-result");
  if (!box) return;
  box.innerHTML = "";
  if (!ev || !ev.text) {
    box.innerHTML = `<div class="mc-ai-empty">Zatím bez vyhodnocení. Vyberte třídu stroje a klikněte na „Vyhodnotit pomocí AI“.</div>`;
    return;
  }

  const meta = document.createElement("div");
  meta.className = "mc-ai-meta";
  const parts = [];
  parts.push(`<span class="mc-ai-mtag">Vyhodnoceno: ${escapeHtml(fmtDate(ev.time))}</span>`);
  if (ev.speed_hz != null) parts.push(`<span class="mc-ai-mtag">Otáčky: ${fmtNum(ev.speed_hz, 2)} Hz</span>`);
  if (ev.norm) parts.push(`<span class="mc-ai-mtag">Norma: ${escapeHtml(ev.norm)}</span>`);
  if (ev.model) parts.push(`<span class="mc-ai-mtag">Model: ${escapeHtml(ev.model)}</span>`);
  if (ev.edited) parts.push(`<span class="mc-ai-mtag mc-ai-edited">ručně upraveno</span>`);
  meta.innerHTML = parts.join("");
  box.appendChild(meta);

  // textový výsledek (zobrazení)
  const view = document.createElement("div");
  view.className = "mc-ai-text";
  view.id = "mc-ai-text-view";
  view.textContent = ev.text;
  box.appendChild(view);

  // ovládací tlačítka
  const tools = document.createElement("div");
  tools.className = "mc-ai-tools";
  tools.innerHTML = `
    <button id="mc-ai-edit" class="cb-btn cb-ghost">Upravit závěr</button>`;
  box.appendChild(tools);

  // editor (skrytý)
  const editor = document.createElement("div");
  editor.className = "mc-ai-editor hidden";
  editor.id = "mc-ai-editor";
  editor.innerHTML = `
    <textarea id="mc-ai-textarea" class="mc-ai-textarea" rows="14"></textarea>
    <div class="mc-ai-editor-actions">
      <button id="mc-ai-save" class="cb-btn cb-primary">Uložit úpravy</button>
      <button id="mc-ai-cancel" class="cb-btn cb-ghost">Zrušit</button>
    </div>`;
  box.appendChild(editor);

  // store current eval for save
  box._aiEval = ev;

  tools.querySelector("#mc-ai-edit").addEventListener("click", () => {
    const ta = document.getElementById("mc-ai-textarea");
    ta.value = ev.text;
    editor.classList.remove("hidden");
    view.classList.add("hidden");
    tools.classList.add("hidden");
    ta.focus();
  });
  editor.querySelector("#mc-ai-cancel").addEventListener("click", () => {
    editor.classList.add("hidden");
    view.classList.remove("hidden");
    tools.classList.remove("hidden");
  });
  editor.querySelector("#mc-ai-save").addEventListener("click", () => saveAiEdit(box));
}

// Uloží ručně upravený text závěru AI.
async function saveAiEdit(box) {
  if (MACHINE.id == null) return;
  const ev = box._aiEval || {};
  const ta = document.getElementById("mc-ai-textarea");
  const newText = ta ? ta.value : "";
  const saveBtn = document.getElementById("mc-ai-save");
  if (saveBtn) saveBtn.disabled = true;
  try {
    const r = await api(`/api/machine/${MACHINE.id}/ai-eval/save`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: newText,
        time: ev.time || null,
        speed_hz: ev.speed_hz != null ? ev.speed_hz : null,
        norm: ev.norm || null,
        model: ev.model || null,
      }),
    });
    if (r && r.ai_eval) {
      if (MACHINE.data) MACHINE.data.ai_eval = r.ai_eval;
      renderAiResult(r.ai_eval, box);
      toast("Úpravy závěru uloženy.");
    }
  } catch (e) {
    toast(e.message || "Uložení úprav selhalo.", true);
  } finally {
    if (saveBtn) saveBtn.disabled = false;
  }
}

// ---- značky poruchových frekvencí z PŘIŘAZENÉHO ložiska ----
// vrací stejný formát jako faultMarkers(): [{f, label}]
function assignedBearingMarkers(bearing, base, xmax) {
  if (!bearing || !base || base <= 0) return [];
  const out = [];
  const defs = [["BPFO", bearing.BPFO], ["BPFI", bearing.BPFI], ["BSF", bearing.BSF], ["FTF", bearing.FTF]];
  defs.forEach(([lbl, k]) => {
    if (k == null || !isFinite(k) || k <= 0) return;
    for (let h = 1; h <= 3; h++) {
      const f = base * k * h;
      if (xmax != null && f > xmax) break;
      out.push({ f, label: h === 1 ? lbl : `${lbl}·${h}` });
    }
  });
  return out;
}


// ---------- views ----------
// ====================== PŘEPÍNATELNÉ PANELY (bod / protokol / stroj) ======================
// Nad hlavním obsahem je pruh otevřených panelů. Každý panel odpovídá jednomu
// pohledu (měřicí bod, tvorba protokolu, karta stroje). Mezi panely lze
// přepínat kliknutím nebo klávesami Ctrl+Tab / Ctrl+Shift+Tab (a Ctrl+1/2/3).
//
// Pohledy (view-point/view-machine/view-report) jsou v DOM jedináčci, proto si
// každý panel pamatuje, JAK se má znovu otevřít (funkce reopen), a při aktivaci
// se pohled znovu vykreslí. To využívá stávající funkce selectPoint/openMachine/
// openReport a je to spolehlivé i offline.
const PANELS = {
  list: [],        // [{ key, type, id, title, reopen }]
  active: null,    // key aktivního panelu
  _switching: false,
};

// Typy panelů, které mají být jen v jedné (sdílené) záložce – otevření
// jiného stroje/bodu přepoužije stejnou záložku místo přidávání dalších.
const SINGLETON_PANELS = new Set(["machine", "point"]);

// Vytvoří jednoznačný klíč panelu (typ + id).
// U singletonových typů (stroj, měřicí bod) je klíč jen typ – vždy jedna záložka.
function panelKey(type, id) {
  if (SINGLETON_PANELS.has(type)) return type;
  return id != null ? `${type}:${id}` : type;
}

// Otevře panel daného typu (nebo ho aktivuje, pokud už existuje).
// reopen = funkce, která znovu vykreslí příslušný pohled.
function openPanel(type, id, title, reopen) {
  const key = panelKey(type, id);
  let p = PANELS.list.find(x => x.key === key);
  if (!p) {
    p = { key, type, id, title, reopen };
    PANELS.list.push(p);
  } else {
    // aktualizuj id (u singletonových panelů jde o jiný stroj/bod), titulek i reopen
    p.id = id;
    p.title = title;
    p.reopen = reopen;
  }
  PANELS.active = key;
  renderPanelTabbar();
}

// Aktivuje existující panel podle klíče – znovu vykreslí jeho pohled.
async function activatePanel(key) {
  const p = PANELS.list.find(x => x.key === key);
  if (!p) return;
  PANELS.active = key;
  PANELS._switching = true;
  try {
    await p.reopen();
  } catch (e) {
    /* tichá chyba – reopen si chyby řeší sám */
  }
  PANELS._switching = false;
  renderPanelTabbar();
}

// Zavře panel. Pokud byl aktivní, aktivuje se sousední (nebo dashboard).
async function closePanel(key) {
  const idx = PANELS.list.findIndex(x => x.key === key);
  if (idx === -1) return;
  const wasActive = PANELS.active === key;
  PANELS.list.splice(idx, 1);
  if (wasActive) {
    if (PANELS.list.length) {
      const next = PANELS.list[Math.min(idx, PANELS.list.length - 1)];
      await activatePanel(next.key);
      return;
    } else {
      PANELS.active = null;
      showView("dashboard");
      // překresli mřížku strojů podle aktuálního DASH.overview – pokud uživatel
      // uložil kartu stroje, jsou barvy puntíků již lokálně aktualizované
      // (viz _applyMachineSeverityToViews)
      try { if (DASH.overview) paintDashboard(); } catch (e) {}
    }
  }
  renderPanelTabbar();
}

// Přepnutí na další / předchozí panel (cyklicky) – pro Ctrl+Tab.
function cyclePanel(dir) {
  if (PANELS.list.length < 2) return;
  let i = PANELS.list.findIndex(x => x.key === PANELS.active);
  if (i === -1) i = 0;
  const n = PANELS.list.length;
  const j = ((i + dir) % n + n) % n;
  activatePanel(PANELS.list[j].key);
}

// Vykreslí pruh záložek panelů.
function renderPanelTabbar() {
  const bar = document.getElementById("panel-tabbar");
  if (!bar) return;
  bar.innerHTML = "";
  if (!PANELS.list.length) {
    bar.classList.add("hidden");
    return;
  }
  bar.classList.remove("hidden");
  const icons = { point: "◉", machine: "▤", report: "🗎" };
  PANELS.list.forEach((p, i) => {
    const tab = document.createElement("div");
    tab.className = "panel-tab" + (p.key === PANELS.active ? " active" : "");
    tab.setAttribute("role", "tab");
    tab.title = `${p.title}  (Ctrl+${i + 1})`;
    const ico = document.createElement("span");
    ico.className = "panel-tab-ico";
    ico.textContent = icons[p.type] || "•";
    const lbl = document.createElement("span");
    lbl.className = "panel-tab-label";
    lbl.textContent = p.title;
    const close = document.createElement("button");
    close.type = "button";
    close.className = "panel-tab-close";
    close.textContent = "×";
    close.title = "Zavřít panel";
    close.addEventListener("click", (e) => { e.stopPropagation(); closePanel(p.key); });
    tab.appendChild(ico);
    tab.appendChild(lbl);
    tab.appendChild(close);
    tab.addEventListener("click", () => activatePanel(p.key));
    // prostřední tlačítko myši = zavřít
    tab.addEventListener("mousedown", (e) => {
      if (e.button === 1) { e.preventDefault(); closePanel(p.key); }
    });
    bar.appendChild(tab);
  });
}

// Klávesové zkratky pro přepínání panelů.
function initPanelHotkeys() {
  document.addEventListener("keydown", (e) => {
    // ignoruj, pokud uživatel píše do vstupního pole (kromě čistého přepnutí)
    if (e.ctrlKey && e.key === "Tab") {
      e.preventDefault();
      cyclePanel(e.shiftKey ? -1 : 1);
      return;
    }
    // Ctrl+1..9 = přímý výběr panelu (nekoliduje s běžným psaním)
    if (e.ctrlKey && !e.shiftKey && !e.altKey && /^[1-9]$/.test(e.key)) {
      const idx = parseInt(e.key, 10) - 1;
      if (idx < PANELS.list.length) {
        e.preventDefault();
        activatePanel(PANELS.list[idx].key);
      }
    }
  });
}


function showView(name) {
  if (name !== "report" && typeof REPORT !== "undefined" && REPORT.context) {
    // Snapshot je synchronní; vlastní síťový zápis běží debouncovaně.
    snapshotReportDraft();
    if (REPORT.dirty) flushReportDraft();
  }
  document.getElementById("view-dashboard").classList.toggle("hidden", name !== "dashboard");
  document.getElementById("view-point").classList.toggle("hidden", name !== "point");
  document.getElementById("view-compare").classList.toggle("hidden", name !== "compare");
  document.getElementById("view-waterfall").classList.toggle("hidden", name !== "waterfall");
  document.getElementById("view-machine").classList.toggle("hidden", name !== "machine");
  document.getElementById("view-report").classList.toggle("hidden", name !== "report");
  document.getElementById("view-settings").classList.toggle("hidden", name !== "settings");
  document.getElementById("empty-state").classList.add("hidden");
}
function showEmpty(msg) {
  document.getElementById("view-dashboard").classList.add("hidden");
  document.getElementById("view-point").classList.add("hidden");
  document.getElementById("view-compare").classList.add("hidden");
  document.getElementById("view-waterfall").classList.add("hidden");
  document.getElementById("view-machine").classList.add("hidden");
  document.getElementById("view-report").classList.add("hidden");
  document.getElementById("view-settings").classList.add("hidden");
  const e = document.getElementById("empty-state");
  e.classList.remove("hidden");
  e.innerHTML = `<p>${escapeHtml(msg)}</p>`;
}

// ---------- upload ----------
async function onUpload(e) {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  toast("Načítám databázi…");
  try {
    const r = await api("/api/upload", { method: "POST", body: fd });
    await refreshDbSelect();
    toast("Databáze načtena: " + r.filename);
    await loadAll();
    // pokud je otevřený modal správy, obnov i seznam
    if (!document.getElementById("manage-modal").classList.contains("hidden")) {
      renderDbList();
    }
  } catch (err) {
    toast(err.message, true);
  }
  e.target.value = "";
}

// ---------- aktualizace aktivní databáze ----------
let DATABASE_UPDATE_FILE = null;
let DATABASE_UPDATE_IN_PROGRESS = false;

function chooseDatabaseUpdate() {
  if (DATABASE_UPDATE_IN_PROGRESS) return;
  const active = (STATE.databases || []).find(db => db.active);
  if (!active) {
    toast("Není vybrána aktivní databáze.", true);
    return;
  }
  const input = document.getElementById("update-db-input");
  input.value = "";
  input.click(); // nativní výběr souboru; Storno nic nemění
}

function formatFileBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n >= 1024 * 1024 * 1024) return `${fmtNum(n / (1024 * 1024 * 1024), 2)} GB`;
  if (n >= 1024 * 1024) return `${fmtNum(n / (1024 * 1024), 1)} MB`;
  return `${fmtNum(n / 1024, 0)} kB`;
}

function onDatabaseUpdateFile(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return; // uživatel dialog zrušil
  if (!/\.ndb$/i.test(file.name)) {
    toast("Vyberte soubor s příponou .ndb.", true);
    e.target.value = "";
    return;
  }
  DATABASE_UPDATE_FILE = file;
  const modified = file.lastModified ? new Date(file.lastModified).toLocaleString("cs-CZ") : "neuvedeno";
  const fileEl = document.getElementById("update-db-file");
  fileEl.textContent = `${file.name} · ${formatFileBytes(file.size)} · zdroj změněn: ${modified}`;
  setDatabaseUpdateStatus("");
  document.getElementById("update-db-confirm").disabled = false;
  document.getElementById("update-db-modal").classList.remove("hidden");
}

function closeDatabaseUpdateModal() {
  if (DATABASE_UPDATE_IN_PROGRESS) return;
  DATABASE_UPDATE_FILE = null;
  const input = document.getElementById("update-db-input");
  if (input) input.value = "";
  document.getElementById("update-db-modal").classList.add("hidden");
}

function setDatabaseUpdateStatus(message, error = false) {
  const el = document.getElementById("update-db-status");
  if (!el) return;
  el.textContent = message || "";
  el.className = error ? "update-db-status err" : "update-db-status";
}

function showDatabaseUpdateClosingState() {
  DATABASE_UPDATE_IN_PROGRESS = true;
  const modal = document.getElementById("update-db-modal");
  const confirm = document.getElementById("update-db-confirm");
  const cancel = document.getElementById("update-db-cancel");
  const close = document.getElementById("update-db-close");
  if (confirm) confirm.disabled = true;
  if (cancel) cancel.disabled = true;
  if (close) close.disabled = true;
  if (modal) modal.classList.add("hidden");
  showEmpty("HADS se ukončuje. Databáze bude aktualizována mimo běžící aplikaci a HADS se automaticky znovu spustí.");
}

async function showExternalDatabaseUpdateResult() {
  try {
    const reply = await api("/api/databases/update-result");
    const result = reply && reply.result;
    if (!result || !result.job_id) return;
    const source = result.source_name ? ` (${result.source_name}${result.source_size ? `, ${formatFileBytes(result.source_size)}` : ""})` : "";
    let message;
    if (result.success) {
      const modified = result.source_last_modified ? ` Zdroj: ${new Date(Number(result.source_last_modified)).toLocaleString("cs-CZ")}.` : "";
      message = `Databáze byla po ukončení HADS úspěšně aktualizována${source}.${modified}`;
    } else {
      const restored = result.old_verified_restored
        ? " Původní databáze byla byteově ověřena a obnovena."
        : " Obnovení původní databáze se nepodařilo byteově ověřit.";
      message = `Externí aktualizace databáze selhala.${restored} Log: ${result.log_path || "není dostupný"}.`;
    }
    toast(message, !result.success);
    await api("/api/databases/update-result/ack", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ job_id: result.job_id }),
    });
  } catch (_) {
    // Receipt must never block normal application startup.
  }
}

function uploadDatabaseUpdate(formData, onProgress, onUploadComplete) {
  return new Promise((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("POST", "/api/databases/update");
    request.responseType = "json";
    request.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(event.loaded, event.total);
    };
    request.upload.onload = () => {
      if (onUploadComplete) onUploadComplete();
    };
    request.onerror = () => reject(new Error("Spojení se serverem bylo přerušeno."));
    request.onload = () => {
      const body = request.response || (() => {
        try { return JSON.parse(request.responseText || "{}"); } catch (_) { return {}; }
      })();
      if (request.status >= 200 && request.status < 300) resolve(body);
      else reject(new Error((body && body.detail) || "Aktualizace databáze se nezdařila."));
    };
    request.send(formData);
  });
}

async function confirmDatabaseUpdate() {
  const file = DATABASE_UPDATE_FILE;
  if (!file || DATABASE_UPDATE_IN_PROGRESS) return;
  DATABASE_UPDATE_IN_PROGRESS = true;
  const confirm = document.getElementById("update-db-confirm");
  const cancel = document.getElementById("update-db-cancel");
  confirm.disabled = true;
  cancel.disabled = true;
  const data = new FormData();
  // Metadata posíláme před souborem, aby server mohl zkontrolovat volné místo
  // ještě před zápisem první části vícegigabajtového uploadu.
  data.append("declared_size", String(file.size));
  data.append("source_last_modified", String(file.lastModified || ""));
  data.append("file", file, file.name);
  let phaseTimer = null;
  try {
    setDatabaseUpdateStatus(`Nahrávám 0 % (${formatFileBytes(file.size)})…`);
    const result = await uploadDatabaseUpdate(data, (loaded, total) => {
      const pct = total ? Math.min(100, Math.round(loaded * 100 / total)) : 0;
      setDatabaseUpdateStatus(`Nahrávám ${pct} % (${formatFileBytes(loaded)} z ${formatFileBytes(file.size)})…`);
    }, () => {
      setDatabaseUpdateStatus("Ověřuji nahranou databázi…");
      phaseTimer = setTimeout(() => setDatabaseUpdateStatus("Dokončuji preflight před externí výměnou…"), 180);
    });
    if (result.no_update) {
      setDatabaseUpdateStatus(result.detail || "Aktualizace není potřeba.");
      toast(result.detail || "Aktualizace není potřeba.");
      return;
    }
    if (phaseTimer) { clearTimeout(phaseTimer); phaseTimer = null; }
    if (result.accepted) {
      // The server has only staged and validated the file. Its response is
      // deliberately visible before graceful shutdown begins.
      showDatabaseUpdateClosingState();
      return;
    }
    setDatabaseUpdateStatus("Preflight byl dokončen.");
  } catch (err) {
    const detail = err.message || "Aktualizace se nezdařila.";
    const retryMessage = `Aktualizace nebyla provedena. Vybraný soubor zůstává připraven k opakování: ${detail}`;
    setDatabaseUpdateStatus(retryMessage, true);
    toast(retryMessage, true);
  } finally {
    if (phaseTimer) clearTimeout(phaseTimer);
    if (!document.getElementById("update-db-modal").classList.contains("hidden")) {
      DATABASE_UPDATE_IN_PROGRESS = false;
      confirm.disabled = !DATABASE_UPDATE_FILE;
      cancel.disabled = false;
    }
  }
}


// ====================== POROVNÁNÍ VÍCE MĚŘICÍCH BODŮ ======================
// Paleta barev pro jednotlivé trendy v grafu porovnání
const COMPARE_COLORS = [
  "#2f9bd6", "#ef8c1b", "#19a974", "#e23b3b", "#a78bfa", "#e6c019",
  "#22d3ee", "#f472b6", "#84cc16", "#fb923c", "#60a5fa", "#34d399",
  "#f87171", "#c084fc", "#facc15", "#2dd4bf", "#fda4af", "#a3e635",
  "#fdba74", "#93c5fd", "#6ee7b7", "#fca5a5", "#d8b4fe", "#fde047",
];

// Přepnutí režimu porovnání (zapnutí/vypnutí zaškrtávacích políček ve stromu)
function toggleCompareMode() {
  STATE.compareMode = !STATE.compareMode;
  const btn = document.getElementById("compare-toggle");
  const bar = document.getElementById("compare-bar");
  const sidebar = document.querySelector(".sidebar");
  btn.classList.toggle("active", STATE.compareMode);
  bar.classList.toggle("hidden", !STATE.compareMode);
  sidebar.classList.toggle("compare-on", STATE.compareMode);
  if (!STATE.compareMode) {
    // při vypnutí režimu zachováme výběr, jen schováme políčka
  }
  updateCompareCount();
}

// Přidání/odebrání měřicího bodu z výběru
function togglePointSelection(pointId, rowEl) {
  const idx = STATE.compareSel.indexOf(pointId);
  if (idx >= 0) {
    STATE.compareSel.splice(idx, 1);
  } else {
    if (STATE.compareSel.length >= 24) {
      toast("Najednou lze porovnat nejvýše 24 měřicích bodů.", true);
      return;
    }
    STATE.compareSel.push(pointId);
  }
  const cb = rowEl.querySelector(".tcheck");
  if (cb) cb.classList.toggle("on", STATE.compareSel.includes(pointId));
  updateCompareCount();
}

// Aktualizace počítadla a stavu tlačítka „Porovnat"
function updateCompareCount() {
  const n = STATE.compareSel.length;
  const word = n === 1 ? "vybraný bod" : (n >= 2 && n <= 4 ? "vybrané body" : "vybraných bodů");
  document.getElementById("compare-count").textContent = n + " " + word;
  const run = document.getElementById("compare-run");
  run.disabled = n < 2;
}

// Vyčištění celého výběru
function clearCompareSelection() {
  STATE.compareSel = [];
  document.querySelectorAll(".tcheck.on").forEach(el => el.classList.remove("on"));
  updateCompareCount();
}

// Načtení dat z backendu a zobrazení pohledu porovnání
async function runCompare() {
  if (STATE.compareSel.length < 2) {
    toast("Vyberte alespoň dva měřicí body.", true);
    return;
  }
  toast("Načítám trendy vybraných bodů…");
  try {
    const data = await api("/api/compare", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ point_ids: STATE.compareSel }),
    });
    STATE.compareData = data;
    // naplnění výběru veličiny
    const sel = document.getElementById("compare-quantity");
    const quantities = data.quantities || [];
    if (!quantities.length) {
      toast("Vybrané body nemají žádné společné trendové veličiny.", true);
      return;
    }
    const prev = sel.value;
    sel.innerHTML = quantities.map(q => `<option value="${escapeHtml(q)}">${escapeHtml(q)}</option>`).join("");
    // pokud byla dříve zvolená veličina stále k dispozici, ponecháme ji
    if (quantities.includes(prev)) sel.value = prev;
    showView("compare");
    drawCompare();
  } catch (err) {
    toast(err.message, true);
  }
}

// Vykreslení grafu porovnání + legendy + statistik
function drawCompare() {
  const data = STATE.compareData;
  if (!data) return;
  const quantity = document.getElementById("compare-quantity").value;
  const normalize = document.getElementById("compare-normalize").checked;
  const showMarkers = document.getElementById("compare-markers").checked;

  const traces = [];
  const legendItems = [];
  // série připravené pro výpočet korelací (jen ty se shodnou veličinou)
  const seriesForStats = [];
  let colorIdx = 0;

  (data.points || []).forEach(pt => {
    const ser = (pt.series || []).find(s => s.quantity === quantity);
    if (!ser || !ser.points || !ser.points.length) return;
    const color = COMPARE_COLORS[colorIdx % COMPARE_COLORS.length];
    colorIdx++;

    const x = ser.points.map(p => p.t);
    let y = ser.points.map(p => p.value);
    let suffix = "";
    if (normalize) {
      const mn = Math.min(...y), mx = Math.max(...y);
      const rng = mx - mn;
      y = y.map(v => rng > 0 ? ((v - mn) / rng) * 100 : 50);
      suffix = " %";
    }
    const label = pt.machine_name ? (pt.point_name + " — " + pt.machine_name) : pt.point_name;
    traces.push({
      x, y,
      type: "scatter",
      mode: showMarkers ? "lines+markers" : "lines",
      line: { color, width: 2, shape: "linear" },
      marker: { size: 6, color },
      name: label,
      hovertemplate: "%{x|%d.%m.%Y %H:%M}<br>%{y:.4f}" + suffix + "<extra>" + escapeHtml(label) + "</extra>",
    });
    legendItems.push({ label, color, n: y.length });
    seriesForStats.push({ label, points: ser.points });
  });

  const chartEl = document.getElementById("compare-chart");
  if (!traces.length) {
    chartEl.innerHTML = '<div class="empty-mini">Pro vybranou veličinu nejsou k dispozici žádná data.</div>';
    document.getElementById("compare-legend").innerHTML = "";
    document.getElementById("compare-stats").innerHTML = "";
    return;
  }

  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.xaxis.title = "Čas měření";
  layout.yaxis.title = normalize ? "Normalizováno (0–100 %)" : "Hodnota";
  layout.xaxis.type = "date";
  layout.showlegend = false; // vlastní legenda pod grafem
  Plotly.newPlot("compare-chart", traces, layout, PLOT_CONFIG);

  // vlastní legenda
  document.getElementById("compare-legend").innerHTML = legendItems.map(it =>
    `<span class="cl-item"><span class="cl-swatch" style="background:${it.color}"></span>${escapeHtml(it.label)} <span class="cl-n">(${it.n})</span></span>`
  ).join("");

  renderCompareStats(seriesForStats, quantity);
}

// Výpočet statistik a korelací mezi vybranými body
function renderCompareStats(series, quantity) {
  const el = document.getElementById("compare-stats");
  if (series.length < 2) {
    el.innerHTML = '<p class="cs-note">Pro výpočet korelace vyberte alespoň dva body se stejnou veličinou.</p>';
    return;
  }

  // 1) přehledová tabulka jednotlivých sérií
  let html = '<div class="cs-section"><h4>Přehled sérií · ' + escapeHtml(quantity) + '</h4>';
  html += '<table class="cs-table"><thead><tr><th>Měřicí bod</th><th>Poslední</th><th>Min</th><th>Max</th><th>Průměr</th><th>Trend</th></tr></thead><tbody>';
  series.forEach(s => {
    const y = s.points.map(p => p.value);
    const last = y[y.length - 1];
    const mn = Math.min(...y), mx = Math.max(...y);
    const avg = y.reduce((a, b) => a + b, 0) / y.length;
    const trend = linregSlope(s.points);
    const trendCls = trend > 0 ? "up" : (trend < 0 ? "down" : "flat");
    const trendSym = trend > 0 ? "▲ roste" : (trend < 0 ? "▼ klesá" : "→ stabilní");
    html += `<tr><td>${escapeHtml(s.label)}</td><td>${fmtNum(last)}</td><td>${fmtNum(mn)}</td><td>${fmtNum(mx)}</td><td>${fmtNum(avg)}</td><td class="cs-trend ${trendCls}">${trendSym}</td></tr>`;
  });
  html += '</tbody></table></div>';

  // 2) korelační matice (Pearson, na společných časech sloučených tolerancí)
  html += '<div class="cs-section"><h4>Korelace (Pearson) — současné nárůsty</h4>';
  html += '<div class="cs-corrwrap"><table class="cs-table cs-corr"><thead><tr><th></th>';
  series.forEach((s, i) => { html += `<th title="${escapeHtml(s.label)}">${i + 1}</th>`; });
  html += '</tr></thead><tbody>';
  series.forEach((a, i) => {
    html += `<tr><th title="${escapeHtml(a.label)}">${i + 1}. ${escapeHtml(shortLabel(a.label))}</th>`;
    series.forEach((b, j) => {
      if (i === j) { html += '<td class="cs-diag">—</td>'; return; }
      const r = pearsonOnCommon(a.points, b.points);
      if (r === null) { html += '<td class="cs-na">·</td>'; return; }
      html += `<td class="cs-cell" style="background:${corrBg(r)}" title="r = ${r.toFixed(3)}">${r.toFixed(2)}</td>`;
    });
    html += '</tr>';
  });
  html += '</tbody></table></div>';
  html += '<p class="cs-note">Vysoká kladná korelace (blízko +1, zeleně) značí současné nárůsty vibrací — body se chovají podobně a mohou mít společnou příčinu. Hodnoty blízko 0 = nezávislý vývoj, záporné (červeně) = opačný trend.</p>';
  html += '</div>';

  el.innerHTML = html;
}

// Lineární regrese — směrnice (pro určení trendu rostoucí/klesající)
function linregSlope(points) {
  const n = points.length;
  if (n < 2) return 0;
  const t0 = new Date(points[0].t).getTime();
  const xs = points.map(p => (new Date(p.t).getTime() - t0) / 86400000); // dny
  const ys = points.map(p => p.value);
  const mx = xs.reduce((a, b) => a + b, 0) / n;
  const my = ys.reduce((a, b) => a + b, 0) / n;
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) { num += (xs[i] - mx) * (ys[i] - my); den += (xs[i] - mx) ** 2; }
  if (den === 0) return 0;
  const slope = num / den;
  // práh na zaokrouhlení (zanedbatelné změny = stabilní)
  const rng = Math.max(...ys) - Math.min(...ys);
  if (rng === 0 || Math.abs(slope) < rng * 0.001) return 0;
  return slope;
}

// Pearsonův korelační koeficient na společných časových bodech
// (spárování podle nejbližšího času s tolerancí 12 hodin)
function pearsonOnCommon(pa, pb) {
  const TOL = 12 * 3600 * 1000; // 12 h
  const a = pa.map(p => ({ t: new Date(p.t).getTime(), v: p.value })).sort((x, y) => x.t - y.t);
  const b = pb.map(p => ({ t: new Date(p.t).getTime(), v: p.value })).sort((x, y) => x.t - y.t);
  const xa = [], xb = [];
  let j = 0;
  for (let i = 0; i < a.length; i++) {
    // najdi v b nejbližší čas k a[i].t
    while (j < b.length - 1 && Math.abs(b[j + 1].t - a[i].t) <= Math.abs(b[j].t - a[i].t)) j++;
    if (Math.abs(b[j].t - a[i].t) <= TOL) { xa.push(a[i].v); xb.push(b[j].v); }
  }
  const n = xa.length;
  if (n < 3) return null;
  const ma = xa.reduce((s, v) => s + v, 0) / n;
  const mb = xb.reduce((s, v) => s + v, 0) / n;
  let num = 0, da = 0, db = 0;
  for (let i = 0; i < n; i++) {
    const va = xa[i] - ma, vb = xb[i] - mb;
    num += va * vb; da += va * va; db += vb * vb;
  }
  if (da === 0 || db === 0) return null;
  return num / Math.sqrt(da * db);
}

// Barva pozadí buňky korelace (zelená = +1, červená = -1)
function corrBg(r) {
  const a = Math.min(Math.abs(r), 1);
  if (r >= 0) return `rgba(25,169,116,${(0.12 + a * 0.45).toFixed(3)})`;
  return `rgba(226,59,59,${(0.12 + a * 0.45).toFixed(3)})`;
}

// Zkrácení popisku pro hlavičku korelační matice
function shortLabel(label) {
  const part = label.split(" — ")[0];
  return part.length > 14 ? part.slice(0, 13) + "…" : part;
}


// ---------- VODOPÁD FFT SPEKTER ----------

// ====================== VODOPÁDOVÝ GRAF FFT SPEKTER ======================
// Barevná škála pro 3D plochu i intenzitu 2D vodopádu (tmavá → teplá)
const WF_COLORSCALE = [
  [0.0, "#0d1117"], [0.2, "#16324a"], [0.4, "#1c5e82"],
  [0.6, "#2f9bd6"], [0.8, "#e6c019"], [1.0, "#e23b3b"],
];

// Otevření vodopádu pro aktivní měřicí bod
async function openWaterfall() {
  const pid = STATE.activePoint;
  if (!pid) { toast("Nejprve vyberte měřicí bod.", true); return; }
  const node = STATE.byId[pid];
  const machine = STATE.byId[node?.parent];
  document.getElementById("wf-title").textContent = "Vodopád FFT spekter — " + (node ? node.name : "");
  document.getElementById("wf-breadcrumb").textContent =
    [machine?.name, node?.name].filter(Boolean).join("  ›  ") || "Vodopádový graf";
  showView("waterfall");
  await loadWaterfall();
}

// Načtení dat vodopádu z backendu (podle limitu a zvoleného měření)
async function loadWaterfall() {
  const pid = STATE.activePoint;
  if (!pid) return;
  const limit = document.getElementById("wf-limit").value || "30";
  const cellSel = document.getElementById("wf-cell");
  const cellId = cellSel.value || "";
  const chart = document.getElementById("wf-chart");
  chart.innerHTML = '<div class="spinner"></div>';
  try {
    let url = `/api/point/${pid}/waterfall?limit=${encodeURIComponent(limit)}`;
    if (cellId) url += `&cell_id=${encodeURIComponent(cellId)}`;
    const data = await api(url);
    STATE.wfData = data;

    // naplň výběr spektrálního měření (pokud jich je víc)
    if (data.cells && data.cells.length) {
      const prev = cellSel.value;
      cellSel.innerHTML = data.cells.map(c =>
        `<option value="${c.cell_id}">${escapeHtml(c.name)} (${c.count})</option>`).join("");
      cellSel.value = String(data.cell_id);
      document.getElementById("wf-cell-wrap").style.display = data.cells.length > 1 ? "" : "none";
    }

    if (!data.spectra || !data.spectra.length) {
      chart.innerHTML = '<div class="empty-mini">Pro tento bod nejsou k dispozici žádná spektra.</div>';
      document.getElementById("wf-detail-chart").innerHTML = "";
      document.getElementById("wf-detail-stats").innerHTML = "";
      return;
    }

    // posuvník: rozsah podle počtu spekter, výchozí = nejnovější
    const slider = document.getElementById("wf-slider");
    slider.min = "0";
    slider.max = String(data.spectra.length - 1);
    STATE.wfSel = data.spectra.length - 1;
    slider.value = String(STATE.wfSel);

    drawWaterfall();
    drawOverallTrend();
    drawWaterfallDetail();
  } catch (e) {
    chart.innerHTML = `<div class="empty-mini">${escapeHtml(e.message)}</div>`;
  }
}

// Trend celkové hodnoty (overall) v čase – pomoc při sledování degradace ložiska
function drawOverallTrend() {
  const data = STATE.wfData;
  const el = document.getElementById("wf-overall-chart");
  if (!el) return;
  if (!data || !data.spectra || !data.spectra.length) { el.innerHTML = ""; return; }
  const times = data.spectra.map(s => s.time);
  const overalls = data.spectra.map(s =>
    s.overall != null ? s.overall : Math.sqrt(s.values.reduce((a, v) => a + v * v, 0)));
  // zvýraznění právě vybraného času
  const markerColors = overalls.map((_, i) =>
    i === STATE.wfSel ? getCss("--sev-alert") : getCss("--accent"));
  const markerSizes = overalls.map((_, i) => i === STATE.wfSel ? 10 : 6);
  const trace = {
    x: times, y: overalls,
    type: "scatter", mode: "lines+markers",
    line: { color: getCss("--accent"), width: 2 },
    marker: { color: markerColors, size: markerSizes,
      line: { color: getCss("--bg"), width: 1 } },
    hovertemplate: "%{x}<br>Overall: %{y:.4f}<extra></extra>",
  };
  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.xaxis.title = "Čas měření";
  layout.yaxis.title = "Overall";
  layout.xaxis.type = "date";
  Plotly.newPlot("wf-overall-chart", [trace], layout, PLOT_CONFIG);
  // klik do trendu vybere dané spektrum
  el.on("plotly_click", (ev) => {
    if (!ev.points || !ev.points.length) return;
    const i = ev.points[0].pointIndex;
    if (i != null) selectWaterfallSpectrum(i);
  });
}

// Vykreslení hlavního vodopádu (3D plocha nebo 2D skládaná spektra)
function drawWaterfall() {
  const data = STATE.wfData;
  if (!data || !data.spectra || !data.spectra.length) return;
  const useLog = document.getElementById("wf-log").checked;
  const freq = data.frequencies;
  const spectra = data.spectra;
  // popisky času pro osu Y
  const times = spectra.map(s => fmtDate(s.time));

  // aplikace log. transformace amplitudy (jen pro zobrazení)
  const tf = v => useLog ? Math.log10(Math.max(v, 1e-9)) : v;
  const ampLabel = useLog ? "Amplituda (log₁₀)" : "Amplituda";

  if (STATE.wfMode === "3d") {
    const z = spectra.map(s => s.values.map(tf));
    const trace = {
      type: "surface",
      x: freq,
      y: times,
      z: z,
      colorscale: WF_COLORSCALE,
      showscale: true,
      colorbar: { title: { text: ampLabel, side: "right" }, thickness: 12, len: 0.7, x: 1.0 },
      contours: { z: { show: true, usecolormap: true, highlightcolor: "#ffffff", project: { z: false } } },
      hovertemplate: "Frekvence: %{x:.1f} Hz<br>Čas: %{y}<br>Ampl.: %{z:.4f}<extra></extra>",
    };
    const layout = {
      paper_bgcolor: "rgba(0,0,0,0)",
      plot_bgcolor: "rgba(0,0,0,0)",
      font: { color: "#9aa6b2", family: "Inter, sans-serif", size: 11 },
      margin: { l: 0, r: 0, t: 10, b: 0 },
      scene: {
        xaxis: { title: "Frekvence [Hz]", gridcolor: "#2a313c", color: "#9aa6b2", backgroundcolor: "rgba(0,0,0,0)", showbackground: true },
        yaxis: { title: "Čas měření", gridcolor: "#2a313c", color: "#9aa6b2", backgroundcolor: "rgba(0,0,0,0)", showbackground: true },
        zaxis: { title: ampLabel, gridcolor: "#2a313c", color: "#9aa6b2", backgroundcolor: "rgba(0,0,0,0)", showbackground: true },
        camera: { eye: { x: 1.7, y: -1.5, z: 0.9 } },
        aspectratio: { x: 1.4, y: 1.1, z: 0.7 },
      },
    };
    Plotly.newPlot("wf-chart", [trace], layout, PLOT_CONFIG);
    // klik do 3D plochy → vyber nejbližší časovou řadu
    const el = document.getElementById("wf-chart");
    el.removeAllListeners && el.removeAllListeners("plotly_click");
    el.on("plotly_click", ev => {
      const pt = ev.points && ev.points[0];
      if (!pt) return;
      const idx = times.indexOf(pt.y);
      if (idx >= 0) selectWaterfallSpectrum(idx);
    });
  } else {
    // 2D skládaná spektra s offsetem (waterfall pohled)
    const n = spectra.length;
    // odhad offsetu z globálního maxima
    let gmax = 0;
    spectra.forEach(s => s.values.forEach(v => { const t = tf(v); if (t > gmax) gmax = t; }));
    let gmin = Infinity;
    spectra.forEach(s => s.values.forEach(v => { const t = tf(v); if (t < gmin) gmin = t; }));
    if (!isFinite(gmin)) gmin = 0;
    const span = (gmax - gmin) || 1;
    const offsetStep = span * 0.45;

    const traces = [];
    spectra.forEach((s, i) => {
      const off = i * offsetStep;
      const y = s.values.map(v => tf(v) + off);
      // barva podle stáří (starší tmavší, nejnovější výrazná)
      const frac = n > 1 ? i / (n - 1) : 1;
      const col = wfMix("#1c5e82", "#e23b3b", frac);
      traces.push({
        x: freq, y,
        type: "scatter", mode: "lines",
        line: { color: col, width: i === STATE.wfSel ? 2.4 : 1.1 },
        name: times[i],
        customdata: y.map(() => i),
        hovertemplate: "%{x:.1f} Hz<extra>" + escapeHtml(times[i]) + "</extra>",
        opacity: i === STATE.wfSel ? 1 : 0.85,
      });
    });
    const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
    layout.margin = { l: 64, r: 24, t: 16, b: 48 };
    layout.xaxis.title = "Frekvence [Hz]";
    layout.yaxis.title = ampLabel + " (posun v čase ↑)";
    layout.showlegend = false;
    layout.hovermode = "closest";
    Plotly.newPlot("wf-chart", traces, layout, PLOT_CONFIG);
    const el = document.getElementById("wf-chart");
    el.removeAllListeners && el.removeAllListeners("plotly_click");
    el.on("plotly_click", ev => {
      const pt = ev.points && ev.points[0];
      if (!pt) return;
      const idx = (pt.customdata != null) ? pt.customdata : pt.curveNumber;
      if (idx != null) selectWaterfallSpectrum(idx);
    });
  }
}

// Lineární míchání dvou hex barev (frac 0..1)
function wfMix(a, b, frac) {
  const pa = [parseInt(a.slice(1, 3), 16), parseInt(a.slice(3, 5), 16), parseInt(a.slice(5, 7), 16)];
  const pb = [parseInt(b.slice(1, 3), 16), parseInt(b.slice(3, 5), 16), parseInt(b.slice(5, 7), 16)];
  const m = pa.map((v, i) => Math.round(v + (pb[i] - v) * frac));
  return `rgb(${m[0]},${m[1]},${m[2]})`;
}

// Výběr konkrétního spektra (z kliknutí nebo posuvníku)
function selectWaterfallSpectrum(idx) {
  const data = STATE.wfData;
  if (!data || !data.spectra) return;
  idx = Math.max(0, Math.min(idx, data.spectra.length - 1));
  STATE.wfSel = idx;
  document.getElementById("wf-slider").value = String(idx);
  // v 2D režimu zvýrazni vybranou křivku překreslením
  if (STATE.wfMode === "2d") drawWaterfall();
  // zvýraznění vybraného bodu v trendu overall
  const el = document.getElementById("wf-overall-chart");
  if (el && el.data && data.spectra.length) {
    const colors = data.spectra.map((_, i) =>
      i === idx ? getCss("--sev-alert") : getCss("--accent"));
    const sizes = data.spectra.map((_, i) => i === idx ? 10 : 6);
    try { Plotly.restyle(el, { "marker.color": [colors], "marker.size": [sizes] }); }
    catch (e) { /* graf ještě není vykreslen */ }
  }
  drawWaterfallDetail();
}

// Detail vybraného spektra (2D řez vodopádem) pod hlavním grafem
function drawWaterfallDetail() {
  const data = STATE.wfData;
  if (!data || !data.spectra || !data.spectra.length) return;
  const idx = STATE.wfSel;
  const s = data.spectra[idx];
  if (!s) return;
  const useLog = document.getElementById("wf-log").checked;
  const freq = data.frequencies;
  const y = s.values;

  document.getElementById("wf-detail-title").textContent = "Detail spektra — " + fmtDate(s.time);
  document.getElementById("wf-slider-time").textContent = fmtDate(s.time);

  const trace = {
    x: freq, y,
    type: "scatter", mode: "lines",
    line: { color: getCss("--accent"), width: 1.6 },
    fill: "tozeroy", fillcolor: "rgba(47,155,214,0.12)",
    hovertemplate: "%{x:.1f} Hz<br>%{y:.4f}<extra></extra>",
  };
  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.xaxis.title = "Frekvence [Hz]";
  layout.yaxis.title = "Amplituda";
  if (useLog) layout.yaxis.type = "log";
  Plotly.newPlot("wf-detail-chart", [trace], layout, PLOT_CONFIG);

  // statistika spektra
  const peak = y.reduce((m, v, i) => v > y[m] ? i : m, 0);
  const rms = Math.sqrt(y.reduce((a, v) => a + v * v, 0) / (y.length || 1));
  const cut = data.hp_cutoff != null ? data.hp_cutoff : 1;
  const overall = s.overall != null ? s.overall
    : Math.sqrt(y.reduce((a, v) => a + v * v, 0));
  document.getElementById("wf-detail-stats").innerHTML = [
    ["Čas měření", fmtDate(s.time)],
    ["Špička", fmtNum(y[peak]) + " @ " + fmtNum(freq[peak], 1) + " Hz"],
    ["Maximum", fmtNum(Math.max(...y))],
    [`Celková hodnota (overall, HP ${fmtNum(cut, 0)} Hz)`, fmtNum(overall)],
    ["RMS spektra", fmtNum(rms)],
    ["Počet čar", y.length],
  ].map(([l, v]) => `<div class="st"><span class="l">${escapeHtml(l)}</span><span class="v">${v}</span></div>`).join("");
}

// Přepnutí režimu 3D / 2D
function setWaterfallMode(mode) {
  STATE.wfMode = mode;
  document.getElementById("wf-mode-3d").classList.toggle("active", mode === "3d");
  document.getElementById("wf-mode-2d").classList.toggle("active", mode === "2d");
  drawWaterfall();
}

init();

// ============================================================
//  PROTOKOL Z MĚŘENÍ (PDF)
// ============================================================
// historyEntryId = id položky historie, ze které byl aktuální návrh vyvolán
// (null = návrh není navázán na žádnou historii). Při uložení do historie se
// použije k rozhodnutí, zda přidat novou položku, nebo přepsat existující.
// expandedMachines = Set klíčů strojů, které má uživatel v záložce
// „Stroje – závěry a doporučení“ ručně rozbalené. Při překreslení editoru
// (např. po AI generování nebo přepnutí karet) se těmto strojům ponechá
// otevřený stav, aby se nesbalilo vždy všechno.
const REPORT = {
  draft: null, activeTab: "setup", historyEntryId: null,
  expandedMachines: new Set(),
  context: null, sessionId: null, revision: 0, loadToken: 0,
  saveTimer: null, dirty: false, localSnapshot: false, preferredModel: null,
};

// --------------------- relace rozpracovaného protokolu ---------------------
// Editor se při aktivaci panelu historicky celý překresloval z GET /draft.
// Text, který ještě neopustil input, proto neměl šanci dostat se ani do
// REPORT.draft, ani na server. Následující vrstva vždy nejdřív synchronně
// sejme DOM do paměti + localStorage a až potom (debouncovaně) zapisuje API.
const REPORT_SESSION = window.HadsReportDraftSession;

function _reportDatabaseContext() {
  const active = (STATE.databases || []).find((db) => db.active);
  if (!active || !active.filename) return null;
  // Název souboru sám není lokálně dostatečný: dva různé podniky mohou
  // legitimně používat export se stejným názvem. Server už odděluje data
  // složkou podniku; localStorage proto používá stejnou dvojitou identitu.
  const plant = (STATE.nodes || []).find((node) => Number(node.type) === 1);
  const company = plant ? (plant.id + ":" + (plant.name || "")) : "";
  return "company:" + company + "|ndb:" + active.filename;
}
function _reportSessionState() {
  const value = (id) => {
    const el = document.getElementById(id);
    return el ? el.value : "";
  };
  const checked = (id) => {
    const el = document.getElementById(id);
    return !!(el && el.checked);
  };
  return {
    draft: REPORT.draft ? collectReportDoc() : null,
    setup: {
      scope_mode: value("report-scope-mode"),
      scope_days: value("report-scope-days"),
      scope_date: value("report-scope-date"),
      use_ai: checked("report-use-ai"),
      model: value("report-model"),
      ai_context: value("report-ai-context"),
      report_version: value("report-version"),
      show_previous: checked("report-show-previous"),
      full_fft: checked("report-full-fft"),
      checked_machine_ids: REPORT_SCOPE_MACHINES.checkedIds
        ? Array.from(REPORT_SCOPE_MACHINES.checkedIds) : null,
    },
    session_id: REPORT.sessionId,
    revision: REPORT.revision,
  };
}
function _applyReportSetup(setup) {
  if (!setup) return;
  const setValue = (id, value) => {
    const el = document.getElementById(id);
    if (el && value != null) el.value = value;
  };
  setValue("report-scope-mode", setup.scope_mode);
  setValue("report-scope-days", setup.scope_days);
  setValue("report-scope-date", setup.scope_date);
  setValue("report-ai-context", setup.ai_context);
  setValue("report-version", setup.report_version);
  const previous = document.getElementById("report-show-previous");
  if (previous && setup.show_previous != null) previous.checked = !!setup.show_previous;
  const fullFft = document.getElementById("report-full-fft");
  if (fullFft && setup.full_fft != null) fullFft.checked = !!setup.full_fft;
  if (setup.model) REPORT.preferredModel = setup.model;
  setValue("report-model", setup.model);
  const ai = document.getElementById("report-use-ai");
  if (ai && typeof setup.use_ai === "boolean") ai.checked = setup.use_ai;
  if (Array.isArray(setup.checked_machine_ids)) {
    REPORT_SCOPE_MACHINES.checkedIds = new Set(setup.checked_machine_ids);
  }
  onReportScopeChangeUiOnly();
}
function onReportScopeChangeUiOnly() {
  const mode = document.getElementById("report-scope-mode")?.value;
  document.getElementById("report-scope-days-wrap")?.classList.toggle("hidden", mode !== "last_days");
  document.getElementById("report-scope-date-wrap")?.classList.toggle("hidden", mode !== "date");
}
function _stampReportDraft(doc) {
  if (!doc || typeof doc !== "object") return doc;
  if (!REPORT.sessionId) REPORT.sessionId = REPORT_SESSION.newSessionId();
  doc._draft_session_id = REPORT.sessionId;
  doc._draft_revision = REPORT.revision;
  return doc;
}
function snapshotReportDraft() {
  const context = REPORT.context || _reportDatabaseContext();
  if (!context || !REPORT_SESSION) return null;
  if (REPORT.draft) REPORT.draft = _stampReportDraft(collectReportDoc());
  const snapshot = _reportSessionState();
  REPORT.preferredModel = snapshot.setup.model || REPORT.preferredModel;
  REPORT_SESSION.save(window.localStorage, context, snapshot);
  REPORT.localSnapshot = true;
  return snapshot;
}
function flushReportDraft(opts) {
  const options = opts || {};
  if (REPORT.saveTimer) { clearTimeout(REPORT.saveTimer); REPORT.saveTimer = null; }
  const snapshot = snapshotReportDraft();
  if (!snapshot || !snapshot.draft) return Promise.resolve();
  const payload = JSON.stringify({ doc: snapshot.draft });
  REPORT.dirty = false;
  if (options.unload) {
    try {
      const blob = new Blob([payload], { type: "application/json" });
      if (navigator.sendBeacon && navigator.sendBeacon(API + "/api/report/save", blob)) return Promise.resolve();
    } catch (e) {}
    try { fetch(API + "/api/report/save", { method: "POST", headers: { "Content-Type": "application/json" }, body: payload, keepalive: true }); } catch (e) {}
    return Promise.resolve();
  }
  // Odpověď se záměrně nepoužívá k překreslení editoru: starší asynchronní
  // save nesmí přepsat pozdější rozpracovaný obsah.
  return api("/api/report/save", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: payload,
  }).catch(() => {});
}
function markReportDraftDirty() {
  if (!REPORT.context) REPORT.context = _reportDatabaseContext();
  REPORT.revision += 1;
  REPORT.dirty = true;
  snapshotReportDraft(); // zachová i rozepsané znaky při okamžité navigaci
  if (REPORT.saveTimer) clearTimeout(REPORT.saveTimer);
  REPORT.saveTimer = setTimeout(() => flushReportDraft(), 350);
}
function initReportDraftSession() {
  const view = document.getElementById("view-report");
  if (view) {
    view.addEventListener("input", markReportDraftDirty);
    view.addEventListener("change", markReportDraftDirty);
  }
  window.addEventListener("pagehide", () => flushReportDraft({ unload: true }));
  window.addEventListener("beforeunload", () => flushReportDraft({ unload: true }));
}

// Stabilní klíč stroje pro pamatování rozbaleného stavu: primárně machine_id,
// při jeho absenci název, jinak pořadí.
function _reportMachineKey(m, idx) {
  if (m && m.machine_id != null && m.machine_id !== "") return "id:" + m.machine_id;
  if (m && m.name) return "name:" + m.name;
  return "idx:" + idx;
}
// stav ručního výběru strojů pro okruh protokolu (checkboxy)
// checkedIds === null => uživatel zatím nic neupravoval, použije se okruh dle data beze změny
// checkedIds === Set(...) => uživatel ručně upravil výběr, tento seznam je závazný
const REPORT_SCOPE_MACHINES = { items: [], checkedIds: null };

// Naplní <select id="report-model"> dostupnými modely (stejný vzor jako
// jinde v aplikaci) a volitelně předvybere `preferId`.
function populateReportModelSelect(preferId) {
  const sel = document.getElementById("report-model");
  if (!sel) return;
  const wanted = preferId || AI_CONF.model || "";
  const modelOpts = (AI_CONF.models || []).map(md => {
    const avail = (md.provider === "anthropic" || md.provider === "anthropic_agent") ? AI_CONF.has_anthropic_key : AI_CONF.has_openai_key;
    const isSel = md.id === wanted ? " selected" : "";
    const dis = avail ? "" : " disabled";
    const suffix = avail ? "" : " — chybí API klíč";
    return `<option value="${escapeHtml(md.id)}"${isSel}${dis}>${escapeHtml(md.label)}${suffix}</option>`;
  }).join("");
  sel.innerHTML = modelOpts || '<option value="">(žádné modely)</option>';
  if (wanted && sel.querySelector(`option[value="${CSS.escape(wanted)}"]`)) {
    sel.value = wanted;
  }
}

// Zobrazí/skryje editor návrhu protokolu (obě části – hlavička+úvod
// v záložce „Okruh strojů a návrh“ i stroje v záložce „Stroje“).
function setReportEditorVisible(visible) {
  document.getElementById("report-editor-setup")?.classList.toggle("hidden", !visible);
  document.getElementById("report-editor-machines")?.classList.toggle("hidden", !visible);
  document.getElementById("report-machines-empty-hint")?.classList.toggle("hidden", visible);
  // záložka „Úvodní strana“: skryj výzvu „nejdřív vytvořte návrh“, když editor svítí
  document.getElementById("report-intro-empty-hint")?.classList.toggle("hidden", visible);
}

// Přepnutí podzáložky v tvorbě protokolu („Okruh strojů a návrh“ /
// „Stroje – závěry a doporučení“). Pozice skrolování se pamatuje zvlášť
// pro každou podzáložku, aby se při návratu obnovilo místo, kde uživatel
// přepnutím přerušil práci (stejně jako u záložek karty stroje).
function switchReportTab(key) {
  if (!key || key === REPORT.activeTab) return;
  saveTabScroll("report", REPORT.activeTab);
  REPORT.activeTab = key;
  document.querySelectorAll("#report-tabbar .mc-tab").forEach(b => {
    b.classList.toggle("active", b.dataset.reportTab === key);
  });
  document.querySelectorAll("#view-report .mc-tabpane").forEach(p => {
    p.classList.toggle("active", p.dataset.reportTab === key);
  });
  // při otevření záložky Historie načti aktuální seznam
  if (key === "history") loadReportHistory();
  restoreTabScroll("report", key);
}

// Otevře pohled tvorby protokolu. Načte případný uložený návrh.
async function openReport() {
  showView("report");
  // zaevidovat jako panel (pro přepínání Ctrl+Tab)
  openPanel("report", null, "Protokol", () => openReport());
  document.getElementById("report-gen-status").textContent = "";
  _showReportRefreshStatus("");
  const context = _reportDatabaseContext();
  if (context !== REPORT.context) {
    REPORT.context = context;
    REPORT.draft = null;
    REPORT.sessionId = null;
    REPORT.revision = 0;
    REPORT.localSnapshot = false;
    REPORT.preferredModel = null;
    REPORT_SCOPE_MACHINES.checkedIds = null;
  }
  const local = context && REPORT_SESSION
    ? REPORT_SESSION.load(window.localStorage, context) : null;
  if (local) {
    REPORT.localSnapshot = true;
    REPORT.sessionId = local.session_id || REPORT_SESSION.newSessionId();
    REPORT.revision = Number(local.revision) || 0;
    _applyReportSetup(local.setup);
    if (local.draft) {
      REPORT.draft = local.draft;
      fillReportEditor(REPORT.draft);
      setReportEditorVisible(true);
      _setReportBtns(true);
    }
  }
  refreshReportScopeMachines();
  _bindReportVersionUi();
  await loadAiConf();
  populateReportModelSelect(REPORT.preferredModel);
  const token = ++REPORT.loadToken;
  const requestRevision = REPORT.revision;
  try {
    const r = await api("/api/report/draft");   // GET = poslední uložený návrh
    // Návrat panelu může doběhnout až po rozepsání textu. Zastaralá odpověď
    // ani serverový stav nesmí překreslit novější lokální snapshot.
    if (!REPORT_SESSION.shouldApplyRemote({
      requestToken: token, activeToken: REPORT.loadToken,
      requestRevision, currentRevision: REPORT.revision,
      hasLocalSnapshot: REPORT.localSnapshot,
      context, activeContext: REPORT.context,
    })) return;
    if (r && r.draft) {
      REPORT.draft = r.draft;
      REPORT.sessionId = r.draft._draft_session_id || REPORT_SESSION.newSessionId();
      REPORT.revision = Number(r.draft._draft_revision) || 0;
      // obnov dosavadní doplňující pokyny pro AI z uloženého návrhu
      const aiCtxEl = document.getElementById("report-ai-context");
      if (aiCtxEl) aiCtxEl.value = r.draft.ai_context || "";
      const versionEl = document.getElementById("report-version");
      if (versionEl) versionEl.value = String(r.draft.report_version || 1);
      _syncReportAppendixImageUi();
      // obnov externí obrázek přílohy z uloženého návrhu (verze 3)
      const capEl = document.getElementById("report-appendix-image-caption");
      if (capEl) capEl.value = r.draft.appendix_image_caption || "";
      _renderAppendixImagePreview(r.draft.appendix_image || "");
      if (r.draft.model) {
        REPORT.preferredModel = r.draft.model;
        populateReportModelSelect(r.draft.model);
      }
      fillReportEditor(r.draft);
      setReportEditorVisible(true);
      _setReportBtns(true);
    } else {
      REPORT.draft = null;
      setReportEditorVisible(false);
      _setReportBtns(false);
    }
  } catch (e) {
    // žádná DB nebo jiná chyba – jen zobrazíme prázdný formulář
    REPORT.draft = null;
    setReportEditorVisible(false);
    _setReportBtns(false);
  }
}

// Přepínání polí dle zvoleného okruhu strojů.
function onReportScopeChange() {
  const mode = document.getElementById("report-scope-mode").value;
  document.getElementById("report-scope-days-wrap").classList.toggle("hidden", mode !== "last_days");
  document.getElementById("report-scope-date-wrap").classList.toggle("hidden", mode !== "date");
  // změna okruhu dle data zruší dosavadní ruční úpravy výběru strojů –
  // nově se znovu předvyplní dle nového okruhu
  REPORT_SCOPE_MACHINES.checkedIds = null;
  refreshReportScopeMachines();
}

// Sestaví objekt okruhu strojů dle formuláře (bez machine_ids – jen datum).
function collectReportDateScope() {
  const mode = document.getElementById("report-scope-mode").value;
  if (mode === "last_days") {
    let d = parseInt(document.getElementById("report-scope-days").value, 10);
    if (!isFinite(d) || d < 1) d = 3;
    return { mode: "last_days", days: d };
  }
  if (mode === "week") return { mode: "week" };
  if (mode === "date") {
    const dt = document.getElementById("report-scope-date").value;
    return { mode: "date", date: dt };
  }
  return { mode: "all" };
}

// Sestaví objekt okruhu strojů dle formuláře, včetně ručně vybraných machine_ids
// (pokud uživatel výběr upravil oproti přednastavenému okruhu dle data).
function collectReportScope() {
  const scope = collectReportDateScope();
  if (REPORT_SCOPE_MACHINES.checkedIds) {
    scope.machine_ids = Array.from(REPORT_SCOPE_MACHINES.checkedIds);
  }
  return scope;
}

// Načte seznam strojů s měřením pro aktuální okruh dle data a vykreslí checkbox seznam.
async function refreshReportScopeMachines() {
  const listEl = document.getElementById("report-scope-machines-list");
  if (!listEl) return;
  const dateScope = collectReportDateScope();
  if (dateScope.mode === "date" && !dateScope.date) {
    listEl.innerHTML = '<div class="rsm-empty">Nejprve vyberte datum měření.</div>';
    REPORT_SCOPE_MACHINES.items = [];
    return;
  }
  try {
    const r = await api("/api/report/scope-machines", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scope: dateScope }),
    });
    REPORT_SCOPE_MACHINES.items = r.items || [];
  } catch (e) {
    listEl.innerHTML = '<div class="rsm-empty">Seznam strojů se nepodařilo načíst.</div>';
    return;
  }
  renderReportScopeMachines();
}

// Vykreslí checkbox seznam strojů seskupený dle podniku (podle STATE.byId parent).
function renderReportScopeMachines() {
  const listEl = document.getElementById("report-scope-machines-list");
  if (!listEl) return;
  const items = REPORT_SCOPE_MACHINES.items || [];
  if (!items.length) {
    listEl.innerHTML = '<div class="rsm-empty">Žádné stroje s měřením nebyly nalezeny.</div>';
    return;
  }
  // pokud uživatel ještě neupravoval výběr ručně, předvyplň dle in_scope
  const checked = REPORT_SCOPE_MACHINES.checkedIds
    || new Set(items.filter((it) => it.in_scope).map((it) => it.machine_id));

  const groups = new Map();
  for (const it of items) {
    const key = it.plant_name || "—";
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(it);
  }

  let html = "";
  for (const [plantName, machines] of groups) {
    html += `<div class="rsm-plant-group"><div class="rsm-plant-name">${escapeHtml(plantName)}</div>`;
    for (const m of machines) {
      const isChecked = checked.has(m.machine_id);
      const dateLabel = m.last_measured ? String(m.last_measured).slice(0, 10) : "";
      html += `<label class="rsm-machine-row">` +
        `<input type="checkbox" data-mid="${m.machine_id}" ${isChecked ? "checked" : ""} />` +
        `<span class="rsm-machine-name">${escapeHtml(m.machine_name)}</span>` +
        `<span class="rsm-machine-date">${escapeHtml(dateLabel)}</span>` +
        `</label>`;
    }
    html += `</div>`;
  }
  listEl.innerHTML = html;
  listEl.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
    cb.addEventListener("change", () => {
      // první ruční zásah – inicializuj checkedIds z aktuálního (předvyplněného) stavu
      if (!REPORT_SCOPE_MACHINES.checkedIds) {
        REPORT_SCOPE_MACHINES.checkedIds = new Set(
          items.filter((it) => it.in_scope).map((it) => it.machine_id)
        );
      }
      const mid = parseInt(cb.dataset.mid, 10);
      if (cb.checked) REPORT_SCOPE_MACHINES.checkedIds.add(mid);
      else REPORT_SCOPE_MACHINES.checkedIds.delete(mid);
      markReportDraftDirty();
    });
  });
}

function setAllReportScopeMachines(value) {
  const items = REPORT_SCOPE_MACHINES.items || [];
  REPORT_SCOPE_MACHINES.checkedIds = value ? new Set(items.map((it) => it.machine_id)) : new Set();
  renderReportScopeMachines();
  markReportDraftDirty();
}

// Vytvoří nový návrh protokolu na serveru (volitelně s AI závěry).
async function generateReportDraft() {
  const scope = collectReportScope();
  if (scope.mode === "date" && !scope.date) {
    toast("Vyberte datum měření.", true);
    return;
  }
  const useAi = document.getElementById("report-use-ai").checked;
  const reportVersionEl = document.getElementById("report-version");
  const reportVersion = reportVersionEl ? parseInt(reportVersionEl.value, 10) || 1 : 1;
  const showPreviousEl = document.getElementById("report-show-previous");
  const showPrevious = !!(showPreviousEl && showPreviousEl.checked);
  const fullFftEl = document.getElementById("report-full-fft");
  const fullFft = !!(fullFftEl && fullFftEl.checked);
  const modelEl = document.getElementById("report-model");
  const reportModel = modelEl && modelEl.value ? modelEl.value : null;
  const btn = document.getElementById("report-generate-btn");
  const status = document.getElementById("report-gen-status");
  btn.disabled = true;
  status.textContent = useAi
    ? "Sestavuji návrh a generuji AI závěry (může trvat desítky sekund)…"
    : "Sestavuji návrh protokolu…";
  try {
    // při regeneraci zachovej dosavadní výběr grafů (pokud existuje editor)
    const graphSel = collectGraphSelectionsMap();
    // doplňující pokyny pro AI (volitelné) – podmínky měření, koncepce strojů, co vyhodnotit
    const aiCtxEl = document.getElementById("report-ai-context");
    const aiContext = aiCtxEl ? aiCtxEl.value.trim() : "";
    const r = await api("/api/report/draft", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scope, use_ai: useAi, model: reportModel, graph_selections: graphSel, ai_context: aiContext, report_version: reportVersion, show_previous: showPrevious, full_fft: fullFft }),
    });
    REPORT.draft = r.draft;
    // Nový/regenerovaný návrh je nová autoritativní relace; jeho následné
    // autosavy tak nemohou prohrát se starší odpovědí předchozí relace.
    REPORT.sessionId = REPORT_SESSION.newSessionId();
    REPORT.revision += 1;
    REPORT.localSnapshot = true;
    REPORT.draft = _stampReportDraft(REPORT.draft);
    snapshotReportDraft();
    flushReportDraft();
    _showReportRefreshStatus("");
    // nově vygenerovaný návrh – začni s všemi stroji sbalenými
    REPORT.expandedMachines.clear();
    fillReportEditor(r.draft);
    setReportEditorVisible(true);
    _setReportBtns(true);
    const n = (r.draft.machines || []).length;
    let msg = `Návrh vytvořen – ${n} stroj(ů). Upravte text a vygenerujte PDF.`;
    if (r.ai_note) msg += " " + r.ai_note;
    status.textContent = msg;
    // pokud AI závěry selhaly, ukž výraznější upozornění (ne jen stavový řádek)
    if (r.ai_note && useAi) {
      toast(r.ai_note, true);
    } else {
      toast("Návrh protokolu vytvořen.");
    }
  } catch (e) {
    status.textContent = "";
    toast(e.message || "Vytvoření návrhu selhalo.", true);
  } finally {
    btn.disabled = false;
  }
}

// Vypíše výsledek aktualizace do stavového řádku pod hlavičkou protokolu.
function _showReportRefreshStatus(html, isWarn) {
  const el = document.getElementById("report-refresh-status");
  if (!el) return;
  if (!html) {
    el.classList.add("hidden");
    el.innerHTML = "";
    return;
  }
  el.classList.remove("hidden");
  el.classList.toggle("is-warn", !!isWarn);
  el.innerHTML = html;
}

// Sestaví HTML výpisu změn (max několik prvních řádků + počet zbytku).
function _reportRefreshDetailHtml(info) {
  const parts = [];
  const changes = (info && info.changes) || [];
  const shown = changes.slice(0, 12);
  if (shown.length) {
    const items = shown.map((c) => {
      const where = [c.place, c.direction].filter(Boolean).join(" ");
      return `<li>${escapeHtml(c.machine)} – ${escapeHtml(where)}: `
        + `${escapeHtml(c.quantity)} ${escapeHtml(c.from)} → <strong>${escapeHtml(c.to)}</strong></li>`;
    }).join("");
    const more = (info.points_changed || 0) - shown.length;
    parts.push(`<ul class="report-refresh-list">${items}`
      + (more > 0 ? `<li>… a další ${more} změn(a)</li>` : "") + "</ul>");
  }
  const sev = (info && info.severity_changes) || [];
  if (sev.length) {
    const items = sev.map((s) => (
      `<li>${escapeHtml(s.machine)}: celkový stav ${escapeHtml(s.from)} → <strong>${escapeHtml(s.to)}</strong>`
      + (s.manual ? " (ručně přepsaný stav zůstává v platnosti)" : "")
      + " – zkontrolujte prosím závěr a doporučení.</li>"
    )).join("");
    parts.push(`<ul class="report-refresh-list">${items}</ul>`);
  }
  return parts.join("");
}

// „Aktualizovat" – přepočítá stav bodů rozpracovaného protokolu z aktuálně
// uložených limitů karet strojů. Posílá i dosud NEULOŽENÉ úpravy z editoru,
// takže se ruční texty neztratí; server je beze změny přenese do nového návrhu.
async function refreshReportLimits() {
  const btn = document.getElementById("report-refresh-btn");
  let doc = null;
  try {
    doc = collectReportDoc();
  } catch (e) {
    doc = REPORT.draft || null;
  }
  if (!doc || !(doc.machines || []).length) {
    toast("Není k dispozici rozpracovaný návrh protokolu – nejprve vytvořte návrh.", true);
    return;
  }
  const requestRevision = REPORT.revision;
  // vezmi AKTUÁLNĚ zaškrtnutý výběr grafů, ať se překreslí přesně to, co je
  // v editoru vidět (i grafy zaškrtnuté teprve teď, bez uložení)
  try {
    const selMap = collectGraphSelectionsMap();
    (doc.machines || []).forEach((m) => {
      const sels = selMap[String(m.machine_id)] || selMap[m.machine_id];
      if (sels) m.graph_selections = sels;
    });
  } catch (e) { /* výběr grafů není kritický */ }
  const oldLabel = btn ? btn.innerHTML : "";
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Aktualizuji…";
  }
  _showReportRefreshStatus("Přepočítávám stav bodů podle aktuálních limitů…", false);
  try {
    const r = await api("/api/report/refresh", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ doc }),
    });
    if (requestRevision !== REPORT.revision) {
      toast("Aktualizace doběhla po novější úpravě; rozepsaný koncept nebyl přepsán.", true);
      return;
    }
    const info = r.refresh || {};
    REPORT.draft = r.draft;
    REPORT.draft = _stampReportDraft(REPORT.draft);
    snapshotReportDraft();
    // stav rozbalených strojů zůstává – uživatel neztratí místo v editoru
    fillReportEditor(r.draft);
    setReportEditorVisible(true);
    _setReportBtns(true);
    const warn = !!((info.points_changed || 0) || (info.severity_changes || []).length
      || (info.no_limits || []).length || (info.skipped || []).length);
    _showReportRefreshStatus(
      `<strong>${escapeHtml(r.message || "Aktualizováno.")}</strong>`
      + _reportRefreshDetailHtml(info), warn);
    toast(r.message || "Protokol aktualizován podle aktuálních limitů.");
  } catch (e) {
    _showReportRefreshStatus(
      escapeHtml(e.message || "Aktualizace protokolu selhala."), true);
    toast(e.message || "Aktualizace protokolu selhala.", true);
  } finally {
    if (btn) {
      btn.innerHTML = oldLabel;
      btn.disabled = false;
    }
  }
}

// Naplní editor hodnotami z návrhu.
// Naveze listenery pro selektor verze protokolu a upload externího obrázku
// (u verze 3). Bezpečně idempotentní — naváže jen jednou.
function _bindReportVersionUi() {
  const versionEl = document.getElementById("report-version");
  if (versionEl && !versionEl._pplxBound) {
    versionEl.addEventListener("change", () => {
      _syncReportAppendixImageUi();
      // U čerstvého nastavení zachováme historické výchozí chování šablony:
      // detailní V2 dříve vždy ukazovala porovnání; V1/V3 ne.
      const prev = document.getElementById("report-show-previous");
      if (prev && !REPORT.draft) prev.checked = (parseInt(versionEl.value, 10) || 1) === 2;
    });
    versionEl._pplxBound = true;
  }
  const fileEl = document.getElementById("report-appendix-image-file");
  if (fileEl && !fileEl._pplxBound) {
    fileEl.addEventListener("change", _onReportAppendixImageFile);
    fileEl._pplxBound = true;
  }
}

// Zobrazí / skryje panel s uploadem externího obrázku dle zvolené verze.
function _syncReportAppendixImageUi() {
  const wrap = document.getElementById("report-appendix-image-wrap");
  if (!wrap) return;
  const versionEl = document.getElementById("report-version");
  const v = versionEl ? parseInt(versionEl.value, 10) || 1 : 1;
  if (v === 3) wrap.classList.remove("hidden");
  else wrap.classList.add("hidden");
}

// Vykreslí náhled externího obrázku (data URL) pod uploadem.
function _renderAppendixImagePreview(dataUrl) {
  const box = document.getElementById("report-appendix-image-preview");
  if (!box) return;
  if (!dataUrl) { box.innerHTML = ""; return; }
  box.innerHTML = '<img src="' + dataUrl + '" alt="náhled" style="max-width:100%;max-height:220px;border:1px solid #ccc;padding:2px;background:#fff">';
}

// Handler pro upload externího obrázku přílohy: převede na base64 data URL
// (JPEG přímo, PNG překoóduje na JPEG přes <canvas>, protože backend umí jen JPEG)
// a uloží do REPORT.draft.appendix_image.
function _onReportAppendixImageFile(ev) {
  const f = ev && ev.target && ev.target.files && ev.target.files[0];
  if (!f) return;
  const MAX_MB = 6;
  if (f.size > MAX_MB * 1024 * 1024) {
    toast("Obrázek je příliš velký (max " + MAX_MB + " MB).", true);
    ev.target.value = "";
    return;
  }
  const reader = new FileReader();
  reader.onload = (e) => {
    const dataUrl = e.target.result || "";
    // PNG -> překoódovat na JPEG (backend _decode_image podporuje jen JPEG)
    if (f.type === "image/png") {
      const img = new Image();
      img.onload = () => {
        try {
          const c = document.createElement("canvas");
          c.width = img.naturalWidth;
          c.height = img.naturalHeight;
          const ctx = c.getContext("2d");
          ctx.fillStyle = "#fff";
          ctx.fillRect(0, 0, c.width, c.height);
          ctx.drawImage(img, 0, 0);
          const jpeg = c.toDataURL("image/jpeg", 0.92);
          if (!REPORT.draft) REPORT.draft = {};
          REPORT.draft.appendix_image = jpeg;
          markReportDraftDirty();
          _renderAppendixImagePreview(jpeg);
        } catch (err) { toast("Nepodařilo se překonvertovat PNG na JPEG.", true); }
      };
      img.onerror = () => toast("Nepodařilo se načíst obrázek.", true);
      img.src = dataUrl;
    } else {
      if (!REPORT.draft) REPORT.draft = {};
      REPORT.draft.appendix_image = dataUrl;
      markReportDraftDirty();
      _renderAppendixImagePreview(dataUrl);
    }
  };
  reader.readAsDataURL(f);
}

// Zda uživatel název PDF souboru ručně upravil. Dokud ne, držíme v poli
// automaticky složený výchozí název (číslo zakázky-zákazník-název protokolu).
let PDF_FNAME_EDITED = false;

// Očistí část názvu souboru — zrcadlí backend `_sanitize_filename_part`.
// Zachovává písmena (vč. českých), číslice, podtržítko a pomlčku; ostatní → '_'.
function _sanitizeFnamePart(text) {
  const s = String(text == null ? "" : text).trim()
    .replace(/[^\p{L}\p{N}_\-]+/gu, "_");
  return s.replace(/^[_\-]+|[_\-]+$/g, "");
}

// Složí výchozí název PDF: <číslo zakázky>-<zákazník>-<název protokolu>
// (bez přípony .pdf). Zrcadlí backend `_report_pdf_filename`.
function _composeDefaultPdfFilename() {
  const val = (id) => {
    const e = document.getElementById(id);
    return e ? (e.value || "") : "";
  };
  let order = val("rep-order_number").trim();
  if (order === "-" || order === "–" || order === "—") order = "";
  const customer = val("rep-company_name").trim();
  const title = val("rep-report_title").trim();
  const parts = [order, customer, title]
    .map(_sanitizeFnamePart).filter(Boolean);
  return parts.length ? parts.join("-") : "Protokol";
}

// Aktualizuje pole názvu PDF výchozím složeným názvem — jen pokud jej
// uživatel dosud ručně neupravil.
function _syncDefaultPdfFilename() {
  if (PDF_FNAME_EDITED) return;
  const el = document.getElementById("rep-pdf_filename");
  if (el) el.value = _composeDefaultPdfFilename();
}

// Náhled skutečně použitých norem (doc.used_norms) na záložce „Úvodní strana“.
// Jen ke čtení – zrcadlí tabulku, která se vysází do přílohy PDF.
function _fmtNormMm(v) {
  if (v === null || v === undefined || v === "") return "–";
  const f = parseFloat(v);
  if (!isFinite(f)) return "–";
  let s = f.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
  return s.replace(".", ",");
}

function renderUsedNormsPreview(used) {
  const box = document.getElementById("report-used-norms-preview");
  if (!box) return;
  used = Array.isArray(used) ? used : [];
  if (!used.length) {
    box.innerHTML = '<p class="brg-hint" style="margin:0">Zatím nejsou známy žádné konkrétní normy – v příloze se použije obecný popis ČSN ISO 20816. Normy přiřadíte na kartě stroje (pole Norma / třída).</p>';
    return;
  }
  let rows = "";
  used.forEach((rec) => {
    const std = ((rec.standard || "–").trim()) || "–";
    const mc = (rec.machine_class || "").trim();
    const label = mc ? (std + " – " + mc) : std;
    let extra = "";
    const brgs = Array.isArray(rec.bearings) ? rec.bearings : [];
    const machs = Array.isArray(rec.machines) ? rec.machines : [];
    if (brgs.length) extra = "ložiska: " + brgs.join(", ");
    else if (machs.length) extra = "stroje: " + machs.join(", ");
    rows += '<tr><td class="unm-name">' + escapeHtml(label) +
      (extra ? '<span class="unm-extra">' + escapeHtml(extra) + '</span>' : '') + '</td>' +
      '<td class="unm-num">' + escapeHtml(_fmtNormMm(rec.ab)) + '</td>' +
      '<td class="unm-num">' + escapeHtml(_fmtNormMm(rec.warning)) + '</td>' +
      '<td class="unm-num">' + escapeHtml(_fmtNormMm(rec.alarm)) + '</td></tr>';
  });
  box.innerHTML =
    '<table class="unm-table"><thead><tr>' +
    '<th>Norma / třída</th><th class="unm-num">A/B</th>' +
    '<th class="unm-num">B/C (výstraha)</th><th class="unm-num">C/D (alarm)</th>' +
    '</tr></thead><tbody>' + rows + '</tbody></table>' +
    '<p class="brg-hint" style="margin:8px 0 0">Hodnoty [mm/s RMS]. „–“ znamená, že norma danou mez neuvádí.</p>';
}

const REPORT_AI_RESPONSE_SHAPE_ERROR =
  "AI odpověď nemá podporovaný tvar pro návrh protokolu. Zkuste akci zopakovat nebo změňte model.";

function assertReportAiTextContract(doc) {
  if (!doc || !Array.isArray(doc.machines)) return;
  for (const machine of doc.machines) {
    if (!machine || typeof machine !== "object") {
      throw new Error(REPORT_AI_RESPONSE_SHAPE_ERROR);
    }
    for (const field of ["problem", "zaver", "doporuceni"]) {
      if (machine[field] != null && typeof machine[field] !== "string") {
        throw new Error(REPORT_AI_RESPONSE_SHAPE_ERROR);
      }
    }
  }
}

function fillReportEditor(doc) {
  // Backend odmítá poškozený AI výstup; toto je obrana pro starší uložený
  // návrh nebo nečekanou odpověď API. Objekt se nikdy nesmí tiše převést na
  // text a dostat do editoru/PDF/DOCX.
  assertReportAiTextContract(doc);
  const set = (id, val) => {
    const e = document.getElementById(id);
    if (e) e.value = (val == null ? "" : val);
  };
  const previousToggle = document.getElementById("report-show-previous");
  if (previousToggle) {
    const rv = parseInt(doc.report_version, 10) || 1;
    previousToggle.checked = doc.show_previous != null ? !!doc.show_previous : rv === 2;
  }
  set("rep-header_left", doc.header_left);
  set("rep-company_name", doc.company_name);
  set("rep-company_address", doc.company_address);
  set("rep-measured_at", doc.measured_at);
  set("rep-report_title", doc.report_title);
  set("rep-order_number", doc.order_number);
  set("rep-contract_number", doc.contract_number);
  set("rep-date_created", doc.date_created);
  set("rep-date_measured", doc.date_measured);
  set("rep-created_by", doc.created_by);
  set("rep-measured_by", doc.measured_by);
  set("rep-measured_by2", doc.measured_by2);
  set("rep-approved_by", doc.approved_by);
  set("rep-intro", doc.intro);
  set("rep-appendix_intro", doc.appendix_intro);
  // náhled skutečně použitých norem v příloze (jen ke čtení)
  renderUsedNormsPreview(doc.used_norms);
  // napln datalist techniků (auto-doplňování polí Vypracoval / Měřil / Schválil)
  loadTechDatalist();
  // název PDF souboru: použij uložený (uživatelský) název, jinak slož výchozí
  {
    const savedFn = (doc.pdf_filename || "").trim();
    if (savedFn) {
      PDF_FNAME_EDITED = true;
      set("rep-pdf_filename", savedFn.replace(/\.pdf$/i, ""));
    } else {
      PDF_FNAME_EDITED = false;
      set("rep-pdf_filename", _composeDefaultPdfFilename());
    }
  }

  const wrap = document.getElementById("report-machines");
  wrap.innerHTML = "";
  const machines = doc.machines || [];
  if (!machines.length) {
    wrap.innerHTML = '<div class="mp-lim-hint">V tomto okruhu nebyl nalezen žádný měřený stroj.</div>';
    return;
  }
  const reportVersion = parseInt(doc.report_version, 10) || 1;
  const showPrevious = doc.show_previous != null
    ? !!doc.show_previous : reportVersion === 2;
  // odraz stav obrázku přílohy (verze 3)
  const capEl = document.getElementById("report-appendix-image-caption");
  if (capEl) capEl.value = doc.appendix_image_caption || "";
  _renderAppendixImagePreview(doc.appendix_image || "");
  _syncReportAppendixImageUi();
  machines.forEach((m, i) => {
    // Automatický stav (odvozený z pásem v tabulce) si vždy dopočítáme pro
    // popisek volby "Automaticky" — i u starších návrhů bez auto_severity.
    if (!m.auto_severity) {
      m.auto_severity = _autoSeverityFromBand(m.worst_band);
      m.auto_severity_label = SEV_MODEL_LABELS[m.auto_severity] || "";
    }
    const sevCls = "sev-" + (m.severity || "none");
    const mKey = _reportMachineKey(m, i);
    const isExpanded = REPORT.expandedMachines.has(mKey);
    const block = document.createElement("div");
    block.className = "report-machine-block" + (isExpanded ? "" : " collapsed");
    block.dataset.idx = i;
    block.dataset.machineKey = mKey;
    block.dataset.machineId = (m.machine_id == null ? "" : m.machine_id);
    const tablesHtml = renderOverallTable(m, reportVersion, {
      withPrev: showPrevious,
      balance: reportVersion === 3 && showPrevious,
    });
    const measurementSelectors = renderMeasurementSelectors(m, showPrevious);
    block.innerHTML = `
      <div class="report-machine-head ${sevCls}" role="button" tabindex="0">
        <span class="rm-toggle">▸</span>
        <span class="rm-name">${escapeHtml(m.name || "Stroj")}</span>
        <span class="rm-sev">${escapeHtml(m.severity_label || "")}</span>
      </div>
      <div class="report-machine-body">
        <div class="brg-field brg-field-wide rm-sev-field">
          <label>Celkový stav stroje</label>
          <select class="brg-in rm-sevoverride">
            <option value="">Automaticky (${escapeHtml(m.auto_severity_label || "—")})</option>
            <option value="ok">OK (zelená)</option>
            <option value="alarm">Upozornění (žlutá)</option>
            <option value="warn">Výstraha (červená)</option>
          </select>
          <div class="mp-lim-hint rm-sev-hint">Výchozí stav vychází pouze z hodnot a pásem v tabulce níže. Zde jej lze pro protokol ručně přepsat.</div>
        </div>
        ${measurementSelectors}
        ${tablesHtml}
        <div class="brg-field brg-field-wide">
          <label>Popis problému</label>
          <input class="brg-in rm-problem" type="text" value="${escapeHtml(m.problem || "")}" placeholder="stručně, např. zvýšené vibrace ložiska L2" />
        </div>
        <div class="brg-field brg-field-wide">
          <label>Závěry</label>
          <textarea class="brg-in rm-zaver report-textarea" rows="3">${escapeHtml(m.zaver || "")}</textarea>
        </div>
        <div class="brg-field brg-field-wide">
          <label>Doporučení</label>
          <textarea class="brg-in rm-doporuceni report-textarea" rows="3">${escapeHtml(m.doporuceni || "")}</textarea>
        </div>
        <div class="norm-form-actions">
          <button type="button" class="cb-btn rm-promote" title="Uložit tento závěr a doporučení do znalostní báze AI jako vzor">Povýšit na vzor AI</button>
        </div>
        ${renderGraphPicker(m)}
      </div>
    `;
    // rozbalení / sbalení stroje kliknutím na hlavičku; stav si pamatujeme,
    // aby při příštím překreslení zůstal daný stroj otevřený
    const head = block.querySelector(".report-machine-head");
    const toggle = () => {
      const nowCollapsed = block.classList.toggle("collapsed");
      if (nowCollapsed) REPORT.expandedMachines.delete(mKey);
      else REPORT.expandedMachines.add(mKey);
    };
    head.addEventListener("click", toggle);
    head.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); }
    });
    // ruční přepis celkového stavu stroje pro protokol
    const sevSel = block.querySelector(".rm-sevoverride");
    if (sevSel) {
      sevSel.value = (m.severity_override && m.severity_override !== "") ? m.severity_override : "";
      sevSel.addEventListener("change", () => {
        const ov = sevSel.value;
        if (ov) {
          m.severity_override = ov;
          m.severity = ov;
          m.severity_manual = true;
        } else {
          m.severity_override = "";
          m.severity = m.auto_severity || "none";
          m.severity_manual = false;
        }
        m.severity_label = SEV_MODEL_LABELS[m.severity] || "";
        // živě překresli hlavičku (barva + popisek)
        head.className = "report-machine-head sev-" + (m.severity || "none");
        const sevSpan = head.querySelector(".rm-sev");
        if (sevSpan) {
          sevSpan.textContent = m.severity_label
            + (m.severity_manual ? " (ručně)" : "");
        }
      });
      // úvodní popisek stavu (ručně) při načtení, je-li přepis aktivní
      if (m.severity_manual) {
        const sevSpan = head.querySelector(".rm-sev");
        if (sevSpan) sevSpan.textContent = (m.severity_label || "") + " (ručně)";
      }
    }
    // Povýšit na vzor AI – načte živé hodnoty z polí a předvyplní znalostní bázi
    const promoteBtn = block.querySelector(".rm-promote");
    if (promoteBtn) {
      promoteBtn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const gvv = (sel) => { const el = block.querySelector(sel); return el ? (el.value || "").trim() : ""; };
        const zaver = gvv(".rm-zaver");
        if (!zaver) { toast("Nejprve vyplňte pole „Závěry“ – vzor musí obsahovat závěr.", true); return; }
        const sevNow = (sevSel && sevSel.value) ? sevSel.value : (m.severity || m.auto_severity || "");
        const rv = (REPORT && REPORT.draft && REPORT.draft.report_version) || 2;
        promoteToAiExample({
          machine_kind: null,
          report_version: rv,
          severity: (sevNow === "none" ? "" : sevNow),
          situation: gvv(".rm-problem"),
          zaver: zaver,
          doporuceni: gvv(".rm-doporuceni"),
        });
      });
    }
    // Manuální pásmo jedné kategorie je reportové rozhodnutí: nikdy nemění
    // kartu stroje ani .ndb. Celkový stav se ihned odvodí z efektivních pásem.
    block.querySelectorAll(".oc-category-state").forEach((sel) => {
      sel.addEventListener("change", () => {
        const place = sel.dataset.place || "";
        const row = (m.rows || []).find((r) => (r.place || "") === place);
        const bearing = (m.bearings_summary || []).find((b) => (b.place || "") === place);
        const override = REPORT_MANUAL_BANDS.has(sel.value) ? sel.value : "";
        if (sel.dataset.category === "velocity" && row) row.vel_band_override = override;
        if (sel.dataset.category === "accel" && bearing) bearing.acc_band_override = override;
        if (sel.dataset.category === "env" && bearing) bearing.env_band_override = override;
        _recomputeReportCategoryStates(m);
        _refreshReportStateControls(block, m, head);
      });
    });
    block.querySelectorAll(".rep-measurement-select").forEach((sel) => {
      sel.addEventListener("change", () => {
        const place = sel.dataset.place || "";
        const kind = sel.dataset.kind === "previous" ? "previous" : "current";
        const direction = sel.dataset.direction || "";
        m.measurement_selection = m.measurement_selection || {};
        const selected = m.measurement_selection[place] = m.measurement_selection[place] || {
          schema: 2, current: {}, previous: {}
        };
        selected.schema = 2;
        selected.current = selected.current || {};
        selected.previous = selected.previous || {};
        if (direction) selected[kind][direction] = sel.value || "";
        // Odešli celý živý draft: backend přepočítá výhradně vybraný výskyt
        // a současně zachová ruční texty. Token brání opožděné odpovědi
        // přepsat novější volbu uživatele.
        const panelWasOpen = !!block.querySelector(".report-measurement-selectors[open]");
        const scrollY = window.scrollY;
        const token = (REPORT.measurementSelectionToken || 0) + 1;
        REPORT.measurementSelectionToken = token;
        markReportDraftDirty();
        const docNow = collectReportDoc();
        api("/api/report/refresh", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ doc: docNow }),
        }).then((r) => {
          if (token !== REPORT.measurementSelectionToken || !r || !r.draft) return;
          REPORT.draft = _stampReportDraft(r.draft);
          fillReportEditor(REPORT.draft);
          if (panelWasOpen) {
            document.querySelectorAll(".report-measurement-selectors").forEach((panel) => {
              if (panel.dataset.machineId === String(m.machine_id)) panel.open = true;
            });
          }
          window.scrollTo(0, scrollY);
          snapshotReportDraft();
        }).catch(() => {
          if (token === REPORT.measurementSelectionToken) {
            toast("Vybraný výskyt se nepodařilo přepočítat.", true);
          }
        });
      });
    });
    block.querySelectorAll(".rep-measurement-reset").forEach((button) => {
      button.addEventListener("click", () => {
        const place = button.dataset.place || "";
        m.measurement_selection = m.measurement_selection || {};
        m.measurement_selection[place] = { schema: 2, current: {}, previous: {} };
        const panelWasOpen = !!block.querySelector(".report-measurement-selectors[open]");
        const scrollY = window.scrollY;
        const token = (REPORT.measurementSelectionToken || 0) + 1;
        REPORT.measurementSelectionToken = token;
        markReportDraftDirty();
        api("/api/report/refresh", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ doc: collectReportDoc() }),
        }).then((r) => {
          if (token !== REPORT.measurementSelectionToken || !r || !r.draft) return;
          REPORT.draft = _stampReportDraft(r.draft);
          fillReportEditor(REPORT.draft);
          if (panelWasOpen) {
            document.querySelectorAll(".report-measurement-selectors").forEach((panel) => {
              if (panel.dataset.machineId === String(m.machine_id)) panel.open = true;
            });
          }
          window.scrollTo(0, scrollY);
          snapshotReportDraft();
        }).catch(() => {
          if (token === REPORT.measurementSelectionToken) toast("Poslední hodnoty se nepodařilo obnovit.", true);
        });
      });
    });
    // interakce v pickeru grafů (podzáložky, ruční počet bodů, náhled)
    wireGraphPicker(block);
    // zaškrtávátka "Zahrnout" u tabulky celkových hodnot – živě znečitelňuj řádek
    block.querySelectorAll(".rep-point-incl input[type=checkbox]").forEach((cb) => {
      cb.addEventListener("change", () => {
        const tr = cb.closest("tr");
        if (tr) tr.classList.toggle("rep-row-excluded", !cb.checked);
      });
    });
    wrap.appendChild(block);
  });
}


const REPORT_MANUAL_BANDS = new Set(["A", "B", "C", "D"]);
function _effectiveReportBand(autoBand, override) {
  return REPORT_MANUAL_BANDS.has(override) ? override : (autoBand || "");
}
function _worstReportBand(...bands) {
  const rank = { A: 1, B: 2, C: 3, D: 4 };
  return bands.reduce((worst, band) => (!worst || (rank[band] || 0) > (rank[worst] || 0)) ? (band || worst) : worst, "");
}
function _recomputeReportCategoryStates(m) {
  const rows = m.rows || [];
  const byPlace = {};
  rows.forEach((r) => {
    if (r.vel_auto_band === undefined) r.vel_auto_band = r.vel_band || "";
    r.vel_band = _effectiveReportBand(r.vel_auto_band, r.vel_band_override);
    byPlace[r.place || ""] = r;
  });
  (m.bearings_summary || []).forEach((b) => {
    if (b.acc_auto_band === undefined) b.acc_auto_band = b.acc_band || "";
    if (b.env_auto_band === undefined) b.env_auto_band = b.env_band || "";
    b.acc_band = _effectiveReportBand(b.acc_auto_band, b.acc_band_override);
    b.env_band = _effectiveReportBand(b.env_auto_band, b.env_band_override);
    // Stav ložiska je výhradně nejhorší ACC/ENV. Pásmo rychlosti zůstává
    // vlastní informací ve sloupci Pásmo a do pravého stavu ložiska nepatří.
    b.bearing_auto_state = _worstReportBand(b.acc_auto_band, b.env_auto_band);
    b.bearing_state = _worstReportBand(b.acc_band, b.env_band);
  });
  const bands = [];
  rows.forEach((r) => bands.push(r.vel_band));
  (m.bearings_summary || []).forEach((b) => bands.push(b.bearing_state));
  m.worst_band = _worstReportBand(...bands);
  m.auto_severity = _autoSeverityFromBand(m.worst_band);
  m.auto_severity_label = SEV_MODEL_LABELS[m.auto_severity] || "";
  if (!m.severity_override) {
    m.severity = m.auto_severity;
    m.severity_label = m.auto_severity_label;
    m.severity_manual = false;
  }
}
function _reportStateControl(category, place, autoBand, override) {
  const opt = (value, label) => `<option value="${value}"${override === value ? " selected" : ""}>${label}</option>`;
  const label = category === "velocity" ? "Pásmo rychlosti" :
    (category === "accel" ? "Pásmo zrychlení" : "Pásmo obálky");
  return `<select class="oc-category-state" data-category="${category}" data-place="${escapeHtml(place)}" aria-label="${label}">
    ${opt("", `Automaticky (${autoBand || "—"})`)}${opt("A", "A")}${opt("B", "B")}${opt("C", "C")}${opt("D", "D")}
  </select>`;
}
function _reportStateMenu(kind, place, v, b) {
  // Uzavřený summary obsahuje výhradně znak pásma. Vysvětlení patří do
  // přístupného názvu a do skrytého popoveru, nikdy do kompaktní buňky.
  const isVelocity = kind === "velocity";
  const effective = isVelocity ? v.vel_band : b.bearing_state;
  const manual = isVelocity
    ? REPORT_MANUAL_BANDS.has(v.vel_band_override)
    : (REPORT_MANUAL_BANDS.has(b.acc_band_override) || REPORT_MANUAL_BANDS.has(b.env_band_override));
  const label = isVelocity ? "Pásmo rychlosti" : "Stav ložiska (zrychlení a obálka)";
  const state = effective || "—";
  const controls = isVelocity
    ? `<label>Pásmo rychlosti${_reportStateControl("velocity", place, v.vel_auto_band || "", v.vel_band_override || "")}</label>`
    : `<label>Zrychlení${_reportStateControl("accel", place, b.acc_auto_band || "", b.acc_band_override || "")}</label>
       <label>Obálka${_reportStateControl("env", place, b.env_auto_band || "", b.env_band_override || "")}</label>`;
  const manualText = manual ? ", ručně" : "";
  return `<details class="oc-state-menu" data-state-menu="${kind}" data-place="${escapeHtml(place)}">
    <summary data-state-badge="${kind}" aria-label="${label}: ${escapeHtml(state)}${manualText}; otevřít ruční klasifikaci">${escapeHtml(state)}</summary>
    <div class="oc-state-popover" role="group" aria-label="${label}">
      <strong>${label}</strong>${controls}
      ${isVelocity ? "" : '<p>Pravý stav je nejhorší z účinných pásem zrychlení a obálky.</p>'}
    </div>
  </details>`;
}
function _reportStateCell(kind, place, v, b) {
  const isVelocity = kind === "velocity";
  const effective = isVelocity ? v.vel_band : b.bearing_state;
  const manual = isVelocity
    ? REPORT_MANUAL_BANDS.has(v.vel_band_override)
    : (REPORT_MANUAL_BANDS.has(b.acc_band_override) || REPORT_MANUAL_BANDS.has(b.env_band_override));
  const label = isVelocity ? "Pásmo rychlosti" : "Stav ložiska (zrychlení a obálka)";
  // .oc-band je záměrně na TD stejně jako ve vzhledu 1.35.0: barva, šířka,
  // padding a zarovnání jsou tak shodné s původní kompaktní tabulkou.
  const bandClass = _bandCls(effective) || "oc-band oc-band-none";
  return `<td class="${bandClass} oc-state-cell${manual ? " oc-state-manual" : ""}"${manual ? ` title="${label}: ruční klasifikace"` : ""}>${_reportStateMenu(kind, place, v, b)}</td>`;
}

function _refreshReportStateControls(block, m, head) {
  const rows = Object.fromEntries((m.rows || []).map((r) => [r.place || "", r]));
  const brgs = Object.fromEntries((m.bearings_summary || []).map((b) => [b.place || "", b]));
  block.querySelectorAll(".oc-category-state").forEach((sel) => {
    const r = rows[sel.dataset.place] || {};
    const b = brgs[sel.dataset.place] || {};
    const isVel = sel.dataset.category === "velocity";
    const isAcc = sel.dataset.category === "accel";
    const override = isVel ? r.vel_band_override : (isAcc ? b.acc_band_override : b.env_band_override);
    sel.value = REPORT_MANUAL_BANDS.has(override) ? override : "";
    sel.className = "oc-category-state";
  });
  block.querySelectorAll("[data-state-badge]").forEach((el) => {
    const place = el.closest("[data-place]")?.dataset.place || "";
    const b = brgs[place] || {};
    const r = rows[place] || {};
    const isVelocity = el.dataset.stateBadge === "velocity";
    const band = isVelocity ? r.vel_band : b.bearing_state;
    const manual = isVelocity
      ? REPORT_MANUAL_BANDS.has(r.vel_band_override)
      : (REPORT_MANUAL_BANDS.has(b.acc_band_override) || REPORT_MANUAL_BANDS.has(b.env_band_override));
    const label = isVelocity ? "Pásmo rychlosti" : "Stav ložiska (zrychlení a obálka)";
    const cell = el.closest(".oc-state-cell");
    if (cell) {
      cell.className = (_bandCls(band) || "oc-band oc-band-none") + " oc-state-cell" + (manual ? " oc-state-manual" : "");
      if (manual) cell.title = label + ": ruční klasifikace";
      else cell.removeAttribute("title");
    }
    el.textContent = band || "—";
    el.setAttribute("aria-label", `${label}: ${band || "—"}${manual ? ", ručně" : ""}; otevřít ruční klasifikaci`);
  });
  if (!m.severity_override) {
    head.className = "report-machine-head sev-" + (m.severity || "none");
    const label = head.querySelector(".rm-sev");
    if (label) label.textContent = m.severity_label || "";
    const machineSelect = block.querySelector(".rm-sevoverride");
    if (machineSelect) machineSelect.options[0].textContent = `Automaticky (${m.auto_severity_label || "—"})`;
  }
}

// Barevné pásmo (A/B/C/D) -> CSS třída pro buňku v tabulce.
function _bandCls(b) {
  return b ? ("oc-band oc-band-" + b) : "";
}

// Nový návrh má pro každé ložisko jeden kanonický řádek s vítězným směrem
// rychlosti H/V/A. Seskupení níže chrání vykreslení staršího návrhu s
// duplicitními řádky.
function _velMaxByPlace(rows) {
  const best = {};
  const order = [];
  (rows || []).forEach((r) => {
    const p = r.place || "";
    const cur = (r.vel_cur == null) ? -Infinity : r.vel_cur;
    if (!(p in best)) { best[p] = r; order.push(p); }
    else if (cur > ((best[p].vel_cur == null) ? -Infinity : best[p].vel_cur)) {
      best[p] = r;
    }
  });
  return order.map((p) => best[p]);
}

function renderMeasurementSelectors(m, showPrevious) {
  const summaries = m.bearings_summary || [];
  if (!summaries.some((b) => Object.values(b.measurement_directions || {}).some((d) => (d.options || []).length))) return "";
  const options = (items, selected, none) => {
    let html = none ? '<option value="__none__">Žádná</option>' : "";
    (items || []).forEach((o) => {
      const chosen = String(o.id) === String(selected || "") ? " selected" : "";
      const disabled = o.usable === false ? " disabled" : "";
      html += `<option value="${escapeHtml(o.id || "")}"${chosen}${disabled}>${escapeHtml(o.label || o.id || "")}</option>`;
    });
    return html;
  };
  const num = (value, unit) => value == null ? "—" : `${fmtNum(value, 2)} ${unit}`;
  const preview = (rec, kind) => {
    const values = (rec && (kind === "previous" ? rec.previous_preview : rec.current_preview)) || {};
    const quantities = m.protocol_quantities || {};
    const when = kind === "previous" ? "Porovnávaný výskyt" : "Vybraný výskyt";
    return `<span class="rep-measurement-preview" aria-live="polite">${when}: R ${num(values[quantities.velocity], "mm/s")} · Z ${num(values[quantities.accel], "g")} · O ${num(values[quantities.env], "g")}</span>`;
  };
  const selector = (place, direction, rec, kind) => {
    const current = kind === "previous" ? rec.previous_id : rec.current_id;
    const field = kind === "previous" ? "Porovnání" : "Aktuální";
    const available = kind === "previous" ? rec.previous_options : rec.options;
    return `<label class="rep-measurement-direction"><span>${field} ${direction}</span>
      <select class="brg-in rep-measurement-select" data-kind="${kind}" data-direction="${direction}" data-place="${escapeHtml(place)}">${options(available, current, kind === "previous")}</select>
      ${preview(rec, kind)}</label>`;
  };
  let rows = "";
  summaries.forEach((b) => {
    const directions = b.measurement_directions || {};
    const available = ["H", "V", "A"].filter((direction) => (directions[direction] || {}).options?.length);
    if (!available.length) return;
    const velocity = (m.rows || []).find((row) => (row.place || "") === (b.place || "")) || {};
    const summary = `R ${velocity.vel_cur == null ? "—" : fmtNum(velocity.vel_cur, 2) + " (" + (velocity.direction || "") + ")"} · Z ${b.acc_cur == null ? "—" : fmtNum(b.acc_cur, 2) + " (" + (b.acc_dir || "") + ")"} · O ${b.env_cur == null ? "—" : fmtNum(b.env_cur, 2) + " (" + (b.env_dir || "") + ")"}`;
    rows += `<section class="rep-measurement-row"><div class="rep-measurement-bear-head"><strong>${escapeHtml(b.place || "Ložisko")}</strong><span>${escapeHtml(summary)}</span><button type="button" class="cb-btn rep-measurement-reset" data-place="${escapeHtml(b.place || "")}">Použít poslední H/V/A</button></div>
      <div class="rep-measurement-directions">${available.map((direction) => selector(b.place || "", direction, directions[direction], "current")).join("")}</div>
      ${showPrevious ? `<div class="rep-measurement-directions rep-measurement-previous">${available.map((direction) => selector(b.place || "", direction, directions[direction], "previous")).join("")}</div>` : ""}
      ${(b.measurement_fallback_directions || []).length ? `<span class="brg-hint-inline">Zvolený výskyt nebyl nalezen; obnovena poslední hodnota směru ${(b.measurement_fallback_directions || []).join("/")}.</span>` : ""}
      ${b.measurement_migration_notice ? `<span class="brg-hint-inline">Starý společný výběr byl bezpečně převeden jen tam, kde jej lze prokázat; ostatní směry používají poslední hodnotu.</span>` : ""}
    </section>`;
  });
  return `<details class="report-measurement-selectors" data-machine-id="${escapeHtml(m.machine_id || "")}"><summary>Výběr měření ložisek <span>Výchozí: poslední H/V/A</span></summary><div class="report-measurement-content"><p class="brg-hint-inline">Každý směr H/V/A má vlastní přesný výskyt. Tabulka používá maximum vybraných směrů; DDS se mezi směry časově nespojuje.</p>${rows}</div></details>`;
}

// Sjednocená kompaktní tabulka — jeden řádek na ložisko. Pásmo patří jen
// rychlosti; pravý Stav ložiska je nejhorší ACC/ENV. Kliknutím na badge se
// otevře skrytá, klávesnicí ovladatelná reportová ruční klasifikace.
// Signatura (zpětně kompatibilní): renderOverallTable(m, withPrev)
//                       (nová):        renderOverallTable(m, version, {withPrev, balance})
// * `withPrev=true` (verze 2) přidá sloupec s předchozí naměřenou hodnotou
//   rychlosti (stejný směr jako aktuální max.).
// * `balance=true` (verze 3 — vyvažování) přidá sloupce PŘED / pásmo /
//   PO / pásmo / úspěšnost [%]. Zrcadlí backend _overall_table (report_pdf.py).
function renderOverallTable(m, versionOrWithPrev, opts) {
  let withPrev = false, balance = false;
  if (typeof versionOrWithPrev === "boolean") withPrev = versionOrWithPrev;
  else if (opts && typeof opts === "object") { withPrev = !!opts.withPrev; balance = !!opts.balance; }
  else { const v = parseInt(versionOrWithPrev, 10) || 1; withPrev = v === 2; balance = v === 3; }
  _recomputeReportCategoryStates(m);
  const velMax = _velMaxByPlace(m.rows || []), brg = m.bearings_summary || [];
  if (!velMax.length && !brg.length) return "";
  const velByPlace = Object.fromEntries(velMax.map((r) => [r.place || "", r]));
  const brgByPlace = Object.fromEntries(brg.map((b) => [b.place || "", b]));
  const places = [...new Set(brg.map((b) => b.place || "").concat(velMax.map((r) => r.place || "")))];
  const keysByPlace = {};
  (m.rows || []).forEach((r) => { const place = r.place || ""; (keysByPlace[place] || (keysByPlace[place] = [])).push(place + "|" + (r.direction || "")); });
  const excluded = new Set(m.excluded_points || []);
  const val = (x) => x != null ? fmtNum(x, 2) : "—";
  let rowsHtml = "";
  places.forEach((place) => {
    const v = velByPlace[place] || {}, b = brgByPlace[place] || {};
    const keys = keysByPlace[place] || [place + "|" + (v.direction || "")];
    const isExcluded = keys.length && keys.every((key) => excluded.has(key));
    const incl = `<td class="rep-incl-cell"><label class="rep-point-incl" title="Zahrnout do protokolu a hodnocení"><input type="checkbox" data-rowkey="${escapeHtml(keys.join(","))}"${isExcluded ? "" : " checked"} /></label></td>`;
    const velState = _reportStateCell("velocity", place, v, b);
    const bearingState = _reportStateCell("bearing", place, v, b);
    const velText = v.vel_cur != null ? val(v.vel_cur) + (v.direction ? " (" + escapeHtml(v.direction) + ")" : "") : "—";
    const accText = b.acc_cur != null ? val(b.acc_cur) + (b.acc_dir ? " (" + escapeHtml(b.acc_dir) + ")" : "") : "—";
    const envText = b.env_cur != null ? val(b.env_cur) + (b.env_dir ? " (" + escapeHtml(b.env_dir) + ")" : "") : "—";
    const prevText = v.vel_prev != null ? val(v.vel_prev) + (v.vel_prev_dir ? " (" + escapeHtml(v.vel_prev_dir) + ")" : "") : "—";
    const trClass = isExcluded ? ' class="rep-row-excluded"' : "";
    if (balance) rowsHtml += `<tr${trClass}>${incl}<td>${escapeHtml(place)}</td><td class="oc-num">${prevText}</td><td class="${_bandCls(v.vel_prev_band) || "oc-band oc-band-none"}">${escapeHtml(v.vel_prev_band || "—")}</td><td class="oc-num">${velText}</td>${velState}<td class="oc-num">${typeof v.balance_success_pct === "number" ? (v.balance_success_pct >= 0 ? "+" : "") + v.balance_success_pct.toFixed(0) + " %" : "—"}</td><td class="oc-num">${accText}</td><td class="oc-num">${envText}</td>${bearingState}</tr>`;
    else rowsHtml += `<tr${trClass}>${incl}<td>${escapeHtml(place)}</td>${withPrev ? `<td class="oc-num">${prevText}</td>` : ""}<td class="oc-num">${velText}</td>${velState}<td class="oc-num">${accText}</td><td class="oc-num">${envText}</td>${bearingState}</tr>`;
  });
  const prev = withPrev ? '<th class="oc-num">Porovnávací rychlost max. H/V/A</th>' : "";
  const balanceHeads = balance ? '<th class="oc-num">Porovnávací max. H/V/A</th><th>Pásmo před</th><th class="oc-num">Aktuální max. H/V/A</th><th>Pásmo</th><th class="oc-num">Úspěšnost</th>' : `${prev}<th class="oc-num">Rychlost max. H/V/A</th><th>Pásmo</th>`;
  return `<div class="overall-tables"><div class="oc-wrap"><div class="oc-title">Rychlost = maximum vybraných H/V/A [mm/s]; každý směr výchozně používá své poslední platné měření, (H)/(V)/(A) = vítězný směr. Zrychlení a obálka [g] se berou <strong>pouze z horizontálního směru H</strong> — stav ložiska je ukazatel jednoho měřicího místa. Pásmo = rychlost, Stav ložiska = nejhorší ze zrychlení a obálky.</div><table class="oc-table${balance ? " oc-table-balance" : ""}"><thead><tr><th class="rep-incl-cell">Zahrnout</th><th>Ložisko</th>${balanceHeads}<th class="oc-num">Zrychlení H</th><th class="oc-num">Obálka H</th><th>Stav ložiska</th></tr></thead><tbody>${rowsHtml}</tbody></table></div></div>`;
}
// Druhy grafů nabízené u každého měřicího bodu (kind -> popisek), rozdělené
// do dvou skupin: statické hodnoty (trendy) a FFT spektra.
const TREND_KIND_OPTS = [
  { kind: "trend_vel",     label: "Trend rychlosti" },
  { kind: "trend_acc",     label: "Trend zrychlení" },
  { kind: "trend_env",     label: "Trend obálky" },
];
const SPECTRUM_KIND_OPTS = [
  { kind: "spectrum_vel",  label: "FFT rychlosti" },
  { kind: "spectrum_acc",  label: "FFT zrychlení" },
  { kind: "spectrum_env",  label: "FFT obálky" },
];
const GRAPH_KIND_OPTS = TREND_KIND_OPTS.concat(SPECTRUM_KIND_OPTS);

// Nabídka značek do FFT spektra (marker -> popisek).
const SPECTRUM_MARKER_OPTS = [
  { marker: "speed",    label: "Otáčková (1× RPM)" },
  { marker: "harmonics", label: "Harmonické otáček (2×, 3×…)" },
  { marker: "bearing",  label: "Ložiskové (BPFO/BPFI/BSF/FTF)" },
];

// Staré kindy mapujeme na nové (zpětná kompatibilita uloženého výběru).
function _normGraphKind(k) {
  if (k === "trend") return "trend_vel";
  if (k === "spectrum") return "spectrum_vel";
  return k;
}

// Sestaví výběr grafů do protokolu. Každý měřicí bod má vlastní podzáložku;
// uvnitř je výběr rozdělen do dvou skupin – statické hodnoty (trendy) a FFT
// spektra – každá s vlastním komentářem. U trendů lze zvolit počet bodů (včetně
// „Vše" a ručního zadání), u spekter značky. Po zaškrtnutí lze zobrazit
// interaktivní náhled (zoom, uživatelské značky), jehož nastavení se přenáš
// do PDF.
function renderGraphPicker(m) {
  const pts = m.points_index || [];
  if (!pts.length) return "";
  // mapy již vybraných grafů: klíč "<point_id>|<kind>" -> selekce (celý item)
  const selMap = {};
  (m.graph_selections || []).forEach((s) => {
    if (s && s.point_id != null && s.kind) {
      selMap[s.point_id + "|" + _normGraphKind(s.kind)] = s;
    }
  });
  // per-kind uložený stav náhledu (zoom rozsah + značky + komentář)
  const selFor = (pid, kind) => selMap[pid + "|" + kind] || null;

  let tabs = "";
  let panels = "";
  pts.forEach((p, idx) => {
    const pid = p.point_id;
    const nm = escapeHtml(p.point_name || ("" + pid));
    // označ podzáložku, která má aspoň jeden vybraný graf
    const anySel = TREND_KIND_OPTS.concat(SPECTRUM_KIND_OPTS)
      .some((o) => (pid + "|" + o.kind) in selMap);
    const dot = anySel ? '<span class="gp-tab-dot" title="Vybrané grafy"></span>' : "";
    tabs += `<button type="button" class="gp-tab${idx === 0 ? " active" : ""}" data-gp-tab="${pid}">${nm}${dot}</button>`;

    // --- skupina TRENDY ---
    let trendOpts = "";
    TREND_KIND_OPTS.forEach((o) => {
      const chk = (pid + "|" + o.kind) in selMap ? "checked" : "";
      trendOpts += `<label class="graph-pick-opt gp-kind-line">`
        + `<input type="checkbox" class="gp-kind" data-kind="${o.kind}" ${chk}/> ${o.label}`
        + `<button type="button" class="gp-preview-btn" data-kind="${o.kind}" title="Náhled grafu">Náhled</button>`
        + `</label>`;
    });
    // --- skupina FFT SPEKTRA ---
    let specOpts = "";
    SPECTRUM_KIND_OPTS.forEach((o) => {
      const chk = (pid + "|" + o.kind) in selMap ? "checked" : "";
      specOpts += `<label class="graph-pick-opt gp-kind-line">`
        + `<input type="checkbox" class="gp-kind" data-kind="${o.kind}" ${chk}/> ${o.label}`
        + `<button type="button" class="gp-preview-btn" data-kind="${o.kind}" title="Náhled grafu">Náhled</button>`
        + `</label>`;
    });
    // skryté pole s per-kind stavem náhledu (JSON):
    // {kind: {x_range, user_markers, note, auto_markers}}
    const previewState = {};
    TREND_KIND_OPTS.concat(SPECTRUM_KIND_OPTS).forEach((o) => {
      const s = selFor(pid, o.kind);
      if (!s) return;
      const hasState = s.x_range
        || (Array.isArray(s.user_markers) && s.user_markers.length)
        || (s.note && s.note.trim())
        || (Array.isArray(s.markers) && s.markers.length);
      if (hasState) {
        previewState[o.kind] = {
          x_range: s.x_range || null,
          user_markers: Array.isArray(s.user_markers) ? s.user_markers : [],
          note: s.note || "",
          auto_markers: Array.isArray(s.markers) ? s.markers : [],
        };
      }
    });
    const psJson = escapeHtml(JSON.stringify(previewState));

    const dsCells = `data-vel-cell="${p.vel_cell_id == null ? "" : p.vel_cell_id}" data-acc-cell="${p.acc_cell_id == null ? "" : p.acc_cell_id}" data-env-cell="${p.env_cell_id == null ? "" : p.env_cell_id}" data-vel-spec="${p.vel_spec_cell_id == null ? "" : p.vel_spec_cell_id}" data-acc-spec="${p.acc_spec_cell_id == null ? "" : p.acc_spec_cell_id}" data-env-spec="${p.env_spec_cell_id == null ? "" : p.env_spec_cell_id}" data-speed-hz="${p.speed_hz == null ? "" : p.speed_hz}" data-bpfo="${p.bearing_bpfo == null ? "" : p.bearing_bpfo}" data-bpfi="${p.bearing_bpfi == null ? "" : p.bearing_bpfi}" data-bsf="${p.bearing_bsf == null ? "" : p.bearing_bsf}" data-ftf="${p.bearing_ftf == null ? "" : p.bearing_ftf}"`;
    panels += `
      <div class="graph-pick-row gp-panel${idx === 0 ? " active" : ""}" data-gp-panel="${pid}" data-point-id="${pid}" data-point-name="${nm}" ${dsCells}>
        <input type="hidden" class="gp-preview-state" value="${psJson}"/>
        <div class="graph-pick-group gp-group-trend">
          <div class="gp-group-title">Statické hodnoty (trendy)</div>
          <div class="graph-pick-opts">${trendOpts}</div>
        </div>
        <div class="graph-pick-group gp-group-spectrum">
          <div class="gp-group-title">FFT spektra</div>
          <div class="graph-pick-opts">${specOpts}</div>
        </div>
        <div class="gp-panel-hint">Komentář, značky a přiblížení nastavíte v náhledu (tlačítko „Náhled“ u každého grafu).</div>
      </div>`;
  });
  return `
    <div class="brg-field brg-field-wide graph-picker">
      <label>Grafy do protokolu (zaškrtněte druhy grafů u měřicích bodů)</label>
      <div class="gp-tabbar">${tabs}</div>
      <div class="graph-pick-list">${panels}</div>
    </div>`;
}

// Napojí interakce pickeru grafů v bloku stroje: přepínání podzáložek
// (měřicích bodů) a otevření náhledu grafu.
function wireGraphPicker(block) {
  const picker = block.querySelector(".graph-picker");
  if (!picker) return;
  // přepínání podzáložek (tabů) – delegovaně
  const tabbar = picker.querySelector(".gp-tabbar");
  if (tabbar) {
    tabbar.addEventListener("click", (e) => {
      const btn = e.target.closest(".gp-tab");
      if (!btn) return;
      const pid = btn.dataset.gpTab;
      picker.querySelectorAll(".gp-tab").forEach((t) => t.classList.toggle("active", t === btn));
      picker.querySelectorAll(".gp-panel").forEach((pn) => {
        pn.classList.toggle("active", pn.dataset.gpPanel === pid);
      });
    });
  }
  // náhled grafu (trend / spektrum)
  picker.querySelectorAll(".gp-preview-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const panel = btn.closest(".gp-panel");
      openGraphPreview(panel, btn.dataset.kind);
    });
  });
}

// ----- Náhled grafu (Plotly) pro protokol -----
// Stav aktuálně otevřeného náhledu: cílový panel + druh grafu + značky.
let GP_PREVIEW = null;

function _gpKindLabel(kind) {
  const o = GRAPH_KIND_OPTS.find((k) => k.kind === kind);
  return o ? o.label : kind;
}

// Otevře modální náhled pro daný panel (měřicí bod) a druh grafu.
async function openGraphPreview(panel, kind) {
  if (!panel || !kind) return;
  const pid = parseInt(panel.dataset.pointId, 10);
  const nm = panel.dataset.pointName || ("" + pid);
  const isTrend = kind.indexOf("trend") === 0;
  const quant = kind.split("_")[1] || "vel";  // vel|acc|env
  // načti uložený stav náhledu (per-kind) z panelu
  let previewState = {};
  const psEl = panel.querySelector(".gp-preview-state");
  if (psEl && psEl.value) {
    try { previewState = JSON.parse(psEl.value) || {}; } catch (e) { previewState = {}; }
  }
  const saved = previewState[kind] || {};
  const _num = (v) => { const f = parseFloat(v); return isFinite(f) && f > 0 ? f : null; };
  GP_PREVIEW = {
    panel, kind, isTrend, quant,
    userMarkers: Array.isArray(saved.user_markers)
      ? saved.user_markers.map((m) => _normUserMarker(m)) : [],
    autoMarkers: Array.isArray(saved.auto_markers) ? saved.auto_markers.slice() : [],
    note: saved.note || "",
    xRange: Array.isArray(saved.x_range) ? saved.x_range.slice() : null,
    // údaje pro výpočet automatických značek (otáčková/harmonické/ložiskové)
    speedHz: _num(panel.dataset.speedHz),
    bearing: {
      BPFO: _num(panel.dataset.bpfo), BPFI: _num(panel.dataset.bpfi),
      BSF: _num(panel.dataset.bsf), FTF: _num(panel.dataset.ftf),
    },
    data: null,
  };

  const modal = document.getElementById("gp-preview-modal");
  const titleEl = document.getElementById("gp-preview-title");
  const chartEl = document.getElementById("gp-preview-chart");
  const statusEl = document.getElementById("gp-preview-status");
  const noteEl = document.getElementById("gp-preview-note");
  titleEl.textContent = (isTrend ? "Náhled trendu – " : "Náhled FFT spektra – ")
    + _gpKindLabel(kind) + " · " + nm;
  chartEl.innerHTML = '<div class="spinner"></div>';
  statusEl.textContent = "";
  if (noteEl) noteEl.value = GP_PREVIEW.note;
  _renderPreviewAutoMarkers();  // sekce auto-značek (jen spektrum)
  modal.classList.remove("hidden");

  try {
    if (isTrend) {
      const cellId = panel.dataset[quant + "Cell"];  // velCell/accCell/envCell
      if (!cellId) { chartEl.innerHTML = '<p class="gp-preview-empty">Pro tento bod není dostupný trend této veličiny.</p>'; return; }
      const d = await api(`/api/cell/${cellId}/trend`);
      GP_PREVIEW.data = d;
      _renderPreviewTrend(d);
    } else {
      const specId = panel.dataset[quant + "Spec"];  // velSpec/accSpec/envSpec
      if (!specId) { chartEl.innerHTML = '<p class="gp-preview-empty">Pro tento bod není dostupné FFT spektrum této veličiny.</p>'; return; }
      // spektrum: přes buňku zjisti dynamické záznamy, vezmi poslední
      const dyn = await api(`/api/cell/${specId}/dynamic`);
      const recs = (dyn && dyn.records) || [];
      if (!recs.length) { chartEl.innerHTML = '<p class="gp-preview-empty">Spektrum nemá žádná pořízení.</p>'; return; }
      const lastId = recs[recs.length - 1].id;
      const sp = await api(`/api/dynamic/${lastId}`);
      GP_PREVIEW.data = sp;
      _renderPreviewSpectrum(sp);
    }
    _renderPreviewMarkerList();
  } catch (err) {
    chartEl.innerHTML = '<p class="gp-preview-empty">Chyba načtení dat náhledu.</p>';
  }
}

function _renderPreviewTrend(d) {
  const chartEl = document.getElementById("gp-preview-chart");
  const pts = (d && d.points) || [];
  const x = pts.map((p, i) => i);           // index bodu (osa X)
  const y = pts.map((p) => p.value);
  const dates = pts.map((p) => (p.t || ""));
  const accent = getCss("--accent");
  const trace = {
    x, y, type: "scatter", mode: "lines+markers",
    line: { color: accent, width: 2 },
    marker: { size: 6 },
    text: dates,
    hovertemplate: "Bod %{x}<br>%{text}<br>%{y:.4f}<extra></extra>",
  };
  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.xaxis.title = "Pořadí měření (index bodu)";
  layout.yaxis.title = "Hodnota";
  layout.shapes = _previewMarkerShapes();
  layout.annotations = _previewMarkerAnnotations();
  // limity (varování/alarm) jako vodorovné čáry
  const lim = (d && d.limits) || {};
  const warn = (lim.warning != null && isFinite(lim.warning)) ? lim.warning : null;
  const alarm = (lim.alarm != null && isFinite(lim.alarm)) ? lim.alarm : null;
  if (warn != null) layout.shapes.push({ type: "line", xref: "paper", x0: 0, x1: 1, y0: warn, y1: warn, line: { color: getCss("--sev-alert"), width: 1.2, dash: "dash" } });
  if (alarm != null) layout.shapes.push({ type: "line", xref: "paper", x0: 0, x1: 1, y0: alarm, y1: alarm, line: { color: getCss("--sev-danger"), width: 1.2, dash: "dash" } });
  if (GP_PREVIEW.xRange) layout.xaxis.range = GP_PREVIEW.xRange.slice();
  Plotly.newPlot(chartEl, [trace], layout, PLOT_CONFIG);
  _attachPreviewHandlers(chartEl);
}

function _renderPreviewSpectrum(d) {
  const chartEl = document.getElementById("gp-preview-chart");
  const x = (d && d.x) || [];
  const y = (d && d.y) || [];
  const unit = (d && d.x_unit) || "Hz";
  const accent = getCss("--accent");
  const trace = {
    x, y, type: "scatter", mode: "lines",
    line: { color: accent, width: 1.3 },
    fill: "tozeroy", fillcolor: "rgba(47,155,214,0.12)",
    hovertemplate: `%{x:.2f} ${unit} · %{y:.5f}<extra></extra>`,
  };
  const layout = JSON.parse(JSON.stringify(PLOT_LAYOUT_BASE));
  layout.xaxis.title = "Frekvence [" + unit + "]";
  layout.yaxis.title = "Amplituda";
  layout.shapes = _previewMarkerShapes();
  layout.annotations = _previewMarkerAnnotations();
  if (GP_PREVIEW.xRange) layout.xaxis.range = GP_PREVIEW.xRange.slice();
  Plotly.newPlot(chartEl, [trace], layout, PLOT_CONFIG);
  _attachPreviewHandlers(chartEl);
}

// Normalizuje uživatelskou značku (zpětná kompatibilita + výchozí pole).
// {x, label, harmonics:int>=1 (1 = jen základní), sidebands:int>=0, sb_spacing:number}
function _normUserMarker(m) {
  m = m || {};
  const x = (m.x != null) ? m.x : (m.freq != null ? m.freq : 0);
  const h = parseInt(m.harmonics, 10);
  const sb = parseInt(m.sidebands, 10);
  const sp = parseFloat(m.sb_spacing);
  return {
    x: x,
    label: m.label || "",
    harmonics: (isFinite(h) && h >= 1) ? h : 1,
    sidebands: (isFinite(sb) && sb >= 0) ? sb : 0,
    sb_spacing: (isFinite(sp) && sp > 0) ? sp : 0,
  };
}

// Spočítá všechny x-pozice značky (základ + harmonické + postranní pásma).
// Vrací pole {x, label, kind:'base'|'harm'|'sb'}.
function _markerLines(m) {
  const out = [];
  const isTrend = GP_PREVIEW.isTrend;
  const nH = isTrend ? 1 : Math.max(1, m.harmonics || 1);  // harmonické jen ve spektru
  for (let k = 1; k <= nH; k++) {
    const fx = m.x * k;
    const lbl = (k === 1) ? (m.label || "") : (m.label ? m.label + " " + k + "×" : k + "×");
    out.push({ x: fx, label: lbl, kind: k === 1 ? "base" : "harm" });
    // postranní pásma kolem této harmonické (jen spektrum, je-li rozteč)
    if (!isTrend && m.sidebands > 0 && m.sb_spacing > 0) {
      for (let s = 1; s <= m.sidebands; s++) {
        out.push({ x: fx - s * m.sb_spacing, label: "", kind: "sb" });
        out.push({ x: fx + s * m.sb_spacing, label: "", kind: "sb" });
      }
    }
  }
  return out;
}

// barvy automatických značek (shodně s PDF: otáčková zelená, harmonické modré,
// ložiskové červené)
function _autoMarkerColor(kind) {
  if (kind === "speed") return getCss("--sev-ok") || "#33b679";
  if (kind === "harmonics") return "#3374cc";
  if (kind === "bearing") return getCss("--sev-danger") || "#d64545";
  return "#888";
}

// Spočítá frekvenční pozice automatických značek dle zaškrtnutých typů
// (odpovídá backendu _spectrum_markers). Vrací [{x, label, kind}].
// Jen pro spektrum; u trendu i bez otáček vrací prázdné pole.
function _autoMarkerLines() {
  const out = [];
  if (!GP_PREVIEW || GP_PREVIEW.isTrend) return out;
  const set = GP_PREVIEW.autoMarkers || [];
  if (!set.length) return out;
  const speed = GP_PREVIEW.speedHz;
  if (!speed || speed <= 0) return out;  // bez otáček nelze nic spočítat
  // horní frekvenční mez z dat spektra (pro ořez)
  const xs = (GP_PREVIEW.data && GP_PREVIEW.data.x) || [];
  const xmax = xs.length ? xs[xs.length - 1] : 0;
  const add = (fx, label, kind) => {
    if (fx == null || fx <= 0) return;
    if (xmax && fx > xmax) return;
    out.push({ x: fx, label: label, kind: kind });
  };
  if (set.indexOf("speed") >= 0) add(speed, "1×", "speed");
  if (set.indexOf("harmonics") >= 0) {
    for (let k = 2; k <= 6; k++) add(speed * k, k + "×", "harmonics");
  }
  if (set.indexOf("bearing") >= 0) {
    const b = GP_PREVIEW.bearing || {};
    [["BPFO", b.BPFO], ["BPFI", b.BPFI], ["BSF", b.BSF], ["FTF", b.FTF]].forEach(([lbl, coef]) => {
      if (coef && coef > 0) add(speed * coef, lbl, "bearing");
    });
  }
  return out;
}

// svislé čáry značek (uživatelské + automatické) pro Plotly layout
function _previewMarkerShapes() {
  const col = "#8c59bf";     // základ
  const colH = "#a97fd0";    // harmonické
  const colS = "#c7a8e0";    // postranní pásma
  const shapes = [];
  // automatické značky (pod uživatelskými)
  _autoMarkerLines().forEach((ln) => {
    const c = _autoMarkerColor(ln.kind);
    shapes.push({
      type: "line", x0: ln.x, x1: ln.x, yref: "paper", y0: 0, y1: 1,
      line: { color: c, width: 1, dash: "dash" },
    });
  });
  // uživatelské značky
  (GP_PREVIEW.userMarkers || []).forEach((m) => {
    _markerLines(m).forEach((ln) => {
      const c = ln.kind === "base" ? col : (ln.kind === "harm" ? colH : colS);
      const w = ln.kind === "sb" ? 0.8 : 1;
      const dash = ln.kind === "base" ? "dot" : (ln.kind === "harm" ? "dash" : "dashdot");
      shapes.push({
        type: "line", x0: ln.x, x1: ln.x, yref: "paper", y0: 0, y1: 1,
        line: { color: c, width: w, dash: dash },
      });
    });
  });
  return shapes;
}
function _previewMarkerAnnotations() {
  const col = "#8c59bf";
  const colH = "#a97fd0";
  const anns = [];
  // popisky automatických značek
  _autoMarkerLines().forEach((ln) => {
    if (!ln.label) return;
    anns.push({
      x: ln.x, y: 1, yref: "paper", text: ln.label, showarrow: false,
      font: { size: 10, color: _autoMarkerColor(ln.kind) }, yanchor: "bottom",
      bgcolor: "rgba(15,20,26,0.7)",
    });
  });
  // popisky uživatelských značek
  (GP_PREVIEW.userMarkers || []).forEach((m) => {
    _markerLines(m).forEach((ln) => {
      if (ln.kind === "sb" || !ln.label) return;  // pásma bez popisku
      anns.push({
        x: ln.x, y: 1, yref: "paper", text: ln.label, showarrow: false,
        font: { size: 10, color: ln.kind === "base" ? col : colH }, yanchor: "bottom",
        bgcolor: "rgba(15,20,26,0.7)",
      });
    });
  });
  return anns;
}

// napojí klik (přidání značky) a zoom (uchování rozsahu) na graf náhledu
function _attachPreviewHandlers(chartEl) {
  chartEl.removeAllListeners && chartEl.removeAllListeners("plotly_click");
  chartEl.on("plotly_click", (ev) => {
    if (!ev || !ev.points || !ev.points.length) return;
    const px = ev.points[0].x;
    if (px == null) return;
    const isTrend = GP_PREVIEW.isTrend;
    const defLabel = isTrend ? ("bod " + Math.round(px)) : (fmtNum(px, 1) + " Hz");
    const label = window.prompt("Popisek značky:", defLabel);
    if (label === null) return;  // zrušeno
    const xVal = isTrend ? Math.round(px) : px;
    // výchozí: 1 harmonická (jen základ), bez postranních pásem; ve spektru
    // předvyplníme 3 harmonické jako rozumný výchozí stav (uživatel upraví)
    GP_PREVIEW.userMarkers.push(_normUserMarker({
      x: xVal, label: (label || defLabel).trim(),
      harmonics: isTrend ? 1 : 3, sidebands: 0, sb_spacing: 0,
    }));
    _refreshPreviewMarkers();
  });
  chartEl.removeAllListeners && chartEl.removeAllListeners("plotly_relayout");
  chartEl.on("plotly_relayout", (ev) => {
    if (!ev) return;
    if (ev["xaxis.autorange"]) { GP_PREVIEW.xRange = null; return; }
    if (ev["xaxis.range[0]"] != null && ev["xaxis.range[1]"] != null) {
      GP_PREVIEW.xRange = [ev["xaxis.range[0]"], ev["xaxis.range[1]"]];
    } else if (Array.isArray(ev["xaxis.range"])) {
      GP_PREVIEW.xRange = ev["xaxis.range"].slice();
    }
  });
}

// překreslí značky (shapes/annotations) beze změny dat/zoomu.
// skipList=true ponechá seznam značek beze změny (aby nezmizel fokus z inputu).
function _refreshPreviewMarkers(skipList) {
  const chartEl = document.getElementById("gp-preview-chart");
  const shapes = _previewMarkerShapes();
  // limitní čáry u trendu se přidávají při vykreslení; zde překreslíme
  // všechny shapes značek (limity zůstávají součástí původního layoutu jen
  // při prvním vykreslení) – pro jednoduchost je znovu přidáme u trendu
  if (GP_PREVIEW && GP_PREVIEW.isTrend && GP_PREVIEW.data) {
    const lim = (GP_PREVIEW.data.limits) || {};
    const warn = (lim.warning != null && isFinite(lim.warning)) ? lim.warning : null;
    const alarm = (lim.alarm != null && isFinite(lim.alarm)) ? lim.alarm : null;
    if (warn != null) shapes.push({ type: "line", xref: "paper", x0: 0, x1: 1, y0: warn, y1: warn, line: { color: getCss("--sev-alert"), width: 1.2, dash: "dash" } });
    if (alarm != null) shapes.push({ type: "line", xref: "paper", x0: 0, x1: 1, y0: alarm, y1: alarm, line: { color: getCss("--sev-danger"), width: 1.2, dash: "dash" } });
  }
  Plotly.relayout(chartEl, { shapes, annotations: _previewMarkerAnnotations() });
  if (!skipList) _renderPreviewMarkerList();
}

// Sekce automatických značek spektra (1×, harmonické, ložiskové).
// U trendu se skryje.
function _renderPreviewAutoMarkers() {
  const wrap = document.getElementById("gp-preview-auto");
  const opts = document.getElementById("gp-preview-auto-opts");
  if (!wrap || !opts) return;
  if (!GP_PREVIEW || GP_PREVIEW.isTrend) { wrap.classList.add("hidden"); opts.innerHTML = ""; return; }
  wrap.classList.remove("hidden");
  const set = GP_PREVIEW.autoMarkers || [];
  opts.innerHTML = SPECTRUM_MARKER_OPTS.map((o) =>
    `<label class="graph-pick-opt gp-marker-opt">`
    + `<input type="checkbox" class="gp-auto-marker" data-marker="${o.marker}" ${set.indexOf(o.marker) >= 0 ? "checked" : ""}/> ${o.label}</label>`
  ).join("");
  opts.querySelectorAll(".gp-auto-marker").forEach((chk) => {
    chk.addEventListener("change", () => {
      const mk = chk.dataset.marker;
      const arr = GP_PREVIEW.autoMarkers;
      const idx = arr.indexOf(mk);
      if (chk.checked && idx < 0) arr.push(mk);
      else if (!chk.checked && idx >= 0) arr.splice(idx, 1);
      // ihned překresli značky v grafu (beze změny seznamu ručních značek)
      _refreshPreviewMarkers(true);
      // upozorni, pokud nejsou známy otáčky (nelze nic vykreslit)
      if (chk.checked && (!GP_PREVIEW.speedHz || GP_PREVIEW.speedHz <= 0)) {
        if (typeof toast === "function") toast("Pro tento bod nejsou známy otáčky – automatické značky nelze vykreslit.", true);
      }
    });
  });
}

// seznam uživatelských značek pod grafem: popisek, pozice, mazání a (ve
// spektru) editace počtu harmonických a postranních pásem.
function _renderPreviewMarkerList() {
  const list = document.getElementById("gp-preview-marker-list");
  if (!list) return;
  const ums = GP_PREVIEW.userMarkers || [];
  if (!ums.length) {
    list.innerHTML = '<span class="gp-preview-empty">Zatím žádné značky. Klikněte do grafu pro přidání.</span>';
    return;
  }
  const isTrend = GP_PREVIEW.isTrend;
  const unit = isTrend ? "" : " Hz";
  list.innerHTML = ums.map((m, i) => {
    const pos = isTrend ? Math.round(m.x) : fmtNum(m.x, 1);
    let extra = "";
    if (!isTrend) {
      extra = `<span class="gp-marker-ctrl">`
        + `<label title="Počet harmonických (1 = jen základ)">harm. ×`
        + `<input type="number" class="gp-marker-h" data-i="${i}" min="1" max="20" step="1" value="${m.harmonics}"/></label>`
        + `<label title="Počet postranních pásem na každou stranu (0 = žádná)">pásma`
        + `<input type="number" class="gp-marker-sb" data-i="${i}" min="0" max="20" step="1" value="${m.sidebands}"/></label>`
        + `<label title="Rozteč postranních pásem [Hz]">rozteč`
        + `<input type="number" class="gp-marker-sp" data-i="${i}" min="0" step="0.1" value="${m.sb_spacing || ""}" placeholder="Hz"/></label>`
        + `</span>`;
    }
    return `<div class="gp-marker-chip"><div class="gp-marker-chip-head">`
      + `<span class="gp-marker-name">${escapeHtml(m.label || "")} <em>(${pos}${unit})</em></span>`
      + `<button type="button" class="gp-marker-del" data-i="${i}" title="Odebrat">×</button></div>`
      + extra + `</div>`;
  }).join("");
  list.querySelectorAll(".gp-marker-del").forEach((b) => {
    b.addEventListener("click", () => {
      const i = parseInt(b.dataset.i, 10);
      GP_PREVIEW.userMarkers.splice(i, 1);
      _refreshPreviewMarkers();
    });
  });
  const bindNum = (cls, field, isInt) => {
    list.querySelectorAll(cls).forEach((inp) => {
      inp.addEventListener("change", () => {
        const i = parseInt(inp.dataset.i, 10);
        const m = GP_PREVIEW.userMarkers[i];
        if (!m) return;
        let v = isInt ? parseInt(inp.value, 10) : parseFloat(inp.value);
        if (!isFinite(v) || v < 0) v = 0;
        if (field === "harmonics" && v < 1) v = 1;
        m[field] = v;
        _refreshPreviewMarkers(true);  // beze změny seznamu (fokus zůstane)
      });
    });
  };
  bindNum(".gp-marker-h", "harmonics", true);
  bindNum(".gp-marker-sb", "sidebands", true);
  bindNum(".gp-marker-sp", "sb_spacing", false);
}

// zavře náhled bez uložení
function closeGraphPreview() {
  const modal = document.getElementById("gp-preview-modal");
  if (modal) modal.classList.add("hidden");
  const chartEl = document.getElementById("gp-preview-chart");
  if (chartEl) { try { Plotly.purge(chartEl); } catch (e) {} chartEl.innerHTML = ""; }
  GP_PREVIEW = null;
}

// uloží stav náhledu (zoom + značky + komentář + auto-značky) do panelu a zavře modal
function saveGraphPreview() {
  if (!GP_PREVIEW || !GP_PREVIEW.panel) { closeGraphPreview(); return; }
  const panel = GP_PREVIEW.panel;
  const kind = GP_PREVIEW.kind;
  const noteEl = document.getElementById("gp-preview-note");
  const note = noteEl ? (noteEl.value || "").trim() : "";
  const psEl = panel.querySelector(".gp-preview-state");
  let state = {};
  if (psEl && psEl.value) { try { state = JSON.parse(psEl.value) || {}; } catch (e) { state = {}; } }
  const entry = {};
  if (GP_PREVIEW.xRange) entry.x_range = GP_PREVIEW.xRange.slice();
  if (GP_PREVIEW.userMarkers && GP_PREVIEW.userMarkers.length) {
    entry.user_markers = GP_PREVIEW.userMarkers.map((m) => {
      const o = { x: m.x, label: m.label || "" };
      if (!GP_PREVIEW.isTrend) {
        if (m.harmonics && m.harmonics > 1) o.harmonics = m.harmonics;
        if (m.sidebands && m.sidebands > 0 && m.sb_spacing > 0) {
          o.sidebands = m.sidebands; o.sb_spacing = m.sb_spacing;
        }
      }
      return o;
    });
  }
  if (!GP_PREVIEW.isTrend && GP_PREVIEW.autoMarkers && GP_PREVIEW.autoMarkers.length) {
    entry.auto_markers = GP_PREVIEW.autoMarkers.slice();
  }
  if (note) entry.note = note;
  if (Object.keys(entry).length) state[kind] = entry;
  else delete state[kind];
  if (psEl) psEl.value = JSON.stringify(state);
  // automaticky zaškrtni odpovídající druh grafu (uživatel připravil náhled)
  const chk = panel.querySelector(`.gp-kind[data-kind="${kind}"]`);
  if (chk) chk.checked = true;
  markReportDraftDirty();
  toast("Náhled uložen do protokolu.");
  closeGraphPreview();
}

// Sebere aktuální (editovaný) návrh z formuláře.
function collectReportDoc() {
  const doc = JSON.parse(JSON.stringify(REPORT.draft || {}));
  // verze protokolu + externí obrázek přílohy (verze 3)
  const versionEl = document.getElementById("report-version");
  if (versionEl) doc.report_version = parseInt(versionEl.value, 10) || 1;
  const showPrevious = document.getElementById("report-show-previous");
  if (showPrevious) doc.show_previous = !!showPrevious.checked;
  const capEl = document.getElementById("report-appendix-image-caption");
  if (capEl) doc.appendix_image_caption = capEl.value || "";
  // obrázek držíme na REPORT.draft.appendix_image (nastaven z upload handleru)
  if (REPORT.draft && REPORT.draft.appendix_image != null) {
    doc.appendix_image = REPORT.draft.appendix_image;
  }
  const val = (id) => {
    const e = document.getElementById(id);
    return e ? (e.value || "") : "";
  };
  doc.header_left = val("rep-header_left");
  doc.company_name = val("rep-company_name");
  doc.company_address = val("rep-company_address");
  doc.measured_at = val("rep-measured_at");
  doc.report_title = val("rep-report_title");
  doc.order_number = val("rep-order_number");
  doc.contract_number = val("rep-contract_number");
  doc.date_created = val("rep-date_created");
  doc.date_measured = val("rep-date_measured");
  doc.created_by = val("rep-created_by");
  doc.measured_by = val("rep-measured_by");
  doc.measured_by2 = val("rep-measured_by2");
  doc.approved_by = val("rep-approved_by");
  doc.intro = val("rep-intro");
  doc.appendix_intro = val("rep-appendix_intro");
  // název PDF souboru (uživatelsky upravitelný; prázdný => backend složí výchozí)
  doc.pdf_filename = val("rep-pdf_filename").trim();

  const blocks = document.querySelectorAll("#report-machines .report-machine-block");
  doc.machines = doc.machines || [];
  blocks.forEach((b) => {
    const i = parseInt(b.dataset.idx, 10);
    if (!doc.machines[i]) return;
    const q = (sel) => { const e = b.querySelector(sel); return e ? (e.value || "") : ""; };
    doc.machines[i].problem = q(".rm-problem");
    doc.machines[i].zaver = q(".rm-zaver");
    doc.machines[i].doporuceni = q(".rm-doporuceni");
    // ruční přepis celkového stavu stroje (prázdné = automaticky z pásem)
    const mm = doc.machines[i];
    const sevOv = q(".rm-sevoverride");
    // Efektivní kategorie mohou být ručně přepsané; výhradně z nich se
    // odvozuje celkový stav stroje, nikoli z historického/stale bearing_state.
    _recomputeReportCategoryStates(mm);
    const autoSev = _autoSeverityFromBand(mm.worst_band);
    mm.auto_severity = autoSev;
    mm.auto_severity_label = SEV_MODEL_LABELS[autoSev] || "";
    if (sevOv === "ok" || sevOv === "alarm" || sevOv === "warn") {
      mm.severity_override = sevOv;
      mm.severity = sevOv;
      mm.severity_manual = true;
    } else {
      mm.severity_override = "";
      mm.severity = autoSev;
      mm.severity_manual = false;
    }
    mm.severity_label = SEV_MODEL_LABELS[mm.severity] || "";
    // ulož i aktuální výběr grafů do stroje (aby se zachoval)
    doc.machines[i].graph_selections = collectMachineGraphSelections(b);
    // vyloučené měřicí body (nezaškrtnuté "Zahrnout").
    // data-rowkey může obsahovat více klíčů (všechny směry místa) oddělených
    // čárkou – rozděl je na jednotlivé klíče "place|direction".
    const excluded = [];
    b.querySelectorAll(".rep-point-incl input[type=checkbox]").forEach((cb) => {
      if (!cb.checked && cb.dataset.rowkey) {
        cb.dataset.rowkey.split(",").forEach((k) => {
          const kk = k.trim();
          if (kk) excluded.push(kk);
        });
      }
    });
    doc.machines[i].excluded_points = excluded;
  });
  return doc;
}

// Z bloku stroje sebere zaškrtnuté grafy. Komentář, značky (automatické i
// uživatelské) a přiblížení se zadávají v náhledu a jsou uloženy per-kind
// v .gp-preview-state. Trendy vždy používají všechny body.
// Položka: {point_id, kind, point_name, note?, markers?, user_markers?, x_range?}.
function collectMachineGraphSelections(block) {
  const out = [];
  block.querySelectorAll(".graph-pick-row").forEach((row) => {
    const pid = parseInt(row.dataset.pointId, 10);
    const nm = row.dataset.pointName || "";
    // per-kind stav náhledu (zoom rozsah + značky + komentář + auto-značky)
    let previewState = {};
    const psEl = row.querySelector(".gp-preview-state");
    if (psEl && psEl.value) {
      try { previewState = JSON.parse(psEl.value) || {}; } catch (e) { previewState = {}; }
    }
    row.querySelectorAll(".gp-kind").forEach((chk) => {
      if (!chk.checked) return;
      const kind = chk.dataset.kind;
      const item = { point_id: pid, kind, point_name: nm };
      // přenes stav náhledu (komentář, rozsah os, značky) pokud existuje
      const ps = previewState[kind];
      if (ps) {
        if (ps.note && ps.note.trim()) item.note = ps.note.trim();
        if (Array.isArray(ps.x_range) && ps.x_range.length === 2) item.x_range = ps.x_range.slice();
        if (Array.isArray(ps.user_markers) && ps.user_markers.length) item.user_markers = ps.user_markers.slice();
        if (Array.isArray(ps.auto_markers) && ps.auto_markers.length) item.markers = ps.auto_markers.slice();
      }
      out.push(item);
    });
  });
  return out;
}

// Sestaví mapu výběru grafů pro všechny stroje: {machine_id: […]}.
function collectGraphSelectionsMap() {
  const map = {};
  document.querySelectorAll("#report-machines .report-machine-block").forEach((b) => {
    const mid = b.dataset.machineId;
    if (mid === "" || mid == null) return;
    map[mid] = collectMachineGraphSelections(b);
  });
  return map;
}

// Výhradně po deklaraci collectReportDoc: při startu se objekt REPORT už
// inicializoval a posluchače tedy nemohou závodit se startem aplikace.
initReportDraftSession();

// Povolí/zakáže tlačítka "Aktualizovat", "Náhled PDF" a "Vygenerovat PDF" najednou.
function _setReportBtns(enabled) {
  const pdf = document.getElementById("report-pdf-btn");
  const prev = document.getElementById("report-preview-btn");
  const hist = document.getElementById("report-save-history-btn");
  const refr = document.getElementById("report-refresh-btn");
  const docx = document.getElementById("report-docx-btn");
  const docxImp = document.getElementById("report-docx-import-btn");
  if (pdf) pdf.disabled = !enabled;
  if (prev) prev.disabled = !enabled;
  if (hist) hist.disabled = !enabled;
  if (refr) refr.disabled = !enabled;
  if (docx) docx.disabled = !enabled;
  if (docxImp) docxImp.disabled = !enabled;
}

// Sdílená příprava: přepočítá grafy dle výběru, uloží návrh a získá PDF
// jako blob. Používají ji náhled i finalní stažení — aby byl náhled 1:1
// shodný s výslednym PDF. Vrací {blob, fname}.
async function _buildReportPdfBlob() {
  let doc = collectReportDoc();
  // přepočítej grafy dle zaškrtnutého výběru (vloží je do návrhu)
  try {
    const gr = await api("/api/report/graphs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ doc, graph_selections: collectGraphSelectionsMap() }),
    });
    if (gr && gr.draft) doc = gr.draft;
  } catch (e) { /* grafy nejsou kritické – pokračuj bez nich */ }
  REPORT.draft = doc;
  // ulož editovaný návrh (ať zůstane zachován)
  await api("/api/report/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ doc }),
  });
  const resp = await fetch(API + "/api/report/pdf", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ doc }),
  });
  if (!resp.ok) {
    let msg = "Chyba " + resp.status;
    try { const j = await resp.json(); if (j.detail) msg = j.detail; } catch (e) {}
    throw new Error(msg);
  }
  const blob = await resp.blob();
  let fname = "Protokol.pdf";
  const cd = resp.headers.get("Content-Disposition") || "";
  const mStar = cd.match(/filename\*=UTF-8''([^;]+)/i);
  const mPlain = cd.match(/filename="?([^";]+)"?/i);
  if (mStar) fname = decodeURIComponent(mStar[1]);
  else if (mPlain) fname = mPlain[1];
  return { blob, fname };
}

// Spustí stažení blobu jako soubor.
function _downloadBlob(blob, fname) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fname;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

// Vygeneruje a stáhne PDF z aktuálně editovaného návrhu.
async function downloadReportPdf() {
  if (!REPORT.draft) {
    toast("Nejprve vytvořte návrh protokolu.", true);
    return;
  }
  _setReportBtns(false);
  const status = document.getElementById("report-gen-status");
  status.textContent = "Připravuji grafy a generuji PDF…";
  try {
    const { blob, fname } = await _buildReportPdfBlob();
    _downloadBlob(blob, fname);
    // po úspěšném vygenerování PDF automaticky archivuj protokol do historie
    // (kompletní doc); nekritické – případná chyba nezastaví stažení PDF
    let histNote = "";
    try {
      await saveReportToHistory({ silent: true });
      histNote = " Uloženo do historie.";
    } catch (e) { /* historie není kritická */ }
    status.textContent = "PDF vygenerováno (" + fname + ")." + histNote;
    toast("PDF protokol vygenerován.");
  } catch (e) {
    status.textContent = "";
    toast(e.message || "Generování PDF selhalo.", true);
  } finally {
    _setReportBtns(true);
  }
}

// ============================================================
//  EXPORT DOCX (plně editovatelný Word) + BEZPEČNÝ TAGOVANÝ IMPORT
// ============================================================
// Sdílená příprava DOCX blobu - stejný vzor jako _buildReportPdfBlob,
// jen jiná koncová route a jiný content-type na výstupu.
async function _buildReportDocxBlob() {
  let doc = collectReportDoc();
  try {
    const gr = await api("/api/report/graphs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ doc, graph_selections: collectGraphSelectionsMap() }),
    });
    if (gr && gr.draft) doc = gr.draft;
  } catch (e) { /* grafy nejsou kritické – pokračuj bez nich */ }
  REPORT.draft = doc;
  await api("/api/report/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ doc }),
  });
  const resp = await fetch(API + "/api/report/docx", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ doc }),
  });
  if (!resp.ok) {
    let msg = "Chyba " + resp.status;
    try { const j = await resp.json(); if (j.detail) msg = j.detail; } catch (e) {}
    throw new Error(msg);
  }
  const blob = await resp.blob();
  let fname = "Protokol.docx";
  const cd = resp.headers.get("Content-Disposition") || "";
  const mStar = cd.match(/filename\*=UTF-8''([^;]+)/i);
  const mPlain = cd.match(/filename="?([^";]+)"?/i);
  if (mStar) fname = decodeURIComponent(mStar[1]);
  else if (mPlain) fname = mPlain[1];
  return { blob, fname };
}

// Vygeneruje a stáhne plně editovatelný DOCX protokol ze stejného návrhu jako PDF.
async function downloadReportDocx() {
  if (!REPORT.draft) {
    toast("Nejprve vytvořte návrh protokolu.", true);
    return;
  }
  _setReportBtns(false);
  const status = document.getElementById("report-gen-status");
  if (status) status.textContent = "Připravuji grafy a generuji DOCX…";
  try {
    const { blob, fname } = await _buildReportDocxBlob();
    _downloadBlob(blob, fname);
    if (status) status.textContent = "DOCX vygenerováno (" + fname + "). Dokument je plně editovatelný ve Wordu.";
    toast("DOCX protokol vygenerován.");
  } catch (e) {
    if (status) status.textContent = "";
    toast(e.message || "Generování DOCX selhalo.", true);
  } finally {
    _setReportBtns(true);
  }
}

// Stav rozpracovaného náhledu importu z DOCX (mezi preview a apply).
const DOCX_IMPORT = { items: [], summary: null, selected: new Set() };

function _docxImportKey(it) {
  return it.machine_id + "|" + it.field;
}

function _closeDocxImportModal() {
  const overlay = document.getElementById("docx-import-modal");
  if (overlay) overlay.classList.add("hidden");
}

function _openDocxImportModal() {
  const overlay = document.getElementById("docx-import-modal");
  if (overlay) overlay.classList.remove("hidden");
}

// Nahraje vybraný .docx na server a zobrazí náhled nalezených změn
// (žádné okamžité uložení – jen náhled pro výběr uživatelem).
async function startDocxImportPreview(file) {
  if (!REPORT.draft) {
    toast("Nejprve vytvořte nebo otevřete návrh protokolu.", true);
    return;
  }
  const status = document.getElementById("report-gen-status");
  if (status) status.textContent = "Načítám a porovnávám dokument…";
  _setReportBtns(false);
  try {
    const doc = collectReportDoc();
    const fd = new FormData();
    fd.append("file", file, file.name);
    fd.append("doc", new Blob([JSON.stringify(doc)], { type: "application/json" }), "doc.json");
    const resp = await fetch(API + "/api/report/docx-import/preview", {
      method: "POST",
      body: fd,
    });
    const j = await resp.json().catch(() => ({}));
    if (!resp.ok || !j.ok) {
      throw new Error((j && j.detail) || ("Chyba " + resp.status));
    }
    DOCX_IMPORT.items = j.items || [];
    DOCX_IMPORT.summary = j.summary || null;
    DOCX_IMPORT.selected = new Set(
      DOCX_IMPORT.items.filter((it) => it.changed && it.matched).map(_docxImportKey)
    );
    _renderDocxImportPreview();
    _openDocxImportModal();
    if (status) status.textContent = "";
  } catch (e) {
    toast(e.message || "Načtení náhledu z DOCX selhalo.", true);
    if (status) status.textContent = "";
  } finally {
    _setReportBtns(true);
  }
}

function _escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Vykreslí seznam nalezených tagovaných polí (závěr/doporučení) s
// porovnáním starého a nového textu a zaškrtávátkem pro výběr.
function _renderDocxImportPreview() {
  const sumEl = document.getElementById("docx-import-summary");
  const unmatchedEl = document.getElementById("docx-import-unmatched");
  const listEl = document.getElementById("docx-import-list");
  const applyBtn = document.getElementById("docx-import-apply");
  if (!listEl) return;
  const s = DOCX_IMPORT.summary || {};
  if (sumEl) {
    sumEl.textContent =
      "Nalezeno polí: " + (s.tagged_count || 0) +
      " · rozpoznaných strojů: " + (s.matched_count || 0) +
      " · se změnou textu: " + (s.changed_count || 0);
  }
  if (unmatchedEl) {
    if (s.unmatched && s.unmatched.length) {
      unmatchedEl.classList.remove("hidden");
      unmatchedEl.textContent =
        "Pozn.: " + s.unmatched.length + " stroj(ů) z dokumentu se nepodařilo přiřadit k aktuálnímu protokolu (ID: " +
        s.unmatched.join(", ") + ") – jejich text nelze importovat.";
    } else {
      unmatchedEl.classList.add("hidden");
      unmatchedEl.textContent = "";
    }
  }
  if (!DOCX_IMPORT.items.length) {
    listEl.innerHTML = '<p class="docx-import-empty">V dokumentu nebyla nalezena žádná importovatelná pole (žádné skryté značky Závěr/Doporučení). Ujistěte se, že jde o DOCX vyexportovaný touto aplikací.</p>';
  } else {
    listEl.innerHTML = DOCX_IMPORT.items.map((it) => {
      const key = _docxImportKey(it);
      const checked = DOCX_IMPORT.selected.has(key) ? "checked" : "";
      const disabled = it.matched ? "" : "disabled";
      const rowCls = "docx-import-row" + (it.changed ? " docx-import-row-changed" : "") + (!it.matched ? " docx-import-row-unmatched" : "");
      const badge = !it.matched
        ? '<span class="docx-import-badge docx-import-badge-warn">stroj nenalezen</span>'
        : (it.changed
          ? '<span class="docx-import-badge docx-import-badge-changed">změněno</span>'
          : '<span class="docx-import-badge">beze změny</span>');
      return (
        '<div class="' + rowCls + '">' +
          '<label class="docx-import-row-head">' +
            '<input type="checkbox" class="docx-import-check" data-key="' + _escapeHtml(key) + '" ' + checked + " " + disabled + ">" +
            '<strong>' + _escapeHtml(it.machine_name) + '</strong>' +
            '<span class="docx-import-field-label">' + _escapeHtml(it.field_label) + '</span>' +
            badge +
          '</label>' +
          '<div class="docx-import-diff">' +
            '<div class="docx-import-old"><span class="docx-import-diff-label">Původní</span><div>' + (_escapeHtml(it.old_text) || '<em>(prázdné)</em>') + '</div></div>' +
            '<div class="docx-import-new"><span class="docx-import-diff-label">Z Wordu</span><div>' + (_escapeHtml(it.new_text) || '<em>(prázdné)</em>') + '</div></div>' +
          '</div>' +
        '</div>'
      );
    }).join("");
    listEl.querySelectorAll(".docx-import-check").forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const key = e.target.dataset.key;
        if (e.target.checked) DOCX_IMPORT.selected.add(key);
        else DOCX_IMPORT.selected.delete(key);
        _updateDocxImportApplyBtn();
      });
    });
  }
  _updateDocxImportApplyBtn();
}

function _updateDocxImportApplyBtn() {
  const applyBtn = document.getElementById("docx-import-apply");
  if (applyBtn) applyBtn.disabled = DOCX_IMPORT.selected.size === 0;
}

function _selectChangedDocxImportItems() {
  DOCX_IMPORT.selected = new Set(
    DOCX_IMPORT.items.filter((it) => it.changed && it.matched).map(_docxImportKey)
  );
  _renderDocxImportPreview();
}

// Uloží pouze vybraná pole (zaver/doporuceni) do aktuálního návrhu –
// nikdy nezasahuje do naměřených hodnot, pásem, stavů ložisek ani termínů.
async function applyDocxImportSelection() {
  const statusEl = document.getElementById("docx-import-status");
  if (!DOCX_IMPORT.selected.size) return;
  const applyBtn = document.getElementById("docx-import-apply");
  if (applyBtn) applyBtn.disabled = true;
  if (statusEl) statusEl.textContent = "Ukládám vybrané změny…";
  try {
    const doc = collectReportDoc();
    const resp = await api("/api/report/docx-import/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        doc,
        items: DOCX_IMPORT.items,
        selected_keys: Array.from(DOCX_IMPORT.selected),
      }),
    });
    if (!resp || !resp.ok) throw new Error("Uložení se nezdařilo.");
    REPORT.draft = resp.draft;
    fillReportEditor(resp.draft);
    if (statusEl) statusEl.textContent = "";
    _closeDocxImportModal();
    toast("Použito " + resp.applied + " vybraných polí (závěry/doporučení) z Wordu.");
  } catch (e) {
    if (statusEl) statusEl.textContent = "";
    toast(e.message || "Uložení vybraných změn selhalo.", true);
  } finally {
    if (applyBtn) applyBtn.disabled = DOCX_IMPORT.selected.size === 0;
  }
}

// ============================================================
//  HISTORIE PROTOKOLŮ
// ============================================================
// Uloží aktuálně editovaný protokol do historie. Pokud byl návrh vyvolán
// z existující položky historie (REPORT.historyEntryId), zeptá se, zda
// přepsat tuto položku, nebo vytvořit novou kopii. Při silent=true (auto-save
// po PDF) vždy přepisuje navázanou položku, jinak přidá novou.
async function saveReportToHistory(opts) {
  opts = opts || {};
  const silent = !!opts.silent;
  if (!REPORT.draft) {
    if (!silent) toast("Nejprve vytvořte návrh protokolu.", true);
    return;
  }
  const doc = collectReportDoc();
  REPORT.draft = doc;
  let entryId = REPORT.historyEntryId || "";
  // při ručním uložení navázané položky nabídni volbu přepsat / nová kopie
  if (!silent && entryId) {
    const overwrite = confirm(
      "Tento protokol byl vyvolán z historie.\n\n" +
      "OK = přepsat původní položku v historii\n" +
      "Zrušit = uložit jako NOVOU položku historie");
    if (!overwrite) entryId = "";
  }
  const payload = { doc };
  if (entryId) payload.id = entryId;
  const r = await api("/api/report/history", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (r && r.item && r.item.id) REPORT.historyEntryId = r.item.id;
  if (!silent) {
    toast(r && r.updated ? "Položka historie aktualizována."
                         : "Protokol uložen do historie.");
    // když je otevřená záložka historie, rovnou obnov seznam
    if (REPORT.activeTab === "history") loadReportHistory();
  }
  return r;
}

// Načte a vykreslí seznam položek historie protokolů.
async function loadReportHistory() {
  const listEl = document.getElementById("report-history-list");
  const statusEl = document.getElementById("report-history-status");
  if (!listEl) return;
  listEl.innerHTML = "";
  if (statusEl) statusEl.textContent = "Načítám…";
  try {
    const r = await api("/api/report/history");
    const items = (r && r.items) || [];
    renderReportHistory(items);
    if (statusEl) {
      statusEl.textContent = items.length
        ? (items.length + " uložených protokolů.")
        : "Zatím žádný uložený protokol.";
    }
  } catch (e) {
    if (statusEl) statusEl.textContent = "";
    renderReportHistory([]);
    toast("Historii se nepodařilo načíst (není načtena databáze?).", true);
  }
}

// Vykreslí karty položek historie s akcemi.
function renderReportHistory(items) {
  const listEl = document.getElementById("report-history-list");
  if (!listEl) return;
  if (!items.length) {
    listEl.innerHTML = '<div class="report-history-empty">Zatím zde není ' +
      'žádný uložený protokol. Vytvořte návrh a uložte jej tlačítkem ' +
      '„Uložit do historie“ (nebo vygenerujte PDF).</div>';
    return;
  }
  const verLabel = (v) => v == 2 ? "Verze 2" : (v == 3 ? "Verze 3" : "Verze 1");
  const rows = items.map(it => {
    const created = _fmtHistTs(it.created_at);
    const updated = it.updated_at && it.updated_at !== it.created_at
      ? (" · upraveno " + _fmtHistTs(it.updated_at)) : "";
    const meta = [
      verLabel(it.report_version),
      (it.machine_count || 0) + " strojů",
      it.scope_label || "",
    ].filter(Boolean).join(" · ");
    const active = it.id === REPORT.historyEntryId ? " is-active" : "";
    return '<div class="report-history-item' + active + '" data-hist-id="' +
      escapeHtml(it.id) + '">' +
      '<div class="report-history-main">' +
        '<div class="report-history-title">' + escapeHtml(it.label || "Protokol") +
        (active ? ' <span class="report-history-badge">otevřeno</span>' : '') +
        '</div>' +
        '<div class="report-history-meta">' + escapeHtml(meta) + '</div>' +
        '<div class="report-history-ts">Uloženo ' + escapeHtml(created) +
        escapeHtml(updated) + '</div>' +
      '</div>' +
      '<div class="report-history-actions">' +
        '<button type="button" class="cb-btn cb-btn-sm" data-hist-act="open">Otevřít / editovat</button>' +
        '<button type="button" class="cb-btn cb-ghost cb-btn-sm" data-hist-act="dup">Duplikovat jako nový</button>' +
        '<button type="button" class="cb-btn cb-ghost cb-btn-sm" data-hist-act="pdf">Stáhnout PDF</button>' +
        '<button type="button" class="cb-btn cb-ghost cb-btn-sm report-history-del" data-hist-act="del">Smazat</button>' +
      '</div>' +
    '</div>';
  }).join("");
  listEl.innerHTML = rows;
  listEl.querySelectorAll(".report-history-item").forEach(el => {
    const id = el.dataset.histId;
    el.querySelectorAll("[data-hist-act]").forEach(btn => {
      btn.addEventListener("click", () => {
        const act = btn.dataset.histAct;
        if (act === "open") openHistoryEntry(id, false);
        else if (act === "dup") openHistoryEntry(id, true);
        else if (act === "pdf") downloadHistoryPdf(id);
        else if (act === "del") deleteHistoryEntry(id);
      });
    });
  });
}

function _fmtHistTs(iso) {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    const p = (n) => String(n).padStart(2, "0");
    return p(d.getDate()) + "." + p(d.getMonth() + 1) + "." + d.getFullYear() +
      " " + p(d.getHours()) + ":" + p(d.getMinutes());
  } catch (e) { return iso; }
}

// Načte kompletní protokol z historie do editoru. duplicate=true vytvoří
// nezavázanou kopii (uloží se jako nová položka); jinak se edituje původní.
async function openHistoryEntry(id, duplicate) {
  const statusEl = document.getElementById("report-history-status");
  try {
    const r = await api("/api/report/history/" + encodeURIComponent(id));
    const rec = r && r.entry;
    if (!rec || !rec.doc) { toast("Položku se nepodařilo načíst.", true); return; }
    const doc = rec.doc;
    REPORT.draft = doc;
    REPORT.historyEntryId = duplicate ? null : rec.id;
    // načítáme jiný protokol – začni s všemi stroji sbalenými
    REPORT.expandedMachines.clear();
    // obnov pomocná pole formuláře (stejně jako v openReport)
    const aiCtxEl = document.getElementById("report-ai-context");
    if (aiCtxEl) aiCtxEl.value = doc.ai_context || "";
    const versionEl = document.getElementById("report-version");
    if (versionEl) versionEl.value = String(doc.report_version || 1);
    _syncReportAppendixImageUi();
    const capEl = document.getElementById("report-appendix-image-caption");
    if (capEl) capEl.value = doc.appendix_image_caption || "";
    _renderAppendixImagePreview(doc.appendix_image || "");
    if (doc.model) populateReportModelSelect(doc.model);
    fillReportEditor(doc);
    setReportEditorVisible(true);
    _setReportBtns(true);
    // ulož jako aktuální rozpracovaný návrh, ať naváže na PDF/save flow
    try {
      await api("/api/report/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ doc }),
      });
    } catch (e) { /* nekritické */ }
    switchReportTab("setup");
    if (statusEl) statusEl.textContent = "";
    toast(duplicate
      ? "Protokol načten jako nová kopie (uloží se jako nová položka)."
      : "Protokol načten z historie k editaci.");
  } catch (e) {
    toast("Načtení z historie selhalo.", true);
  }
}

// Stáhne PDF přímo z uloženého protokolu v historii (bez přepisu editoru).
async function downloadHistoryPdf(id) {
  try {
    const r = await api("/api/report/history/" + encodeURIComponent(id));
    const rec = r && r.entry;
    if (!rec || !rec.doc) { toast("Položku se nepodařilo načíst.", true); return; }
    const resp = await fetch(API + "/api/report/pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ doc: rec.doc }),
    });
    if (!resp.ok) {
      let msg = "Chyba " + resp.status;
      try { const j = await resp.json(); if (j.detail) msg = j.detail; } catch (e) {}
      throw new Error(msg);
    }
    const blob = await resp.blob();
    let fname = rec.pdf_filename || "Protokol.pdf";
    const cd = resp.headers.get("Content-Disposition") || "";
    const mStar = cd.match(/filename\*=UTF-8''([^;]+)/i);
    const mPlain = cd.match(/filename="?([^";]+)"?/i);
    if (mStar) fname = decodeURIComponent(mStar[1]);
    else if (mPlain) fname = mPlain[1];
    _downloadBlob(blob, fname);
    toast("PDF z historie vygenerováno.");
  } catch (e) {
    toast(e.message || "Generování PDF z historie selhalo.", true);
  }
}

// Smaže položku historie (po potvrzení).
async function deleteHistoryEntry(id) {
  if (!confirm("Opravdu smazat tento protokol z historie? Tuto akci nelze vrátit."))
    return;
  try {
    await api("/api/report/history/" + encodeURIComponent(id), { method: "DELETE" });
    if (REPORT.historyEntryId === id) REPORT.historyEntryId = null;
    toast("Položka historie smazána.");
    loadReportHistory();
  } catch (e) {
    toast("Smazání selhalo.", true);
  }
}

// Stav náhledu PDF (blob URL a název pro stažení z modalu).
let PDF_PREVIEW = { url: null, blob: null, fname: "Protokol.pdf" };

function _closePdfPreview() {
  const modal = document.getElementById("pdf-preview-modal");
  if (modal) modal.classList.add("hidden");
  const frame = document.getElementById("pdf-preview-frame");
  if (frame) { frame.src = "about:blank"; frame.classList.add("hidden"); }
  if (PDF_PREVIEW.url) {
    try { URL.revokeObjectURL(PDF_PREVIEW.url); } catch (e) {}
  }
  PDF_PREVIEW = { url: null, blob: null, fname: "Protokol.pdf" };
}

// Zobrazí náhled celého PDF protokolu na NOVÉ KARTĚ prohlížeče (ne v modalním
// okně). Náhled je vytvořen stejnou cestou jako výsledné PDF, takže je s ním
// 1:1 shodný. Kartu otevíráme synchronně hned na kliknutí (jinak by ji blokoval
// pop-up blocker) a URL do ní doplníme po vygenerování blobu.
async function previewReportPdf() {
  if (!REPORT.draft) {
    toast("Nejprve vytvořte návrh protokolu.", true);
    return;
  }
  // uvolnění předchozího náhledu
  if (PDF_PREVIEW.url) { try { URL.revokeObjectURL(PDF_PREVIEW.url); } catch (e) {} }
  PDF_PREVIEW = { url: null, blob: null, fname: "Protokol.pdf" };
  // otevři prázdnou kartu ještě před asynchronním generováním (kvůli pop-up
  // blockeru); do ní později nastavíme adresu PDF
  const tab = window.open("", "_blank");
  if (tab) {
    try {
      tab.document.write(
        '<!doctype html><html lang="cs"><head><meta charset="utf-8">' +
        '<title>Náhled protokolu…</title><style>' +
        'html,body{height:100%;margin:0;font-family:system-ui,Arial,sans-serif;' +
        'background:#1e1e1e;color:#ddd;display:flex;align-items:center;' +
        'justify-content:center}</style></head><body>' +
        'Připravuji náhled PDF…</body></html>');
    } catch (e) { /* ignore */ }
  }
  const st = document.getElementById("pdf-preview-status");
  if (st) st.textContent = "";
  _setReportBtns(false);
  try {
    const { blob, fname } = await _buildReportPdfBlob();
    const url = URL.createObjectURL(blob);
    PDF_PREVIEW = { url, blob, fname };
    if (tab && !tab.closed) {
      // přesěruj otevřenou kartu přímo na blob s PDF
      tab.location.href = url;
    } else {
      // kartu se nepodařilo otevřít (blokováno) – zkus ještě jednou
      const t2 = window.open(url, "_blank");
      if (!t2) {
        toast("Prohlížeč zablokoval otevření nové karty. Povolte vyskakovací "
          + "okna pro tuto stránku, nebo použijte „Vygenerovat PDF“.", true);
      }
    }
    if (st) st.textContent = fname;
    // blob URL neuvolňujeme hned – musí zůstat živý pro otevřenou kartu;
    // uvolní se při příštím náhledu / stažení
  } catch (e) {
    if (tab && !tab.closed) { try { tab.close(); } catch (e2) {} }
    toast(e.message || "Náhled PDF selhal.", true);
  } finally {
    _setReportBtns(true);
  }
}


// ====================================================================
//  AI PORADCE PRO DIAGNOSTIKY — na úrovni MĚŘICÍHO BODU
//  Panel pod grafy v detailu bodu: detekce/ruční zadání otáček +
//  historie, přiřazené ložisko + defektní frekvence (Hz), AI vyhodnocení
//  (výběr modelu, spuštění, výsledek, editace, historie). Vše se ukládá.
// ====================================================================

// Stav AI poradce pro aktuálně otevřený bod.
let PT = {
  pointId: null,
  data: null,            // objekt "point" z /api/point/<id>/ai-data
  overrides: null,       // {speed_hz, speed_history, ai_eval, ai_eval_history}
  isoNorm: null,         // norma zděděná z karty stroje
  speedHistory: [],
};

// Hlavní vstupní bod — naplní kontejner #point-advisor pro daný bod.
async function renderPointAdvisor(pointId) {
  const host = document.getElementById("point-advisor");
  if (!host) return;
  PT = { pointId, data: null, overrides: null, isoNorm: null, speedHistory: [] };
  host.innerHTML = '<div class="pa-loading"><div class="spinner"></div></div>';
  try {
    const r = await api(`/api/point/${pointId}/ai-data`);
    PT.data = r.point || null;
    PT.overrides = r.overrides || {};
    PT.isoNorm = r.iso_norm || null;
    PT.speedHistory = (r.overrides && r.overrides.speed_history) || [];
  } catch (e) {
    host.innerHTML =
      `<div class="pa-error">Data pro AI poradce se nepodařilo načíst: ${escapeHtml(e.message || "")}</div>`;
    return;
  }
  if (!PT.data) {
    host.innerHTML = `<div class="pa-error">Měřicí bod nenalezen.</div>`;
    return;
  }

  host.innerHTML = "";

  // nadpis sekce
  const title = document.createElement("div");
  title.className = "pa-section-title";
  title.innerHTML =
    `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" style="vertical-align:-3px;margin-right:7px"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15l-1.9-4.1L5.5 9l4.6-1.4z"/><path d="M18 14l.9 2.2L21 17l-2.1.8L18 20l-.9-2.2L15 17l2.1-.8z"/></svg>` +
    `AI poradce pro diagnostiky — lokální vyhodnocení bodu`;
  host.appendChild(title);

  host.appendChild(renderPointSpeedPanel());
  host.appendChild(renderPointBearingPanel());
  host.appendChild(renderPointAiPanel());
}

// ---- panel otáček bodu (detekce + ruční + historie) ----
function renderPointSpeedPanel() {
  const panel = document.createElement("div");
  panel.className = "pa-panel pa-speed";

  const own = PT.overrides && PT.overrides.speed_hz != null ? PT.overrides.speed_hz : null;
  const mach = PT.data.machine_speed_hz != null ? PT.data.machine_speed_hz : null;
  const dbp = PT.data.db_speed_hz != null ? PT.data.db_speed_hz : null;
  const spec = PT.data.spectrum_speed_hz != null ? PT.data.spectrum_speed_hz : null;
  const fallback = mach != null ? mach : (dbp != null ? dbp : (spec != null ? spec : null));
  const ph = fallback != null ? fmtNum(fallback, 2) : "—";
  let srcLabel, srcCls;
  if (own != null) { srcLabel = "vlastní"; srcCls = "pa-src-own"; }
  else if (mach != null) { srcLabel = "z karty stroje"; srcCls = "pa-src-db"; }
  else if (dbp != null) { srcLabel = "z DB (bod)"; srcCls = "pa-src-db"; }
  else { srcLabel = "nezadáno"; srcCls = "pa-src-db"; }
  const inputVal = own != null ? own : "";

  const head = document.createElement("div");
  head.className = "pa-head";
  head.innerHTML =
    `<span class="pa-name">Otáčky pro diagnostiku bodu</span>` +
    `<span class="pa-src ${srcCls}">${srcLabel}</span>`;
  panel.appendChild(head);

  const body = document.createElement("div");
  body.className = "pa-row";
  body.innerHTML = `
    <div class="brg-field">
      <label>Otáčky [Hz]</label>
      <input id="pa-speed-input" class="brg-in" type="number" step="any" min="0"
             value="${inputVal}" placeholder="${ph}" title="Výchozí: ${ph} Hz" />
    </div>
    <button id="pa-speed-detect" class="brg-search-btn" title="Automaticky detekovat otáčky z maxima spektra rychlosti tohoto bodu (5–70 Hz)">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.9" style="vertical-align:-3px;margin-right:5px"><path d="M3 12h4l3 8 4-16 3 8h4"/></svg>
      Detekovat ze spektra
    </button>`;
  panel.appendChild(body);

  const hint = document.createElement("div");
  hint.className = "pa-hint";
  hint.innerHTML =
    "Otáčky se použijí pro přepočet <strong>defektních frekvencí ložiska</strong> do Hz a vloží se do " +
    "promptu pro AI. Prázdné pole = použijí se otáčky z karty stroje / databáze (šedě). " +
    "Tlačítko <em>Detekovat ze spektra</em> najde maximální amplitudu spektra rychlosti tohoto bodu (5–70 Hz).";
  panel.appendChild(hint);

  const histSection = document.createElement("div");
  histSection.className = "pa-subsection";
  histSection.innerHTML =
    `<div class="pa-subtitle">Historie detekcí otáček</div><div id="pa-speed-hist"></div>`;
  panel.appendChild(histSection);

  body.querySelector("#pa-speed-detect").addEventListener("click", detectPointSpeed);
  renderPointSpeedHistory(PT.speedHistory, histSection.querySelector("#pa-speed-hist"));
  return panel;
}

function renderPointSpeedHistory(history, boxEl) {
  const box = boxEl || document.getElementById("pa-speed-hist");
  if (!box) return;
  box.innerHTML = "";
  if (!history || !history.length) {
    box.innerHTML = `<div class="pa-empty">Zatím žádné detekce. Použijte tlačítko „Detekovat ze spektra“.</div>`;
    return;
  }
  const table = document.createElement("table");
  table.className = "mc-hist-table";
  table.innerHTML = `<thead><tr><th>Datum a čas detekce</th><th>Otáčky [Hz]</th><th></th></tr></thead>`;
  const tbody = document.createElement("tbody");
  history.forEach((rec, i) => {
    const tr = document.createElement("tr");
    if (i === 0) tr.className = "mc-hist-latest";
    const d = document.createElement("td"); d.className = "mc-hist-date"; d.textContent = fmtDate(rec.time);
    const v = document.createElement("td"); v.className = "mc-hist-val"; v.textContent = fmtNum(rec.value, 2);
    const a = document.createElement("td"); a.className = "mc-hist-act";
    const btn = document.createElement("button");
    btn.className = "mc-hist-restore"; btn.type = "button";
    btn.title = "Obnovit tuto hodnotu jako aktuální otáčky bodu"; btn.textContent = "Obnovit";
    btn.addEventListener("click", () => applyPointSpeed(rec.value));
    a.appendChild(btn);
    tr.appendChild(d); tr.appendChild(v); tr.appendChild(a);
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  box.appendChild(table);
}

function applyPointSpeed(value) {
  const inp = document.getElementById("pa-speed-input");
  if (inp) { inp.value = fmtNum(value, 2); inp.focus(); }
  // překresli defektní frekvence dle nových otáček
  renderPointBearingFreqs(currentPointSpeed());
  toast(`Otáčky nastaveny na ${fmtNum(value, 2)} Hz.`);
}

async function detectPointSpeed() {
  if (PT.pointId == null) return;
  const btn = document.getElementById("pa-speed-detect");
  const inp = document.getElementById("pa-speed-input");
  if (btn) btn.disabled = true;
  try {
    const r = await api(`/api/point/${PT.pointId}/detect-speed`);
    if (r && r.speed_hz != null) {
      if (inp) inp.value = fmtNum(r.speed_hz, 2);
      const amp = r.amplitude != null ? fmtNum(r.amplitude, 3) : "—";
      if (r.speed_history) { PT.speedHistory = r.speed_history; renderPointSpeedHistory(r.speed_history); }
      renderPointBearingFreqs(currentPointSpeed());
      toast(`Detekováno ${fmtNum(r.speed_hz, 2)} Hz (amplituda ${amp}).`);
    } else {
      toast("Otáčky se nepodařilo detekovat – bod nemá vhodné spektrum rychlosti.", true);
    }
  } catch (e) {
    const msg = (e && e.message && /404/.test(e.message))
      ? "Otáčky se nepodařilo detekovat – bod nemá naměřené spektrum rychlosti (5–70 Hz)."
      : (e.message || "Detekce otáček selhala.");
    toast(msg, true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

// Aktuální otáčky bodu pro výpočty/prompt: pole > karta stroje > DB bodu > spektrum.
function currentPointSpeed() {
  const inp = document.getElementById("pa-speed-input");
  if (inp && inp.value !== "") {
    const v = parseFloat(inp.value);
    if (isFinite(v) && v > 0) return v;
  }
  if (PT.data) {
    if (PT.data.machine_speed_hz != null) return PT.data.machine_speed_hz;
    if (PT.data.db_speed_hz != null) return PT.data.db_speed_hz;
    if (PT.data.spectrum_speed_hz != null) return PT.data.spectrum_speed_hz;
  }
  return null;
}

// ---- panel přiřazeného ložiska + defektní frekvence ----
function renderPointBearingPanel() {
  const panel = document.createElement("div");
  panel.className = "pa-panel pa-bearing";

  const b = PT.data.assigned_bearing;
  const head = document.createElement("div");
  head.className = "pa-head";
  const bk = PT.data.bearing_label || PT.data.bearing_key || "—";
  const dir = PT.data.direction || "—";
  head.innerHTML =
    `<span class="pa-name">Přiřazené ložisko · místo ${escapeHtml(bk)} (směr ${escapeHtml(dir)})</span>`;
  panel.appendChild(head);

  if (!b) {
    const empty = document.createElement("div");
    empty.className = "pa-empty";
    empty.innerHTML =
      "Pro toto měřicí místo zatím není přiřazeno ložisko. Přiřaďte ho na " +
      "<strong>kartě stroje</strong> (sekce ložiska), poté se zde zobrazí jeho " +
      "defektní frekvence a vloží se do AI promptu.";
    panel.appendChild(empty);
    return panel;
  }

  const info = document.createElement("div");
  info.className = "pa-brg-info";
  const bits = [];
  if (b.designation) bits.push(`<span class="pa-brg-tag pa-brg-desig">${escapeHtml(b.designation)}</span>`);
  if (b.manufacturer) bits.push(`<span class="pa-brg-tag">${escapeHtml(b.manufacturer)}</span>`);
  if (b.type) bits.push(`<span class="pa-brg-tag">${escapeHtml(b.type)}</span>`);
  info.innerHTML = bits.join("") || `<span class="pa-brg-tag">ložisko bez označení</span>`;
  panel.appendChild(info);

  const freqWrap = document.createElement("div");
  freqWrap.className = "pa-freqs";
  freqWrap.id = "pa-freqs";
  panel.appendChild(freqWrap);

  const note = document.createElement("div");
  note.className = "pa-hint";
  note.innerHTML =
    "Defektní frekvence se počítají jako <strong>násobek otáček</strong>: f [Hz] = koeficient ×ot × otáčky [Hz]. " +
    "Tyto hodnoty se vloží do AI promptu pro posouzení stavu ložiska.";
  panel.appendChild(note);

  renderPointBearingFreqs(currentPointSpeed(), freqWrap, b);
  return panel;
}

// Vykreslí defektní frekvence (FTF/BSF/BPFO/BPFI) v ×ot a v Hz dle otáček.
function renderPointBearingFreqs(speedHz, boxEl, bearing) {
  const box = boxEl || document.getElementById("pa-freqs");
  if (!box) return;
  const b = bearing || (PT.data && PT.data.assigned_bearing);
  if (!b) { box.innerHTML = ""; return; }
  const defs = [
    { k: "FTF",  label: "FTF",  sub: "klec" },
    { k: "BSF",  label: "BSF",  sub: "valivý element" },
    { k: "BPFO", label: "BPFO", sub: "vnější kroužek" },
    { k: "BPFI", label: "BPFI", sub: "vnitřní kroužek" },
  ];
  const rows = defs.map(d => {
    const coef = b[d.k];
    const coefTxt = coef != null ? fmtNum(coef, 3) + " ×ot" : "—";
    let hzTxt = "—";
    if (coef != null && speedHz != null && isFinite(speedHz) && speedHz > 0) {
      hzTxt = fmtNum(coef * speedHz, 2) + " Hz";
    } else if (coef != null) {
      hzTxt = "— Hz";
    }
    return `<div class="pa-freq-cell ${coef != null ? "" : "pa-freq-na"}">
        <div class="pa-freq-k">${d.label}</div>
        <div class="pa-freq-sub">${d.sub}</div>
        <div class="pa-freq-coef">${coefTxt}</div>
        <div class="pa-freq-hz">${hzTxt}</div>
      </div>`;
  }).join("");
  const spd = (speedHz != null && isFinite(speedHz) && speedHz > 0)
    ? `při otáčkách ${fmtNum(speedHz, 2)} Hz (${fmtNum(speedHz * 60, 0)} ot/min)`
    : "otáčky nezadány – zadejte je výše pro přepočet do Hz";
  box.innerHTML = `<div class="pa-freq-grid">${rows}</div><div class="pa-freq-note">${spd}</div>`;
}

// ---- AI poradce (výběr modelu, spuštění, výsledek, editace, historie) ----
function renderPointAiPanel() {
  const panel = document.createElement("div");
  panel.className = "pa-panel pa-ai";

  const head = document.createElement("div");
  head.className = "pa-head";
  head.innerHTML =
    `<span class="pa-name">Vyhodnocení bodu pomocí AI</span>` +
    `<span class="pa-src pa-ai-badge">rádce pro diagnostiky</span>`;
  panel.appendChild(head);

  // info o normě (děděná z karty stroje)
  const normInfo = document.createElement("div");
  normInfo.className = "pa-norm-info";
  const nlabel = ptNormLabel(PT.isoNorm);
  normInfo.innerHTML = nlabel
    ? `Norma (z karty stroje): <strong>${escapeHtml(nlabel)}</strong>`
    : `Norma nebyla na kartě stroje zadána — AI použije obecné principy ČSN ISO 20816.`;
  panel.appendChild(normInfo);

  const hint = document.createElement("div");
  hint.className = "pa-hint";
  hint.innerHTML =
    "AI vystupuje jako <strong>rádce pro diagnostiky</strong> a provede lokální vyhodnocení tohoto " +
    "měřicího bodu: porovná hodnoty s limity a normou a se zaměřením na přiřazené ložisko a jeho " +
    "defektní frekvence posoudí možné závady. Volání AI spotřebovává kredity. Výsledek se automaticky ukládá.";
  panel.appendChild(hint);

  // výběr modelu + spuštění
  const actRow = document.createElement("div");
  actRow.className = "pa-actions";
  const modelOpts = (AI_CONF.models || []).map(md => {
    const avail = (md.provider === "anthropic" || md.provider === "anthropic_agent") ? AI_CONF.has_anthropic_key : AI_CONF.has_openai_key;
    const sel = md.id === AI_CONF.model ? " selected" : "";
    const dis = avail ? "" : " disabled";
    const suffix = avail ? "" : " — chybí API klíč";
    return `<option value="${escapeHtml(md.id)}"${sel}${dis}>${escapeHtml(md.label)}${suffix}</option>`;
  }).join("");
  actRow.innerHTML = `
    <div class="pa-model-field">
      <label for="pa-ai-model">Model AI</label>
      <select id="pa-ai-model" class="cb-input">${modelOpts || '<option value="">(žádné modely)</option>'}</select>
    </div>
    <button id="pa-ai-run" class="cb-btn cb-primary">
      <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" style="vertical-align:-3px;margin-right:6px"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15l-1.9-4.1L5.5 9l4.6-1.4z"/><path d="M18 14l.9 2.2L21 17l-2.1.8L18 20l-.9-2.2L15 17l2.1-.8z"/></svg>
      Vyhodnotit bod pomocí AI
    </button>
    <span id="pa-ai-status" class="mc-ai-status"></span>`;
  panel.appendChild(actRow);

  const resBox = document.createElement("div");
  resBox.className = "mc-ai-result"; resBox.id = "pa-ai-result";
  panel.appendChild(resBox);

  const histBox = document.createElement("div");
  histBox.className = "mc-ai-history"; histBox.id = "pa-ai-history";
  panel.appendChild(histBox);

  actRow.querySelector("#pa-ai-run").addEventListener("click", runPointAiEval);

  renderPointAiResult((PT.overrides && PT.overrides.ai_eval) || null, resBox);
  renderPointAiHistory((PT.overrides && PT.overrides.ai_eval_history) || [], histBox);
  return panel;
}

function ptNormLabel(iso) {
  if (!iso) return "";
  const parts = [];
  if (iso.standard) parts.push(iso.standard);
  if (iso.machine_class) parts.push(iso.machine_class);
  if (iso.custom) parts.push(iso.custom);
  return parts.join(" – ");
}

async function runPointAiEval() {
  if (PT.pointId == null) return;
  const btn = document.getElementById("pa-ai-run");
  const statusEl = document.getElementById("pa-ai-status");
  const resBox = document.getElementById("pa-ai-result");

  const speed_hz = currentPointSpeed();
  let model = null;
  const mdlSel = document.getElementById("pa-ai-model");
  if (mdlSel && mdlSel.value) model = mdlSel.value;

  if (btn) btn.disabled = true;
  if (statusEl) { statusEl.textContent = "AI vyhodnocuje data bodu… (může trvat několik sekund)"; statusEl.className = "mc-ai-status busy"; }
  if (resBox) resBox.innerHTML = '<div class="spinner"></div>';

  try {
    const r = await api(`/api/point/${PT.pointId}/ai-eval`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ speed_hz, model, save: true }),
    });
    if (r && r.ai_eval) {
      if (PT.overrides) {
        PT.overrides.ai_eval = r.ai_eval;
        if (r.ai_eval_history) PT.overrides.ai_eval_history = r.ai_eval_history;
      }
      renderPointAiResult(r.ai_eval, resBox);
      renderPointAiHistory((PT.overrides && PT.overrides.ai_eval_history) || [], document.getElementById("pa-ai-history"));
      if (statusEl) { statusEl.textContent = "Vyhodnocení dokončeno a uloženo."; statusEl.className = "mc-ai-status ok"; }
      toast("AI vyhodnocení bodu dokončeno a uloženo.");
    } else {
      if (statusEl) { statusEl.textContent = "AI nevrátila žádný výsledek."; statusEl.className = "mc-ai-status err"; }
    }
  } catch (e) {
    const msg = e.message || "Vyhodnocení selhalo.";
    if (resBox) resBox.innerHTML = `<div class="mc-ai-error">${escapeHtml(msg)}</div>`;
    if (statusEl) { statusEl.textContent = "Chyba při volání AI."; statusEl.className = "mc-ai-status err"; }
    toast(msg, true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

function renderPointAiResult(ev, boxEl) {
  const box = boxEl || document.getElementById("pa-ai-result");
  if (!box) return;
  box.innerHTML = "";
  if (!ev || !ev.text) {
    box.innerHTML = `<div class="mc-ai-empty">Zatím bez vyhodnocení. Vyberte model a klikněte na „Vyhodnotit bod pomocí AI“.</div>`;
    return;
  }
  const meta = document.createElement("div");
  meta.className = "mc-ai-meta";
  const parts = [];
  parts.push(`<span class="mc-ai-mtag">Vyhodnoceno: ${escapeHtml(fmtDate(ev.time))}</span>`);
  if (ev.speed_hz != null) parts.push(`<span class="mc-ai-mtag">Otáčky: ${fmtNum(ev.speed_hz, 2)} Hz</span>`);
  if (ev.norm) parts.push(`<span class="mc-ai-mtag">Norma: ${escapeHtml(ev.norm)}</span>`);
  if (ev.model) parts.push(`<span class="mc-ai-mtag">Model: ${escapeHtml(ev.model)}</span>`);
  if (ev.edited) parts.push(`<span class="mc-ai-mtag mc-ai-edited">ručně upraveno</span>`);
  meta.innerHTML = parts.join("");
  box.appendChild(meta);

  const view = document.createElement("div");
  view.className = "mc-ai-text"; view.id = "pa-ai-text-view"; view.textContent = ev.text;
  box.appendChild(view);

  const tools = document.createElement("div");
  tools.className = "mc-ai-tools";
  tools.innerHTML = `<button id="pa-ai-edit" class="cb-btn cb-ghost">Upravit závěr</button>`;
  box.appendChild(tools);

  const editor = document.createElement("div");
  editor.className = "mc-ai-editor hidden"; editor.id = "pa-ai-editor";
  editor.innerHTML = `
    <textarea id="pa-ai-textarea" class="mc-ai-textarea" rows="14"></textarea>
    <div class="mc-ai-editor-actions">
      <button id="pa-ai-save" class="cb-btn cb-primary">Uložit úpravy</button>
      <button id="pa-ai-cancel" class="cb-btn cb-ghost">Zrušit</button>
    </div>`;
  box.appendChild(editor);
  box._aiEval = ev;

  tools.querySelector("#pa-ai-edit").addEventListener("click", () => {
    const ta = document.getElementById("pa-ai-textarea");
    ta.value = ev.text;
    editor.classList.remove("hidden");
    view.classList.add("hidden");
    tools.classList.add("hidden");
    ta.focus();
  });
  editor.querySelector("#pa-ai-cancel").addEventListener("click", () => {
    editor.classList.add("hidden");
    view.classList.remove("hidden");
    tools.classList.remove("hidden");
  });
  editor.querySelector("#pa-ai-save").addEventListener("click", () => savePointAiEdit(box));
}

async function savePointAiEdit(box) {
  if (PT.pointId == null) return;
  const ev = box._aiEval || {};
  const ta = document.getElementById("pa-ai-textarea");
  const newText = ta ? ta.value : "";
  const saveBtn = document.getElementById("pa-ai-save");
  if (saveBtn) saveBtn.disabled = true;
  try {
    const r = await api(`/api/point/${PT.pointId}/ai-eval/save`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: newText,
        time: ev.time || null,
        speed_hz: ev.speed_hz != null ? ev.speed_hz : null,
        norm: ev.norm || null,
        model: ev.model || null,
      }),
    });
    if (r && r.ai_eval) {
      if (PT.overrides) {
        PT.overrides.ai_eval = r.ai_eval;
        if (r.ai_eval_history) PT.overrides.ai_eval_history = r.ai_eval_history;
      }
      renderPointAiResult(r.ai_eval, box);
      renderPointAiHistory((PT.overrides && PT.overrides.ai_eval_history) || [], document.getElementById("pa-ai-history"));
      toast("Úpravy závěru uloženy.");
    }
  } catch (e) {
    toast(e.message || "Uložení úprav selhalo.", true);
  } finally {
    if (saveBtn) saveBtn.disabled = false;
  }
}

function renderPointAiHistory(history, boxEl) {
  const box = boxEl || document.getElementById("pa-ai-history");
  if (!box) return;
  box.innerHTML = "";
  const list = Array.isArray(history) ? history : [];
  if (!list.length) return;
  const activeText = (PT.overrides && PT.overrides.ai_eval && PT.overrides.ai_eval.text) || null;

  const head = document.createElement("div");
  head.className = "mc-ai-history-head";
  head.textContent = `Historie vyhodnocení (${list.length})`;
  box.appendChild(head);

  const ul = document.createElement("div");
  ul.className = "mc-ai-history-list";
  list.forEach((ev, idx) => {
    const isActive = activeText != null && ev && ev.text === activeText;
    const item = document.createElement("div");
    item.className = "mc-ai-history-item" + (isActive ? " active" : "");
    const tags = [];
    tags.push(`<span class="mc-ai-hi-meta">${escapeHtml(fmtDate(ev.time))}</span>`);
    if (ev.model) tags.push(`<span class="mc-ai-hi-meta">${escapeHtml(ev.model)}</span>`);
    if (ev.norm) tags.push(`<span class="mc-ai-hi-meta">${escapeHtml(ev.norm)}</span>`);
    if (ev.edited) tags.push(`<span class="mc-ai-hi-meta">ručně upraveno</span>`);
    const preview = (ev.text || "").replace(/\s+/g, " ").trim().slice(0, 90);
    const previewSuffix = (ev.text || "").length > 90 ? "…" : "";
    item.innerHTML = `
      <div class="mc-ai-hi-tags">${tags.join("")}</div>
      <div class="mc-ai-hi-prev">${escapeHtml(preview)}${previewSuffix}</div>
      <button class="cb-btn cb-ghost mc-ai-hi-recall" data-idx="${idx}" ${isActive ? "disabled" : ""}>${isActive ? "Zobrazeno" : "Zobrazit"}</button>`;
    item.querySelector(".mc-ai-hi-recall").addEventListener("click", () => recallPointAiEval(idx));
    ul.appendChild(item);
  });
  box.appendChild(ul);
}

async function recallPointAiEval(index) {
  if (PT.pointId == null) return;
  try {
    const r = await api(`/api/point/${PT.pointId}/ai-eval/recall`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ index }),
    });
    if (r && r.ai_eval) {
      if (PT.overrides) {
        PT.overrides.ai_eval = r.ai_eval;
        if (r.ai_eval_history) PT.overrides.ai_eval_history = r.ai_eval_history;
      }
      renderPointAiResult(r.ai_eval, document.getElementById("pa-ai-result"));
      renderPointAiHistory((PT.overrides && PT.overrides.ai_eval_history) || [], document.getElementById("pa-ai-history"));
      toast("Vyhodnocení bylo vyvoláno z historie.");
    }
  } catch (e) {
    toast(e.message || "Vyvolání vyhodnocení selhalo.", true);
  }
}
