"""
Lokální webový server aplikace HADS – Heistech AI Diagnostic Software.
(zpracování diagnostických dat z měřicích přístrojů).

Používá POUZE standardní knihovnu Pythonu (http.server) — nevyžaduje
instalaci žádných externích balíčků. Funguje na jakékoli verzi Pythonu 3.8+
(včetně 3.14) bez stahování čehokoli z internetu.

Spuštění:
    python server.py
Server poběží na http://127.0.0.1:8000
"""

import json
import os
import re
import shutil
import sys
import time
import webbrowser
import threading
import atexit
import hashlib
import hmac
import secrets
import socket
import platform
import ipaddress
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, quote

# umožni import ndb_parser ze stejné složky
sys.path.insert(0, str(Path(__file__).resolve().parent))
from ndb_parser import NdbDatabase  # noqa: E402
from database_update import (  # noqa: E402
    ActiveDatabaseUpdater,
    DatabaseUpdateCoordinator,
    DatabaseBusy,
    DatabaseOperationLock,
    UpdateError,
    acknowledge_database_update_receipt,
    ensure_space,
    pending_database_update_receipt,
    recover_abandoned_database_update,
    read_locked,
    stream_multipart_ndb,
    validate_ndb,
    write_locked,
)
from version import APP_VERSION  # noqa: E402
from lifecycle import LifecycleBusy, LifecycleController, ShutdownNonceStore  # noqa: E402
import bearings  # noqa: E402
import branding  # noqa: E402
import fft_analysis  # noqa: E402
import fft_settings  # noqa: E402
import machine_config  # noqa: E402
import ai_eval  # noqa: E402
import company  # noqa: E402
import report as report_mod  # noqa: E402
import report_pdf  # noqa: E402
import report_docx  # noqa: E402
import docx_import  # noqa: E402
import report_store  # noqa: E402
import report_refresh  # noqa: E402
import report_history  # noqa: E402
import ai_knowledge  # noqa: E402
import ai_prompts  # noqa: E402
import report_settings  # noqa: E402
import data_store  # noqa: E402
import shared_updates  # noqa: E402
import data_protection  # noqa: E402
from process_identity import current_process_identity  # noqa: E402

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
FRONTEND_DIR = BASE_DIR / "frontend"
DATA_DIR.mkdir(exist_ok=True)
_SHARED_UPDATE_PUBLIC_KEY = BASE_DIR / "backend" / "release_signing_public.pem"
_startup_update_badge: dict | None = None

# Zámek je výhradně lokální smlouva mezi nativním spouštěčem, serverem a
# aktualizátorem. Token se nikdy nevrací přes běžné API ani se nezapisuje do logu.
_SERVER_LOCK_FILE = DATA_DIR / "hads_server.lock"
_SHUTDOWN_TOKEN = os.environ.get("HADS_SHUTDOWN_TOKEN", "")
_SERVER: ThreadingHTTPServer | None = None
_LIFECYCLE = LifecycleController()
_UI_SHUTDOWN_NONCES = ShutdownNonceStore()
_AI_CONFIG_NONCES = ShutdownNonceStore()
_AI_PROMPT_NONCES = ShutdownNonceStore()
_BACKGROUND_CANCEL = threading.Event()
_BACKGROUND_THREADS: list[threading.Thread] = []
_BACKGROUND_TIMERS: list[threading.Timer] = []
_TEARDOWN_LOCK = threading.Lock()
_TEARDOWN_STARTED = False
_SHUTDOWN_WAIT_SECONDS = 2.0


def _installation_fingerprint() -> str:
    return hashlib.sha256(str(BASE_DIR.resolve()).casefold().encode("utf-8")).hexdigest()


def _process_identity() -> str | None:
    """Identita instance z jediného sdíleného a verifikovatelného API."""
    return current_process_identity()


def _write_server_lock(port: int) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "format": 2,
        "pid": os.getpid(),
        "port": int(port),
        "started_at": time.time(),
        "installation_root": str(BASE_DIR.resolve()),
        "installation_fingerprint": _installation_fingerprint(),
        "process_identity": _process_identity() or "unavailable",
        "process_executable": str(Path(sys.executable).resolve()),
        "server_script": str(Path(__file__).resolve()),
        # Není součástí veřejných odpovědí ani logů; launcher jej používá pouze
        # pro lokální autentizované ukončení před restartem.
        "shutdown_token": _SHUTDOWN_TOKEN,
    }
    tmp = _SERVER_LOCK_FILE.with_name(_SERVER_LOCK_FILE.name + ".tmp-" + secrets.token_hex(8))
    try:
        tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, _SERVER_LOCK_FILE)
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


def _remove_server_lock() -> None:
    try:
        if _SERVER_LOCK_FILE.exists():
            rec = json.loads(_SERVER_LOCK_FILE.read_text(encoding="utf-8"))
            if int(rec.get("pid", -1)) == os.getpid() and rec.get("process_identity") == _process_identity():
                _SERVER_LOCK_FILE.unlink()
    except Exception:
        pass


def _is_loopback_peer(address: object) -> bool:
    if not isinstance(address, tuple) or not address:
        return False
    try:
        return ipaddress.ip_address(str(address[0])).is_loopback
    except ValueError:
        return False


def _valid_shutdown_token(value: str | None) -> bool:
    return bool(_SHUTDOWN_TOKEN) and isinstance(value, str) and hmac.compare_digest(value, _SHUTDOWN_TOKEN)


def _server_port() -> int | None:
    server = _SERVER
    if server is not None:
        try:
            return int(server.server_address[1])
        except (AttributeError, IndexError, TypeError, ValueError):
            return None
    return None


def _allowed_ui_origins() -> tuple[str, ...]:
    port = _server_port()
    if port is None:
        return ()
    return (f"http://127.0.0.1:{port}", f"http://localhost:{port}")


def _valid_ui_origin(value: str | None) -> bool:
    return isinstance(value, str) and any(hmac.compare_digest(value, candidate) for candidate in _allowed_ui_origins())


def _valid_ui_host(value: str | None) -> bool:
    """Host musí patřit právě našemu loopback listeneru.

    Browser same-origin GET běžně neposílá Origin. Host je v HTTP/1.1 povinný
    a společně s loopback peerem tak poskytuje potřebnou lokální hranici.
    """
    if not isinstance(value, str):
        return False
    port = _server_port()
    if port is None:
        return False
    return any(hmac.compare_digest(value, candidate) for candidate in (
        f"127.0.0.1:{port}", f"localhost:{port}",
    ))


def _valid_ui_referer(value: str | None) -> bool:
    """Referer, pokud jej browser poslal, musí mít přesně náš origin."""
    if not isinstance(value, str) or not value:
        return False
    try:
        parsed = urlparse(value)
    except ValueError:
        return False
    if parsed.username or parsed.password or parsed.fragment:
        return False
    origin = f"{parsed.scheme}://{parsed.netloc}"
    return _valid_ui_origin(origin)


def _safe_ai_log(phase: str) -> None:
    """Zapisuje jen diagnózu fáze/kódu bez cest, klíčů, blobů či promptů."""
    if phase not in {
        "ai_status_ok", "ai_status_stored_unavailable", "ai_prompts_defaults",
        "ai_prompts_warning", "ai_request_denied",
    }:
        phase = "ai_request_internal"
    _lifecycle_log(phase)


def _lifecycle_log(phase: str) -> None:
    """Zapíše pouze bezpečnou fázi lifecycle; nikdy token, nonce ani cestu uživatele."""
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        with (DATA_DIR / "hads_server.log").open("a", encoding="utf-8") as log:
            log.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} lifecycle={phase}\n")
            log.flush()
    except OSError:
        pass


def _track_timer(timer: threading.Timer) -> threading.Timer:
    _BACKGROUND_TIMERS.append(timer)
    return timer


def _cancel_background_work() -> None:
    _BACKGROUND_CANCEL.set()
    for timer in list(_BACKGROUND_TIMERS):
        try:
            timer.cancel()
        except Exception:
            pass
    for worker in list(_BACKGROUND_THREADS):
        if worker is threading.current_thread():
            continue
        try:
            worker.join(timeout=0.5)
        except (RuntimeError, AttributeError):
            pass


def _close_database_resources() -> None:
    """Vyprázdní cache a korektně uzavře aktivní SQLite/NDB spojení."""
    acquired = _db_operations.acquire_write(timeout=2.0)
    if not acquired:
        _lifecycle_log("database_close_deferred")
        return
    try:
        db = _db_cache.get("db")
        # Do not checkpoint, rename or remove WAL/SHM/JOURNAL here.  A pending
        # database update is committed only by the independent helper after
        # this whole backend process exits. Closing our own cache is sufficient
        # to release HADS handles before that helper runs.
        _close_active_cache()
        active = _active_filename()
        if active:
            _db_operations.close_registered_connections(DATA_DIR / active)
        _invalidate_db_caches()
    finally:
        _db_operations.release_write()


def _graceful_teardown() -> None:
    """Ukončí jen vlastní HTTP službu; nikdy nehledá ani nezabíjí cizí procesy."""
    global _TEARDOWN_STARTED
    with _TEARDOWN_LOCK:
        if _TEARDOWN_STARTED:
            return
        _TEARDOWN_STARTED = True
    _lifecycle_log("teardown_begin")
    _cancel_background_work()
    _close_database_resources()
    _remove_server_lock()
    server = _SERVER
    if server is not None:
        try:
            server.shutdown()
        except Exception:
            _lifecycle_log("server_shutdown_error")
    _lifecycle_log("teardown_scheduled")


def _schedule_shutdown(delay: float = 0.0) -> None:
    """Naplánuje teardown až po odeslání HTTP odpovědi volajícímu."""
    timer = _track_timer(threading.Timer(delay, _graceful_teardown))
    timer.name = "hads-graceful-shutdown"
    timer.daemon = True
    timer.start()


def _start_background(target, name: str) -> threading.Thread:
    thread = threading.Thread(target=target, name=name, daemon=True)
    _BACKGROUND_THREADS.append(thread)
    thread.start()
    return thread


HOST = "127.0.0.1"
PORT = 8000

_STATE_FILE = DATA_DIR / "current.txt"      # jmeno aktivniho souboru
_LIBRARY_FILE = DATA_DIR / "library.json"   # vlastni nazvy databazi
_db_cache = {"path": None, "db": None, "connection_token": None}
# cache identity (klic) podniku podle jmena souboru: {filename: enterprise_key}
_dbkey_cache = {}
# Secret-free state used by the persistence status endpoint and one-time UI
# recovery notice.  It intentionally contains no raw company/DB labels.
_persistence_context = {"filename": None, "result": None}
_db_operations = DatabaseOperationLock()


def _sanitize_filename_part(text):
    r"""Očistí část názvu souboru: povolí písmena/číslice/pomlčku, zbytek na '_'.
    Zachovává české znaky (\w s re.UNICODE). Odstraní úvodní/koncové '_' a '-'.
    """
    s = re.sub(r"[^\w\-]+", "_", str(text or "").strip(), flags=re.UNICODE)
    return s.strip("_-")


def _report_pdf_filename(doc):
    """Sestaví název PDF souboru protokolu.

    Priorita:
    1) explicitní `pdf_filename` z návrhu (uživatel jej mohl upravit ve
       frontendu) — očistí se a dolní přípona .pdf se zajistí,
    2) jinak výchozí formát: <číslo zakázky>-<zákazník>-<název protokolu>.
    """
    d = doc if isinstance(doc, dict) else {}
    # 1) explicitní název od uživatele
    explicit = str(d.get("pdf_filename") or "").strip()
    if explicit:
        explicit = re.sub(r"\.pdf$", "", explicit, flags=re.IGNORECASE)
        clean = _sanitize_filename_part(explicit)
        if clean:
            return clean + ".pdf"
    # 2) výchozí složený název
    order = str(d.get("order_number") or d.get("contract_number") or "").strip()
    if order in ("-", "–", "—"):
        order = ""
    customer = str(d.get("company_name") or "").strip()
    title = str(d.get("report_title") or "").strip()
    parts = [_sanitize_filename_part(p) for p in (order, customer, title)]
    parts = [p for p in parts if p]
    base = "-".join(parts) if parts else "Protokol"
    return base + ".pdf"


def _report_docx_filename(doc):
    """Sestaví název DOCX souboru protokolu (stejná logika jako u PDF)."""
    d = doc if isinstance(doc, dict) else {}
    explicit = str(d.get("docx_filename") or d.get("pdf_filename") or "").strip()
    if explicit:
        explicit = re.sub(r"\.(docx|pdf)$", "", explicit, flags=re.IGNORECASE)
        clean = _sanitize_filename_part(explicit)
        if clean:
            return clean + ".docx"
    base = _report_pdf_filename(d)
    return re.sub(r"\.pdf$", ".docx", base, flags=re.IGNORECASE)


CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".ico": "image/x-icon",
}


# ---------------- knihovna databází ----------------
def _load_library():
    """Načte mapu {filename: vlastni_nazev} z library.json."""
    if _LIBRARY_FILE.exists():
        try:
            return json.loads(_LIBRARY_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_library(lib):
    _LIBRARY_FILE.write_text(json.dumps(lib, ensure_ascii=False, indent=2), encoding="utf-8")


def _list_ndb_files():
    return sorted(DATA_DIR.glob("*.ndb"), key=lambda p: p.name.lower())


def _active_filename():
    """Vrátí jméno souboru (ne cestu) aktivní databáze, nebo None."""
    if _STATE_FILE.exists():
        name = _STATE_FILE.read_text(encoding="utf-8").strip()
        # zpetna kompatibilita: drive se ukladala cela cesta
        name = os.path.basename(name)
        if name and (DATA_DIR / name).exists():
            return name
    files = _list_ndb_files()
    return files[0].name if files else None


def _set_active(filename):
    _STATE_FILE.write_text(os.path.basename(filename), encoding="utf-8")
    _close_active_cache()
    # Selecting a database is the explicit persistence-context boundary.  Do
    # not reuse an identity derived before an external replacement/rename.
    _dbkey_cache.pop(os.path.basename(filename), None)
    _persistence_context["filename"] = None
    _persistence_context["result"] = None


def _close_active_cache():
    """Uzavře cache jediného aktivního spojení (voláno pod výhradním zámkem)."""
    if _db_cache["db"] is not None:
        try:
            _db_cache["db"].close()
        finally:
            _db_operations.unregister_connection(_db_cache.get("connection_token"))
    _db_cache["db"] = None
    _db_cache["path"] = None
    _db_cache["connection_token"] = None


def _open_registered_ndb(path, label="NdbDatabase"):
    """Otevře HADS-owned parser a zapíše jej do registru údržby.

    Každý přístup k aktivní pracovní databázi je tak dohledatelný. Údržba
    nejprve ukončí request leases a potom registr zavře ještě před checkpointem
    WAL, což je nezbytné pro Windows sdílecí zámky.
    """
    db = NdbDatabase(str(path))
    token = _db_operations.register_connection(
        path, lambda database=db: database.close(), label
    )
    return db, token


def _close_registered_ndb(db, token):
    try:
        db.close()
    finally:
        _db_operations.unregister_connection(token)


def _reopen_active_cache():
    """Obnoví běžnou cache po úspěšné výměně nebo rollbacku."""
    if _active_filename():
        get_db()


def _verify_reopened_database():
    """Po swapu ověří normální parserem, že nová pracovní kopie je čitelná."""
    db = get_db()
    if db is None:
        raise UpdateError("Novou pracovní databázi se nepodařilo po výměně otevřít.")
    db.info()
    db.tree()


def _invalidate_db_caches(filename=None):
    """Zahodí identity i odvozené cache vázané na obsah .ndb."""
    if filename:
        _dbkey_cache.pop(filename, None)
    else:
        _dbkey_cache.clear()
    _persistence_context["filename"] = None
    _persistence_context["result"] = None


_active_updater = ActiveDatabaseUpdater(
    DATA_DIR,
    _active_filename,
    _close_active_cache,
    _reopen_active_cache,
    _invalidate_db_caches,
    _db_operations,
    _verify_reopened_database,
)

# Production database exchange path.  Unlike the retained legacy utility
# above, this coordinator only stages/validates and spawns the external helper;
# it never mutates the active .ndb or its sidecars in this backend process.
_database_update_coordinator = DatabaseUpdateCoordinator(
    BASE_DIR,
    DATA_DIR,
    _active_filename,
    backend_identity=_process_identity,
    installation_fingerprint=_installation_fingerprint,
    version=APP_VERSION,
)


def _default_db_path():
    name = _active_filename()
    return str(DATA_DIR / name) if name else None


def _db_key(filename=None):
    """Return a durable context key for all per-company settings.

    Since 1.38.2 the primary key is an intrinsic NDB fingerprint.  It is
    independent of installation directory, temporary extraction root and NDB
    filename.  The registry reconciles it to verified historical aliases before
    the UI service reads settings.  An unreadable NDB retains the former
    filename fallback rather than making a weak name/slug guess.
    """
    fn = filename or _active_filename()
    if not fn:
        return None
    if fn in _dbkey_cache:
        return _dbkey_cache[fn]
    key = None
    reconcile = None
    try:
        path = str(DATA_DIR / fn)
        # pokud je to aktivni DB, pouzij sdilenou cache spojeni
        if _db_cache["path"] == path and _db_cache["db"] is not None:
            identity = _db_cache["db"].persistence_identity()
        else:
            tmp, token = _open_registered_ndb(path, "dočasné zjištění podniku")
            try:
                identity = tmp.persistence_identity()
            finally:
                _close_registered_ndb(tmp, token)
        fingerprint = (identity or {}).get("fingerprint")
        enterprise = (identity or {}).get("enterprise") or ""
        if fingerprint:
            reconcile = data_store.reconcile_context(
                fingerprint,
                aliases=(fn, "podnik:" + enterprise if enterprise else ""),
                enterprise=enterprise,
            )
            key = reconcile.get("key")
    except Exception:
        key = None
    if not key:
        key = fn  # zaloha: stary zpusob (jmeno souboru)
    _dbkey_cache[fn] = key
    _persistence_context["filename"] = fn
    _persistence_context["result"] = reconcile or {
        "key": key, "status": "legacy_fallback", "code": "ID_LEGACY_FALLBACK"
    }
    # Do not let the pre-1.38.2 move bypass the non-destructive registry
    # recovery.  It is retained solely for a corrupted/unreadable legacy NDB.
    if not reconcile:
        _migrate_legacy_keys(fn, key)
    return key


def _report_draft_context(filename=None):
    """Vrátí přesnou identitu zdrojové databáze pro rozpracovaný protokol.

    Per-podnik data (karta stroje, technici) mohou být záměrně sdílena mezi
    exporty stejného podniku. Návrh protokolu ale obsahuje konkrétní ID bodů,
    grafy a okamžité hodnoty, proto je bezpečné jej vázat i na aktivní .ndb.
    """
    fn = filename or _active_filename()
    return os.path.basename(fn) if fn else None


def _migrate_legacy_keys(filename, new_key):
    """Přesune dříve uložená data z klíče = jméno souboru na nový klíč podniku.

    Týká se obou úložišť: machine_config.json (karty strojů + AI vyhodnocení)
    a company.json (údaje o podniku). Běží pouze tehdy, když nový klíč je
    odlišný od jména souboru a pod novým klíčem ještě nejsou žádná data.
    """
    if not new_key or new_key == filename:
        return
    # Všechna per-podnik data se nyní ukládají do jedné složky na podnik
    # (data/podniky/<slug>/). Jednoznačný přesun přesune celý adresář; pokud
    # již cíl existuje, starý adresář se nikdy nemaže. Následná konzervativní
    # oprava hledá jedinou mapovatelnou osiřelou složku.
    try:
        moved = data_store.rename_podnik(filename, new_key)
        repaired = data_store.repair_orphan_mapping(new_key, aliases=(filename,))
        # Log neobsahuje název podniku ani DB klíč, pouze diagnózu výsledku.
        if moved or repaired.get("status") == "repaired":
            _lifecycle_log("company_data_mapping_repaired")
        elif repaired.get("status") == "ambiguous":
            _lifecycle_log("company_data_mapping_ambiguous_preserved")
    except Exception:
        pass


def list_databases():
    """Seznam všech databází v knihovně s metadaty."""
    lib = _load_library()
    active = _active_filename()
    out = []
    for p in _list_ndb_files():
        try:
            st = p.stat()
            size_mb = round(st.st_size / (1024 * 1024), 1)
            mtime_ms = int(st.st_mtime * 1000)
        except Exception:
            size_mb, mtime_ms = None, None
        out.append({
            "filename": p.name,
            "display_name": lib.get(p.name) or p.stem,
            "active": p.name == active,
            "size_mb": size_mb,
            "modified": mtime_ms,
        })
    return out


def get_db():
    path = _default_db_path()
    if not path:
        return None
    if _db_cache["path"] != path or _db_cache["db"] is None:
        if _db_cache["db"] is not None:
            _close_active_cache()
        db, token = _open_registered_ndb(path, "aktivní cache")
        _db_cache["db"] = db
        _db_cache["path"] = path
        _db_cache["connection_token"] = token
    return _db_cache["db"]


def _safe_collection_count(value):
    return len(value) if isinstance(value, (list, dict)) else 0


def _persistence_status():
    """Semantic reachability check used by Settings → Database.

    This deliberately calls the same storage services that UI routes call,
    rather than treating a hash or an existing file as proof.  It never returns
    technician names, prompts, credentials, paths or company labels.
    """
    fn = _db_key()
    context = _persistence_context.get("result") or {}
    categories = []

    def row(identifier, state, count=None, code="OK"):
        item = {"id": identifier, "state": state, "code": code}
        if count is not None:
            item["count"] = int(count)
        categories.append(item)

    if fn:
        settings = report_settings.get(fn)
        row("technicians", "reachable", len(settings.get("technicians") or []))
        row("company", "reachable", bool(company.get_company(fn)))
        config = machine_config.get_db_overrides(fn)
        row("machine_config", "reachable", _safe_collection_count(config))
        row("report_history", "reachable", len(report_history.list_history(fn)))
        draft = report_store.get_draft(fn, _report_draft_context())
        row("report_drafts", "reachable", 1 if draft else 0)
        folder = data_store.podnik_dir(fn)
        try:
            attachments = sum(1 for p in folder.rglob("*")
                              if p.is_file() and p.name not in {
                                  "_key.txt", "company.json", "machine_config.json",
                                  "report_history.json", "report_drafts.json",
                                  "report_settings.json",
                              })
        except OSError:
            attachments = 0
        row("company_attachments", "reachable", attachments)
    else:
        for identifier in ("technicians", "company", "machine_config",
                           "report_history", "report_drafts", "company_attachments"):
            row(identifier, "unavailable", 0, "NO_ACTIVE_DATABASE")

    # Global scopes must stay outside data/podniky.  Only state/count metadata
    # is exposed, never source text, prompt text or encrypted secret content.
    row("custom_norms", "reachable", len(ai_eval.list_custom_norms()))
    row("ai_examples", "reachable", len(ai_knowledge.list_examples()))
    prompts = ai_prompts.public_config()
    row("ai_prompts", "custom" if any(t.get("modified") for t in prompts.get("templates", [])
                                      if isinstance(t, dict)) else "default",
        len(prompts.get("templates") or []))
    ai_status = ai_eval.status()
    credential = ai_status.get("credential_storage") or "not_configured"
    row("ai_credentials", credential, None,
        "AI_" + str(credential).upper())
    row("ai_config", "reachable", 1 if ai_status.get("model") else 0)
    brand_status = branding.status()
    row("branding", "custom" if brand_status.get("customized") else "default",
        None, "BRANDING_LOGO_" + str(brand_status.get("logo", "none")).upper())
    row("shared_updates", "reachable",
        1 if (DATA_DIR / "shared_updates.json").is_file() else 0)
    row("database_library", "reachable", len(_load_library()))
    row("active_selection", "reachable", 1 if _active_filename() else 0)
    ndb_count = len(_list_ndb_files())
    sidecars = sum(1 for path in DATA_DIR.iterdir()
                   if path.is_file() and ".ndb-" in path.name.casefold())
    row("ndb_and_sidecars", "reachable", ndb_count + sidecars)

    status = str(context.get("status") or "unknown")
    code = str(context.get("code") or "ID_UNKNOWN")
    notice = None
    if status in {"recovered", "merged"}:
        notice = "Obnovena uložená data pro vybranou databázi."
    elif status in {"ambiguous", "conflict"}:
        notice = ("Nalezena nejednoznačná uložená data; nic nebylo přepsáno. "
                  "Zkontrolujte Kontrolu uložených dat a kontaktujte podporu.")
    return {
        "format": 1,
        "context": {
            "state": status, "code": code,
            "folder_hash": context.get("folder_hash"),
            "candidate_count": int(context.get("candidate_count") or 0),
            "conflicts": int(context.get("conflicts") or 0),
        },
        "categories": categories,
        "notice": notice,
        "registry": data_store.persistence_registry(),
    }


# ---------------- API logika ----------------
def _api_handler(path, method, body=None, headers=None, query=""):
    """Vrátí (status_code, dict_nebo_None)."""
    if path == "/api/health" and method == "GET":
        return 200, {"ok": True, "version": APP_VERSION}
    if path == "/api/updates/status" and method == "GET":
        result = shared_updates.status(DATA_DIR, APP_VERSION, _SHARED_UPDATE_PUBLIC_KEY)
        result["startup_badge"] = _startup_update_badge
        result["post_update_notes"] = shared_updates.post_update_notes(DATA_DIR, APP_VERSION)
        return 200, result
    if path == "/api/updates/check" and method == "POST":
        result = shared_updates.check(DATA_DIR, APP_VERSION, _SHARED_UPDATE_PUBLIC_KEY)
        result["post_update_notes"] = shared_updates.post_update_notes(DATA_DIR, APP_VERSION)
        return 200, result
    if path == "/api/updates/settings" and method == "POST":
        data = _parse_json_body(body)
        settings = shared_updates.save_settings(
            DATA_DIR,
            source_path=data.get("source_path") if "source_path" in data else None,
            automatic_startup_check=data.get("automatic_startup_check") if "automatic_startup_check" in data else None,
        )
        return 200, {"ok": True, "settings": settings}
    if path == "/api/updates/source/pick" and method == "POST":
        chosen = shared_updates.choose_source_folder()
        return 200, {"path": chosen, "supported": os.name == "nt"}
    if path == "/api/updates/notes" and method == "GET":
        return 200, {"notes": shared_updates.post_update_notes(DATA_DIR, APP_VERSION)}
    if path == "/api/updates/notes/shown" and method == "POST":
        return 200, {"notes": shared_updates.post_update_notes(DATA_DIR, APP_VERSION, mark_shown=True)}

    if path == "/api/status":
        name = _active_filename()
        lib = _load_library()
        return 200, {
            "loaded": name is not None,
            "filename": name,
            "display_name": (lib.get(name) or Path(name).stem) if name else None,
            "version": APP_VERSION,
        }
    if path == "/api/persistence/status" and method == "GET":
        return 200, _persistence_status()
    if path == "/api/databases/update-result" and method == "GET":
        return 200, {"result": pending_database_update_receipt(BASE_DIR)}
    if path == "/api/databases/update-result/ack" and method == "POST":
        data = _parse_json_body(body)
        acknowledge_database_update_receipt(BASE_DIR, str(data.get("job_id") or ""))
        return 200, {"ok": True}

    # ---- databaze lozisek (nezavisla na nactene .ndb) ----
    if path == "/api/bearings/search":
        qs = parse_qs(query or "")
        q = qs.get("q", [""])[0]
        mfg = qs.get("mfg", [""])[0]
        try:
            limit = int(qs.get("limit", ["50"])[0])
        except (TypeError, ValueError):
            limit = 50
        return 200, bearings.search(q=q, mfg=mfg, limit=limit)

    if path == "/api/bearings/manufacturers":
        return 200, {
            "manufacturers": bearings.manufacturers(),
            "total": bearings.count(),
        }

    # ---- knihovna databazi ----
    if path == "/api/databases":
        return 200, {"databases": list_databases()}

    if path == "/api/databases/activate" and method == "POST":
        return handle_activate(body)

    if path == "/api/databases/rename" and method == "POST":
        return handle_rename(body)

    if path == "/api/databases/delete" and method == "POST":
        return handle_delete(body)

    if path == "/api/upload" and method == "POST":
        return handle_upload(body, headers)

    if path == "/api/databases/update" and method == "POST":
        return 400, {"detail": "Aktualizace databáze vyžaduje streamovaný multipart upload."}

    # ---- katalog norem pro hodnocení rychlosti vibrací ----
    # Vrací strukturovaný seznam norem a jejich tříd/kategorií včetně limitů
    # (mm/s RMS). Frontend jej používá k dynamickému naplnení selectů a
    # k zobrazení orientačních limitů. Endpoint záměrně nevyžaduje načtenou
    # databázi – potřeba už při inicializaci karty stroje.
    if path == "/api/norms/catalog":
        return 200, {"catalog": ai_eval.norms_catalog()}

    # ---- vlastní (uživatelské) normy: CRUD ----
    if path == "/api/norms/custom":
        if method == "POST":
            data = _parse_json_body(body)
            try:
                norms = ai_eval.save_custom_norm(data)
            except ValueError as e:
                return 400, {"detail": str(e)}
            return 200, {"norms": norms, "catalog": ai_eval.norms_catalog()}
        return 200, {"norms": ai_eval.list_custom_norms()}

    if path == "/api/norms/custom/delete" and method == "POST":
        data = _parse_json_body(body)
        try:
            norms = ai_eval.delete_custom_norm(
                data.get("standard"), data.get("machine_class"))
        except ValueError as e:
            return 400, {"detail": str(e)}
        return 200, {"norms": norms, "catalog": ai_eval.norms_catalog()}

    # ---- nastavení AI (OpenAI) ----
    if path == "/api/ai/status":
        return 200, ai_eval.status()

    if path == "/api/ai/config" and method == "POST":
        data = _parse_json_body(body)
        try:
            return 200, ai_eval.set_config(
                provider=data.get("provider"),
                api_key=data.get("api_key"),
                model=data.get("model"),
            )
        except (ValueError, ai_eval.SecretStorageError):
            return 400, {"detail": "Nastavení AI nelze bezpečně uložit."}

    if path == "/api/ai/config/delete" and method == "POST":
        data = _parse_json_body(body)
        try:
            return 200, ai_eval.delete_provider(data.get("provider"))
        except (ValueError, ai_eval.SecretStorageError):
            return 400, {"detail": "Nastavený klíč nelze bezpečně odstranit."}

    # ---- editovatelné AI prompty pro závěry jednotlivých protokolů ----
    # Konfigurace neobsahuje tajemství, přesto ji HTTP vrstva vydává výhradně
    # stejnému lokálnímu UI a s Cache-Control: no-store.
    if path == "/api/ai/prompts" and method == "GET":
        return 200, ai_prompts.public_config()

    if path == "/api/ai/prompts/preview" and method == "POST":
        data = _parse_json_body(body)
        try:
            return 200, ai_prompts.preview(data.get("id"), data.get("text"))
        except ai_prompts.PromptValidationError as e:
            return 400, {"detail": str(e)}

    if path == "/api/ai/prompts" and method == "POST":
        data = _parse_json_body(body)
        try:
            return 200, ai_prompts.save_override(
                data.get("id"), data.get("text"), data.get("revision"))
        except ai_prompts.PromptConflictError as e:
            return 409, {
                "detail": str(e),
                "current_revision": e.current_revision,
                "reload_required": True,
            }
        except ai_prompts.PromptValidationError as e:
            return 400, {"detail": str(e)}

    m = re.match(r"^/api/ai/prompts/([a-z0-9_]+)/reset$", path)
    if m and method == "POST":
        data = _parse_json_body(body)
        try:
            return 200, ai_prompts.reset_override(m.group(1), data.get("revision"))
        except ai_prompts.PromptConflictError as e:
            return 409, {
                "detail": str(e),
                "current_revision": e.current_revision,
                "reload_required": True,
            }
        except ai_prompts.PromptValidationError as e:
            return 400, {"detail": str(e)}

    db = get_db()
    if db is None:
        return 404, {"detail": "Žádná databáze není načtena. Nahrajte soubor .ndb."}

    if path == "/api/info":
        return 200, {"info": db.info(), "severities": db.severities()}
    if path == "/api/tree":
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        return 200, {
            "nodes": db.tree(),
            "point_severity": db.effective_point_severity(overrides=all_over),
            "severities": db.severities(),
        }
    if path == "/api/overview":
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        return 200, db.status_overview(overrides=all_over)

    if path == "/api/compare" and method == "POST":
        data = _parse_json_body(body)
        raw = data.get("point_ids", [])
        try:
            ids = [int(x) for x in raw][:24]  # rozumný limit počtu bodů
        except (TypeError, ValueError):
            return 400, {"detail": "Neplatný seznam měřicích bodů."}
        return 200, db.compare_trends(ids)

    # ---- karty stroju ----
    if path == "/api/machines":
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        _t0 = time.perf_counter()
        res = db.machines(overrides=all_over)
        _dt = (time.perf_counter() - _t0) * 1000
        print("[perf] /api/machines: %.0f ms (%d strojů)"
              % (_dt, len(res.get("machines", []))), file=sys.stderr)
        return 200, res

    # rychlé načtení JEDNOHO stroje pro kartu stroje (bez výpočtu celé DB)
    m = re.match(r"^/api/machine/(\d+)$", path)
    if m and method == "GET":
        mid = int(m.group(1))
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        _t0 = time.perf_counter()
        res = db.machine(mid, overrides=all_over)
        _dt = (time.perf_counter() - _t0) * 1000
        print("[perf] /api/machine/%d: %.0f ms" % (mid, _dt), file=sys.stderr)
        if not res.get("machine"):
            return 404, {"error": "stroj nenalezen"}
        return 200, res

    m = re.match(r"^/api/machine/(\d+)/config$", path)
    if m:
        mid = int(m.group(1))
        fn = _db_key()
        if method == "POST":
            data = _parse_json_body(body)
            saved = machine_config.save_machine_overrides(fn, mid, data)
            # po uložení vrať i sloučený stroj (DB výchozí + přepisy) –
            # počítáme jen pro tento jeden stroj (rychlé)
            all_over = machine_config.get_db_overrides(fn) if fn else {}
            merged = db.machine(mid, overrides=all_over).get("machine")
            return 200, {"ok": True, "machine_id": mid,
                         "overrides": saved, "machine": merged}
        return 200, {
            "machine_id": mid,
            "overrides": machine_config.get_machine_overrides(fn, mid),
        }

    # autodetekce otáček ze spektra rychlosti (max amplituda v pásmu 5–70 Hz)
    m = re.match(r"^/api/machine/(\d+)/detect-speed$", path)
    if m:
        mid = int(m.group(1))
        qs = parse_qs(query or "")
        def _qf(name, default):
            try:
                return float(qs.get(name, [str(default)])[0])
            except (TypeError, ValueError):
                return default
        fmin = _qf("fmin", 5.0)
        fmax = _qf("fmax", 70.0)
        result = db.detect_speed_hz(mid, fmin=fmin, fmax=fmax)
        if not result:
            return 404, {"detail": "Pro tento stroj není dostupné spektrum rychlosti."}
        # zaznamenej detekci do historie (max. 5 záznamů na stroj)
        fn = _db_key()
        if fn and result.get("speed_hz") is not None:
            try:
                result["speed_history"] = machine_config.append_speed_detection(
                    fn, mid, result["speed_hz"]
                )
            except Exception:
                result["speed_history"] = []
        return 200, result

    # AI vyhodnocení stroje (OpenAI) – sestaví prompt z dat stroje a zavolá LLM
    m = re.match(r"^/api/machine/(\d+)/ai-eval$", path)
    if m and method == "POST":
        mid = int(m.group(1))
        if not ai_eval.has_any_key():
            return 400, {"detail": "Není nastaven žádný API klíč (OpenAI ani "
                         "Claude). Zadejte jej v nastavení AI."}
        data = _parse_json_body(body)
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        md = db.machine_ai_data(mid, overrides=all_over)
        if not md:
            return 404, {"detail": "Stroj nenalezen."}
        # otáčky: buď zadané z UI, jinak uložený přepis / DB hodnota
        speed_hz = data.get("speed_hz")
        try:
            speed_hz = float(speed_hz) if speed_hz not in (None, "") else None
        except (TypeError, ValueError):
            speed_hz = None
        if speed_hz is None:
            mover = (all_over.get(str(mid), {}) or {})
            speed_hz = mover.get("speed_hz") or md.get("db_speed_hz")
        # norma: z UI, jinak uložená na kartě
        iso_norm = data.get("iso_norm")
        if iso_norm is None:
            iso_norm = (all_over.get(str(mid), {}) or {}).get("iso_norm")
        # model: z UI, jinak výchozí uložený
        model = data.get("model") or None
        try:
            text, prompt, used_model = ai_eval.evaluate(
                md, speed_hz, iso_norm, model=model)
        except RuntimeError as e:
            return 502, {"detail": ai_eval.public_error_message(e)}
        eval_obj = {
            "text": text,
            "time": ai_eval.now_iso(),
            "speed_hz": speed_hz,
            "norm": _norm_label(iso_norm),
            "model": used_model,
            "edited": False,
        }
        saved = None
        history = []
        if fn:
            try:
                saved = machine_config.save_ai_eval(fn, mid, eval_obj)
                history = machine_config.get_machine_overrides(
                    fn, mid).get("ai_eval_history", [])
            except Exception:
                saved = None
        return 200, {"ok": True, "ai_eval": saved or eval_obj,
                     "ai_eval_history": history}

    # chat s AI diagnostikem nad daty stroje (bod A – plný kontext předem)
    m = re.match(r"^/api/machine/(\d+)/chat$", path)
    if m and method == "POST":
        mid = int(m.group(1))
        if not ai_eval.has_any_key():
            return 400, {"detail": "Není nastaven žádný API klíč (OpenAI ani "
                         "Claude). Zadejte jej v nastavení AI."}
        data = _parse_json_body(body)
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        md = db.machine_ai_data(mid, overrides=all_over)
        if not md:
            return 404, {"detail": "Stroj nenalezen."}
        mover = (all_over.get(str(mid), {}) or {})
        # otáčky: z UI, jinak uložený přepis / DB hodnota
        speed_hz = data.get("speed_hz")
        try:
            speed_hz = float(speed_hz) if speed_hz not in (None, "") else None
        except (TypeError, ValueError):
            speed_hz = None
        if speed_hz is None:
            speed_hz = mover.get("speed_hz") or md.get("db_speed_hz")
        # norma: z UI, jinak uložená na kartě
        iso_norm = data.get("iso_norm")
        if iso_norm is None:
            iso_norm = mover.get("iso_norm")
        # model: z UI, jinak výchozí uložený
        model = data.get("model") or None
        # obrázek stroje z karty (pro vision)
        image = (mover.get("card") or {}).get("image") or ""
        # historie zpráv: poslední položka je nový dotaz uživatele
        history = data.get("messages")
        if history is None:
            history = data.get("history")
        if not isinstance(history, list):
            history = []
        try:
            text, used_model = ai_eval.chat(
                md, speed_hz, iso_norm, history, model=model, image=image)
        except RuntimeError as e:
            return 502, {"detail": ai_eval.public_error_message(e)}
        return 200, {"ok": True, "reply": text, "model": used_model}

    # uložení (ručně editovaného) výsledku AI vyhodnocení
    m = re.match(r"^/api/machine/(\d+)/ai-eval/save$", path)
    if m and method == "POST":
        mid = int(m.group(1))
        data = _parse_json_body(body)
        fn = _db_key()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        eval_obj = {
            "text": str(data.get("text", "") or ""),
            "time": data.get("time") or ai_eval.now_iso(),
            "speed_hz": data.get("speed_hz"),
            "norm": data.get("norm", ""),
            "model": data.get("model", ""),
            "edited": True,
        }
        saved = machine_config.save_ai_eval(fn, mid, eval_obj)
        history = machine_config.get_machine_overrides(
            fn, mid).get("ai_eval_history", [])
        return 200, {"ok": True, "ai_eval": saved,
                     "ai_eval_history": history}

    # zpětné vyvolání staršího AI vyhodnocení z historie podle indexu
    m = re.match(r"^/api/machine/(\d+)/ai-eval/recall$", path)
    if m and method == "POST":
        mid = int(m.group(1))
        data = _parse_json_body(body)
        fn = _db_key()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        chosen = machine_config.set_active_ai_eval(fn, mid, data.get("index"))
        if chosen is None:
            return 404, {"detail": "Záznam v historii nenalezen."}
        history = machine_config.get_machine_overrides(
            fn, mid).get("ai_eval_history", [])
        return 200, {"ok": True, "ai_eval": chosen,
                     "ai_eval_history": history}

    # ---- údaje o podniku (vázané na databázi) ----
    if path == "/api/company":
        fn = _db_key()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        if method == "POST":
            data = _parse_json_body(body)
            saved = company.save_company(fn, data)
            return 200, {"ok": True, "company": saved}
        return 200, {"company": company.get_company(fn)}

    # ---- nastavení protokolu: výběr veličin + jména techniků (vázané na DB) ----
    if path == "/api/report/settings":
        fn = _db_key()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        if method == "POST":
            data = _parse_json_body(body)
            saved = report_settings.save(fn, data)
            return 200, {"ok": True, "settings": saved}
        return 200, {"settings": report_settings.get(fn)}

    # ---- personalizace vydavatele protokolů: logo + patička (GLOBÁLNÍ) ----
    # Nezávislé na aktivní databázi: popisuje firmu, která protokoly vydává,
    # nikoli zákazníka (ten je v /api/company). Ukládá se do data/branding/,
    # kterou aktualizace nikdy nepřepisuje.
    if path == "/api/branding":
        if method == "POST":
            data = _parse_json_body(body)
            saved = branding.save(data)
            return 200, {"ok": True, "branding": saved,
                         "logo_preview": branding.logo_data_url()}
        return 200, {"branding": branding.get(),
                     "logo_preview": branding.logo_data_url()}

    # ---- tolerance shody frekvencí ve spektru (GLOBÁLNÍ) ----
    if path == "/api/fft/settings":
        if method == "POST":
            data = _parse_json_body(body)
            return 200, {"ok": True, "settings": fft_settings.save(data)}
        return 200, {"settings": fft_settings.get()}

    if path == "/api/fft/settings/reset" and method == "POST":
        return 200, {"ok": True, "settings": fft_settings.reset()}

    if path == "/api/branding/reset" and method == "POST":
        return 200, {"ok": True, "branding": branding.reset(),
                     "logo_preview": branding.logo_data_url()}

    if path == "/api/branding/logo":
        if method == "DELETE":
            try:
                saved = branding.delete_logo()
            except ValueError as e:
                return 400, {"detail": str(e)}
            return 200, {"ok": True, "branding": saved,
                         "logo_preview": branding.logo_data_url()}
        if method == "POST":
            data = _parse_json_body(body)
            try:
                saved = branding.save_logo(data.get("image"))
            except ValueError as e:
                # Konkrétní český důvod (formát, velikost, CMYK…), nikdy
                # traceback ani cesta k souboru.
                return 400, {"detail": str(e)}
            return 200, {"ok": True, "branding": saved,
                         "logo_preview": branding.logo_data_url()}
        return 405, {"detail": "Nepodporovaná metoda."}

    # ---- seznam všech měřených veličin v aktivní databázi ----
    if path == "/api/report/quantities":
        if db is None:
            return 404, {"detail": "Žádná databáze není načtena."}
        try:
            names = db.distinct_quantities()
        except Exception:
            names = []
        return 200, {"quantities": names,
                     "defaults": {"velocity": report_mod.VELOCITY_Q,
                                  "accel": report_mod.ACCEL_Q,
                                  "env": report_mod.ENV_Q}}

    # ---- seznam strojů pro ruční výběr v okruhu protokolu ----
    if path == "/api/report/scope-machines" and method == "POST":
        fn = _db_key()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        data = _parse_json_body(body)
        scope = data.get("scope") or {"mode": "all"}
        # ignoruj případné machine_ids ve scope – chceme kompletní nabídku
        # strojů s měřením + informaci, které z nich okruh dle data vybral
        scope_for_dates = dict(scope)
        scope_for_dates.pop("machine_ids", None)
        selected, scope_label, _dates = report_mod.select_machines_by_scope(
            db, scope_for_dates)
        mach_last = report_mod.machines_with_measurements(db)
        tree_nodes = db.tree()
        by_id = {n["id"]: n for n in tree_nodes}
        items = []
        for mid, dt in mach_last.items():
            node = by_id.get(mid)
            mname = node["name"] if node else ("Stroj #%d" % mid)
            plant_id = node["parent"] if node else None
            plant_node = by_id.get(plant_id) if plant_id is not None else None
            plant_name = plant_node["name"] if plant_node else "—"
            items.append({
                "machine_id": mid,
                "machine_name": mname,
                "plant_id": plant_id,
                "plant_name": plant_name,
                "last_measured": dt.isoformat(),
                "in_scope": mid in selected,
            })
        items.sort(key=lambda it: (it["plant_name"], it["machine_name"]))
        return 200, {"items": items, "scope_label": scope_label}

    # ---- protokol z měření (PDF) ----
    if path == "/api/report/draft":
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        if method == "POST":
            # vygeneruj nový návrh protokolu dle okruhu strojů (+ AI závěry)
            data = _parse_json_body(body)
            scope = data.get("scope") or {"mode": "all"}
            use_ai = bool(data.get("use_ai", True))
            model = data.get("model") or None
            graph_selections = data.get("graph_selections") or {}
            ai_context = data.get("ai_context") or ""
            report_version = report_mod.norm_report_version(
                data.get("report_version"))
            show_previous = data.get("show_previous")
            full_fft = bool(data.get("full_fft", False))
            return _build_report_draft(db, fn, scope, use_ai, model,
                                       graph_selections, ai_context,
                                       report_version, draft_context,
                                       show_previous, full_fft)
        # GET = vrať poslední uložený návrh (nebo prázdno)
        return 200, {"draft": report_store.get_draft(fn, draft_context)}

    if path == "/api/report/graphs" and method == "POST":
        # přepočti grafy pro existující návrh dle nového výběru (bez AI/regenerace)
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        data = _parse_json_body(body)
        doc = data.get("doc") or report_store.get_draft(fn, draft_context) or {}
        graph_selections = data.get("graph_selections") or {}
        all_over = machine_config.get_db_overrides(fn)
        for mrep in doc.get("machines", []):
            mid = mrep.get("machine_id")
            sels = (graph_selections.get(str(mid))
                    or graph_selections.get(mid) or [])
            try:
                mrep["graphs"] = report_mod.collect_machine_graphs(db, mrep, sels)
            except Exception:
                mrep["graphs"] = []
            mrep["graph_selections"] = sels
        try:
            report_store.save_draft(fn, doc, draft_context)
        except Exception:
            pass
        return 200, {"ok": True, "draft": doc}

    if path == "/api/report/refresh" and method == "POST":
        # Aktualizuj rozpracovaný návrh podle AKTUÁLNÍCH limitů karet strojů.
        # Přepočítají se pásma bodů, stavy ložisek a z nich odvozené souhrny;
        # ručně editované texty (závěry, doporučení, úvody) zůstávají.
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        data = _parse_json_body(body)
        # `doc` z editoru má přednost – obsahuje i dosud neuložené úpravy.
        doc = data.get("doc") or report_store.get_draft(fn, draft_context)
        if not isinstance(doc, dict) or not doc:
            return 400, {"detail": "Není k dispozici rozpracovaný návrh "
                                   "protokolu – nejprve vytvořte návrh."}
        all_over = machine_config.get_db_overrides(fn)
        qmap = report_settings.quantity_map(fn)
        try:
            new_doc, refresh_info = report_refresh.refresh_report_draft(
                db, doc, all_over, qmap=qmap)
        except Exception as e:
            return 500, {"detail": "Chyba při aktualizaci protokolu: %s" % e}
        try:
            new_doc = report_store.save_draft(fn, new_doc, draft_context)
        except Exception:
            pass
        return 200, {"ok": True, "draft": new_doc, "refresh": refresh_info,
                     "message": report_refresh.summary_text(refresh_info)}

    if path == "/api/report/save" and method == "POST":
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        data = _parse_json_body(body)
        doc = data.get("doc") or data
        saved = report_store.save_draft(fn, doc, draft_context)
        return 200, {"ok": True, "draft": saved}

    # ---- DOCX import (tagovaný, bezpečný) — NÁHLED navrhovaných změn ----
    # Soubor .docx přichází jako multipart/form-data (stejně jako /api/upload).
    # Nikdy nic nezapisuje – jen vrátí návrh položek k výběru uživatelem.
    if path == "/api/report/docx-import/preview" and method == "POST":
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        ctype = headers.get("Content-Type", "") if headers else ""
        m = re.search(r"boundary=(.+)", ctype)
        if not m:
            return 400, {"detail": "Chybí boundary (očekáván multipart/form-data)."}
        boundary = m.group(1).strip().strip('"').encode()
        delim = b"--" + boundary
        file_data = None
        doc_field = None
        for part in body.split(delim):
            if b"filename=" in part and file_data is None:
                header_end = part.find(b"\r\n\r\n")
                if header_end < 0:
                    continue
                raw = part[header_end + 4:]
                if raw.endswith(b"\r\n"):
                    raw = raw[:-2]
                file_data = raw
            elif b'name="doc"' in part:
                header_end = part.find(b"\r\n\r\n")
                if header_end < 0:
                    continue
                raw = part[header_end + 4:]
                if raw.endswith(b"\r\n"):
                    raw = raw[:-2]
                doc_field = raw
        if not file_data:
            return 400, {"detail": "Soubor .docx nebyl nalezen v požadavku."}
        current_doc = None
        if doc_field:
            try:
                current_doc = json.loads(doc_field.decode("utf-8"))
            except Exception:
                current_doc = None
        if not isinstance(current_doc, dict):
            current_doc = report_store.get_draft(fn, draft_context) or {}
        try:
            items, summary = docx_import.extract_preview(file_data, current_doc)
        except docx_import.DocxImportError as e:
            return 400, {"detail": str(e)}
        except Exception as e:
            return 500, {"detail": "Chyba při čtení DOCX souboru: %s" % e}
        return 200, {"ok": True, "items": items, "summary": summary}

    # ---- DOCX import — APLIKACE vybraných položek (selective apply) ----
    # `selected_keys` = ["<machine_id>|zaver", "<machine_id>|doporuceni", ...].
    # Zapisuje VÝHRADNĚ pole zaver/doporuceni u odpovídajícího stroje —
    # nikdy technické/naměřené hodnoty (viz docx_import.apply_selected).
    if path == "/api/report/docx-import/apply" and method == "POST":
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        data = _parse_json_body(body)
        current_doc = data.get("doc") or report_store.get_draft(fn, draft_context)
        items = data.get("items") or []
        selected_keys = data.get("selected_keys") or []
        if not isinstance(current_doc, dict) or not current_doc:
            return 400, {"detail": "Není k dispozici žádný návrh protokolu."}
        new_doc, applied = docx_import.apply_selected(current_doc, items, selected_keys)
        try:
            new_doc = report_store.save_draft(fn, new_doc, draft_context)
        except Exception:
            pass
        return 200, {"ok": True, "draft": new_doc, "applied": applied}

    # -------- HISTORIE PROTOKOLŮ (archiv finalizovaných protokolů) --------
    # Uchovává KOMPLETNÍ dokument každého protokolu (úvody, doplňující pokyny
    # pro AI, okruh strojů, závěry i doporučení) – vše zpětně vyvolatelné
    # a editovatelné. Klíčováno per podnik jako ostatní data.
    if path == "/api/report/history":
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        if method == "POST":
            # ulož AKTUÁLNÍ návrh jako novou položku historie, nebo (když je
            # zadáno `id`) přepiš existující položku (editace v historii).
            data = _parse_json_body(body)
            doc = data.get("doc") or report_store.get_draft(fn, draft_context)
            if not doc:
                return 400, {"detail": "Není co uložit do historie – "
                                       "nejprve vytvořte návrh protokolu."}
            entry_id = (data.get("id") or "").strip()
            pdf_filename = _report_pdf_filename(doc)
            if entry_id:
                item = report_history.update_entry(fn, entry_id, doc,
                                                   pdf_filename)
                if not item:
                    return 404, {"detail": "Položka historie nenalezena."}
                return 200, {"ok": True, "item": item, "updated": True}
            item = report_history.add_entry(fn, doc, pdf_filename)
            return 200, {"ok": True, "item": item, "updated": False}
        # GET = seznam položek historie (bez těžkého doc)
        return 200, {"items": report_history.list_history(fn)}

    m = re.match(r"^/api/report/history/([0-9a-fA-F]+)$", path)
    if m:
        fn = _db_key()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        entry_id = m.group(1)
        if method == "DELETE":
            ok = report_history.delete_entry(fn, entry_id)
            if not ok:
                return 404, {"detail": "Položka historie nenalezena."}
            return 200, {"ok": True}
        # GET = kompletní záznam včetně doc (pro vyvolání / editaci)
        rec = report_history.get_entry(fn, entry_id)
        if not rec:
            return 404, {"detail": "Položka historie nenalezena."}
        return 200, {"entry": rec}

    # ==================================================================
    #  ZNALOSTNÍ BÁZE AI VZORŮ (varianta B – učení z minulých protokolů)
    #  Kurátorované „zlaté“ dvojice situace → závěr + doporučení, které se
    #  vkládají do AI promptu jako příklady stylu. Globální (nezávislé na DB).
    # ==================================================================
    if path == "/api/ai/examples":
        if method == "POST":
            data = _parse_json_body(body)
            rec = ai_knowledge.add_example(data)
            if not rec:
                return 400, {"detail": "Vzor musí obsahovat aspoň pole "
                                       "„Situace“ a „Závěr“."}
            return 200, {"ok": True, "example": rec}
        # GET = seznam všech vzorů + číselníky pro UI
        return 200, {
            "examples": ai_knowledge.list_examples(),
            "machine_kinds": list(ai_knowledge.MACHINE_KINDS),
            "severities": list(ai_knowledge.SEVERITIES),
        }

    m = re.match(r"^/api/ai/examples/([0-9a-fA-F]+)$", path)
    if m:
        ex_id = m.group(1)
        if method == "DELETE":
            ok = ai_knowledge.delete_example(ex_id)
            if not ok:
                return 404, {"detail": "Vzor nenalezen."}
            return 200, {"ok": True}
        if method == "POST" or method == "PUT":
            data = _parse_json_body(body)
            rec = ai_knowledge.update_example(ex_id, data)
            if not rec:
                return 404, {"detail": "Vzor nenalezen."}
            return 200, {"ok": True, "example": rec}
        rec = ai_knowledge.get_example(ex_id)
        if not rec:
            return 404, {"detail": "Vzor nenalezen."}
        return 200, {"example": rec}

    m = re.match(r"^/api/point/(\d+)/cells$", path)
    if m:
        cells = db.cells_for_point(int(m.group(1)))
        # u statických (trendových) buněk dopočítáme stav vůči platným limitům
        # (ok / warning / alarm) – použije se k podbarvení záložek na stránce bodu.
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        for c in cells:
            if c.get("kind") != "trend":
                continue
            try:
                eff = db.cell_effective_limits(c["id"], overrides=all_over) or {}
                pts = db.trend(c["id"]) or []
                last_val = pts[-1]["value"] if pts else None
                warn = eff.get("warning")
                alarm = eff.get("alarm")
                state = None
                if last_val is not None:
                    if alarm is not None and last_val >= alarm:
                        state = "alarm"
                    elif warn is not None and last_val >= warn:
                        state = "warning"
                    elif warn is not None or alarm is not None:
                        state = "ok"
                c["lim_state"] = state          # ok | warning | alarm | None
                c["last_value"] = last_val
                c["lim_warning"] = warn
                c["lim_alarm"] = alarm
            except Exception:
                c["lim_state"] = None
        return 200, {"cells": cells}

    m = re.match(r"^/api/cell/(\d+)/trend$", path)
    if m:
        cid = int(m.group(1))
        cell = db.cell(cid)
        if not cell:
            return 404, {"detail": "Měření nenalezeno."}
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        eff = db.cell_effective_limits(cid, overrides=all_over)
        return 200, {"cell": cell, "points": db.trend(cid), "limits": eff}

    m = re.match(r"^/api/cell/(\d+)/dynamic$", path)
    if m:
        cid = int(m.group(1))
        cell = db.cell(cid)
        if not cell:
            return 404, {"detail": "Měření nenalezeno."}
        return 200, {"cell": cell, "records": db.dynamic_records(cid)}

    m = re.match(r"^/api/dynamic/(\d+)$", path)
    if m:
        data = db.dynamic_data(int(m.group(1)))
        if not data:
            return 404, {"detail": "Záznam nenalezen."}
        return 200, data

    # ---- AI poradce na úrovni měřicího bodu ----
    # kompaktní data bodu pro AI (veličiny, spektra, ložisko, otáčky) + přepisy
    m = re.match(r"^/api/point/(\d+)/ai-data$", path)
    if m:
        pid = int(m.group(1))
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        pd = db.point_ai_data(pid, overrides=all_over)
        if not pd:
            return 404, {"detail": "Měřicí bod nenalezen."}
        pov = machine_config.get_point_overrides(fn, pid) if fn else {}
        # norma se dědí z karty stroje (na bod se neukládá samostatně)
        mid = pd.get("machine_id")
        iso_norm = None
        if mid is not None:
            iso_norm = (all_over.get(str(mid), {}) or {}).get("iso_norm")
        return 200, {
            "point": pd,
            "overrides": pov,
            "iso_norm": iso_norm,
            "ai_status": ai_eval.status(),
        }

    # autodetekce otáček ze spektra rychlosti daného bodu (5–70 Hz)
    m = re.match(r"^/api/point/(\d+)/detect-speed$", path)
    if m:
        pid = int(m.group(1))
        qs = parse_qs(query or "")
        def _qf(name, default):
            try:
                return float(qs.get(name, [str(default)])[0])
            except (TypeError, ValueError):
                return default
        fmin = _qf("fmin", 5.0)
        fmax = _qf("fmax", 70.0)
        result = db.detect_point_speed_hz(pid, fmin=fmin, fmax=fmax)
        if not result:
            return 404, {"detail": "Pro tento bod není dostupné spektrum rychlosti."}
        fn = _db_key()
        if fn and result.get("speed_hz") is not None:
            try:
                result["speed_history"] = machine_config.append_point_speed_detection(
                    fn, pid, result["speed_hz"]
                )
            except Exception:
                result["speed_history"] = []
        return 200, result

    # AI vyhodnocení bodu – sestaví prompt z dat bodu a zavolá LLM
    m = re.match(r"^/api/point/(\d+)/ai-eval$", path)
    if m and method == "POST":
        pid = int(m.group(1))
        if not ai_eval.has_any_key():
            return 400, {"detail": "Není nastaven žádný API klíč (OpenAI ani "
                         "Claude). Zadejte jej v nastavení AI."}
        data = _parse_json_body(body)
        fn = _db_key()
        all_over = machine_config.get_db_overrides(fn) if fn else {}
        pd = db.point_ai_data(pid, overrides=all_over)
        if not pd:
            return 404, {"detail": "Měřicí bod nenalezen."}
        mid = pd.get("machine_id")
        # otáčky: z UI, jinak uložený přepis bodu, jinak otáčky stroje / DB bodu
        speed_hz = data.get("speed_hz")
        try:
            speed_hz = float(speed_hz) if speed_hz not in (None, "") else None
        except (TypeError, ValueError):
            speed_hz = None
        if speed_hz is None:
            pov = machine_config.get_point_overrides(fn, pid) if fn else {}
            speed_hz = pov.get("speed_hz")
        if speed_hz is None:
            speed_hz = (pd.get("machine_speed_hz") or pd.get("db_speed_hz")
                        or pd.get("spectrum_speed_hz"))
        # norma: z UI, jinak z karty stroje
        iso_norm = data.get("iso_norm")
        if iso_norm is None and mid is not None:
            iso_norm = (all_over.get(str(mid), {}) or {}).get("iso_norm")
        model = data.get("model") or None
        try:
            text, prompt, used_model = ai_eval.evaluate_point(
                pd, speed_hz, iso_norm, model=model)
        except RuntimeError as e:
            return 502, {"detail": ai_eval.public_error_message(e)}
        eval_obj = {
            "text": text,
            "time": ai_eval.now_iso(),
            "speed_hz": speed_hz,
            "norm": _norm_label(iso_norm),
            "model": used_model,
            "edited": False,
        }
        saved = None
        history = []
        if fn:
            try:
                saved = machine_config.save_point_ai_eval(fn, pid, eval_obj)
                history = machine_config.get_point_overrides(
                    fn, pid).get("ai_eval_history", [])
            except Exception:
                saved = None
        return 200, {"ok": True, "ai_eval": saved or eval_obj,
                     "ai_eval_history": history}

    # uložení (ručně editovaného) výsledku AI vyhodnocení bodu
    m = re.match(r"^/api/point/(\d+)/ai-eval/save$", path)
    if m and method == "POST":
        pid = int(m.group(1))
        data = _parse_json_body(body)
        fn = _db_key()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        eval_obj = {
            "text": str(data.get("text", "") or ""),
            "time": data.get("time") or ai_eval.now_iso(),
            "speed_hz": data.get("speed_hz"),
            "norm": data.get("norm", ""),
            "model": data.get("model", ""),
            "edited": True,
        }
        saved = machine_config.save_point_ai_eval(fn, pid, eval_obj)
        history = machine_config.get_point_overrides(
            fn, pid).get("ai_eval_history", [])
        return 200, {"ok": True, "ai_eval": saved,
                     "ai_eval_history": history}

    # zpětné vyvolání staršího AI vyhodnocení bodu z historie podle indexu
    m = re.match(r"^/api/point/(\d+)/ai-eval/recall$", path)
    if m and method == "POST":
        pid = int(m.group(1))
        data = _parse_json_body(body)
        fn = _db_key()
        if not fn:
            return 404, {"detail": "Žádná databáze není načtena."}
        chosen = machine_config.set_active_point_ai_eval(fn, pid, data.get("index"))
        if chosen is None:
            return 404, {"detail": "Záznam v historii nenalezen."}
        history = machine_config.get_point_overrides(
            fn, pid).get("ai_eval_history", [])
        return 200, {"ok": True, "ai_eval": chosen,
                     "ai_eval_history": history}

    # vodopádový graf: sada FFT spekter bodu v čase
    m = re.match(r"^/api/point/(\d+)/waterfall$", path)
    if m:
        pid = int(m.group(1))
        qs = parse_qs(query or "")
        try:
            limit = int(qs.get("limit", ["30"])[0])
        except (TypeError, ValueError):
            limit = 30
        limit = max(2, min(limit, 200))  # rozumné meze
        cell_id = None
        if qs.get("cell_id"):
            try:
                cell_id = int(qs["cell_id"][0])
            except (TypeError, ValueError):
                cell_id = None
        return 200, db.waterfall(pid, limit=limit, cell_id=cell_id)

    return 404, {"detail": "Neznámé API."}


_MUTATING_API_PATHS = {
    "/api/databases/activate",
    "/api/databases/rename",
    "/api/databases/delete",
    "/api/upload",
}


def api_handler(path, method, body=None, headers=None, query=""):
    """Obal API zámkem: čtení nesmí běžet přes výměnu aktivního souboru."""
    try:
        if method in {"POST", "PUT", "PATCH", "DELETE"} and path in _MUTATING_API_PATHS:
            with write_locked(_db_operations):
                return _api_handler(path, method, body=body, headers=headers, query=query)
        with read_locked(_db_operations):
            return _api_handler(path, method, body=body, headers=headers, query=query)
    except DatabaseBusy as exc:
        return 409, {"detail": str(exc)}


def handle_update_stream(stream, content_length, headers, *, simulate_failure_after_swap=False):
    """Streamed preflight/staging endpoint; final swap happens after exit."""
    if not _active_filename():
        raise UpdateError("Není aktivní databáze. Nejprve ji načtěte nebo vyberte.")
    ctype = headers.get("Content-Type", "") if headers else ""
    uploaded = stream_multipart_ndb(
        stream,
        int(content_length),
        ctype,
        DATA_DIR,
        preflight=lambda declared: ensure_space(DATA_DIR, declared),
    )
    try:
        # `simulate_failure_after_swap` is retained in the signature for old
        # callers/tests only. It is intentionally not forwarded: production
        # must never use the in-process commit path.
        result = _database_update_coordinator.prepare_and_spawn(uploaded)
        if result.get("no_update"):
            return 200, result
        return 202, result
    except (UpdateError, DatabaseBusy) as exc:
        return 409 if isinstance(exc, DatabaseBusy) else 400, {"detail": str(exc)}


def _parse_json_body(body):
    try:
        return json.loads((body or b"").decode("utf-8")) or {}
    except Exception:
        return {}


def _norm_label(iso_norm):
    """Vytvoří krátký lidský popisek normy pro uložení k výsledku AI."""
    if not iso_norm:
        return ""
    parts = []
    if iso_norm.get("standard"):
        parts.append(iso_norm["standard"])
    if iso_norm.get("machine_class"):
        parts.append(iso_norm["machine_class"])
    if iso_norm.get("custom"):
        parts.append(iso_norm["custom"])
    return " – ".join(parts)


def _build_report_draft(db, fn, scope, use_ai, model, graph_selections=None,
                        ai_context="", report_version=None, draft_context=None,
                        show_previous=None, full_fft=False):
    """Sestaví návrh protokolu; volitelně doplní AI stručný závěr per stroj.

    `fn` = klíč podniku (_db_key). `ai_context` = volitelný doplňující prompt
    od uživatele, který se přidá do AI promptu (podmínky měření, koncepce
    strojů, co vyhodnotit a co ne). Obrázek stroje z karty se přidá do promptu
    jako vision vstup. `report_version` volí šablonu PDF (1 = stručná,
    2 = detailní se všemi stroji). Vrací (status, obj) jako ostatní handlery.
    """
    all_over = machine_config.get_db_overrides(fn) if fn else {}
    comp = company.get_company(fn) if fn else {}
    qmap = report_settings.quantity_map(fn) if fn else {}
    ai_fn = None
    ai_error = None
    prompt_snapshot = None
    if use_ai and ai_eval.has_any_key():
        # Jediný snapshot pro celý běh: editace v jiné kartě nemůže změnit
        # prompty mezi stroji téhož návrhu a audit proto přesně odpovídá běhu.
        prompt_snapshot = ai_prompts.report_snapshot(report_version)
        def ai_fn(mc, rep):
            mover = (all_over.get(str(mc["id"]), {}) or {})
            # Rozsah spektrálních podkladů řídí nejhorší pásmo stroje
            # V PROTOKOLU: u stroje v pásmu A stačí celkové hodnoty, u stroje
            # ve výstraze má smysl poslat vrcholy, harmonické i poruchové
            # frekvence ložisek. Šetří to tokeny tam, kde není co vyšetřovat.
            # Rozsah podkladů je rozhodnutí o SBĚRU DAT, ne pokyn v promptu:
            # při „minimal" se spektrální nálezy vůbec nespočítají, takže je
            # žádný text v Doplňujících pokynech nemůže vyvolat. Diagnostik
            # proto musí mít možnost úsporu vypnout.
            detail = (fft_analysis.LEVEL_FULL if full_fft
                      else fft_analysis.detail_level_for_band(rep.get("worst_band")))
            md = db.machine_ai_data(
                mc["id"], overrides=all_over, spectrum_detail=detail,
                speed_hz=mover.get("speed_hz"))
            if not md:
                return None
            speed_hz = mover.get("speed_hz") or md.get("db_speed_hz")
            iso_norm = mover.get("iso_norm")
            # obrázek stroje z karty (pro vision)
            card = (rep.get("card") or {})
            image = card.get("image") or ""
            # varianta B: klíče pro výběr schválených vzorů ze znalostní báze
            #   severity = stav stroje odvozený z pásem (ok/alarm/warn)
            #   machine_kind = volitelný ruční štítek typu stroje na kartě
            sev_model = rep.get("severity") or None
            machine_kind = mover.get("machine_kind") or None
            # AI dostává stejný efektivní stav, který se objeví v tabulce
            # protokolu. Při novém návrhu jde o automatiku; při budoucím
            # znovupoužití reportového kontextu se tím neztratí ruční A–D.
            state_context = report_mod.report_state_context(rep)
            canonical_context = report_mod.report_measurement_context(rep)
            # Stavy kategorií jsou fakta, pokyny diagnostika jsou instrukce.
            # Instrukce patří na konec, aby je nic nepřebilo.
            own_context = (ai_context or "").strip()
            prompt_context = (("Stavy kategorií v protokolu: " + state_context)
                              if state_context else "")
            if own_context:
                prompt_context = ((prompt_context + "\n\n") if prompt_context else "")
                prompt_context += own_context
            res, _used = ai_eval.evaluate_brief(
                md, speed_hz, iso_norm, model=model,
                severity_label=rep.get("severity_label"),
                user_context=prompt_context, image=image,
                report_version=report_version,
                machine_kind=machine_kind, severity=sev_model,
                prompt_snapshot=prompt_snapshot,
                canonical_report_context=canonical_context)
            return res
    try:
        doc = report_mod.build_report_draft(
            db, all_over, comp, scope, ai_fn=ai_fn, model=model,
            graph_selections=graph_selections, report_version=report_version,
            qmap=qmap)
    except Exception as e:
        return 500, {"detail": "Chyba při sestavování protokolu: %s" % e}
    # zapamatuj si doplňující AI kontext do návrhu (pro příští generování)
    try:
        if isinstance(doc, dict):
            # Výchozí zachovává starší šablony: v detailní v2 byl sloupec
            # porovnání vždy vidět, v ostatních šablonách nebyl.
            doc["show_previous"] = (bool(show_previous) if show_previous is not None
                                    else report_mod.norm_report_version(report_version) == 2)
            doc["ai_context"] = str(ai_context or "")[:4000]
            doc["model"] = str(model or "")
            if prompt_snapshot is not None:
                # Bez obsahu promptu: historický záznam je auditovatelný, ale
                # neukládá nadbytečnou kopii globální konfigurace do podniku.
                doc["ai_prompt_audit"] = ai_prompts.audit_metadata(prompt_snapshot)
    except Exception:
        pass
    # ulož jako rozpracovaný návrh
    try:
        report_store.save_draft(fn, doc, draft_context)
    except Exception:
        pass
    out = {"ok": True, "draft": doc}
    if use_ai and not ai_eval.has_any_key():
        out["ai_note"] = ("Není nastaven žádný API klíč – závěry a doporučení "
                          "je třeba doplnit ručně.")
    elif use_ai and isinstance(doc, dict):
        # propiš diagnostiku AI závěrů do hlášky pro uživatele
        ai_errors = doc.get("ai_errors") or []
        ai_ok = doc.get("ai_ok", 0)
        if ai_errors and not ai_ok:
            out["ai_note"] = (
                "AI závěry se nepodařilo vygenerovat pro žádný stroj. "
                "Důvod: " + "; ".join(ai_errors[:5]))
        elif ai_errors:
            out["ai_note"] = (
                "AI závěry vygenerovány pro %d strojů; u některých se to "
                "nepodařilo: %s" % (ai_ok, "; ".join(ai_errors[:5])))
    return 200, out


def handle_activate(body):
    """Přepne aktivní databázi na zvolený soubor."""
    data = _parse_json_body(body)
    fn = os.path.basename(str(data.get("filename", "")))
    if not fn or not (DATA_DIR / fn).exists():
        return 404, {"detail": "Databáze nenalezena."}
    _set_active(fn)
    # Selecting a filename is also the boundary after the supported external
    # database replacement flow.  Its contents may have changed while keeping
    # the filename, so never reuse a fingerprint from the prior file handle.
    _invalidate_db_caches(fn)
    # Reconcile immediately, before Settings makes its first GET.  A malformed
    # third-party NDB still receives the legacy fallback; activation itself is
    # never blocked by a recovery diagnostic.
    _db_key(fn)
    context = _persistence_context.get("result") or {}
    return 200, {
        "ok": True, "filename": fn,
        "persistence": {
            "state": context.get("status"), "code": context.get("code"),
            "conflicts": int(context.get("conflicts") or 0),
        },
    }


def handle_rename(body):
    """Nastaví vlastní zobrazovaný název databáze."""
    data = _parse_json_body(body)
    fn = os.path.basename(str(data.get("filename", "")))
    new_name = str(data.get("display_name", "")).strip()
    if not fn or not (DATA_DIR / fn).exists():
        return 404, {"detail": "Databáze nenalezena."}
    lib = _load_library()
    if new_name:
        lib[fn] = new_name[:120]
    else:
        lib.pop(fn, None)  # prázdný název = zpět na název souboru
    _save_library(lib)
    return 200, {"ok": True, "filename": fn, "display_name": lib.get(fn) or Path(fn).stem}


def handle_delete(body):
    """Odebere databázi z knihovny (smaže soubor)."""
    data = _parse_json_body(body)
    fn = os.path.basename(str(data.get("filename", "")))
    target = DATA_DIR / fn
    if not fn or not target.exists():
        return 404, {"detail": "Databáze nenalezena."}
    was_active = (_active_filename() == fn)
    # uvolni cache pokud je to aktivni databaze
    if was_active:
        _close_active_cache()
        _db_operations.close_registered_connections(target)
    try:
        target.unlink()
    except Exception as e:
        return 500, {"detail": f"Nelze smazat soubor: {e}"}
    # odeber z knihovny metadat
    lib = _load_library()
    if fn in lib:
        lib.pop(fn, None)
        _save_library(lib)
    # pokud byla aktivni, prepni na jinou (nebo zadnou)
    if was_active:
        remaining = _list_ndb_files()
        if remaining:
            _set_active(remaining[0].name)
        else:
            try:
                _STATE_FILE.unlink()
            except Exception:
                pass
    new_active = _active_filename()
    return 200, {"ok": True, "deleted": fn, "active": new_active}


def handle_upload(body, headers):
    """Zpracuje multipart upload .ndb souboru (bez externích knihoven)."""
    ctype = headers.get("Content-Type", "") if headers else ""
    m = re.search(r"boundary=(.+)", ctype)
    if not m:
        return 400, {"detail": "Chybí boundary."}
    boundary = m.group(1).strip().strip('"').encode()
    delim = b"--" + boundary
    parts = body.split(delim)
    for part in parts:
        if b"filename=" not in part:
            continue
        header_end = part.find(b"\r\n\r\n")
        if header_end < 0:
            continue
        raw_header = part[:header_end].decode("utf-8", "ignore")
        fn_m = re.search(r'filename="([^"]*)"', raw_header)
        filename = fn_m.group(1) if fn_m else None
        if not filename:
            continue
        file_data = part[header_end + 4:]
        # odřízni koncové \r\n
        if file_data.endswith(b"\r\n"):
            file_data = file_data[:-2]
        if not filename.lower().endswith(".ndb"):
            return 400, {"detail": "Nahrajte soubor s příponou .ndb"}
        # vyřeš kolizi názvů – nepřepisuj existující databázi
        base = os.path.basename(filename)
        stem = Path(base).stem
        dest = DATA_DIR / base
        i = 2
        while dest.exists():
            dest = DATA_DIR / f"{stem} ({i}).ndb"
            i += 1
        with open(dest, "wb") as f:
            f.write(file_data)
        # Validace přidané databáze je striktně read-only; běžný parser by při
        # otevření vytvářel indexy a Windows vedlejší WAL soubory.
        try:
            validate_ndb(dest)
        except Exception as e:
            try:
                dest.unlink()
            except Exception:
                pass
            return 400, {"detail": f"Soubor není platná databáze HADS: {e}"}
        # přidej do knihovny a aktivuj
        _set_active(dest.name)
        return 200, {"ok": True, "filename": dest.name}
    return 400, {"detail": "Soubor nebyl nalezen v požadavku."}


# ---------------- HTTP handler ----------------
def _shutdown_can_be_accepted() -> bool:
    accepted = _LIFECYCLE.request_shutdown(_SHUTDOWN_WAIT_SECONDS)
    if accepted:
        _lifecycle_log("shutdown_accepted")
    return accepted


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # tichý provoz

    def _send_json(self, status, obj, *, no_store=False):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        if no_store:
            self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _ui_shutdown_request_is_allowed(self) -> bool:
        return _is_loopback_peer(self.client_address) and _valid_ui_origin(self.headers.get("Origin"))

    def _ai_config_request_is_allowed(self) -> bool:
        """Změny klíčů přijímá jen stejné lokální UI s jednorázovým nonce."""
        return (
            _is_loopback_peer(self.client_address)
            and _valid_ui_host(self.headers.get("Host"))
            and _valid_ui_origin(self.headers.get("Origin"))
        )

    def _ai_config_nonce_is_valid(self, payload: dict) -> bool:
        nonce = payload.get("nonce")
        return _AI_CONFIG_NONCES.consume(
            self.headers.get("Origin"),
            self.headers.get("X-HADS-AI-Config-Nonce"),
            nonce,
        )

    def _ai_prompt_request_is_allowed(self) -> bool:
        """Mutace promptů smí dělat jen stejné loopback UI."""
        return self._ai_config_request_is_allowed()

    def _ai_read_request_is_allowed(self) -> bool:
        """Bezpečný AI GET toleruje chybějící Origin dle browser fetchu.

        Jestliže browser poslal Origin nebo Referer, oba musí souhlasit s
        přesným lokálním originem. Cizí Host, peer i cizí origin zůstávají
        odmítnuty. Mutace tuto výjimku nemají.
        """
        if not _is_loopback_peer(self.client_address) or not _valid_ui_host(self.headers.get("Host")):
            return False
        origin = self.headers.get("Origin")
        referer = self.headers.get("Referer")
        if origin is not None and not _valid_ui_origin(origin):
            return False
        if referer is not None and not _valid_ui_referer(referer):
            return False
        return True

    def _ai_prompt_nonce_is_valid(self, payload: dict) -> bool:
        return _AI_PROMPT_NONCES.consume(
            self.headers.get("Origin"),
            self.headers.get("X-HADS-AI-Prompts-Nonce"),
            payload.get("nonce"),
        )

    def _read_prompt_payload(self) -> dict:
        """Načte omezený JSON editoru bez sdílení promptu do běžného logu."""
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except (TypeError, ValueError):
            raise ValueError("Neplatná délka požadavku.")
        if length < 2 or length > ai_prompts.MAX_TEMPLATE_CHARS + 4096:
            raise ValueError("Neplatný nebo příliš velký požadavek na AI prompt.")
        try:
            value = json.loads(self._read_body(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("Neplatný požadavek na AI prompt.") from exc
        if not isinstance(value, dict):
            raise ValueError("Neplatný požadavek na AI prompt.")
        return value

    def _read_ui_payload(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except (TypeError, ValueError):
            raise ValueError("Neplatná délka požadavku.")
        if length < 2 or length > 2048:
            raise ValueError("Neplatný požadavek na ukončení.")
        try:
            value = json.loads(self._read_body(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("Neplatný požadavek na ukončení.") from exc
        if not isinstance(value, dict):
            raise ValueError("Neplatný požadavek na ukončení.")
        return value

    def _send_file(self, file_path):
        if not file_path.is_file():
            self.send_error(404, "Soubor nenalezen")
            return
        ext = file_path.suffix.lower()
        ctype = CONTENT_TYPES.get(ext, "application/octet-stream")
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        # zabranuje tomu, aby prohlizec drzel starou verzi po aktualizaci
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/api/ui/shutdown-session", "/api/ui/shutdown"):
            self._send_json(405, {"detail": "Použijte zabezpečený POST požadavek."})
            return
        if path.startswith("/api/"):
            if not _LIFECYCLE.accepting_work:
                self._send_json(503, {"detail": "HADS se právě ukončuje."})
                return
            if path in ("/api/ai/status", "/api/ai/prompts"):
                # Stav neobsahuje tajemství, přesto nesmí zůstat v cache.
                if not self._ai_read_request_is_allowed():
                    _safe_ai_log("ai_request_denied")
                    self._send_json(403, {"detail": "Zakázáno"}, no_store=True)
                    return
                try:
                    status, obj = api_handler(path, "GET", query=urlparse(self.path).query)
                except Exception:
                    status, obj = 500, {"detail": "Nastavení AI nelze bezpečně načíst."}
                if path == "/api/ai/status" and isinstance(obj, dict):
                    _safe_ai_log(
                        "ai_status_stored_unavailable"
                        if obj.get("credential_storage") == "stored_unavailable"
                        else "ai_status_ok"
                    )
                elif path == "/api/ai/prompts" and isinstance(obj, dict):
                    _safe_ai_log("ai_prompts_warning" if obj.get("warnings") else "ai_prompts_defaults")
                self._send_json(status, obj, no_store=True)
                return
            try:
                status, obj = api_handler(path, "GET", query=urlparse(self.path).query)
            except Exception as e:
                status, obj = 500, {"detail": f"Chyba serveru: {e}"}
            self._send_json(status, obj)
            return
        # frontend
        if path == "/" or path == "":
            self._send_file(FRONTEND_DIR / "index.html")
            return
        # bezpečná cesta uvnitř frontendu
        rel = path.lstrip("/")
        target = (FRONTEND_DIR / rel).resolve()
        if str(target).startswith(str(FRONTEND_DIR.resolve())) and target.is_file():
            self._send_file(target)
        else:
            self.send_error(404, "Soubor nenalezen")

    def do_DELETE(self):
        """Obsluha DELETE požadavků (např. mazání položek historie protokolů)."""
        path = urlparse(self.path).path
        if not path.startswith("/api/"):
            self.send_error(404)
            return
        if path.startswith("/api/ai/config"):
            self._send_json(405, {"detail": "Použijte potvrzenou akci mazání."}, no_store=True)
            return
        try:
            status, obj = api_handler(path, "DELETE",
                                      query=urlparse(self.path).query)
        except Exception as e:
            import traceback
            traceback.print_exc()
            status, obj = 500, {"detail": f"Chyba serveru: {e}"}
        try:
            self._send_json(status, obj)
        except Exception:
            pass

    def _read_body(self, length):
        """Načte tělo požadavku po blocích (kvůli velkým .ndb souborům)."""
        chunks = []
        remaining = length
        while remaining > 0:
            chunk = self.rfile.read(min(remaining, 1 << 20))  # 1 MB bloky
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def _send_pdf(self, pdf_bytes, filename):
        """Odešle binární PDF jako přílohu ke stažení."""
        self.send_response(200)
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Length", str(len(pdf_bytes)))
        # ASCII-bezpečný název + UTF-8 varianta dle RFC 5987
        try:
            ascii_name = filename.encode("ascii", "ignore").decode("ascii") or "protokol.pdf"
        except Exception:
            ascii_name = "protokol.pdf"
        disp = ("attachment; filename=\"%s\"; filename*=UTF-8''%s"
                % (ascii_name, quote(filename)))
        self.send_header("Content-Disposition", disp)
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.end_headers()
        self.wfile.write(pdf_bytes)

    def _send_docx(self, docx_bytes, filename):
        """Odešle binární DOCX jako přílohu ke stažení."""
        self.send_response(200)
        self.send_header(
            "Content-Type",
            "application/vnd.openxmlformats-officedocument."
            "wordprocessingml.document")
        self.send_header("Content-Length", str(len(docx_bytes)))
        try:
            ascii_name = filename.encode("ascii", "ignore").decode("ascii") or "protokol.docx"
        except Exception:
            ascii_name = "protokol.docx"
        disp = ("attachment; filename=\"%s\"; filename*=UTF-8''%s"
                % (ascii_name, quote(filename)))
        self.send_header("Content-Disposition", disp)
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.end_headers()
        self.wfile.write(docx_bytes)

    def _handle_report_docx(self, body):
        """Vykreslí PLNĚ EDITOVATELNÉ DOCX protokolu (mirror _handle_report_pdf)."""
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            self._send_json(404, {"detail": "Žádná databáze není načtena."})
            return
        data = _parse_json_body(body)
        doc = data.get("doc") or report_store.get_draft(fn, draft_context)
        if not doc:
            self._send_json(
                404, {"detail": "Žádný návrh protokolu k vykreslení. "
                                 "Nejprve vytvořte návrh."})
            return
        try:
            report_store.save_draft(fn, doc, draft_context)
        except Exception:
            pass
        try:
            doc = report_mod.apply_excluded_points(doc)
        except Exception:
            pass
        try:
            docx_bytes = report_docx.render(doc)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self._send_json(500, {"detail": "Chyba při generování DOCX: %s" % e})
            return
        filename = _report_docx_filename(doc)
        self._send_docx(docx_bytes, filename)

    def _handle_report_pdf(self, body):
        """Vykreslí PDF protokol z (editovaného) návrhu nebo z uloženého návrhu.

        Při chybě odešle JSON s detailem. Tělo požadavku může obsahovat
        `doc` (editovaný návrh z frontendu); jinak se použije uložený návrh.
        """
        fn = _db_key()
        draft_context = _report_draft_context()
        if not fn:
            self._send_json(404, {"detail": "Žádná databáze není načtena."})
            return
        data = _parse_json_body(body)
        doc = data.get("doc") or report_store.get_draft(fn, draft_context)
        if not doc:
            self._send_json(
                404, {"detail": "Žádný návrh protokolu k vykreslení. "
                                 "Nejprve vytvořte návrh."})
            return
        # ulož editovanou verzi, ať PDF a uložený návrh sedí
        try:
            report_store.save_draft(fn, doc, draft_context)
        except Exception:
            pass
        # odškrtnuté měřicí body se do PDF nezahrnou ani nehodnotí
        # (uložený návrh výše zůstává kompletní i se zaškrtávátky)
        try:
            doc = report_mod.apply_excluded_points(doc)
        except Exception:
            pass
        try:
            pdf_bytes = report_pdf.render(doc)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self._send_json(500, {"detail": "Chyba při generování PDF: %s" % e})
            return
        filename = _report_pdf_filename(doc)
        self._send_pdf(pdf_bytes, filename)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/ai/prompts/session":
            if (not self._ai_prompt_request_is_allowed()
                    or not hmac.compare_digest(str(self.headers.get("X-HADS-AI-Prompts-Session", "")), "request")):
                self._send_json(403, {"detail": "Zakázáno"}, no_store=True)
                return
            try:
                payload = self._read_prompt_payload()
            except ValueError:
                self._send_json(400, {"detail": "Neplatný požadavek."}, no_store=True)
                return
            if payload.get("purpose") != "ai-prompts":
                self._send_json(400, {"detail": "Neplatný požadavek."}, no_store=True)
                return
            nonce = _AI_PROMPT_NONCES.issue(self.headers.get("Origin"))
            self._send_json(200, {"nonce": nonce, "expires_in": 180}, no_store=True)
            return
        if path == "/api/ai/prompts/preview":
            if not self._ai_prompt_request_is_allowed():
                self._send_json(403, {"detail": "Zakázáno"}, no_store=True)
                return
            try:
                payload = self._read_prompt_payload()
                status, obj = api_handler(
                    path, "POST", body=json.dumps(payload).encode("utf-8"), headers=self.headers)
            except Exception:
                status, obj = 500, {"detail": "Náhled AI promptu nelze připravit."}
            self._send_json(status, obj, no_store=True)
            return
        prompt_reset = re.match(r"^/api/ai/prompts/[a-z0-9_]+/reset$", path)
        if path == "/api/ai/prompts" or prompt_reset:
            if not self._ai_prompt_request_is_allowed():
                self._send_json(403, {"detail": "Zakázáno"}, no_store=True)
                return
            try:
                payload = self._read_prompt_payload()
            except ValueError:
                self._send_json(400, {"detail": "Neplatný požadavek."}, no_store=True)
                return
            if not self._ai_prompt_nonce_is_valid(payload):
                self._send_json(403, {"detail": "Platnost potvrzení vypršela. Načtěte nastavení znovu a akci opakujte."}, no_store=True)
                return
            try:
                status, obj = api_handler(
                    path, "POST", body=json.dumps(payload).encode("utf-8"), headers=self.headers)
            except Exception:
                status, obj = 500, {"detail": "AI prompt nelze bezpečně uložit."}
            self._send_json(status, obj, no_store=True)
            return
        if path == "/api/ai/config/session":
            if (not self._ai_config_request_is_allowed()
                    or not hmac.compare_digest(str(self.headers.get("X-HADS-AI-Config-Session", "")), "request")):
                self._send_json(403, {"detail": "Zakázáno"}, no_store=True)
                return
            try:
                payload = self._read_ui_payload()
            except ValueError:
                self._send_json(400, {"detail": "Neplatný požadavek."}, no_store=True)
                return
            if payload.get("purpose") != "ai-config":
                self._send_json(400, {"detail": "Neplatný požadavek."}, no_store=True)
                return
            nonce = _AI_CONFIG_NONCES.issue(self.headers.get("Origin"))
            self._send_json(200, {"nonce": nonce, "expires_in": 180}, no_store=True)
            return
        if path in ("/api/ai/config", "/api/ai/config/delete"):
            if not self._ai_config_request_is_allowed():
                self._send_json(403, {"detail": "Zakázáno"}, no_store=True)
                return
            try:
                payload = self._read_ui_payload()
            except ValueError:
                self._send_json(400, {"detail": "Neplatný požadavek."}, no_store=True)
                return
            if not self._ai_config_nonce_is_valid(payload):
                self._send_json(403, {"detail": "Platnost potvrzení vypršela. Zkuste akci znovu."}, no_store=True)
                return
            try:
                status, obj = api_handler(path, "POST", body=json.dumps(payload).encode("utf-8"),
                                          headers=self.headers)
            except Exception:
                status, obj = 500, {"detail": "Nastavení AI nelze bezpečně změnit."}
            self._send_json(status, obj, no_store=True)
            return
        if path == "/api/ui/shutdown-session":
            # POST s vlastním hlavičkovým záměrem zajistí Origin i mimo formulářové CSRF.
            if (not self._ui_shutdown_request_is_allowed()
                    or not hmac.compare_digest(str(self.headers.get("X-HADS-UI-Session", "")), "request")):
                self._send_json(403, {"detail": "Zakázáno"})
                return
            try:
                payload = self._read_ui_payload()
            except ValueError:
                self._send_json(400, {"detail": "Neplatný požadavek."})
                return
            if payload.get("purpose") != "shutdown" or not _LIFECYCLE.accepting_work:
                self._send_json(409, {"detail": "Ukončení nyní nelze připravit."})
                return
            nonce = _UI_SHUTDOWN_NONCES.issue(self.headers.get("Origin"))
            self._send_json(200, {"nonce": nonce, "expires_in": 180}, no_store=True)
            return
        if path == "/api/ui/shutdown":
            if not self._ui_shutdown_request_is_allowed():
                self._send_json(403, {"detail": "Zakázáno"})
                return
            try:
                payload = self._read_ui_payload()
            except ValueError:
                self._send_json(400, {"detail": "Neplatný požadavek."})
                return
            nonce = payload.get("nonce")
            if not _UI_SHUTDOWN_NONCES.consume(self.headers.get("Origin"), self.headers.get("X-HADS-UI-Shutdown-Nonce"), nonce):
                self._send_json(403, {"detail": "Platnost potvrzení ukončení vypršela. Zkuste akci znovu."})
                return
            if not _shutdown_can_be_accepted():
                self._send_json(409, {"detail": "Probíhá důležitá operace. Počkejte na její dokončení a ukončení zopakujte."})
                return
            # Odpověď je hotová dřív, než timer může zavřít naslouchající server.
            self._send_json(202, {"accepted": True})
            _schedule_shutdown(0.20)
            return
        if path == "/api/internal/shutdown":
            # Token je pouze v paměti procesu a v lokálním locku pro nativní launcher.
            if not _is_loopback_peer(self.client_address) or not _valid_shutdown_token(self.headers.get("X-HADS-Shutdown-Token")):
                self._send_json(403, {"detail": "Zakázáno"})
                return
            if not _shutdown_can_be_accepted():
                self._send_json(409, {"detail": "Probíhá důležitá operace."})
                return
            self._send_json(202, {"ok": True})
            _schedule_shutdown(0.05)
            return
        if not path.startswith("/api/"):
            self.send_error(404)
            return
        if not _LIFECYCLE.accepting_work:
            self._send_json(503, {"detail": "HADS se právě ukončuje."})
            return
        # Tento endpoint nesmí použít _read_body(): .ndb může mít několik GB
        # a během přenosu se zapisuje po blocích přímo do data/ na stejném
        # souborovém systému jako cílová databáze.
        if path == "/api/updates/install":
            try:
                with _LIFECYCLE.critical():
                    result = shared_updates.stage_and_spawn(DATA_DIR, BASE_DIR, APP_VERSION, _SHARED_UPDATE_PUBLIC_KEY)
                # Odpověď musí dorazit do prohlížeče dřív než se začne autentizované ukončení.
                self._send_json(202, result)
                if _shutdown_can_be_accepted():
                    _schedule_shutdown(0.35)
                else:
                    _lifecycle_log("update_shutdown_deferred")
            except LifecycleBusy as exc:
                self._send_json(409, {"detail": str(exc)})
            except shared_updates.StageBusy as exc:
                self._send_json(409, {"detail": str(exc)})
            except shared_updates.SharedUpdateError as exc:
                self._send_json(400, {"detail": str(exc)})
            except Exception:
                self._send_json(500, {"detail": "Přípravu aktualizace nelze bezpečně dokončit."})
            return
        if path == "/api/databases/update":
            try:
                with _LIFECYCLE.critical():
                    raw_length = self.headers.get("Content-Length")
                    length = int(raw_length) if raw_length else 0
                    status, obj = handle_update_stream(self.rfile, length, self.headers)
                    if status == 202 and obj.get("accepted"):
                        # Reserve graceful shutdown before releasing the
                        # critical section. The helper is already detached; no
                        # second click or request can start meanwhile.
                        _LIFECYCLE.reserve_external_handoff()
            except LifecycleBusy as e:
                status, obj = 409, {"detail": str(e)}
            except UpdateError as e:
                status, obj = 400, {"detail": str(e)}
            except Exception as e:
                status, obj = 500, {"detail": f"Chyba serveru při aktualizaci databáze: {e}"}
            self._send_json(status, obj)
            if status == 202 and obj.get("accepted"):
                # The accepted response is written before the timer begins
                # graceful close. The independent helper waits for exact PID
                # termination and only then touches database files.
                _lifecycle_log("database_external_update_accepted")
                _schedule_shutdown(0.25)
            return
        # binární PDF endpoint (api_handler vrací jen JSON)
        if path == "/api/report/pdf":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self._read_body(length) if length else b""
                with read_locked(_db_operations):
                    self._handle_report_pdf(body)
            except DatabaseBusy as e:
                self._send_json(409, {"detail": str(e)})
            except Exception as e:
                import traceback
                traceback.print_exc()
                try:
                    self._send_json(500, {"detail": f"Chyba serveru: {e}"})
                except Exception:
                    pass
            return
        # binární DOCX endpoint (plně editovatelný Word export)
        if path == "/api/report/docx":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self._read_body(length) if length else b""
                with read_locked(_db_operations):
                    self._handle_report_docx(body)
            except DatabaseBusy as e:
                self._send_json(409, {"detail": str(e)})
            except Exception as e:
                import traceback
                traceback.print_exc()
                try:
                    self._send_json(500, {"detail": f"Chyba serveru: {e}"})
                except Exception:
                    pass
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = self._read_body(length) if length else b""
            status, obj = api_handler(path, "POST", body=body, headers=self.headers)
        except Exception as e:
            import traceback
            traceback.print_exc()
            try:
                status, obj = 500, {"detail": f"Chyba serveru: {e}"}
            except Exception:
                return
        try:
            self._send_json(status, obj)
        except Exception:
            pass


def _validate_data_protection_before_initialization() -> None:
    """Refuse normal startup when a just-updated installation lost protected data.

    The receipt is made by the external updater before it changes program code.
    A damaged installation gets its program rolled back by the same packaged
    updater.  Only absent, independently hash-verified small files may be
    restored automatically; existing divergent files are never overwritten.
    """
    result = data_protection.validate_pending_startup(BASE_DIR)
    if result is None or result.get("ok"):
        return
    updater = BASE_DIR / "tools" / "hads_updater.py"
    python = BASE_DIR / "runtime" / ("python.exe" if os.name == "nt" else "python3")
    executable = str(python) if python.is_file() else sys.executable
    rollback_note = ""
    if updater.is_file():
        try:
            import subprocess
            completed = subprocess.run(
                [executable, str(updater), "--rollback", "--recovery-internal",
                 "--install", str(BASE_DIR)],
                cwd=str(BASE_DIR), text=True, encoding="utf-8", errors="replace",
                capture_output=True, timeout=120, check=False,
            )
            rollback_note = " Automatický rollback programu " + (
                "proběhl." if completed.returncode == 0 else "selhal; spusťte jej ručně."
            )
        except Exception:
            rollback_note = " Automatický rollback se nepodařilo spustit; spusťte jej ručně."
    raise SystemExit(str(result.get("error") or "Kontrola ochrany dat selhala.") + rollback_note)


def main():
    global _SERVER, _TEARDOWN_STARTED
    _TEARDOWN_STARTED = False
    _BACKGROUND_CANCEL.clear()
    _lifecycle_log("server_start")
    _validate_data_protection_before_initialization()
    # Až po porovnání předaktualizačního inventáře se mohou provést historické
    # nedestruktivní migrace root JSONů do per-podnik složek.
    try:
        data_store.migrate_all_legacy()
    except Exception:
        pass
    # A native supervisor marker or a 1.34.3 orphan is converted into a
    # one-time diagnostic before UI startup.  It never modifies customer DB.
    recover_abandoned_database_update(BASE_DIR)
    try:
        port = int(os.environ.get("HADS_PORT", "8000"))
    except ValueError:
        port = 8000
    if not 1 <= port <= 65535:
        raise SystemExit("Neplatný port HADS_PORT")
    server = ThreadingHTTPServer((HOST, port), Handler)
    server.daemon_threads = True
    _SERVER = server
    _write_server_lock(port)
    atexit.register(_remove_server_lock)
    # Kontrola je záměrně asynchronní a čte pouze uživatelem zvolenou lokální/synchronizovanou cestu.
    def _startup_update_check() -> None:
        global _startup_update_badge
        if _BACKGROUND_CANCEL.is_set():
            return
        try:
            settings = shared_updates.load_settings(DATA_DIR)
            if (not _BACKGROUND_CANCEL.is_set()
                    and settings.get("automatic_startup_check") and settings.get("source_path")):
                result = shared_updates.check(DATA_DIR, APP_VERSION, _SHARED_UPDATE_PUBLIC_KEY)
                if not _BACKGROUND_CANCEL.is_set() and result.get("update"):
                    _startup_update_badge = {"version": result["update"]["version"], "message": result["message"]}
        except Exception:
            # Chyba synchronizované složky nesmí brzdit start ani opakovaně rušit uživatele.
            pass
    _start_background(_startup_update_check, "hads-startup-update-check")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
    finally:
        try:
            _cancel_background_work()
            _close_database_resources()
            _lifecycle_log("server_stop")
        finally:
            _remove_server_lock()
            server.server_close()
            _SERVER = None


if __name__ == "__main__":
    main()
