from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


SHARED = load("shell_permissions_shared_updates", ROOT / "backend" / "shared_updates.py")
BUILD = load("shell_permissions_build_release", ROOT / "tools" / "build_release.py")


class ShellPermissionTests(unittest.TestCase):
    def test_zip_tree_stores_every_shell_script_as_755(self):
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / "source"
            source.mkdir()
            script = source / "start.sh"
            script.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
            script.chmod(0o644)
            archive_path = Path(temporary) / "release.zip"

            BUILD.zip_tree(source, archive_path, prefix="release")

            with zipfile.ZipFile(archive_path) as archive:
                info = archive.getinfo("release/start.sh")
                self.assertEqual((info.external_attr >> 16) & 0o777, 0o755)
            self.assertEqual(script.stat().st_mode & 0o777, 0o644)

    def test_safe_extraction_restores_shell_script_as_755(self):
        with tempfile.TemporaryDirectory() as temporary:
            temporary_path = Path(temporary)
            package = temporary_path / "HADS_Update_9.9.9.zip"
            version_bytes = b'APP_VERSION = "9.9.9"\n'
            manifest = {
                "product": "HADS",
                "version": "9.9.9",
                "minimum_version": "1.0.0",
                "preserve": ["data/**", "runtime/**"],
                "release_notes": "test",
                "files": [{
                    "path": "backend/version.py",
                    "size": len(version_bytes),
                    "sha256": hashlib.sha256(version_bytes).hexdigest(),
                }],
            }
            with zipfile.ZipFile(package, "w") as archive:
                archive.writestr("HADS_Update_9.9.9/manifest.json", json.dumps(manifest))
                archive.writestr("HADS_Update_9.9.9/hads_updater.py", "# test\n")
                archive.writestr("HADS_Update_9.9.9/aktualizovat_hads.sh", "#!/bin/sh\nexit 0\n")
                archive.writestr("HADS_Update_9.9.9/payload/backend/version.py", version_bytes)

            root = SHARED._safe_extract_update(package, temporary_path / "staging", "9.9.9")

            self.assertEqual((root / "aktualizovat_hads.sh").stat().st_mode & 0o777, 0o755)


if __name__ == "__main__":
    unittest.main()
