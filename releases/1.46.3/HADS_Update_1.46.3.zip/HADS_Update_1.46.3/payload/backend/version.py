"""Jednotné místo pro číslo verze aplikace HADS – Heistech AI Diagnostic Software."""

APP_VERSION = "1.46.3"
