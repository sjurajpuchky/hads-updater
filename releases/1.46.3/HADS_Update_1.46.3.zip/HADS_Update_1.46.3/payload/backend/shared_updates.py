"""Ověřování, stažení a staging aktualizací HADS z oficiálního HTTPS endpointu.

Modul používá pouze standardní knihovnu. Podpis je RSASSA-PKCS1-v1_5/SHA-256
nad kanonickým UTF-8 JSONem; veřejný klíč je součástí programu, soukromý klíč
se nikdy nehledá ani neukládá v instalaci.
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import zipfile
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen

PRODUCT = "HADS"
RELEASE_URL = "https://updater.heistech.cz/release.json"
SETTINGS_NAME = "shared_updates.json"
NOTES_NAME = "shared_update_notes.json"
# Staging ani poznámky vydání nejsou uživatelská data.  Musí proto ležet mimo
# data/: inventář aktualizace tak může garantovat, že payload ani updater pod
# data/ nezapisují.
STAGE_ROOT = "updates/shared-staging"
MAX_METADATA_BYTES = 256 * 1024
MAX_PACKAGE_BYTES = 4 * 1024 * 1024 * 1024
MAX_ZIP_MEMBERS = 10000
MAX_EXTRACTED_BYTES = 4 * 1024 * 1024 * 1024
_NOTE_GROUPS = ("new", "improved", "fixed", "security", "important")
_SHA256_DIGESTINFO = bytes.fromhex("3031300d060960864801650304020105000420")
_stage_lock = threading.Lock()


class SharedUpdateError(RuntimeError):
    """Chyba bezpečné aktualizace vhodná pro české uživatelské rozhraní."""


class StageBusy(SharedUpdateError):
    pass


def version_tuple(value: str) -> tuple[int, int, int]:
    if not isinstance(value, str):
        raise SharedUpdateError("Číslo verze musí být text ve tvaru X.Y.Z.")
    parts = value.split(".")
    if len(parts) != 3 or any(not p or not p.isascii() or not p.isdecimal() or (len(p) > 1 and p[0] == "0") for p in parts):
        raise SharedUpdateError(f"Neplatné číslo verze: {value!r}.")
    result = tuple(int(p) for p in parts)
    if any(n > 999999 for n in result):
        raise SharedUpdateError(f"Neplatné číslo verze: {value!r}.")
    return result  # type: ignore[return-value]


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    try:
        os.chmod(temporary, 0o600)
    except OSError:
        pass
    os.replace(temporary, path)


def _settings_path(data_dir: Path) -> Path:
    return data_dir / SETTINGS_NAME


def _notes_path(data_dir: Path) -> Path:
    """Vrátí místo pro důvěryhodné poznámky mimo chráněná uživatelská data."""
    return data_dir.parent / "updates" / NOTES_NAME


def _staging_root(data_dir: Path) -> Path:
    """Vrátí staging mimo celou nahrazovanou instalaci HADS."""
    installation = data_dir.parent.resolve()
    identity = hashlib.sha256(os.path.normcase(str(installation)).encode("utf-8")).hexdigest()[:20]
    candidate = Path(tempfile.gettempdir()).resolve() / "HADS-updates" / identity
    if _is_inside(candidate, installation):
        candidate = installation.parent / (".HADS-updates-" + identity)
    return candidate


def load_settings(data_dir: Path) -> dict[str, Any]:
    path = _settings_path(data_dir)
    default = {"format": 2, "automatic_startup_check": True, "automatic_install_on_restart": False, "last_check": None, "last_status": "Nezkontrolováno."}
    if not path.exists():
        return default
    if path.is_symlink():
        return default
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return default
    if not isinstance(value, dict):
        return default
    default.update({k: value[k] for k in default if k in value and isinstance(value[k], type(default[k]))})
    default["format"] = 2
    if value.get("last_check") is None:
        default["last_check"] = None
    return default


def save_settings(data_dir: Path, automatic_startup_check: bool | None = None, automatic_install_on_restart: bool | None = None) -> dict[str, Any]:
    settings = load_settings(data_dir)
    if automatic_startup_check is not None:
        if not isinstance(automatic_startup_check, bool):
            raise SharedUpdateError("Volba kontroly po spuštění musí být ano/ne.")
        settings["automatic_startup_check"] = automatic_startup_check
    if automatic_install_on_restart is not None:
        if not isinstance(automatic_install_on_restart, bool):
            raise SharedUpdateError("Volba automatické instalace musí být ano/ne.")
        settings["automatic_install_on_restart"] = automatic_install_on_restart
    _atomic_json(_settings_path(data_dir), settings)
    return settings


def _mark_check(data_dir: Path, message: str) -> None:
    settings = load_settings(data_dir)
    settings["last_check"] = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    settings["last_status"] = message[:500]
    _atomic_json(_settings_path(data_dir), settings)


def _read_limited_json(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise SharedUpdateError(f"{label} není bezpečný běžný soubor.")
    if path.stat().st_size > MAX_METADATA_BYTES:
        raise SharedUpdateError(f"{label} je příliš velký.")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SharedUpdateError(f"Nelze načíst {label}: {exc}") from exc
    if not isinstance(data, dict):
        raise SharedUpdateError(f"{label} musí být JSON objekt.")
    return data


def _der_length(raw: bytes, offset: int) -> tuple[int, int]:
    if offset >= len(raw):
        raise ValueError("DER length")
    first = raw[offset]; offset += 1
    if first < 128:
        return first, offset
    count = first & 0x7f
    if not 1 <= count <= 4 or offset + count > len(raw):
        raise ValueError("DER length")
    length = int.from_bytes(raw[offset:offset + count], "big")
    return length, offset + count


def _der_item(raw: bytes, offset: int, tag: int) -> tuple[bytes, int]:
    if offset >= len(raw) or raw[offset] != tag:
        raise ValueError("DER tag")
    size, start = _der_length(raw, offset + 1)
    end = start + size
    if end > len(raw):
        raise ValueError("DER size")
    return raw[start:end], end


def _rsa_public_key(pem_path: Path) -> tuple[int, int]:
    text = pem_path.read_text(encoding="ascii")
    lines = [line.strip() for line in text.splitlines() if "---" not in line]
    der = base64.b64decode("".join(lines), validate=True)
    outer, end = _der_item(der, 0, 0x30)
    if end != len(der):
        raise SharedUpdateError("Veřejný podpisový klíč má neplatný formát.")
    _, pos = _der_item(outer, 0, 0x30)  # AlgorithmIdentifier
    bits, pos = _der_item(outer, pos, 0x03)
    if pos != len(outer) or not bits or bits[0] != 0:
        raise SharedUpdateError("Veřejný podpisový klíč má neplatný formát.")
    rsa, end2 = _der_item(bits[1:], 0, 0x30)
    if end2 != len(bits) - 1:
        raise SharedUpdateError("Veřejný podpisový klíč má neplatný formát.")
    modulus, pos = _der_item(rsa, 0, 0x02)
    exponent, pos = _der_item(rsa, pos, 0x02)
    if pos != len(rsa):
        raise SharedUpdateError("Veřejný podpisový klíč má neplatný formát.")
    n, e = int.from_bytes(modulus, "big"), int.from_bytes(exponent, "big")
    if n.bit_length() < 2048 or e < 3 or e % 2 == 0:
        raise SharedUpdateError("Veřejný podpisový klíč nesplňuje bezpečnostní parametry.")
    return n, e


def verify_detached_signature_bytes(metadata: dict[str, Any], signature_text: bytes, public_key: Path) -> None:
    try:
        signature = base64.b64decode(signature_text.strip(), validate=True)
        n, e = _rsa_public_key(public_key)
    except (OSError, ValueError, UnicodeDecodeError) as exc:
        raise SharedUpdateError("Oddělený podpis nebo veřejný klíč není platný.") from exc
    size = (n.bit_length() + 7) // 8
    if len(signature) != size:
        raise SharedUpdateError("Oddělený podpis má nesprávnou délku.")
    expected = _SHA256_DIGESTINFO + hashlib.sha256(canonical_json(metadata)).digest()
    encoded = pow(int.from_bytes(signature, "big"), e, n).to_bytes(size, "big")
    if len(encoded) < len(expected) + 11 or not encoded.startswith(b"\x00\x01"):
        raise SharedUpdateError("Oddělený podpis release.json neověřen.")
    separator = encoded.find(b"\x00", 2)
    if separator < 10 or encoded[2:separator] != b"\xff" * (separator - 2) or encoded[separator + 1:] != expected:
        raise SharedUpdateError("Oddělený podpis release.json neověřen.")


def verify_detached_signature(metadata: dict[str, Any], signature_path: Path, public_key: Path) -> None:
    if not signature_path.is_file() or signature_path.is_symlink():
        raise SharedUpdateError("Chybí bezpečný oddělený podpis release.json.")
    verify_detached_signature_bytes(metadata, signature_path.read_bytes(), public_key)


def _valid_text(value: Any, label: str, maximum: int, minimum: int = 1) -> str:
    if not isinstance(value, str) or not minimum <= len(value.strip()) <= maximum or "\x00" in value:
        raise SharedUpdateError(f"release.json má neplatnou položku {label}.")
    return value.strip()


def _safe_package_name(value: Any) -> str:
    name = _valid_text(value, "package_filename", 180)
    p = PurePosixPath(name)
    if p.name != name or name in {".", ".."} or any(x in name for x in ("/", "\\", ":")) or not name.lower().endswith(".zip"):
        raise SharedUpdateError("release.json obsahuje nepovolený název balíčku.")
    return name


def validate_release(metadata: dict[str, Any], folder_version: str) -> dict[str, Any]:
    required = {"product", "version", "release_date", "package_filename", "byte_size", "sha256", "minimum_version", "mandatory", "title", "summary", "release_notes"}
    if set(metadata) != required:
        raise SharedUpdateError("release.json nemá přesně očekávané položky.")
    if metadata["product"] != PRODUCT:
        raise SharedUpdateError("Vydání není určeno pro HADS.")
    version = _valid_text(metadata["version"], "version", 32)
    if version != folder_version or version_tuple(version) != version_tuple(folder_version):
        raise SharedUpdateError("Verze release.json neodpovídá složce vydání.")
    try:
        dt.date.fromisoformat(_valid_text(metadata["release_date"], "release_date", 10, 10))
    except ValueError as exc:
        raise SharedUpdateError("release_date musí být datum RRRR-MM-DD.") from exc
    package = _safe_package_name(metadata["package_filename"])
    byte_size = metadata["byte_size"]
    digest = metadata["sha256"]
    if not isinstance(byte_size, int) or isinstance(byte_size, bool) or not 1 <= byte_size <= MAX_PACKAGE_BYTES:
        raise SharedUpdateError("release.json má neplatnou byte_size.")
    if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise SharedUpdateError("release.json má neplatný SHA-256.")
    minimum = _valid_text(metadata["minimum_version"], "minimum_version", 32)
    version_tuple(minimum)
    if not isinstance(metadata["mandatory"], bool):
        raise SharedUpdateError("release.json má neplatnou mandatory.")
    title = _valid_text(metadata["title"], "title", 140)
    summary = _valid_text(metadata["summary"], "summary", 2000)
    notes = metadata["release_notes"]
    if not isinstance(notes, dict) or set(notes) != set(_NOTE_GROUPS):
        raise SharedUpdateError("release_notes musí obsahovat všech pět kategorií.")
    clean_notes: dict[str, list[str]] = {}
    for group in _NOTE_GROUPS:
        entries = notes[group]
        if not isinstance(entries, list) or len(entries) > 40:
            raise SharedUpdateError(f"release_notes.{group} není platný seznam.")
        clean_notes[group] = [_valid_text(entry, f"release_notes.{group}", 500) for entry in entries]
    return {**metadata, "version": version, "package_filename": package, "sha256": digest.lower(), "minimum_version": minimum, "title": title, "summary": summary, "release_notes": clean_notes}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _is_inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (ValueError, OSError):
        return False


def _candidate(folder: Path, installed_version: str, public_key: Path, verify_package: bool = True) -> dict[str, Any] | None:
    if not folder.is_dir() or folder.is_symlink():
        return None
    try:
        folder_version = folder.name
        version_tuple(folder_version)
    except SharedUpdateError:
        return None
    try:
        metadata = _read_limited_json(folder / "release.json", "release.json")
        verify_detached_signature(metadata, folder / "release.json.sig", public_key)
        release = validate_release(metadata, folder_version)
        package = folder / release["package_filename"]
        if not _is_inside(package, folder) or not package.is_file() or package.is_symlink():
            raise SharedUpdateError("Aktualizační balíček není bezpečně uvnitř své složky vydání.")
        if package.stat().st_size != release["byte_size"]:
            raise SharedUpdateError("Velikost aktualizačního balíčku nesouhlasí s release.json.")
        if verify_package and sha256_file(package) != release["sha256"]:
            raise SharedUpdateError("SHA-256 aktualizačního balíčku nesouhlasí s release.json.")
        release["folder"] = str(folder)
        release["package_path"] = str(package)
        if version_tuple(release["version"]) <= version_tuple(installed_version):
            return None
        if version_tuple(installed_version) < version_tuple(release["minimum_version"]):
            return None
        return release
    except SharedUpdateError:
        return None


def _release_endpoint_parts() -> tuple[str, str, str]:
    parsed = urlsplit(RELEASE_URL)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise SharedUpdateError("Adresa aktualizační služby není bezpečný HTTPS endpoint.")
    return parsed.scheme, parsed.netloc, f"{parsed.scheme}://{parsed.netloc}"


def _validate_response_url(response: Any) -> None:
    scheme, netloc, _ = _release_endpoint_parts()
    final = urlsplit(response.geturl())
    if final.scheme != scheme or final.netloc != netloc:
        raise SharedUpdateError("Aktualizační služba přesměrovala požadavek mimo důvěryhodný HTTPS server.")


def _download_bytes(url: str, maximum: int, label: str) -> bytes:
    request = Request(url, headers={"Accept": "application/json", "User-Agent": "HADS-Updater/1"})
    try:
        with urlopen(request, timeout=20) as response:
            _validate_response_url(response)
            length = response.headers.get("Content-Length")
            if length is not None and (not length.isdecimal() or int(length) > maximum):
                raise SharedUpdateError(f"{label} je příliš velký.")
            raw = response.read(maximum + 1)
    except SharedUpdateError:
        raise
    except (HTTPError, URLError, TimeoutError, OSError) as exc:
        raise SharedUpdateError(f"Aktualizační služba není dostupná: {exc}") from exc
    if len(raw) > maximum:
        raise SharedUpdateError(f"{label} je příliš velký.")
    return raw


def _release_urls(release: dict[str, Any]) -> tuple[str, str]:
    _, _, origin = _release_endpoint_parts()
    version = quote(release["version"], safe="")
    package = quote(release["package_filename"], safe="")
    return f"{origin}/release.json.sig", f"{origin}/release-files/{version}/{package}"


def fetch_release(installed_version: str, public_key: Path) -> dict[str, Any] | None:
    version_tuple(installed_version)
    raw = _download_bytes(RELEASE_URL, MAX_METADATA_BYTES, "release.json")
    try:
        metadata = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SharedUpdateError(f"release.json není platný JSON: {exc}") from exc
    if not isinstance(metadata, dict):
        raise SharedUpdateError("release.json musí být JSON objekt.")
    release = validate_release(metadata, str(metadata.get("version", "")))
    signature_url, package_url = _release_urls(release)
    signature = _download_bytes(signature_url, 16 * 1024, "Podpis release.json")
    verify_detached_signature_bytes(metadata, signature, public_key)
    if version_tuple(release["version"]) <= version_tuple(installed_version):
        return None
    if version_tuple(installed_version) < version_tuple(release["minimum_version"]):
        return None
    return {**release, "release_url": RELEASE_URL, "package_url": package_url}


def status(data_dir: Path, installed_version: str, public_key: Path) -> dict[str, Any]:
    settings = load_settings(data_dir)
    out = {"current_version": installed_version, "release_url": RELEASE_URL, "automatic_startup_check": settings["automatic_startup_check"], "automatic_install_on_restart": settings["automatic_install_on_restart"], "last_check": settings["last_check"], "last_status": settings["last_status"], "update": None}
    return out


def check(data_dir: Path, installed_version: str, public_key: Path) -> dict[str, Any]:
    try:
        item = fetch_release(installed_version, public_key)
        message = f"Nalezena aktualizace {item['version']}." if item else "Nainstalovaná verze je aktuální."
        _mark_check(data_dir, message)
        return {**status(data_dir, installed_version, public_key), "update": item, "message": message}
    except SharedUpdateError as exc:
        _mark_check(data_dir, str(exc))
        raise


def _validate_extracted_update(root: Path, expected_version: str) -> None:
    """Před spuštěním updateru ověří přesný manifest/payload; updater to zopakuje."""
    manifest = _read_limited_json(root / "manifest.json", "manifest aktualizačního balíčku")
    required = {"product", "version", "minimum_version", "files", "preserve", "release_notes"}
    if not required.issubset(manifest) or manifest.get("product") != PRODUCT or manifest.get("version") != expected_version:
        raise SharedUpdateError("Interní manifest aktualizačního balíčku neodpovídá vydání.")
    version_tuple(manifest["version"]); version_tuple(manifest["minimum_version"])
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise SharedUpdateError("Interní manifest neobsahuje seznam payloadu.")
    payload = root / "payload"
    if not payload.is_dir() or payload.is_symlink():
        raise SharedUpdateError("Aktualizační payload není bezpečná složka.")
    actual: set[str] = set(); declared: set[str] = set()
    for file in payload.rglob("*"):
        if file.is_symlink():
            raise SharedUpdateError("Aktualizační payload obsahuje symbolický odkaz.")
        if file.is_file(): actual.add(file.relative_to(payload).as_posix())
    allowed = {"backend", "frontend", "tests", "assets", "launcher", "tools", "README.md", "README_AKTUALIZACE.txt", "spustit.bat", "spustit.sh", "HADS.exe"}
    for row in files:
        if not isinstance(row, dict): raise SharedUpdateError("Interní manifest obsahuje neplatnou položku.")
        name = row.get("path")
        try: rel = PurePosixPath(name)
        except TypeError as exc: raise SharedUpdateError("Interní manifest obsahuje neplatnou cestu.") from exc
        if not isinstance(name, str) or rel.is_absolute() or ".." in rel.parts or not rel.parts or rel.parts[0] not in allowed or name in declared:
            raise SharedUpdateError("Interní manifest obsahuje nepovolenou nebo duplicitní cestu.")
        path = payload / rel
        digest = row.get("sha256"); size = row.get("size")
        if not path.is_file() or path.is_symlink() or not isinstance(size, int) or size < 0 or not isinstance(digest, str) or len(digest) != 64:
            raise SharedUpdateError("Interní manifest má neplatný soubor payloadu.")
        if path.stat().st_size != size or sha256_file(path) != digest.lower():
            raise SharedUpdateError("Payload neodpovídá internímu manifestu.")
        declared.add(name)
    if actual != declared:
        raise SharedUpdateError("Payload přesně neodpovídá internímu manifestu.")


def _safe_extract_update(package: Path, target: Path, expected_version: str) -> Path:
    with zipfile.ZipFile(package) as archive:
        infos = archive.infolist()
        if len(infos) > MAX_ZIP_MEMBERS:
            raise SharedUpdateError("Aktualizační ZIP obsahuje příliš mnoho položek.")
        total = 0
        for info in infos:
            p = PurePosixPath(info.filename)
            if not info.filename or p.is_absolute() or ".." in p.parts or "\\" in info.filename or info.file_size < 0:
                raise SharedUpdateError("Aktualizační ZIP obsahuje nebezpečnou cestu.")
            mode = (info.external_attr >> 16) & 0o170000
            if mode == 0o120000:
                raise SharedUpdateError("Aktualizační ZIP nesmí obsahovat symbolické odkazy.")
            total += info.file_size
            if total > MAX_EXTRACTED_BYTES:
                raise SharedUpdateError("Aktualizační ZIP je po rozbalení příliš velký.")
        for info in infos:
            destination = target / PurePosixPath(info.filename)
            if not _is_inside(destination, target):
                raise SharedUpdateError("Aktualizační ZIP míří mimo staging.")
            if info.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as source, destination.open("xb") as output:
                shutil.copyfileobj(source, output, 1024 * 1024)
            if destination.suffix.lower() == ".sh":
                destination.chmod(0o755)
    root = target / f"HADS_Update_{expected_version}"
    if not root.is_dir() or root.is_symlink() or not (root / "manifest.json").is_file() or not (root / "hads_updater.py").is_file():
        raise SharedUpdateError("Aktualizační ZIP nemá očekávaný bezpečný kořen a updater.")
    top = {PurePosixPath(info.filename).parts[0] for info in infos if info.filename}
    if top != {root.name}:
        raise SharedUpdateError("Aktualizační ZIP musí mít jediný kořen odpovídající verzi.")
    _validate_extracted_update(root, expected_version)
    return root


def cleanup_abandoned_staging(data_dir: Path, older_than_seconds: int = 7 * 86400) -> int:
    root = _staging_root(data_dir)
    if not root.is_dir() or root.is_symlink():
        return 0
    removed = 0
    cutoff = time.time() - older_than_seconds
    for item in root.iterdir():
        try:
            if item.is_dir() and not item.is_symlink() and item.name.startswith("shared-") and item.stat().st_mtime < cutoff:
                shutil.rmtree(item)
                removed += 1
        except OSError:
            continue
    return removed


def _copy_verified(source: Path, destination: Path, expected_size: int, expected_hash: str) -> None:
    before = source.stat()
    if before.st_size != expected_size:
        raise SharedUpdateError("Balíček se před kopírováním změnil.")
    digest = hashlib.sha256(); written = 0
    with source.open("rb") as origin, destination.open("xb") as staged:
        while True:
            block = origin.read(1024 * 1024)
            if not block:
                break
            written += len(block); digest.update(block); staged.write(block)
    after = source.stat()
    if written != expected_size or digest.hexdigest() != expected_hash or after.st_size != before.st_size or after.st_mtime_ns != before.st_mtime_ns:
        raise SharedUpdateError("Balíček se během kopírování změnil nebo neprošel ověřením.")
    if destination.stat().st_size != expected_size or sha256_file(destination) != expected_hash:
        raise SharedUpdateError("Staged balíček neprošel opakovaným ověřením.")


def _download_verified(url: str, destination: Path, expected_size: int, expected_hash: str) -> None:
    request = Request(url, headers={"Accept": "application/zip", "User-Agent": "HADS-Updater/1"})
    digest = hashlib.sha256(); written = 0
    try:
        with urlopen(request, timeout=60) as response, destination.open("xb") as staged:
            _validate_response_url(response)
            length = response.headers.get("Content-Length")
            if length is not None and (not length.isdecimal() or int(length) != expected_size):
                raise SharedUpdateError("Velikost balíčku na serveru nesouhlasí s release.json.")
            while True:
                block = response.read(1024 * 1024)
                if not block: break
                written += len(block)
                if written > expected_size:
                    raise SharedUpdateError("Stažený balíček je větší než uvádí release.json.")
                digest.update(block); staged.write(block)
    except SharedUpdateError:
        destination.unlink(missing_ok=True); raise
    except (HTTPError, URLError, TimeoutError, OSError) as exc:
        destination.unlink(missing_ok=True)
        raise SharedUpdateError(f"Aktualizační balíček nelze stáhnout: {exc}") from exc
    if written != expected_size or digest.hexdigest() != expected_hash:
        destination.unlink(missing_ok=True)
        raise SharedUpdateError("Stažený balíček neprošel kontrolou velikosti a SHA-256.")


def stage_and_spawn(data_dir: Path, installation: Path, installed_version: str, public_key: Path, runner=None) -> dict[str, Any]:
    if not _stage_lock.acquire(blocking=False):
        raise StageBusy("Příprava aktualizace již probíhá. Vyčkejte na její dokončení.")
    try:
        release = fetch_release(installed_version, public_key)
        if release is None:
            raise SharedUpdateError("Není dostupná kompatibilní novější aktualizace.")
        root = _staging_root(data_dir)
        root.mkdir(mode=0o700, parents=True, exist_ok=True)
        if root.is_symlink() or not root.is_dir() or _is_inside(root, installation):
            raise SharedUpdateError("Staging aktualizace musí být bezpečná složka mimo instalaci HADS.")
        stage = root / ("shared-" + uuid.uuid4().hex)
        stage.mkdir(mode=0o700)
        try:
            metadata_raw = _download_bytes(RELEASE_URL, MAX_METADATA_BYTES, "release.json")
            try:
                copied_metadata = json.loads(metadata_raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise SharedUpdateError(f"release.json není platný JSON: {exc}") from exc
            signature_url, _ = _release_urls(release)
            signature_raw = _download_bytes(signature_url, 16 * 1024, "Podpis release.json")
            verify_detached_signature_bytes(copied_metadata, signature_raw, public_key)
            validate_release(copied_metadata, release["version"])
            (stage / "release.json").write_bytes(metadata_raw)
            (stage / "release.json.sig").write_bytes(signature_raw)
            package = stage / release["package_filename"]
            _download_verified(release["package_url"], package, release["byte_size"], release["sha256"])
            update_root = _safe_extract_update(package, stage / "extracted", release["version"])
            notes = {"format": 1, "version": release["version"], "title": release["title"], "summary": release["summary"], "release_date": release["release_date"], "release_notes": release["release_notes"], "trusted_sha256": hashlib.sha256(canonical_json(copied_metadata)).hexdigest(), "shown_version": ""}
            notes_path = stage / "trusted_release_notes.json"
            _atomic_json(notes_path, notes)
            python = installation / "runtime" / ("python.exe" if os.name == "nt" else "python3")
            executable = str(python) if python.is_file() else sys.executable
            command = [executable, str(update_root / "hads_updater.py"), "--install", str(installation), "--wait-pid", str(os.getpid()), "--restart", "--trusted-release-notes", str(notes_path)]
            launch = runner or subprocess.Popen
            try:
                launch(command, cwd=str(stage), close_fds=(os.name != "nt"))
            except OSError as exc:
                raise SharedUpdateError(f"Nelze spustit externí aktualizátor: {exc}") from exc
            return {"accepted": True, "status": "Aktualizace byla ověřena a připravena. Aplikace se nyní bezpečně restartuje.", "version": release["version"], "stage": str(stage), "command": command}
        except Exception:
            shutil.rmtree(stage, ignore_errors=True)
            raise
    finally:
        _stage_lock.release()


def save_post_update_notes(data_dir: Path, notes_path: str, version: str) -> None:
    candidate = Path(notes_path)
    record = _read_limited_json(candidate, "důvěryhodné poznámky k vydání")
    if record.get("version") != version or not isinstance(record.get("release_notes"), dict):
        raise SharedUpdateError("Důvěryhodné poznámky neodpovídají nainstalované verzi.")
    _atomic_json(_notes_path(data_dir), record)


def post_update_notes(data_dir: Path, installed_version: str, mark_shown: bool = False) -> dict[str, Any] | None:
    # 1.36.2 ukládala poznámky do data/. Jen pro čtení jej podporujeme, aby
    # uživatel po aktualizaci o oznámení nepřišel. Nové zápisy vždy míří mimo
    # data/ a uživatelský obsah se jimi nemění.
    path = _notes_path(data_dir)
    legacy_path = data_dir / NOTES_NAME
    if not path.exists() and legacy_path.exists() and not legacy_path.is_symlink():
        path = legacy_path
    if not path.exists() or path.is_symlink():
        return None
    try:
        record = _read_limited_json(path, "poznámky k vydání")
        if record.get("version") != installed_version or not isinstance(record.get("release_notes"), dict):
            return None
        for group in _NOTE_GROUPS:
            if not isinstance(record["release_notes"].get(group), list):
                return None
        record["unseen"] = record.get("shown_version") != installed_version
        if mark_shown and record["unseen"]:
            record["shown_version"] = installed_version
            _atomic_json(path, record)
            record["unseen"] = False
        return record
    except SharedUpdateError:
        return None
